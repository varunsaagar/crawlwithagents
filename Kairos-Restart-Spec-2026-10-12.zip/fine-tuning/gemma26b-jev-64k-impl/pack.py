"""Reference native Jev decision head + packer (Kairos 26B port reference).

Follows avbiswas/bev-train (commit a58c551): each option is a separate span that
starts at the SAME position id, options cannot attend to each other, the answer
slot sees all options, a small position-free attention block over option reps,
then a bilinear readout einsum(answer_proj, choice_proj)/sqrt(d), masked_fill(-inf).
Head runs in fp32 with autocast disabled ("bf16 logits are too coarse for a stable loss").
Noul = 2 options ["No","Yes"]; Score = ordinal levels written as "i: level".
Extension over bev-train (which explodes one question per row): several questions
about one state are PACKED in one sequence; the state is encoded once.
"""
import math, torch, torch.nn as nn, torch.nn.functional as F

TASK = {"choice": 0, "noul": 1, "score": 2}

# ---------------- head ----------------
class _Block(nn.Module):
    def __init__(s, h, d):
        super().__init__(); s.n1 = nn.LayerNorm(h); s.q = nn.Linear(h, d); s.k = nn.Linear(h, d)
        s.v = nn.Linear(h, h); s.n2 = nn.LayerNorm(h); s.ff = nn.Sequential(nn.Linear(h, 2*h), nn.GELU(), nn.Linear(2*h, h)); s.d = d
    def forward(s, x, m):
        y = s.n1(x); a = torch.einsum("bqd,bkd->bqk", s.q(y), s.k(y)) / math.sqrt(s.d)
        a = a.masked_fill(~m[:, None, :], float("-inf")).softmax(-1)
        x = x + torch.einsum("bqk,bkd->bqd", a, s.v(y))
        return x + s.ff(s.n2(x))

class JevHead(nn.Module):
    """Permutation-equivariant over options; no positions inside the head."""
    def __init__(s, hidden, d=64, layers=1, n_types=3):
        super().__init__(); s.d = d
        s.task = nn.Embedding(n_types, hidden); s.inorm = nn.LayerNorm(hidden)
        s.blocks = nn.ModuleList(_Block(hidden, d) for _ in range(layers)); s.fnorm = nn.LayerNorm(hidden)
        s.a_proj = nn.Linear(hidden, d); s.c_proj = nn.Linear(hidden, d)
        s.log_temp = nn.Parameter(torch.zeros(n_types), requires_grad=False)  # fitted post-hoc per type
        s.float()  # fp32 head always
    def forward(s, choices, answer, choice_mask, task):
        with torch.autocast(device_type=choices.device.type, enabled=False):
            choices, answer = choices.float(), answer.float()
            B = choices.shape[0]; one = torch.ones(B, 1, dtype=torch.bool, device=choices.device)
            x = s.inorm(torch.cat([s.task(task)[:, None], choices, answer[:, None]], 1))
            m = torch.cat([one, choice_mask, one], 1)
            for b in s.blocks: x = b(x, m)
            x = s.fnorm(x)
            logits = torch.einsum("bd,bcd->bc", s.a_proj(x[:, -1]), s.c_proj(x[:, 1:-1])) / math.sqrt(s.d)
            return logits.masked_fill(~choice_mask, float("-inf"))
    def log_probs(s, logits, task):
        return F.log_softmax(logits / s.log_temp.exp()[task][:, None], -1)

def options_for(q):
    if q["type"] == "noul": return ["No", "Yes"]
    if q["type"] == "score": return [f"{i}: {l}" for i, l in enumerate(q["levels"])]
    return list(q["options"])

# ---------------- packer ----------------
def pack(state_ids, questions, tok, max_len=65536):
    """questions: list of dict(type, q_ids, options:[ids...]).
    Layout: [state][q1 text][q1 opt1]..[q1 optK][q1 ans] [q2 text]...
    Positions: state 0..S-1; every question block restarts at S (blocks are mutually
    invisible, so packed == separate). Options of a question all start at the same pos.
    Returns dict with ids, pos, allowed[L,L] bool, read idx, answer idx, truncated."""
    ids, pos, seg = list(state_ids), list(range(len(state_ids))), []
    S = len(state_ids); spans = []
    ANS = tok["ANS"]
    for qi, q in enumerate(questions):
        b = len(ids); qa = list(q["q_ids"])
        ids += qa; pos += list(range(S, S + len(qa))); p0 = S + len(qa)
        opt_spans = []
        for o in q["options"]:
            st = len(ids); ids += o; pos += list(range(p0, p0 + len(o))); opt_spans.append((st, len(ids)))
        mx = max(e - s for s, e in opt_spans)
        a = len(ids); ids.append(ANS); pos.append(p0 + mx)
        spans.append(dict(begin=b, q_end=b + len(qa), opts=opt_spans, ans=a, type=q["type"]))
    L = len(ids); truncated = max(0, L - max_len)
    if truncated: raise ValueError(f"pack exceeds max_len by {truncated} tokens (truncated must be 0)")
    allowed = torch.zeros(L, L, dtype=torch.bool)
    allowed[:S, :S] = torch.tril(torch.ones(S, S, dtype=torch.bool))
    for sp in spans:
        b, qe = sp["begin"], sp["q_end"]
        allowed[b:qe, :S] = True; allowed[b:qe, b:qe] = torch.tril(torch.ones(qe-b, qe-b, dtype=torch.bool))
        for s, e in sp["opts"]:
            allowed[s:e, :qe] = False; allowed[s:e, :S] = True; allowed[s:e, b:qe] = True
            allowed[s:e, s:e] = torch.tril(torch.ones(e-s, e-s, dtype=torch.bool))
        a = sp["ans"]; allowed[a, :S] = True; allowed[a, b:a+1] = True
    return dict(ids=torch.tensor(ids), pos=torch.tensor(pos), allowed=allowed, spans=spans, truncated=truncated)

def readout(hidden, packed, kmax=None):
    """hidden [L,H] -> per question (choices [C,H], answer [H]) padded to batch."""
    sp = packed["spans"]; K = kmax or max(len(s["opts"]) for s in sp); H = hidden.shape[-1]
    C = hidden.new_zeros(len(sp), K, H); A = hidden.new_zeros(len(sp), H); M = torch.zeros(len(sp), K, dtype=torch.bool)
    for i, s in enumerate(sp):
        for j, (_, e) in enumerate(s["opts"]): C[i, j] = hidden[e - 1]; M[i, j] = True
        A[i] = hidden[s["ans"]]
    T = torch.tensor([TASK[s["type"]] for s in sp])
    return C, A, M, T

# ---------------- tiny backbone (stands in for Gemma4TextModel) ----------------
class TinyBackbone(nn.Module):
    """Pre-norm transformer with explicit boolean attention mask + rotary positions.
    `linear_cls` lets the trainer swap in a ZeRO-3-style sharded linear."""
    def __init__(s, vocab=128, h=64, layers=2, heads=4, linear_cls=nn.Linear, lora_r=4):
        super().__init__(); s.h, s.nh = h, heads
        s.emb = nn.Embedding(vocab, h)
        s.layers = nn.ModuleList()
        for _ in range(layers):
            s.layers.append(nn.ModuleDict(dict(n1=nn.LayerNorm(h), qkv=LoRALinear(linear_cls(h, 3*h), lora_r),
                o=LoRALinear(linear_cls(h, h), lora_r), n2=nn.LayerNorm(h), up=linear_cls(h, 4*h), down=linear_cls(4*h, h))))
        s.norm = nn.LayerNorm(h); s.gc = False
    def _rope(s, x, pos):
        d = x.shape[-1] // 2; f = 1.0 / (10000 ** (torch.arange(d, device=x.device) / d))
        a = pos[:, None].float() * f[None]; c, si = a.cos(), a.sin()
        x1, x2 = x[..., :d], x[..., d:]; return torch.cat([x1*c - x2*si, x1*si + x2*c], -1)
    def _layer(s, l, x, pos, allowed):
        L = x.shape[0]; hd = s.h // s.nh
        q, k, v = l["qkv"](l["n1"](x)).view(L, 3, s.nh, hd).unbind(1)
        q, k = s._rope(q.transpose(0, 1), pos), s._rope(k.transpose(0, 1), pos)
        o = F.scaled_dot_product_attention(q, k, v.transpose(0, 1), attn_mask=allowed)
        x = x + l["o"](o.transpose(0, 1).reshape(L, s.h))
        return x + l["down"](F.gelu(l["up"](l["n2"](x))))
    def forward(s, ids, pos, allowed):
        x = s.emb(ids)
        for l in s.layers:
            if s.gc and s.training:
                x = torch.utils.checkpoint.checkpoint(s._layer, l, x, pos, allowed, use_reentrant=False)
            else: x = s._layer(l, x, pos, allowed)
        return s.norm(x)

class LoRALinear(nn.Module):
    def __init__(s, base, r):
        super().__init__(); s.base = base
        s.lora_A = nn.Parameter(torch.randn(r, base.in_features) * 0.01); s.lora_B = nn.Parameter(torch.zeros(base.out_features, r))
    def forward(s, x): return s.base(x) + x @ s.lora_A.t() @ s.lora_B.t()

def freeze_for_lora(backbone):
    """Mirror of the 26B policy: base (incl. MoE experts) frozen; LoRA on attention/dense trainable."""
    for n, p in backbone.named_parameters(): p.requires_grad = "lora_" in n

class JevNet(nn.Module):
    def __init__(s, backbone, hidden):
        super().__init__(); s.backbone = backbone; s.head = JevHead(hidden)
    def forward(s, packed):
        h = s.backbone(packed["ids"], packed["pos"], packed["allowed"])
        C, A, M, T = readout(h.float(), packed)
        return s.head(C, A, M, T), T
