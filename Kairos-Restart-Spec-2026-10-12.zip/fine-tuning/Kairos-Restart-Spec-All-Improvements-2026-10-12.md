# Kairos Jev restart spec: all improvements (pplx, RLCD, vegaml, run log, long context)
2026-10-12. Target: Gemma-4-26B-A4B (E4B for gating). Code: `gemma26b-jev-64k-impl/` (new: `restart_utils.py`, `tests/test_restart.py`). References: `refs/pplx-decider-src/`, `refs/vegaml/`.
GPU-hour figures are estimates, not measurements. Nothing here has run on Gemma or a GPU.

## 0. vegaml: what it is and what transfers
Repo `NandhaKishorM/vegaml`, Apache-2.0 (`LICENSE`; README "Licence: Apache 2.0").

**Architecture** (README "How it works")
- The LLM backbone (Qwen3.5-0.8B or 4B) is **frozen** and read at two intermediate layers. The LM head never runs.
- The prompt is `Observation: {state} Measurement ({type}): {instructions} Possible outcomes: * {opt} … Outcome:`.
- Spans are pooled: situation, question, each option and the final token.
- A 14.3M/30.9M-parameter "physics engine" places a particle in a 64-d space. Each option is a Gaussian well, and P = softmax(−E/τ).
- **τ is predicted per decision** from residual kinetic energy, distance to the nearest well, steps used and log(#options).
- Conformal sets, an abstain flag and an "unbound" flag come with each answer.

**Long context** (README "73,728-token context"; `_common.py:359-403`)
- Read-once prefix cache for states of 4,096+ tokens.
- A "memory reader" cuts long states into 16 pieces (`chunk_tokens=128`, min 2), mean-pools them at the deepest layer, and feeds them to the engine.
- Over-long input is refused, never truncated.
- Blockwise causal attention keeps memory bounded on a T4 (`_common.py:245`).

**"Learning update"**
- (a) **TTT** (`vegaml/ttt.py`): a PCA-128 plus multinomial logistic head on frozen features, fitted per label set from ≥6 examples. It is 5-fold stratified-CV gated and **discarded unless it beats chance** (README; `ttt.py:91-142`).
- (b) **Gated rank-32 adapter** (`notebooks/vega_finetune.py`): AdamW lr 3e-4, OneCycle, 3 epochs, CE (`:266-281`).
  - The adapter has a sigmoid gate trained with **negatives from another task (ag_news) so it learns when not to fire** (`:283-297`, gate_weight 0.5).
  - Calibration and conformal thresholds are refitted on a validation split training never saw.
- **Training method** (README): a counterfactual objective that pairs items sharing an answer space, plus a one-step world-dynamics auxiliary.
- No EMA or curriculum is visible in the code I read.

**Measured numbers** (`bench/RESULTS.md`, run of 2026-10-11, 2×T4)
- **The notebook `vega_benchmark_2xT4.ipynb` has 41 cells and 0 saved outputs**, so these numbers come from RESULTS.md and the README, not from notebook output.
- Public menu, 43 tasks: Vega 4B 0.717 accuracy vs Jev 0.836. ECE 0.148 vs 0.115. NLL **0.768** vs 0.878.
- JevBench: 0.662 vs 0.866 (hard tier 0.513 vs 0.730). Paraphrase consistency 0.722 vs 0.972.
- DecisionBench: 0.633 vs 0.752, but NLL 1.420 vs 3.196.
- **Backbone baselines:** Qwen3.5-4B *generate* scores 0.700 public and 0.634 DecisionBench, while *logprob of option text* scores 0.303 and 0.342. README: "the engine's contribution on this menu is coverage, probabilities and latency rather than raw accuracy."

**What applies to Kairos Jev**
1. **Scoring option text by likelihood collapses accuracy** (0.30 vs 0.70 generate on the same backbone). Reading the *answer-code token*, as pplx does, is the one that matches generation. This supports gating test G1 and warns against span-pooled readouts initialised from nothing.
2. A frozen backbone plus a small head tops out near the prompted backbone (Vega 4B ≈ base-4b generate). **Fine-tuning the backbone (pplx, full FT) is what moved past Jev**, so keep LoRA or full FT and don't freeze.
3. Adopt now: per-decision temperature features (log #options, length bucket) in calibration, a TTT-style CV gate ("don't serve a head that doesn't beat chance or the step-0 floor"), and abstain/unbound flags.
4. Adopt later: gate negatives (out-of-task rows labelled "abstain/escalate") for the router, and the 16-piece memory reader as a long-context *auxiliary feature* (Stage B option).
5. Paraphrase consistency is the 4B's biggest gap (0.72 vs 0.97). Add a paraphrase-group metric to monitoring.

## (a) STOP checklist (current run)
1. Wait for the next eval/save boundary, or SIGTERM after `save(last/)` has been fixed. Confirm `last/` is about 240 MB and reloads, using `reference/score_single.py`.
2. Save: `last/`, `best/`, `log.jsonl`, stdout/stderr per rank, the DeepSpeed config, the resolved run YAML, git SHA/diff of `train.py`, the data manifest (row counts per source, type and length bucket), tokenizer revision, and the seed.
3. Save per-item predictions on the 200 comparison items and the 1,552 eval states (`item_id, type, source, n_options, len_bucket, logits`).
4. Record: step reached, LR at stop, and the last 3 dev evals per regime. Do **not** delete the run dir.

## (b) Gating experiments (≤ ~3 GPU-h total, E4B, same 200 item_ids)
| ID | Experiment | Cost | Decision rule |
|---|---|---|---|
| G0 | Prompted E4B (generate) + prompted E2B rerun with the current harness | ~0.3 h | Sets the **floor F** = max(prompted E4B, 0.500). |
| G1 | **Step-0 code-readout**: letter-coded prompt, `CodeReadoutHead` from Gemma unembedding rows, no training | ~0.2 h | If acc ≥ F−0.03: **adopt the code-readout head** (the gap was the head). If < 0.40, check the prompt and template; if still low, keep the bilinear head with G4. |
| G2 | Causal vs noncausal global layers, 300 steps each at 8k, from G1 | ~1.2 h | Adopt noncausal if it gains ≥ +2 pts on the 200 items with no type dropping more than 3. |
| G3 | Packed vs unpacked, 300 steps each | ~1.0 h | Unpack if unpacked gains ≥ +2 pts **or** the Noul P(yes) spread (p90−p10) is ≥ 0.2 larger. Otherwise keep packing (it's faster). |
| G4 (only if G1 fails) | Bilinear head with LoRA frozen for 100 steps (head warmup) | ~0.3 h | Must reach ≥ F at step 100, or stop and debug the pooling/packing indices. |

## (c) Restart config
```yaml
run: kairos-jev-26b-restart-A
model: {base: google/gemma-4-26b-a4b, dtype: bf16, attn: flex_attention, grad_ckpt: true}
head:
  type: code_readout            # G1; fallback: bilinear  (pplx model.py:248-250)
  init: lm_unembedding_rows     # restart_utils.select_answer_codes + CodeReadoutHead, single-token-after-prefix check
  dtype: fp32
  max_options: 255              # fails loudly if Gemma has <255 single-token codes
  pooling: last
  prompt: "State/Question/Options(A: …)/Return only the letter code"  # pplx model.py:95-113
attention: {global_layers: noncausal, local_layers: causal}   # only if G2 passes
packing: {enabled: false, validate_equal_separate: true}      # per G3
trainable: {lora: {r: 32, alpha: 32, targets: [attn, dense_mlp], experts: frozen}, head: true}
optim:
  lr_lora: 5.0e-5               # low end for LoRA; full-FT equivalent would be pplx's 2e-6
  lr_head: 1.0e-5               # the head is already a good init: do not blow it up
  warmup_ratio: 0.05
  schedule: cosine_floor_0.1    # pplx train.py:143-147
  weight_decay: 0.01
  grad_clip: 1.0
  epochs: 1
  effective_batch: 256          # rows, as in pplx
loss:                           # kairos_loss.py flags
  label_smoothing: 0.05
  brier_w: 0.5
  kl_w: 0.02                    # cached base logits; 0 for Stage A first 10% steps if G1 init used
  ordinal_eps: 0.1
  soft_targets: teacher_or_human_where_available
data:
  splits: family                # restart_utils.family_split; dev 5% / temperature 5%
  decontaminate_vs: [eval_1552, items_200]   # NearDuplicates 0.85 + exact
  drop_conflicts: true
  noul_balance: per_source_50_50
  option_shuffle: per_epoch
  contrastive_pairs: {sources: [voice, otel_safety, churn], share: 0.15}
  quotas: {short_jev: 0.45, long_jev: 0.25, public_mix: 0.15, pairs: 0.15}  # cap open_clinc ≤ 5%
  pretokenised_cache: mmap      # mmap_cache.py
  length: {stageA: 8192, stageB: [32768, 65536]}
eval:
  step0: true                   # floor logged before step 1
  every: 50
  dev: hard_family_dev          # long, many-option, Noul; no open_clinc-only
  temperature_fold: true
  select: [-acc, brier]         # after per-eval temperature fit (pplx evaluate.py:282)
  compare_ids: items_200        # paired, identical item_ids
dist: {zero_stage: 3, eval_all_ranks: true, save_last_unconditional: true, safe_teardown: true}
stage2: {enabled: false}
```
**Code patches** (in order)
1. `restart_utils.py` (new, tested): `select_answer_codes`, `CodeReadoutHead`, `shuffle_options`/`epoch_iter`, `NoulBalancedSampler`, `NearDuplicates`, `family_split`, `drop_conflicts`, `decontaminate`.
2. `train.py`: build the prompt with letter codes, take the last hidden, apply `CodeReadoutHead`, then `kairos_loss` (`kairos_loss.py`).
3. `train.py`: noncausal mask on the global layers (adapt pplx `enable_noncausal_full_attention`, `model.py:30-58`, to a flex_attention `mask_mod` returning true for valid keys on global layers).
4. ZeRO-3 control flow from `reference/PATCH.md`.
5. Calibration: `calibrate.py`, per type × length bucket, adding log(#options) as a temperature feature (vega).

## (d) Staged plan
| Stage | What | Go/no-go | Est. GPU-h |
|---|---|---|---|
| A | 8k, fixed recipe, 1 epoch | **Go to B only if** native 26B ≥ prompted 26B − 0.05 on the 200 items (paired), never below the step-0 floor, and every type ≥ its step-0 | 60–100 |
| B | 32k then 64k: null-chunk rows (no evidence → abstain/No), query sandwich, hard-distractor ramp 0→40%, depth-varied evidence, replay 30% of 8k rows | 64k bucket within 5 pts of 8k on in-domain sources; else serve chunked map-reduce with the 0.80 floor above 16k | 150–250 |
| C | Temperature per type × length (+ log K), LTT thresholds, abstain/escalate | Certified coverage > 0 at ε on held-out; fail closed | 2–5 |
| D (opt.) | Stage-2 selective REINFORCE (reward correct-above-threshold, penalise wrong, small escalate cost) | Only if AUROC is weak after C | 20–40 |

## (e) Monitoring (log every eval)
- **Loss per regime** (short, long, Noul, Choice ≤26, Choice >26, Score). **Never report a pooled loss on the bimodal mix** (report lesson).
- Accuracy per type, source and length bucket, against the **step-0 floor**. Alarm if any falls more than 3 pts below it.
- Noul: P(yes) p10/p50/p90 and the true-rate per source. **Alarm if p90−p10 < 0.2** (constant-predictor pathology).
- Dev variance across the last 5 evals > 0 (defect 7). Hard-batch fraction per step.
- Paraphrase-group consistency (vega). ECE/Brier after the per-eval temperature.
- Paired 200-item accuracy vs prompted 26B, on identical item_ids (`eval_compare.py`).

## (f) Prioritised improvements
| # | Improvement | Source | Impact | Effort | In restart? |
|---|---|---|---|---|---|
| 1 | LM-prior code-readout head + letter prompt + single-token check | pplx | Very high (likely explains 0.215 vs 0.500) | 1–2 d | Yes (G1-gated) |
| 2 | Step-0 eval and floor alarm; paired same-ids comparison | log | High (detects regressions) | hrs | Yes |
| 3 | Low LR, 1 epoch, clip 1.0, cosine floor | pplx | High | config | Yes |
| 4 | Hard family dev + temperature fold; select acc then Brier | pplx, log (defect 7) | High | 1 d | Yes |
| 5 | Noul 50/50 per source + P(yes) spread alarm | log, pplx | High for Noul | hrs | Yes |
| 6 | Noncausal global layers | pplx | Med–high | 2–4 d | If G2 |
| 7 | Unpacked (or validated) packing | pplx | Medium | 1 d | Per G3 |
| 8 | Decontaminate, family split, conflict drop | pplx | Medium (trustworthy eval) | hrs | Yes |
| 9 | Smoothed CE + Brier + small KL, ordinal Score, soft targets | RLCD/Clef, pplx | Medium (calibration) | done | Yes |
| 10 | Contrastive minimal pairs | pplx, vega (counterfactual objective) | Medium | 2–3 d + teacher | Yes (15%) |
| 11 | Public multitask mix, cap open_clinc, replay | pplx | Medium | 1–2 d | Yes |
| 12 | Per-option shuffle per epoch | pplx | Low–medium (needed once head #1 is order-sensitive) | done | Yes |
| 13 | ZeRO-3 control-flow fixes, unconditional last/, safe teardown, mmap cache | log | Run survival | done | Yes |
| 14 | Null-chunk training, query sandwich, distractor ramp, per-length calibration, chunked fallback | long-ctx plan | High for 64k | Stage B | Stage B |
| 15 | Per-decision temperature features (log K, length) + abstain/unbound | vega | Calibration | hrs | Stage C |
| 16 | TTT-style CV-gated per-customer heads; gated adapters with out-of-task negatives | vega | Product, not base accuracy | 2–3 d | Later |
| 17 | 16-piece memory-reader feature for long states | vega | Unknown | 2 d | Stage B ablation only |
| 18 | Stage-2 RL | OpenJev-RLCD | Low–medium | 3–5 d | Stage D, optional |

## Uncertain
- Whether Gemma-4's tokenizer has 255 single-token codes after its chat prefix. `select_answer_codes` will raise if not; fall back to fewer codes plus the bilinear head for K > available codes.
- Whether Gemma-4 applies final-logit softcapping (set `CodeReadoutHead.softcap` from config).
- Interaction of the noncausal mask with Gemma's local sliding-window layers: only the global layers are changed.
- The LoRA LR (5e-5) is a judgement call; pplx's 2e-6 is for full FT. Sweep {2e-5, 5e-5, 1e-4} in G2 if time allows.
- vegaml numbers come from its RESULTS.md, not reproduced here; the notebook has no outputs.
