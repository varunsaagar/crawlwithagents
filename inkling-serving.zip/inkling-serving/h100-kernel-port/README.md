# h100-kernel-port

Hopper (H100) path for Inkling 2 Mini's NVFP4/MXFP8 MoE experts. Start with `design.md`.

```bash
pip install torch triton pytest
# CPU (interpreter) tests: what has actually been run so far
TRITON_INTERPRET=1 python3 -m pytest -q tests          # 14 passed on CPU
INKLING_SHAPES=1 python3 -m pytest -q tests            # on an H100: real shapes (never run)
python3 bench/bench_moe.py --json bench.json           # on an H100 (never run)
cd autokernel && TRITON_INTERPRET=1 python3 loop.py --dry-run 3
```

Nothing here has run on a GPU. See `design.md` section 11 for status and assumptions.
