# Reward hack 1: skip the kernel, call torch matmul (KernelBench pattern). Must be rejected by G1.
import torch, triton
@triton.jit
def unused(): pass
def fused_moe_wq(x, topk_ids, topk_w, w13, w2, fmt13, fmt2, softcap=None):
    return torch.matmul(x.float(), torch.zeros(x.shape[1], x.shape[1])).bfloat16()
