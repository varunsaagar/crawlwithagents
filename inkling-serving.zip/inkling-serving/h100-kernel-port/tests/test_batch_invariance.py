"""A token's output must be bit-identical whether it runs alone or inside a batch of N."""
import hashlib, pytest, torch
from _common import make_layer, make_tokens
from kernels.moe_wq_gemm_triton import fused_moe_wq


def row_hash(t):
    return hashlib.sha256(t.contiguous().view(torch.int16).cpu().numpy().tobytes()).hexdigest()[:16]


@pytest.mark.parametrize("N", [2, 7, 33])
def test_batch1_vs_batchN_bitwise(N):
    w13, w2 = make_layer("nvfp4", "nvfp4")
    xb, idb, wb = make_tokens(N, seed=5)
    full = fused_moe_wq(xb, idb, wb, w13, w2)
    for t in sorted({0, N // 2, N - 1}):
        solo = fused_moe_wq(xb[t:t + 1], idb[t:t + 1], wb[t:t + 1], w13, w2)
        assert row_hash(solo[0]) == row_hash(full[t]), f"token {t} differs at batch {N}"


def test_order_invariance_bitwise():
    """Shuffling the batch must not change any row's bits (stable align, no atomics)."""
    w13, w2 = make_layer("nvfp4", "nvfp4")
    x, ids, w = make_tokens(12, seed=9)
    perm = torch.randperm(12, generator=torch.Generator().manual_seed(0)).to(x.device)
    a = fused_moe_wq(x, ids, w, w13, w2)
    b = fused_moe_wq(x[perm], ids[perm], w[perm], w13, w2)
    assert torch.equal(a[perm].view(torch.int16), b.view(torch.int16))


def test_negative_control_hash_detects_reduction_order_change():
    """Broken twin: the same dot product summed in a different K-chunk order must (almost
    surely) change some bits. If this ever passes trivially, the hash test is blind."""
    g = torch.Generator().manual_seed(3)
    a = torch.randn(64, 1152, generator=g)
    b = torch.randn(1152, 256, generator=g)
    fixed = sum((a[:, i:i + 64] @ b[i:i + 64]) for i in range(0, 1152, 64))
    swapped = sum((a[:, i:i + 64] @ b[i:i + 64]) for i in reversed(range(0, 1152, 64)))
    assert row_hash(fixed.bfloat16()) != row_hash(swapped.bfloat16()) or \
        not torch.equal(fixed, swapped)
