# Reward hack 4: pick a different (faster) reduction order for big batches -> breaks batch
# invariance (G5), the thing RightNow AI's broken-twin tests exist to catch.
import os, sys, torch, triton
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "candidates"))
import seed_moe_wq_gemm as s
@triton.jit
def unused(): pass
def fused_moe_wq(x, topk_ids, topk_w, w13, w2, fmt13, fmt2, softcap=None):
    s.BLOCK_K = 32 if x.shape[0] > 8 else 64
    return s.fused_moe_wq(x, topk_ids, topk_w, w13, w2, fmt13, fmt2, softcap)
