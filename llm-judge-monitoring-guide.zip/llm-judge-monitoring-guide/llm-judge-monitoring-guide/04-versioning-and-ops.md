# 04 — Versioning and operations

Cross-links: [Architecture](01-architecture.md) · [Build plan](02-build-plan.md) · [Implementation](03-implementation-guide.md) · [Metrics](05-metrics-and-drift.md) · [Templates](07-templates.md)

If it can change a score or a user-visible answer, it has a version. Silent edits are incidents.

---

## Version fields

| Field | Applies to | Format | Example |
|-------|------------|--------|---------|
| `prompt_version` | Search rewrite, reply, tool policy prompts | `name@MAJOR.MINOR.PATCH` | `voice_reply@3.2.1` |
| `judge_version` | Judge system+user prompt bundle | `metric@MAJOR.MINOR.PATCH` | `faithfulness@1.4.0` |
| `rubric_version` | Human-readable scoring rules | `metric-rubric@MAJOR.MINOR.PATCH` | `faithfulness-rubric@1.2.0` |
| `gold_set_version` | Labelled dataset manifest | `gold@MAJOR.MINOR.PATCH` | `gold@0.3.0` |
| `model_version` / `model_id` | Generator weights + decoding profile | registry id + date/tag | `llama-3.1-70b-instruct@2026-08-01` |
| `judge_model_id` | Model behind the judge | same | `gpt-4.1-mini@2026-04-01` |
| `schema_version` | Trace JSON shape | `session_trace.vN` | `session_trace.v1` |

**Semver meaning (practical):**

- **MAJOR:** behaviour or label polarity change; invalidates prior κ; requires new baseline.
- **MINOR:** additive rubric clarification or prompt hardening; re-run calibration.
- **PATCH:** typo, logging, non-semantic.

`judge_version` and `rubric_version` often bump together; they are still separate fields so you can change wording without changing the contract (or vice versa — rare, deliberate).

---

## Immutable artifacts

```text
s3://eval-artifacts/
  prompts/voice_reply/3.2.1/prompt.txt
  prompts/voice_reply/3.2.1/MANIFEST.json
  judges/faithfulness/1.4.0/judge.json
  rubrics/faithfulness-rubric/1.2.0/rubric.md
  gold/gold/0.3.0/gold.csv
  gold/gold/0.3.0/MANIFEST.json
  baselines/faithfulness/1.4.0/on_gold-0.3.0.json
```

`MANIFEST.json` sketch:

```json
{
  "artifact": "prompt",
  "name": "voice_reply",
  "version": "3.2.1",
  "git_sha": "abcdef0",
  "created_at": "2026-09-10T12:00:00Z",
  "created_by": "varun",
  "changelog": "Tighten refund refusal language.",
  "dependencies": {
    "rubric_version": null,
    "gold_set_version_for_ci": "gold@0.3.0"
  },
  "content_sha256": "..."
}
```

Rules:

1. Never overwrite an existing version prefix.
2. Live config points to versions by reference, not by mutable “latest” file (except a pointer object you update atomically).
3. Langfuse prompt management is fine **if** you also export immutable copies to object store / git tags.

---

## Changelog

Keep `CHANGELOG.md` per artifact family (prompts, judges, rubrics, gold).

```markdown
## faithfulness@1.4.0 — 2026-09-10
### Changed
- Require explicit citation of doc_id for financial claims.
### Calibration
- κ vs gold@0.3.0: report after run (do not invent).
### Migration
- Shadow 48h before canary.
```

---

## Promotion: shadow → canary → full

Aligned with Netflix-style LLM-as-judge lifecycle discipline: evaluate judges/rubrics offline, shadow online, then promote — **humans approve rubric changes before live scoring**.

```mermaid
stateDiagram-v2
  [*] --> Shadow
  Shadow --> Canary: gates pass
  Canary --> Full: gates pass + owner sign-off
  Canary --> Shadow: regression
  Full --> Canary: partial rollback
  Full --> Shadow: hard rollback
  Shadow --> [*]: abandon
```

### Shadow

- New `prompt_version` or `judge_version` runs on mirrored traffic or async replay.
- Scores written to a **shadow** namespace / Langfuse tag `shadow:true`.
- Alerts muted; dashboards compare shadow vs control on same `session_id`s.

**Exit:** CI green on pinned gold; shadow metrics not worse than ε; no judge exceptions storm.

### Canary

- 5–20% of live sessions use new prompt **or** 25–50% sample rate on sessions already on canary prompt.
- Alerts enabled on `canary.*` only.
- HITL spot-check N sessions/day.

**Exit:** κ (if judge change) ≥ floor; bias-adjusted quality metrics within band; cost within band; human approve if rubric touched.

### Full

- Pointer update: `live.prompt_version = ...`
- Keep previous version warm for instant rollback.
- Post-promotion watch window (e.g. 24–72h).

---

## Rollback

| Scenario | Action | Time target |
|----------|--------|-------------|
| Bad reply prompt | Repoint `prompt_version` to last good; clear canary flag | ≤15 min |
| Bad judge | Stop scoring with new `judge_version`; repoint; mute `judge.*` pages if calibration-broken | ≤15 min |
| Bad rubric | Revert pointer; **do not** edit old rubric file | ≤15 min |
| Model registry issue | Pin previous `model_id` in orchestrator | ≤15 min |

Rollback is a **config change**, not a git revert of history. Leave bad artifacts immutable for autopsy.

---

## Netflix-style: human approve rubric changes before live

Rubrics define the meaning of “good”. Automated PRs may draft rubric text; **production scoring must not switch `rubric_version` without an explicit human approval** (CODEOWNERS + checkbox in promotion ticket).

Checklist before approving a rubric:

- [ ] Polarity clear (what does pass=1 mean?)
- [ ] Examples of pass and fail attached
- [ ] Gold labels updated or waiver documented
- [ ] κ plan: re-label or re-score schedule
- [ ] Alert thresholds reviewed (raw rates will jump)

This mirrors the lifecycle emphasis in Netflix’s LLM-as-a-Judge writing and arXiv 2608.18300 — see [06-references.md](06-references.md).

---

## Runbooks

### Runbook: judge drift

**Symptoms:** Judge score-rate jumps; gold replay with frozen sessions also jumps; κ down; system human labels stable.

**Steps:**

1. Confirm `judge_version` / `judge_model_id` / temperature / provider.
2. Replay frozen gold through current and previous judge; diff disagreement set.
3. If judge-side confirmed: rollback judge pointer; open `judge.drift` incident.
4. Do **not** change production reply prompts to “fix” the graph.
5. Recalibrate Se/Sp before re-enabling prevalence alerts.

### Runbook: system drift

**Symptoms:** Human / HITL failure rate up; input or retrieval distributions shift (Phoenix/Evidently); judge κ stable on gold.

**Steps:**

1. Slice by `prompt_version`, `model_id`, `search_backend_id`, locale, ASR band.
2. Check retrieval hit-rate and empty-retrieval rate.
3. Check ASR confidence distribution (voice-specific).
4. Canary rollback of latest prompt/model if coincident.
5. Page product only after judge health verified on gold.

### Runbook: cost spike

**Symptoms:** Judge $/1k sessions or token volume > budget.

**Steps:**

1. Check sampling rate config and high-risk fraction (did taxonomy suddenly mark everything high-risk?).
2. Check retries / timeouts / provider failover loops.
3. Engage kill-switch: drop random sample to 1%; keep 100% high-risk if safety-critical.
4. Inspect avg transcript length and retrieved_doc count (context bloat).

### Runbook: false safety flood

**Symptoms:** Safety fail alerts; on-call flooded; product unconvinced.

**Steps:**

1. Immediately run safety judge on frozen gold + known-safe fixtures.
2. If Se/Sp broken → treat as **judge drift**; mute `system.safety` pages; fix judge.
3. If judge healthy → sample fails for human review within 1h; slice by prompt/model.
4. Consider temporary force-escalate behaviour only with product approval — not a silent prompt hack.

---

## On-call hygiene

- Every alert links to one runbook.
- After incident: classify `system` | `judge` | `ops` | `unknown` in the ticket (forces taxonomy).
- Weekly: review promotion log and any skipped human rubric approvals (process breach).

---

## Next

What to plot and what never to publish: [05-metrics-and-drift.md](05-metrics-and-drift.md).
