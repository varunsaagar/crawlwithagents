# Packing, token budgets and chunking

The packer (`jevjudge.packing`) turns a `Session` into the `state` text that a backend reads.

## Views

Each criterion names the view it needs. Criteria that share a view and a chunk plan share one request.

| View | Content | Use for |
|---|---|---|
| `agent_only` | numbered AGENT utterances only | agent behaviour, where user hostility or user-disclosed data must not leak in (toxicity) |
| `dialogue` | CUSTOMER / AGENT lines in order | PII, sexism, anything that depends on who said what first |
| `grounded` | dialogue plus inline `TOOL name(args) -> result` lines before the agent reply that used them | hallucination, action completion |

Every state starts with the `header` from `packing.yaml`, which tells the model that the transcript is data. Role labels come from `roles` (`CUSTOMER`, `AGENT`, `SYSTEM`, `TOOL`). Lines look like `[T3] AGENT: …`.

```python
from jevjudge import Session
from jevjudge.packing.views import PackOptions, pack

s = Session.from_turns("s1", [{"speaker": "user", "text": "Why is my bill $90?"},
                              {"speaker": "agent", "text": "It includes a $10 late fee.",
                               "tool_calls": [{"name": "get_bill", "arguments": "{}", "result": "{\"late_fee\": 10}"}]}])
print(pack(s, "grounded", PackOptions(max_tokens=2000, tokenizer="tiktoken:cl100k_base")))
```

## Token budgets

Budgets are in **tokens of the backend's own tokenizer**, the unit the model actually limits. The budget for a backend is `min(backend.max_state_tokens, grader.max_state_tokens)`. `max_state_tokens` comes from `models.yaml`, and the grader default is 30000.

Tokenizer specs (`jevjudge.text.get_counter`):

| Spec | Library | Notes |
|---|---|---|
| `hf:<repo>` | Hugging Face `tokenizers` | exact for the backbone (e.g. granite-embedding for kairos-jev) |
| `tiktoken:<encoding>` | `tiktoken` | good proxy for LLMs; the default (`cl100k_base`) |
| `chars:<ratio>` | none | `len(text) / ratio`; never fails (`chars:1` = a character limit, used for djev) |

If a spec fails to load (offline, gated repo), `hf:` falls back to `tiktoken:cl100k_base`, and anything else falls back to `chars:3.2`. A warning is logged once, and judging never stops on tokenizer I/O.

With `strategy: none`, an over-budget state is shrunk in two steps:

1. Tool results shrink through `tool_result_max_tokens` (`[500, 250, 100, 40]`).
2. Middle lines are elided with an explicit `…[N lines elided for length]…` marker. Head and tail are kept.

Single utterances are clipped at `turn_max_tokens` (400) and tool arguments at `tool_args_max_tokens` (60).

## Chunking

Elision throws evidence away. Chunking keeps it: the conversation is split into several small states, each one is judged, and the answers are aggregated per criterion. Decision models are most accurate when the verdict can be read off a short state. Small Kairos encoders have 8k-token windows, while real voice sessions run 5k–20k tokens, mostly tool JSON. Kairos requests are cheap, so one request per chunk is affordable.

Set chunking per criterion with `Criterion.chunking`:

```yaml
chunking:
  strategy: window          # none | window | units   ("claims" is an alias for units)
  max_tokens: 3000          # per-chunk cap (default: the backend budget)
  aggregate: max            # max | noisy_or | mean | last | first
  max_chunks: 16
  # window
  overlap_turns: 1
  carry: none               # none | user ("customer" is an alias) | opening
  carry_max_tokens: 400
  # units
  unit_roles: [agent]
  unit_min_tokens: 4
  select: evidence          # evidence | all
  evidence_k: 3
  evidence_max_tokens: 250
  unit_label: UNIT
  evidence_label: "EVIDENCE (tool results available at that point)"
  segmenter: null           # default: packing.yaml segmenter (pysbd:en)
  retriever: null           # default: packing.yaml retriever (bm25:en)
```

### `strategy: window`

The conversation is split into consecutive turn windows that fit the budget, labelled `(part i, turns a–b)`. Each window shares `overlap_turns` turns with its neighbour. A single line too large for a window is split with LangChain's `RecursiveCharacterTextSplitter`, using token length. `carry: user` prefixes every chunk with the earlier CUSTOMER lines, which preserves who disclosed what. `carry: opening` prefixes the first turns instead. If the whole conversation fits, you get one chunk.

### `strategy: units`

This strategy makes one state per sentence unit. Sentences come from pysbd, taken from the turns of `unit_roles`. Each unit is paired with the top-`evidence_k` evidence passages, ranked by BM25 (`bm25s`, scikit-learn English stop-words). Only tool results available up to that turn are eligible. Tool results are split into `evidence_max_tokens` passages, so retrieval returns the relevant part of a large JSON payload. `select: evidence` checks first the units that best match some evidence. `select: all` takes units in order. If no units are found, the strategy falls back to one `agent_only` state.

### Aggregation

For a Noul, aggregation runs on **P(positive label)**, so polarity is respected:

| `aggregate` | P over chunks | Typical use |
|---|---|---|
| `max` | maximum | "did it happen anywhere" (violations) |
| `noisy_or` | `1 − Π(1 − p)` | many weak signals |
| `mean` | average | |
| `last` | last chunk | "by the end of the call" (action completed) |
| `first` | first chunk | opening behaviour |

For Choice and Score questions, `last` and `first` pick that chunk's answer; the other modes average the distributions. The merged `Answer.chunks` records how many chunks were aggregated. Each chunk is one request, so `report.calls` grows accordingly.

`ChunkSpec.key` identifies the chunk *plan*. Criteria that differ only in `aggregate` share the same chunks and requests.

```python
from jevjudge.packing.chunking import ChunkSpec, chunk, aggregate_p
from jevjudge.packing.views import PackOptions

states = chunk(s, "grounded", ChunkSpec(strategy="window", max_tokens=300), PackOptions(tokenizer="tiktoken:cl100k_base"))
print(len(states), aggregate_p([0.5, 0.5], "noisy_or"))    # n, 0.75
```

The `voice_decomposed` preset uses windowed chunking for action completion: `{strategy: window, carry: opening, aggregate: last, overlap_turns: 2}` on the verdict and `aggregate: max` on most detail questions.

## Segmenter and retriever specs

| Setting | Specs |
|---|---|
| `segmenter` | `pysbd:<lang>` (default `pysbd:en`), `lines`, `none` |
| `retriever` | `bm25:<stopwords>` (default `bm25:en`), `bm25:none` |
