"""Microbenchmark (GPU only). Measures latency and effective weight-stream bandwidth of the
Triton kernel vs a dequantise-then-bmm BF16 baseline at Inkling 2 Mini expert shapes.
Add vLLM's Humming path as the real baseline once you are on the target vLLM build
(its Python API moves; see vllm/models/inkling2/nvidia/ops/moe_sm90.py).

Usage on an H100:  python bench/bench_moe.py --tokens 1 8 32 128 512
Nothing here has been run on a GPU yet; no numbers are recorded in this repo.
"""
import argparse, os, sys, json, torch
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT); sys.path.insert(0, os.path.join(ROOT, "tests"))
os.environ.setdefault("INKLING_SHAPES", "1")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--tokens", type=int, nargs="+", default=[1, 8, 32, 128, 512])
    ap.add_argument("--iters", type=int, default=50)
    ap.add_argument("--json", default="")
    args = ap.parse_args()
    assert torch.cuda.is_available(), "GPU benchmark; run on an H100"
    from _common import make_layer, make_tokens, E, H, I, TOPK
    from kernels.moe_wq_gemm_triton import fused_moe_wq
    from kernels.reference import dequant
    dev = torch.cuda.get_device_name()
    print(dev, "E,H,I,topk =", E, H, I, TOPK)
    w13, w2 = make_layer("nvfp4", "nvfp4")
    W13 = dequant("nvfp4", *[t.cpu() for t in w13]).to("cuda", torch.bfloat16)
    W2 = dequant("nvfp4", *[t.cpu() for t in w2]).to("cuda", torch.bfloat16)

    def baseline(x, ids, w):
        out = torch.zeros((x.shape[0], H), device="cuda", dtype=torch.float32)
        for j in range(TOPK):
            e = ids[:, j].long()
            h = torch.bmm(x[:, None, :], W13[e].transpose(1, 2))[:, 0]
            g, u = h.float().chunk(2, -1)
            a = (torch.nn.functional.silu(g) * u).bfloat16()
            out += torch.bmm(a[:, None, :], W2[e].transpose(1, 2))[:, 0].float() * w[:, j:j + 1]
        return out.bfloat16()

    def timeit(fn):
        for _ in range(5):
            fn()
        torch.cuda.synchronize()
        cache = torch.empty(256 * 2**20, dtype=torch.uint8, device="cuda")  # flush L2 each iter
        ts = []
        for _ in range(args.iters):
            cache.zero_()
            s, e = torch.cuda.Event(True), torch.cuda.Event(True)
            s.record(); fn(); e.record(); torch.cuda.synchronize()
            ts.append(s.elapsed_time(e) * 1e3)
        ts.sort()
        return ts[len(ts) // 2]  # median, us

    bytes_per_expert = (2 * I * H + H * I) * (0.5 + 1 / 16)   # NVFP4 codes + E4M3 scales
    rows = []
    for T in args.tokens:
        x, ids, w = make_tokens(T)
        distinct = ids.unique().numel()
        t_k = timeit(lambda: fused_moe_wq(x, ids, w, w13, w2))
        t_b = timeit(lambda: baseline(x, ids, w))
        gbs = distinct * bytes_per_expert / (t_k * 1e-6) / 1e9
        rows.append(dict(device=dev, T=T, distinct=distinct, triton_us=t_k, baseline_us=t_b, gbs=gbs))
        print(f"T={T:5d} distinct_experts={distinct:3d} triton={t_k:9.1f} us "
              f"({gbs:7.1f} GB/s)  bf16-baseline={t_b:9.1f} us")
    if args.json:
        json.dump(rows, open(args.json, "w"), indent=1)


if __name__ == "__main__":
    main()
