# autokernel: an automated H100 kernel search loop for Inkling 2 Mini

Status: the loop, harness and guardrails run end to end on CPU (`TRITON_INTERPRET=1`). **No H100
run yet, so no timings exist.** Nothing here invents a speed-up.

## What already exists (research, Nov 2026)

| Project | What it is | Takeaway for us |
|---|---|---|
| RightNow AI **AutoKernel** (MIT): https://github.com/RightNow-AI/autokernel, paper arXiv 2603.21331 | Agent edits one kernel file; 5-stage harness (smoke, shape sweep, stability, determinism, edge cases); Amdahl-ranked targets; about 90 s per experiment | Closest template. We copy the single-file contract and the staged checks. A third party noted in June 2026 that the repo looks stalled, so don't depend on it |
| **KernelBench** v0.1 reward hacks: https://scalingintelligence.stanford.edu/blogs/kernelbenchv01/ | Benchmark for LLM-written kernels; documents hacks: calling torch/cuBLAS, never calling the kernel, no-op kernels with memory reuse, stream/timing tricks | Basis for guardrails G1, G6, G7, G8 (roofline sanity check) |
| **Sakana AI CUDA Engineer** and **robust-kbench**: arXiv 2509.14279, https://github.com/SakanaAI/robust-kbench | Claimed 3.13× fell to 1.49× under robust evaluation; Sakana published a post-mortem | Evaluate on held-out shapes in a fresh process; never trust the agent's own timer |
| **Wafer** "fake 104×": https://wafer.ai/blog/reward-hacking | Shared-memory overflow returned garbage that looked fast; caught by a bitwise determinism check | G4: bitwise run-to-run, not just tolerance |
| **KernelLLM** (Meta): https://huggingface.co/facebook/KernelLLM | 8B model fine-tuned for PyTorch→Triton; reported KernelBench-Triton pass@1 of 20.2 | A cheap local proposer for the `command`/`openai` hook; a frontier model will likely propose better sm_90 code (unverified) |
| **AMD GEAK v4** (AMD article on GEAK v4) | Two-altitude loop: end-to-end vLLM/SGLang serving profile → Amdahl ranking → kernel agent | Template for wiring this into Auto vLLM (below) |
| **CUDA-L1**: arXiv 2507.14111 | Contrastive RL for CUDA optimisation | Ideas for a later learned proposer; not needed for v1 |
| **Triton autotune** (general knowledge, not re-researched) | `@triton.autotune` picks configs per key at runtime | Use offline only. Runtime autotune keyed on M **breaks batch invariance**; freeze one config per shape class |
| **TVM / Ansor / MetaSchedule** (general knowledge, not re-researched) | Search over schedules with a cost model | Good for dense ops; weak fit for custom FP4 dequant + MoE routing on sm_90 |

## The loop

```
config.json ─► loop.py
   for i in 1..max_iters:
     check frozen-file hashes (G9)
     proposer(best.py, history, program.md) ─► candidates/current.py      (mutate | command | openai)
     fresh subprocess: harness.py current.py
         G1 static AST ─► G2/G3 numerics on visible shapes ─► G4 bitwise ─► G5 batch invariance
         ─► G6 input sensitivity ─► G7 timing (CUDA events, L2 flush, median) ─► G8 roofline
     if faster than best by ≥ min_speedup: fresh subprocess with --holdout (hidden shapes)
         pass ─► best.py ;  every attempt logged to results.sqlite (source, result JSON, reason)
     stop after max_consecutive_reverts
   best.py ─► human review ─► vLLM plugin (../vllm_plugin) ─► end-to-end gate (vllm bench serve + evals)
```

The score is the geometric mean of median seconds over `bench_tokens` (1, 8, 32, 128, 512). Decode
sizes dominate on purpose.

Targets, in order: (1) w13 grouped GEMM with fused SwiGLU epilogue; (2) w2 GEMM with routing weight,
scatter and fixed-order combine; (3) fused persistent decode block; (4) attention and loop glue
(norms, residual) for the looped layers. Pick by Amdahl from the phase-0 profile, not by taste.

## Guardrails and the hacks they stop

See the table in `../design.md`, section 9. `test_guardrails.py` feeds four deliberate cheats
(`cheats/`) to the harness:

| Cheat | CPU result |
|---|---|
| calls `torch.matmul` | rejected by G1 |
| returns zeros (no-op) | rejected by G2 |
| caches the first answer per shape | rejected by G2 (other modes) and G6 |
| switches BLOCK_K by batch size | **not caught at CPU shapes**: BF16 rounding hides it. GPU mode uses Inkling shapes and 512 tokens so many values are compared. A torch simulation at 1024×2304 flipped 532 of 2.36 M BF16 values. **Unverified on H100** |

Extra rules: hidden shapes live only in `config.json` (frozen, never sent in prompts); each
candidate runs in a fresh process with a timeout; the LLM never sees the harness source; every
kept winner needs a human to read the diff.

## Usage

```bash
cd h100-kernel-port/autokernel
# CPU smoke test (no timing; checks the plumbing and guardrails)
TRITON_INTERPRET=1 python3 loop.py --dry-run 3
TRITON_INTERPRET=1 python3 test_guardrails.py
# H100: set the proposer in config.json, then
export AUTOKERNEL_LLM_BASE_URL=...   AUTOKERNEL_LLM_API_KEY=...    # for "openai" proposer
python3 loop.py
python3 harness.py candidates/best.py --holdout --json best.json   # re-check the winner
sqlite3 results.sqlite 'select iter,ok,kept,score,reason from runs order by id'
```

Proposers: `mutate` (tile-size mutations, no LLM, for plumbing); `command` (any CLI that reads the
prompt on stdin and prints code, e.g. a local KernelLLM wrapper); `openai` (any OpenAI-compatible
`/chat/completions` endpoint, including an on-prem vLLM serving a coding model on your own H100s).

## How it fits your Auto vLLM auto-research effort

I don't know Auto vLLM's internals, so this is the intended shape and not a drop-in. Use GEAK-v4-style
two altitudes:
1. **Outer loop (Auto vLLM):** sweep serving config (TP/EP, max-num-seqs, CUDA graphs, MoE backend,
   batch-invariant on/off, speculative decoding), run `vllm bench serve`, profile, rank kernels
   by Amdahl share of step time.
2. **Inner loop (this):** for a top-ranked kernel, build a harness target (reference + shapes taken
   from the profile), run `loop.py`, return the best candidate plus `results.sqlite`.
3. **Back to the outer loop:** register the winner through `vllm_plugin` behind a flag, then re-run
   the end-to-end benchmark and evals. Keep it only if end-to-end improves; a faster microkernel
   that doesn't move tokens/s is discarded.
Interface between the two: `config.json` (target, shapes, bench sizes) in, and `best.py` + the
results DB + harness JSON out.
