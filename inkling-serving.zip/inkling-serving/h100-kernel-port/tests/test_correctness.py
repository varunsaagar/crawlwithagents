"""Kernel vs PyTorch reference. CPU: TRITON_INTERPRET=1 python -m pytest -q tests ; GPU: pytest -q tests"""
import pytest, torch
from _common import make_layer, make_tokens, E, H, I, TOPK, DEVICE
from kernels.formats import e4m3fn_decode
from kernels.reference import moe_ref, dequant
from kernels.moe_wq_gemm_triton import fused_moe_wq, moe_wq_gemm, align_rows


def test_e4m3_decode_matches_torch():
    u = torch.arange(256, dtype=torch.uint8)
    ours = e4m3fn_decode(u)
    ref = u.view(torch.float8_e4m3fn).float()
    both_nan = ours.isnan() & ref.isnan()
    assert torch.equal(ours[~both_nan], ref[~both_nan])


@pytest.mark.parametrize("fmt", ["nvfp4", "mxfp8"])
def test_single_gemm_vs_fp64(fmt):
    """One expert GEMM against fp64 math on the exactly dequantised weights."""
    w13, _ = make_layer(fmt, "nvfp4")
    x, ids, _ = make_tokens(5)
    sorted_ids, blocks = align_rows(ids, E)
    out = moe_wq_gemm(x, w13, fmt, sorted_ids, blocks, ids.numel(), a_row_div=TOPK).float().cpu()
    W = dequant(fmt, *[t.cpu() for t in w13]).double()
    rows = x.cpu().double().repeat_interleave(TOPK, 0)
    ref = torch.stack([rows[r] @ W[ids.cpu().reshape(-1)[r]].T for r in range(rows.shape[0])])
    # allowed: fp32 accumulation order + final bf16 rounding (2^-8 relative)
    torch.testing.assert_close(out.double(), ref, rtol=1.6e-2, atol=1e-2)


@pytest.mark.parametrize("fmts", [("nvfp4", "nvfp4"), ("mxfp8", "mxfp8")])
@pytest.mark.parametrize("T", [1, 3, 17])
def test_fused_moe_vs_reference(fmts, T):
    w13, w2 = make_layer(*fmts)
    x, ids, w = make_tokens(T)
    out = fused_moe_wq(x, ids, w, w13, w2, *fmts).float().cpu()
    ref = moe_ref(x.cpu(), ids.cpu(), w.cpu(), tuple(t.cpu() for t in w13),
                  tuple(t.cpu() for t in w2), *fmts).float()
    rel = (out - ref).norm() / ref.norm()
    assert rel < 2e-2, f"relative error {rel:.3e}"
