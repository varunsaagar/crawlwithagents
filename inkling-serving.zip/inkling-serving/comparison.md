# Inkling 2 Mini: best-in-world serving options and a custom-engineering path

Prepared 22 Nov 2026 (IST). Follow-up to `report.md`. "Verified" means seen in a source this session. "Unverified" means inference or not found. Everything here is under 3 days old.

## 1. The two posts

### nnsight / NDIF: "Opening the box of Inkling 2 Mini" (20 Nov)
- **What they did.** NDIF hosts `thinkingmachines/inkling-2-mini` and the variable-loop research model for remote white-box inference. NNsight can read, patch, steer and differentiate activations at every one of the 48 layer visits, with no local GPU. They also launched the "Looped Lens Challenge".
- **Hooks.** There is no single residual stream.
  - `layers[i].output` is only the active 6-layer block.
  - Full state is the active block, the completed blocks (`layer.inputs[0][1]`) and the cross-pass messages (`inputs[0][2]`, `message_input`).
  - `tracer.iter[:3]` steps through the three passes. Other hooks: block-mix queries, `*_message_gate`, MoE mixed input.
  - Varloop checkpoint: set `loop_num_passes` for 1, 2, 3 (trained on 1–5, post-trained on 3, TML evaluated up to 10 passes).
- **What it shows (CounterFact, 100 prompts).**
  - Logit-lens readouts reach at most 0.31 agreement with the final prediction across the looped middle. They only work after the coda block.
  - On "The capital of France is", " Paris" does not appear until visit 35 (late in pass 3).
- **Companion post (Goodfire, 20 Nov), verified.**
  - Later passes almost always read block 3 from the previous pass.
  - One activation coordinate (d2027) carries about 46% of the squared norm. It spikes at layer 18 of passes 1–2 and is cleaned up at the end of pass 3. It looks like a "another pass follows" signal.
  - Tuned-lens and coda-lens decode intermediate states well. Plain logit-lens does not.
- **Serving relevance (my inference).**
  - The model's own computation is not exit-friendly at the middle layers.
  - A coda-lens or tuned-lens read after pass 1 or 2 is the only credible early-exit probe.
  - It would need training and an accuracy gate. Nobody has shown it works for serving.
  - Nothing in either post covers per-expert routing statistics, so "expert-usage-aware routing" has no published support yet (unverified).
  - NNsight is a research tool, not a serving tool.

### RightNow AI: "Optimizing Inkling 2 Small's kernels on NVIDIA B300" (22 Nov)
Note the title: it is **Inkling 2 Small (594B) on 8× B300**, not Mini and not Hopper. The URL says "bit-identical FP4 MoE kernels on Blackwell".
- **Technique (all hand-written CUDA, produced by their AI kernel engine).**
  - **Batch-invariant by construction.** Fixed-shape reductions: fixed chunks, balanced trees, cross-GPU sums in rank order in FP32, `-fmad=false`.
  - **Each property is paired with a deliberately broken variant** that the tests must catch.
  - **Experts split across all 8 GPUs by columns, not expert-parallel.** SGLang says NVFP4 experts cannot be TP-sharded, because their activation scales need the full row. They exchange the row maximum, which is order-independent and therefore exact.
  - **Block-scaled tensor-core GEMM** (`tcgen05.mma ... mxf4nvf4.block_scale`) rebuilt for one token with split-K and a fixed-tree combine.
  - **Depth-mix reduction cut from two rounds to one** using a Gram matrix.
- **Results (B300, 21 Nov).**
  - 599 of 599 logit rows are bit-identical at 64 rows per step and at 1.
  - The distance from vLLM is 0.025 nats mean and 0.13 at p95.
  - The rebuilt w13 GEMM is 5.1× (NVFP4) and 7.5× (MXFP8) faster than their first kernel, in isolation.
  - Their engine is **not faster than vLLM yet**: about 16 ms per step, the rebuilt kernel is not wired in, and the 1,900 tok/s/user figure is a projection against vLLM's 666.
- **Applicability.** It targets `tcgen05` and `sm_103a`, so it is **Blackwell-only**. It does not run on H100 as is. The reusable ideas for Hopper are:
  - the fixed reduction-tree discipline;
  - the paired "broken twin" tests;
  - the exact max-exchange trick.
  The kernels would need a rewrite on `wgmma`.
- **Open source.** Apache-2.0 per the post, at `github.com/RightNow-AI/inkling-b300-kernels`. The repo page I fetched showed 0 stars, no content. I couldn't confirm the code.
- **API.** The page shows an `api.rightnowai.co` endpoint template. I found no Inkling model listing for it.

## 2. Engines and stacks compared (H100 first)

| Option | Inkling 2 Mini status | H100 | Custom-kernel story | Spec decoding | Determinism | Licence | Maturity |
|---|---|---|---|---|---|---|---|
| **vLLM** | Day-0 (PR #69028, recipe, blog) | Listed and recipe-verified, **but published image lacks sm_90 kernels** (#69046, open) | Fused loop kernels, Triton, Humming W4A16 on Hopper, FA3/FA4. Plugin path (`CustomOp.register_oot`) | DSpark (bundled), adaptive verification (new) | `VLLM_BATCH_INVARIANT=1` documented for CC 8.0+. Inkling coverage unverified, slower | Apache-2.0 | Highest. Fast-moving |
| **SGLang** | Day-0, cookbook | **Not listed.** H200, Blackwell, 5090, Spark, MI350X, TPU7x. H200 uses Marlin | Own MegaMoE (Blackwell), Marlin GEMV retune, `fa4` | DSpark | `--enable-deterministic-inference` (fa3, FlashInfer, Triton). Inkling untested (unverified) | Apache-2.0 | High. Needs H200+ for Mini |
| **TokenSpeed** (lightseek) | Day-0, recipe | Not in the Mini recipe I read (AMD 4-GPU, NVIDIA for Small on B300) (unverified) | Triton backends, FlashInfer autotune, **MXFP8 KV cache** (0.70× bytes), **decode "monokernel"** on AMD | DSpark, 3 tokens per round for Mini | Not stated | Open source (licence not checked) | New. Single-vendor recipes. Looks like the most custom-engineered |
| **TensorRT-LLM** | Inkling 2 Small only (commit 20 Nov). **No Mini/looped evidence** | Mature for H100 in general. Mini unverified | TRT-LLM-gen batched GEMMs (SM100 only for Inkling) | Generic EAGLE/MTP. DSpark unverified | Not shown | Apache-2.0 | Mini not usable yet |
| **NVIDIA Dynamo** | Listed by TML. Recipe is SGLang runtime on **B200/VR200 only** (experimental) | **No H100 recipe.** Needs TP2/EP2 | KV-aware router, NIXL/Mooncake PD. Looped checkpoints: no layerwise PD transfer | Via SGLang | Not shown | Apache-2.0 | Orchestration layer, not a kernel engine |
| **LMDeploy / TurboMind** | **No.** `supported_models.py` has no Inkling arch | n/a | C++/CUDA, KV int4/8 for other models | n/a | n/a | Apache-2.0 | Not an option now |
| **Together / Fireworks / Baseten / Modal** | Together and Modal host **Small**. Mini hosting not found (OpenRouter: Prime Intellect, io.net). One aggregator claims more providers; I didn't trust it | Managed, hardware hidden | Closed (FireAttention, Together kernels/ATLAS). No Inkling detail found | Hosted. Unverified | Not offered | Closed | Good for a benchmark baseline, not for control |
| **RightNow AI** (YC) | Small on B300, research engine. **Not Mini** | **No** (`tcgen05`/`sm_103a`) | Hand-written CUDA via agent kernel engine. Open source (claimed) | Uses Inkling's draft. Not faster than vLLM yet | **Bit-identical across batch size, proven on 599 rows** | Apache-2.0 (claimed) | Early research. Valuable as a design reference |
| **FlashInfer** | Library, not a server. TRT-LLM batched expert GEMMs are SM100 only. vLLM's fused loop kernels are not FlashInfer's | Attention/sampling yes. Inkling expert path no | TMA/CUTLASS, autotuner | n/a | n/a | Apache-2.0 | Component, used by SGLang/TokenSpeed |
| **DeepGEMM / Mirage MPK / ThunderKittens / Liger / Luminal** | **No Inkling support found.** MPK and ThunderKittens are general frameworks. None shows a looped-MoE port | DeepGEMM and ThunderKittens support Hopper. Mini port would be your work (unverified) | MPK: whole-model persistent megakernel. TK: tile primitives | n/a | n/a | Open (mostly) | Research or building blocks |
| **Perplexity / Character.AI custom stacks** | Not searched in depth. No Inkling evidence | Unverified | Closed or partial | Unverified | Unverified | Closed or partial | Not assessed |

Read this as: vLLM and SGLang are the only two that run Mini end to end on NVIDIA with a documented recipe, and only vLLM lists H100.

## 3. Recommendation for Varun's team

**Adopt now**
1. **vLLM as the H100 engine.**
   - Build from main with `TORCH_CUDA_ARCH_LIST=9.0` and test image input.
   - Use TP1, DSpark and the recipe flags from `report.md`.
   - Run one replica per GPU behind a prefix-aware router. Dynamo's router is worth testing as a router only.
2. **SGLang on H200 or Blackwell as the comparison and fallback.** Do not plan on it for H100.
3. **A benchmark and hosted baseline.** Run the same `speed_bench` workload on vLLM, SGLang (H200) and a managed endpoint (OpenRouter or Tinker). Keep the numbers.
4. **TokenSpeed as a watch item.** Its MXFP8 KV cache is a documented, measured idea (33% more throughput at 64 sessions, on Small and B300). Re-check whether it runs on H100 before relying on it.

**Build in-house** (in this order)
1. **Determinism gate.**
   - Turn on `VLLM_BATCH_INVARIANT=1` on one replica and measure the cost.
   - Add a logit-hash regression test (RightNow's method: same prompts at batch 1 versus batch N, hash per row) to every upgrade, because the engine, image and kernels are changing daily.
   - Do not write bit-identical kernels yet.
2. **Loop-aware capacity model.** Each pass has its own KV and conv state (48 of each). Size context and sessions on that (about 69 KB/token), cap context, and check the prefix-cache hit rate per session.
3. **Loop-aware scheduling and latency tiers.**
   - Run the varloop checkpoint at 1 or 2 passes as a "fast tier". It can't use DSpark, and quality is only lightly evaluated.
   - Keep the fixed 3-pass Mini plus DSpark as the quality tier. Route by request class.
4. **Early-exit research spike (time-boxed).** Train a coda-lens or tuned-lens on a small corpus, as Goodfire did. Measure how often the pass-2 readout matches pass 3. Only build kernels if the match rate is high. Today there is no evidence it works.
5. **Expert-usage telemetry.** Log per-layer expert counts in a vLLM fork or plugin. Use them to decide Humming tuning and expert-aware placement. The published work gives no guidance here, so this is exploratory.

**Don't build yet**
- Custom FP4 kernels for H100: Hopper has no FP4 tensor cores, and vLLM already runs these experts as W4A16 via Humming. Revisit when Blackwell arrives, or reuse RightNow's open-source kernels if the licence and tests hold up.
- Your own engine. Nothing public beats vLLM or SGLang on Mini yet, including RightNow's.

## Phased plan

| Phase | When | What | Exit test |
|---|---|---|---|
| 0 | This week | Sm_90 vLLM build. Text and image smoke tests. Single-GPU `speed_bench` baseline | Image input correct. Numbers recorded |
| 1 | Weeks 1–2 | Replicas plus prefix-aware routing. Sweep `max_num_batched_tokens` and `max_num_seqs`. DSpark on and off. Logit-hash regression harness | P99 latency and tok/s/user target met. Hash test green |
| 2 | Weeks 2–4 | Batch-invariant mode cost. Adaptive-verification canary. Fast-tier varloop trial. SGLang H200 comparison. FP8 KV experiment | Accuracy within agreed tolerance on your evals |
| 3 | Month 2 | Early-exit probe spike. Expert telemetry. Decide on any kernel work | Go or no-go with data |
| 4 | When Blackwell lands | Re-baseline native NVFP4 path. Evaluate RightNow kernels and TokenSpeed on B200/B300 | Measured gain over vLLM |

## Caveats
- Almost everything is days old. Support lists and image builds are changing.
- I did not run any code or GPU.
- RightNow's performance claims are theirs and mostly projections. The bit-identity result is measured on Small.
- Perplexity, Character.AI, Fireworks, Baseten, Luminal, Liger and DeepGEMM were not assessed for Inkling beyond a search that found nothing.

## Sources
- nnsight/NDIF post: https://nnsight.net/blog/2026/11/20/opening-the-box-of-inkling-2-mini-using-nnsight-ndif/
- Goodfire: https://www.goodfire.com/research/interpreting-inkling-2-mini
- RightNow AI: https://www.rightnowai.co/blog/bit-identical-fp4-moe-kernels-on-blackwell and https://github.com/RightNow-AI/inkling-b300-kernels
- TML announcement and model card: https://thinkingmachines.ai/news/inkling-2-mini/ , https://thinkingmachines.ai/model-card/inkling-2-mini/
- vLLM: https://vllm.ai/blog/2026-11-20-inkling2-mini , https://github.com/vllm-project/vllm/pull/69028 , https://github.com/vllm-project/vllm/pull/68761 , https://github.com/vllm-project/vllm/issues/69046 , https://docs.vllm.ai/en/stable/features/batch_invariance/
- SGLang: https://docs.sglang.io/cookbook/autoregressive/ThinkingMachines/Inkling-2-Mini , https://docs.sglang.io/docs/advanced_features/deterministic_inference
- TokenSpeed: https://lightseek.org/tokenspeed/recipes/models , https://github.com/lightseekorg/tokenspeed/commits
- TensorRT-LLM: https://github.com/NVIDIA/TensorRT-LLM/commits
- Dynamo: https://docs.nvidia.com/dynamo/dev/recipes/inkling-2-mini.md
- LMDeploy: https://github.com/InternLM/lmdeploy/blob/main/lmdeploy/turbomind/supported_models.py
- Providers: https://www.together.ai/models/inkling-2-small , https://modal.com/library/thinking-machines , https://openrouter.ai/thinkingmachines/inkling-2-mini
- FlashInfer / vLLM Hopper attention: https://github.com/vllm-project/vllm/pull/48858 , https://github.com/flashinfer-ai/flashinfer/pull/5283
- Mirage MPK: https://github.com/mirage-project/mirage/ ; ThunderKittens: https://arxiv.org/abs/2410.20399
