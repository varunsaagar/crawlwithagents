"""Jev 64K concurrency / throughput calculator (ESTIMATES, formulas below; verify with inference-bench).
KV/seq = sum over KV-owning layers: sliding layers store min(ctx, window) tokens, global layers store ctx tokens.
bytes/token/layer = kv_heads*head_dim*(1 if K==V else 2)*bytes_per_elem.
max_seqs = (GPU_GB*util - weights - act) / KV_seq.   prefill_s = (2*N_active*n + attn_flops(n)) / (peak*MFU).
Doc-once: one prefill of the document answers Q questions; in-flight decisions = docs_in_flight * Q."""
import argparse, json

MODELS = {  # from HF config.json (see Jev-64K-LongContext-Base-Model-Selection doc)
 "26B-A4B": dict(sl=25, sl_kvh=8, sl_hd=256, sl_keqv=False, gl=5, gl_kvh=2, gl_hd=512, gl_keqv=True, win=1024,
                 active=3.8e9, w_bf16=51.6, w_fp8=26.5, q_heads_gl=16),
 "E4B":     dict(sl=20, sl_kvh=2, sl_hd=256, sl_keqv=False, gl=4, gl_kvh=2, gl_hd=512, gl_keqv=False, win=512,
                 active=4.0e9, w_bf16=16.0, w_fp8=8.5, q_heads_gl=8),   # 24 KV-owning layers (18 of 42 share KV)
}
GPUS = {"H800-80GB": (80, 1979e12), "H100-80GB": (80, 1979e12), "H200-141GB": (141, 1979e12)}  # dense FP8 peak

def kv_gb(m, ctx, b):
    sl = m["sl"] * min(ctx, m["win"]) * m["sl_kvh"] * m["sl_hd"] * (1 if m["sl_keqv"] else 2) * b
    gl = m["gl"] * ctx * m["gl_kvh"] * m["gl_hd"] * (1 if m["gl_keqv"] else 2) * b
    return (sl + gl) / 1e9

def prefill_s(m, n, peak, mfu):
    lin = 2 * m["active"] * n
    attn = m["gl"] * 2 * n * n * m["q_heads_gl"] * m["gl_hd"]  # causal QK^T+AV on global layers (~4*n^2*h*d/2)
    return (lin + attn) / (peak * mfu)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--target", type=int, default=3250); ap.add_argument("--util", type=float, default=0.92)
    ap.add_argument("--act_gb", type=float, default=6.0); ap.add_argument("--mfu", type=float, default=0.25)
    ap.add_argument("--q_per_doc", type=int, default=32); ap.add_argument("--suffix_tok", type=int, default=256)
    ap.add_argument("--json", action="store_true"); a = ap.parse_args()
    rows = []
    for g, (mem, peak) in GPUS.items():
        for mn, m in MODELS.items():
            w = m["w_fp8"]; free = mem * a.util - w - a.act_gb
            for ctx in (65536, 32768, 8192, 6144):
                for kvn, b in (("BF16", 2), ("FP8", 1), ("INT4", 0.5)):
                    kv = kv_gb(m, ctx, b); seqs = int(free / kv); p = prefill_s(m, ctx, peak, a.mfu)
                    # doc-once: each doc holds full KV + Q short question suffixes
                    per_doc = kv + a.q_per_doc * kv_gb(m, a.suffix_tok, b)
                    docs = int(free / per_doc); dec = docs * a.q_per_doc
                    rows.append(dict(gpu=g, model=mn, ctx=ctx, kv=kvn, kv_gb=round(kv, 3), max_seqs=seqs,
                                     prefill_s=round(p, 3), rps_per_gpu=round(1 / p, 2),
                                     decisions_s=round(a.q_per_doc / p, 1), doc_once_inflight=dec,
                                     hits_target_seq=seqs >= a.target, hits_target_doc_once=dec >= a.target,
                                     gpus_for_target_seqs=-(-a.target // max(seqs, 1)),
                                     gpus_for_target_rps_noshare=round(a.target * p, 0)))
    if a.json: print(json.dumps(rows, indent=1)); return
    print(f"target={a.target} in-flight | util={a.util} act={a.act_gb}GB MFU={a.mfu} Q/doc={a.q_per_doc} (ESTIMATES)")
    print(f"{'gpu':11}{'model':9}{'ctx':>6} {'kv':5}{'KV GB':>7}{'maxSeq':>7}{'prefill s':>10}{'RPS/GPU':>8}"
          f"{'dec/s':>7}{'docOnce':>8}{'GPUs@seq':>9}{'GPUs@3250RPS':>13}")
    for r in rows:
        if r["gpu"] != "H800-80GB" and r["kv"] == "INT4": continue
        print(f"{r['gpu']:11}{r['model']:9}{r['ctx']:>6} {r['kv']:5}{r['kv_gb']:>7}{r['max_seqs']:>7}{r['prefill_s']:>10}"
              f"{r['rps_per_gpu']:>8}{r['decisions_s']:>7}{r['doc_once_inflight']:>8}{r['gpus_for_target_seqs']:>9}"
              f"{int(r['gpus_for_target_rps_noshare']):>13}")

if __name__ == "__main__": main()
