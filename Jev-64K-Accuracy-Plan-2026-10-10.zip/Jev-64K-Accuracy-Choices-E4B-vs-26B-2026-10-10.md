# Jev 64K addendum: choice capacity, keeping accuracy at length, E4B reuse vs 26B (2026-10-10)

Extends `Jev-64K-Recipe-E4B-26B-Leaderboard-2026-10-10.md`. Changes in this addendum: Claude Opus or Gemini may now be the **teacher** (no Qwen base,
still). "101 H100" is read as **one H100**; the 101-GPU fleet is in §4. All speed/memory figures are **estimates** from
`jev-64k-recipe/concurrency_calc.py`. Nothing here was trained or measured.

## Direct answers
1. **Choices at 64K:** token budget is not the limit. 300 options × 20 tokens ≈ 7K tokens (11% of 64K). The limits are the **readout** and the **accuracy**:
   - **letter-logit** (your current E4B jev-lite): 26 single-token letters A–Z;
   - **strands pointer head**: `num_slots` is a config value, default **24**, raise it to 300+;
   - **more than about 300 options:** shortlist with INDEX, or run a **tournament** (`chunk_aggregate.py`).
2. **Long-context accuracy drop is real and fixable.** The main causes are: training at short length (strands trains and serves at a **4,096-token window**), lost-in-the-middle, and calibration that shifts with length. Ranked fixes:
   - keep effective context short (INDEX, chunk-and-aggregate);
   - question before **and** after the document;
   - length curriculum with 25% short replay;
   - randomise evidence position;
   - long-document teacher labels from Gemini/Opus;
   - per-length-bucket calibration and LTT, with fallback to the LLM.
   - **Gate:** accuracy drop from 8K to 64K ≤ 2 percentage points, and ECE ≤ 0.03 per bucket.
3. **How the open models were trained:**
   - **Gemma 3** pretrained at 32K, then rescaled RoPE to 128K.
   - **Gemma 4:** 5:1 local:global attention, p-RoPE on global layers (θ=1M), 128K (E2B/E4B) / 256K (12B/26B/31B). The report text I read does not state the length schedule.
   - **strands-decider** models (including Gemma 26B/E4B/12B) are trained and scored at window **4096**. **None of the open decision models is trained for 64K**, so we have to do it.
4. **Yes, reuse your E4B.** Merge the jev-lite LoRA and continue with 16K→32K→64K stages, keeping the letter-logit readout.
   - Move to **26B-A4B** only if, after the curriculum, the 8K→64K drop is still > 2 pp or 64K accuracy misses target by > 3 pp.
   - **1×H100, estimates:**
     - training at 64K: ~38–46 GB, ~45 GPU-h per seed;
     - serving at 64K: ~0.74 req/s and 107 sequences in flight (FP8 KV);
     - with read-once for 32 questions: ~24 decisions/s.
5. **Procedure:** §5. It takes about **3 weeks** and **~250 GPU-h** for E4B (estimate), plus teacher API spend (formula in §5; no prices assumed).

## 1. Choice capacity at 64K
Tokens for the option list ≈ N × (L + 4 separator/label tokens):

| Options N | 10 tok/opt | 20 | 40 | 60 | Accuracy risk (qualitative) |
|---|---|---|---|---|---|
| 24 | 336 | 576 | 1,056 | 1,536 | low (inside letter A–Z and default 24 slots) |
| 100 | 1.4K | 2.4K | 4.4K | 6.4K | medium: needs pointer head or tournament; distractor confusion grows |
| 300 | 4.2K | 7.2K | 13.2K | 19.2K | high: patch slots to 300, train with 2–300 options, hard negatives |
| 1,000 | 14K | 24K | 44K | 64K (no room for doc) | too high for one pass: INDEX shortlist to ≤50, or tournament |

- **Readouts:**
  - **Letter-logit (jev-lite):** softmax over single-token letters at the last position, so at most 26 per pass. Beyond that, use groups of 26 in a tournament (top-2 advance).
  - **Strands pointer head:** scores each option from that option's own hidden state, so the count is limited only by `num_slots` (`DEFAULT_NUM_SLOTS = 24`, `modeling.py`). The server rejects more options than `num_slots`. With the slot head, only slots 0–8 have single-token initialisation (`modeling.py` comment).
- **Evidence on accuracy vs number of options:** I found **no public measurement** in JevBench, Hard-Decisions or the strands results that varies option count. Hard-Decisions uses 2–3 options; the earlier E4B guide noted the Quyet-31B entry is limited to ≤10 options. So accuracy vs N must be **measured** in our sweep: N = 2/10/26/100/300 at 8K and 64K.
- **Practical rule:** shortlist with INDEX to ≤26–50 options. Keep pointer + 300 slots for catalog decisions. Use the tournament when N > slots.

## 2. Why Jev loses accuracy at length, and the fix stack
**Causes:**
- **(a) Train/test length mismatch:** strands trains and serves at 4,096 tokens (`evaluation/jevbench.md` "The context window is not the ceiling"; its corpus median is 204 tokens, `training/hardware.md`). Our jev-lite was also trained short. The readout has never seen 64K hidden states.
- **(b) Lost in the middle:** LMs use evidence at the start/end better than in the middle (Liu et al., arXiv:2307.03172).
- **(c) Gemma 4 architecture:** only about 1 in 6 layers is global, and the local windows are 512 (E4B) / 1024. Long-range evidence must flow through the few global layers, and their attention mass spreads across more tokens as length grows (a mechanism hypothesis, not measured here).
- **(d) Calibration shifts with length:** confidence fitted at short length becomes over- or under-confident at 64K.
- **(e) Option dilution:** more distractor documents → more plausible wrong options.

| Rank | Fix | Expected effect | Evidence / note | Measure |
|---|---|---|---|---|
| 1 | Keep effective context short: INDEX shortlist to 4–8K | removes most of the drop and ~10× compute | throughput plan; the cheapest fix | acc at 8K on shortlisted vs full 64K |
| 2 | Chunk-and-aggregate (8–16K chunks; Noul = noisy-OR/max, Choice = max per option + tournament) | turns 64K into several 8–16K problems the model already handles | map-reduce long-doc pattern; aggregate needs re-calibration | `chunk_aggregate.py` vs single pass |
| 3 | Question **before and after** the document (sandwich) | helps the last-position readout find the question | Anthropic long-context tips (query at end) [docs](https://docs.anthropic.com/en/docs/build-with-claude/prompt-engineering/long-context-tips); re-reading (arXiv:2309.06275) | A/B in length sweep |
| 4 | Length curriculum 8/16→32→64K with 25% short replay + KL anchor to old model | teaches readout long hidden states without losing short skill | standard long-context continued training; Gemma 3 extended 32K→128K | short acc ≥ old −1 pp |
| 5 | Evidence-position randomisation (start/middle/end, multi-needle) | flattens the position curve | targets (b) | acc by position, gap ≤3 pp |
| 6 | Long-document teacher labels (Gemini logprobs / Opus votes / Gemma-31B), gold-filtered | soft targets on hard long rows | strands uses 31B teacher only where = gold | ECE, Brier per bucket |
| 7 | Per-length-bucket temperature + LTT thresholds; uncertified bucket goes to the LLM | keeps app accuracy within ε even if the model drops | our calibration engine | LTT certificates |
| 8 | Doc-once multi-question | throughput, not accuracy; keeps 64K affordable | strands serving | dec/s |
| 9 | RoPE/YaRN/attention-temperature scaling | **not needed** (64K < native 128K); only beyond native | Gemma card | — |

**Measurement:** run `length_sweep_eval.py` at 4/8/16/32/64K × start/middle/end on a held-out set. **Gate:** acc(8K) − acc(64K) ≤ 2 pp; position gap ≤ 3 pp; ECE ≤ 0.03 per bucket.

## 3. How the models were trained for long context (sources only)
| Model | What the source says | Source |
|---|---|---|
| Gemma 3 | Pretrained at 32K, then RoPE rescaled (factor 8) to 128K for 4B+; 5:1 local:global, window 1024; global RoPE base 1M, local 10K | Gemma 3 Technical Report, arXiv:2503.19786 |
| Gemma 4 | 5:1 local:global (4:1 E2B), final layer global; windows 512 (E2B/E4B) / 1024; p-RoPE p=0.25 on global, θ 1M global / 10K local; K reused as V on global except E2B/E4B; KV sharing 18/42 on E4B; context 128K small / 256K medium. The length-extension schedule is not stated in the text I read. | [Gemma 4 model card](https://ai.google.dev/gemma/docs/core/model_card_4), [Gemma 4 Tech Report arXiv:2607.02770](https://arxiv.org/html/2607.02770) |
| strands-decider (incl. Gemma 26B-A4B/E4B/12B v1) | Pointer/slot head + LoRA, KL to teacher/anchor, 3-seed soup, per-kind temperature; **window 4096** for training and scoring (raised 1024→3072 on v5, 4096 from v19); corpus median 204 tokens | `/workspace/refs/strands-decider` `evaluation/results.md`, `evaluation/jevbench.md`, `training/hardware.md` |
| Gemma-4-31B | Same family recipe (256K). It is a strands teacher, not a long-trained decision model. | model card; strands results |
| Kev, pplx-decider/AutoJev | Qwen bases (banned). I found no long-context decision training documented. | Hard-Decisions, earlier docs |

## 4. E4B reuse vs 26B
- **Your current E4B is a letter-logit QLoRA** (jev-lite lineage, soft-label CE; 4-bit training → BF16 serving needed T≈1.4). This readout differs from strands' pointer head, and **you don't need to switch** to go to 64K.
- **Plan:** merge the LoRA into BF16 E4B → re-fit T in BF16 → continue with BF16 LoRA (not 4-bit, so the T shift doesn't recur) using `configs/e4b-continue-stage{2-16k,3-32k,4-64k}.yaml`, with KL anchor 0.3 to the merged old model on short replay rows. No RoPE change (native 128K).
- **Decision rule:**
  1. Run `length_sweep_eval.py` on today's E4B for a baseline.
  2. After stage 4, if the 8K→64K drop is ≤ 2 pp and the gates pass, ship E4B.
  3. If the drop is 2–5 pp, add chunk-and-aggregate for the >32K bucket and re-test.
  4. If it is still > 2 pp, or 64K accuracy is > 3 pp below target, train **26B-A4B** with the same data. Why 26B: RULER 128K 89.8 vs 86.6 for E4B, 1024 windows and more global capacity (Gemma 4 report numbers, as cited in the base-model doc).
- **1×H100 (estimates):**

| | E4B | 26B-A4B |
|---|---|---|
| Train memory at 64K (BF16 LoRA, grad ckpt) | ~38–46 GB (~30–36 with offload) | ~68–78 GB (tight) |
| Continue stages 16→64K per seed | ~45 GPU-h | ~70 GPU-h |
| Serve 64K: KV per seq FP8 / max in-flight seqs | 0.55 GB / 107 | 0.44 GB / 93 |
| Prefill at 64K / req/s / dec/s with Q=32 | 1.34 s / 0.74 / 23.8 | 1.72 s / 0.58 / 18.6 |
| Serve 8K (shortlisted): req/s / max seqs FP8 | 7.3 / 761 | 7.3 / 279 |

- **If you meant 101 H100s literally** (no prefix-cache benefit counted):
  - E4B at 64K: ~75 req/s, or ~2,400 decisions/s with 32 questions per document.
  - E4B at 8K: ~740 req/s, or ~23,600 decisions/s.
  - 26B-A4B at 64K: ~59 req/s.

## 5. Step-by-step procedure (E4B first)
1. **Baseline:**
   - serve the current E4B;
   - `python jev-64k-recipe/length_sweep_eval.py --eval heldout.jsonl --pool pool.jsonl --url http://host:8000/v1/systemone`;
   - also sweep N options (2/10/26).
2. **Merge:** merge the jev-lite LoRA into `google/gemma-4-E4B-it` (PEFT `merge_and_unload`), save to `checkpoints/e4b-jev-lite-merged`, re-fit temperature in BF16.
3. **Build long data:**
   - `python jev-64k-recipe/build_long_context.py --short jev_short.jsonl --out data/jev64k/long_upto_65536.jsonl --max_len 65536 --per_bucket 20000 --jevbench jevbench.jsonl --tokenizer google/gemma-4-E4B-it`;
   - add a 15% no-evidence/"unknown" share, 10% multi-needle rows and the question sandwich.
4. **Teacher labels:**
   - `python jev-64k-recipe/teacher_label.py --provider gemini --inp long.jsonl --out data/jev64k/teacher_65536.jsonl`, or `--provider opus --samples 8`. Gemma-31B via vLLM logprobs is the no-API option.
   - Gemini can return token logprobs (check that your model and API version expose them). Opus has no logprobs, so the script uses vote distributions from samples.
   - Rows are kept as soft labels only where teacher argmax = gold.
   - **Cost:** rows × avg input tokens × input price × samples (input dominates). Use provider prompt caching for shared documents. Example size: 60K rows × 30K tokens = 1.8B input tokens per sample, so Opus with 8 samples is expensive. Prefer Gemini logprobs (1 call) or Gemma-31B for the bulk, and Opus for a hard subset.
   - Check provider terms on using outputs for training.
5. **Train** (3 seeds each): `configs/e4b-continue-stage2-16k.yaml` → `stage3-32k` → `stage4-64k`. Before each stage, run a 20-step smoke run to measure memory.
6. **Soup:** average the 3 seeds' LoRA deltas, then merge.
7. **Calibrate:** temperature per kind × length bucket (≤8K, 8–32K, 32–64K); keep only if NLL improves; then LTT thresholds per group × bucket. Uncertified buckets go to the LLM.
8. **Evaluate:**
   - **Gates:** length-sweep drop ≤ 2 pp; position gap ≤ 3 pp; ECE ≤ 0.03 per bucket; short accuracy ≥ old −1 pp; JevBench ≥ current E4B; option-count sweep reported.
   - **Fallback:** if the drop is 2–5 pp, enable `chunk_aggregate.py` for >32K and re-run. If it still fails, step 9.
9. **Fallback to 26B-A4B:** same data with `configs/26b-stage{1-8k,2-32k,3-64k}.yaml`.
10. **Serve:** INDEX shortlist where possible, read-once multi-question, prefix cache, FP8 KV (re-fit T), per-bucket queues; benchmark with `inference-bench`.

**Timeline (estimate):**
- week 1: baseline, merge, data build, teacher labelling;
- week 2: stages 2–4 × 3 seeds (~135 GPU-h), soup, calibration;
- week 3: sweeps, gates, serving bench.
- **E4B total ~250 GPU-h**, including labelling with Gemma-31B for the bulk. **+~250 GPU-h** if 26B is needed.

## Uncertain
- Option-count vs accuracy has no public evidence. It must be measured.
- Gemma 4's long-context training schedule is not stated in the sources I read.
- Gemini logprob availability depends on the model and version. Provider terms on training with outputs need legal review.
- Config fields `readout`, `question_sandwich`, `kl_anchor_*`, `activation_offload` and `position_jitter` need trainer support (jev-lite trainer or a strands patch).
- All speed and memory numbers are formula estimates (25% prefill MFU).
- The noisy-OR aggregate is overconfident until re-calibrated.
