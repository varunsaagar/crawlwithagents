"""Reference (PyTorch, fp32 accumulate) MoE forward for one Inkling-style expert layer.

Not the Inkling model: routing, softcap and combine details are simplified and must be
checked against vLLM's `vllm/models/inkling2/nvidia/ops/moe*.py` before trusting parity.
"""
import torch
from .formats import dequant_nvfp4, dequant_mxfp8


def dequant(fmt, packed, scale, gscale):
    return dequant_nvfp4(packed, scale, gscale) if fmt == "nvfp4" else dequant_mxfp8(packed, scale, gscale)


def swiglu(h, softcap=None):
    """h: [..., 2I] with gate first then up (layout assumption; Inkling interleaves gate/up
    rows in w13 per the vLLM PR, so map accordingly). Optional tanh softcap on the gate."""
    g, u = h.chunk(2, dim=-1)
    if softcap is not None:
        g = softcap * torch.tanh(g / softcap)
    return torch.nn.functional.silu(g) * u


def route(router_logits, top_k=8, scale=8.0):
    """Softmax over all experts, pick top-k, renormalise selected, scale by 8 (per HF blog)."""
    p = router_logits.float().softmax(-1)
    w, ids = torch.topk(p, top_k, dim=-1)
    w = w / w.sum(-1, keepdim=True) * scale
    return w, ids.to(torch.int32)


def grouped_gemm_ref(x_rows, expert_of_row, W):
    """x_rows [R, K] bf16, expert_of_row [R], W fp32 [E, N, K] -> fp32 [R, N]."""
    out = torch.empty((x_rows.shape[0], W.shape[1]), dtype=torch.float32)
    for e in expert_of_row.unique().tolist():
        idx = (expert_of_row == e).nonzero().flatten()
        out[idx] = x_rows[idx].float() @ W[e].T
    return out


def moe_ref(x, topk_ids, topk_w, w13, w2, fmt13="nvfp4", fmt2="nvfp4", softcap=None):
    """x [T, H] bf16; w13/w2 are (packed, scale, gscale) tuples. Returns bf16 [T, H]."""
    T, H = x.shape
    k = topk_ids.shape[1]
    W13 = dequant(fmt13, *w13)
    W2 = dequant(fmt2, *w2)
    rows = x.repeat_interleave(k, dim=0)                      # [T*k, H], row t*k+j
    eids = topk_ids.reshape(-1).long()
    h = grouped_gemm_ref(rows, eids, W13).to(torch.bfloat16)  # kernel stores bf16
    a = swiglu(h.float(), softcap).to(torch.bfloat16)
    y = grouped_gemm_ref(a, eids, W2)                          # fp32
    y = (y * topk_w.reshape(-1, 1).float()).to(torch.bfloat16).float()
    y = y.view(T, k, H)
    acc = torch.zeros((T, H), dtype=torch.float32)
    for j in range(k):                                         # fixed combine order
        acc = acc + y[:, j]
    return acc.to(torch.bfloat16)
