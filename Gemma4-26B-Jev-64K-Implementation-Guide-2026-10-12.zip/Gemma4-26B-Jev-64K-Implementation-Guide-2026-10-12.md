# Gemma-4-26B-A4B native Jev (Kairos) at 64K — implementation guide (2026-10-12)
Code: `gemma26b-jev-64k-impl/`. Everything here is **additive and config-flagged on top of the current Kairos trainer**: the forward pass and the choice-invariant head are NOT changed. With all new flags at 0 the run is the current run. Numbers marked *(est.)* are estimates; others come from the run log.

## Minimal diff against current train.py
```diff
+from kairos_loss import kairos_loss, ref_logits_lora_disabled          # new file, additive
 ...
     logits, task = net(packed)                                          # UNCHANGED forward + head
-    loss = F.cross_entropy(logits, labels)
+    ref = ref_logits_lora_disabled(net, packed) if cfg.loss.kl_w > 0 else None   # ALL ranks (collective under ZeRO-3)
+    loss = kairos_loss(logits, labels, task, cfg.loss, ref)              # flags=0 -> identical F.cross_entropy
 ...
-    if rank == 0:
-        dev = evaluate(net, dev_set)                                     # Failure #8: deadlock under ZeRO-3
-    dist.barrier()
+    assert cfg.zero_stage == 3
+    dev = evaluate(net, dev_set)                                         # all ranks; deterministic -> same value
     if dev > best:
-        if rank == 0: save(net, out/"best")
+        save(net, out/"best")                                            # all ranks gather, rank 0 writes, safe_barrier()
 ...
-    dist.destroy_process_group()
-    save(net, out/"last")
-    ... rank-0 calibrate/test block ...
-    else: dist.barrier()                                                 # train.py:406 crash
+    save(net, out/"last")                                                # BEFORE teardown
+    if cfg.stage2.enabled: ...                                           # optional, off by default (s11)
+    safe_teardown()                                                      # if initialized: barrier(); destroy -- last call
```
New config keys (all default 0/false): `loss.label_smoothing`, `loss.brier_w`, `loss.kl_w`, `loss.ordinal_eps`, `stage2.enabled`. Calibration/certification moves to a separate single-GPU job (`calibrate.py`). Proven on CPU: flags=0 gives a loss **bit-identical** to `F.cross_entropy` with identical gradients; with the flags on, the loss is invariant to option permutation (|diff| 0.0) (`tests/test_flags.py`).
Note: the codebase's existing `kl` term (CE + KL from the run) stays as-is; `loss.kl_w` is only for the new frozen-base KL. If yours already computes the same thing, keep it and leave `kl_w=0`.

## 0. TL;DR + architecture recap
- Model: Gemma-4-26B-A4B text stack (hidden 2816), 25.30B params, experts 22.84B frozen, 63.80M trainable (LoRA q/k/v/o/gate/up/down + norms + fp32 head). One forward pass over [state][q][options][ANS]..., options share start positions and are mutually invisible, bilinear fp32 head `a_proj·c_proj/√d`, `masked_fill(-inf)`, log_softmax. Measured permutation error at K=255: 0.000e+00.
- Training: DeepSpeed ZeRO-3, 3 ranks (pod-RAM bound), max_len 65,536, 74.6 GB/rank, 81–99 s/step, seqs_per_epoch 7000, long-source weight 0.40.
- Diagrams: `diagrams/kairos-jev-arch/fig1-one-forward-pass.png`, `fig2-where-one-pass-not-used.png`, `fig3-training-stages.png`.
- **The gate that matters:** native 26B must be compared with the **prompted 26B's 0.900** on the same 200 item_ids. L1c E4B got 0.215 against 0.500 for a prompted E2B, which is a recipe gap. Don't spend 64K compute until the native 26B is near 0.900 at ≤8K.

## 1. Prerequisites / hardware / env pins
- Train: 3× 80 GB (H100/H800) with the current pod RAM limit (104 GiB). Go to 4–5 ranks only after the mmap cache (s4). Serve: 1× H100 (tight) or H200.
- Pins: use the versions from the run that reached step 25. I don't have the exact pins, so freeze them with `pip freeze > pins.txt` in the pod.
  - torch ≥ 2.5 (flex_attention + BlockMask).
  - transformers with `gemma4`/`Gemma4TextModel` support (the version that loaded `/drafter/gemma-4-26b-a4b-it`).
  - peft (LoRA).
  - deepspeed: the release in the pod asserts a single dtype for trainables (`zero/utils.py:217`, defect 7). **PR #8113** adds mixed fp32/bf16 trainables. Only on a release that contains it can you stop promoting LoRA to fp32, and you must verify that before changing it.
- Attention: `attn_implementation="flex_attention"` with the two-mask path (25 sliding layers with window 1024 + 5 full layers, as run). SDPA with a dense mask needs about 90 GiB at 64K.

## 2. Model loading, LoRA, frozen experts, fp32 head (`model.py`, template; reuse your `wrap()`)
- Defect 1: load with `AutoModelForCausalLM`, take `.model.language_model` (Gemma4TextModel) and pass it to the existing `wrap()`. `AutoModel`/`AutoConfig` give `hidden_size=None`.
- Don't target experts: they are an `nn.Parameter` that peft can't target, so they stay frozen. `check_experts_frozen()` asserts 0 trainable.
- Defect 7: `promote_trainables_fp32()` promotes 271 bf16 trainables (~128 MB); the head stays fp32.
- Defect 2: call `net.train()` so gradient checkpointing actually engages.
- Defect 5: no `init_from` from E4B (shape [32,2560] vs 2816).

## 3. Packing / 64K input format (`pack.py` = the existing reference head and packer, unchanged)
- Layout: state (positions 0..S-1), then for each question: q text, options all starting at the same position p0, then the ANS slot. Question blocks restart at S and can't see each other, so packed equals separate (max err 1.6e-7).
- Noul = ["No","Yes"]; Score = "i: level".
- **Refuse, never truncate:** `pack()` raises if L > max_len (`truncated must be 0`). The data builder must budget the state, not cut it.
- At 64K, build the flex `BlockMask` from segment ids and positions; don't materialise L×L (a 64K² bool mask is 4 GiB).

## 4. Data pipeline (`jev-64k-recipe/build_long_context.py`, `teacher_label.py`; docs `Jev-64K-*`)
- Sources:
  - About 245k short Jev rows (replay).
  - About 17.5k long rows: `llmops_voice_64k` (weight 0.22), `open:otel_safety` (0.10), `churn_long64k` (0.08). Long weight in total 0.40; the long rows are 82% of the tokens.
- Long-row synthesis:
  - Same-domain distractor docs.
  - Evidence at start/middle/end.
  - Buckets 0–8K / 8–32K / 32–64K.
  - Hard-negative options from 2 up to 255.
  - Dedupe and contamination check against the eval.
  - Null/abstain rows: evidence removed, gold = "No"/none. This teaches a confident-wrong-free chunk head.
- Labels: gold first. Teacher labels from gemini-3.7-flash / bedrock-gemma-4-26b-a4b are kept only where they agree with gold.
- **mmap cache (`mmap_cache.py`):** tokenise once into `tokens.u32 + index.npy`. Every rank memory-maps the same files and reads a disjoint shard. This removes the "ranks × corpus" pod-RAM wall (defects 4/6: 103/104 GiB). Tested on CPU.

## 5. Loss (`kairos_loss.py`, `losses.py`)
- The defaults reproduce today's run. Recommended stage-1 values *(start; tune on dev)*: `label_smoothing 0.05, brier_w 0.5, ordinal_eps 0.1, kl_w 0.02` (or reuse the existing KL).
- Smoothing goes only onto valid options. KL masks before subtracting (an earlier version gave NaN gradients).
- Ordinal targets assume level order, so never shuffle Score levels.
- Cost of `kl_w>0` with the LoRA-disabled ref: one extra no-grad 64K forward per step, about +30–45% step time *(est.)*. Under ZeRO-3 it must run on all ranks. Cheaper option: cache ref logits offline once per row.
- Why not RL here: OpenJev-RLCD (arXiv 2609.38850) shows that for a direct scorer, RLCD's expected gradient equals the Brier loss, and RLCD didn't beat CE on CLINC150. Clef and Unsloth both ship exactly LS-CE + Brier (+ ordinal).

## 6. DeepSpeed ZeRO-3 + launcher + loop
- Config: `configs/ds_zero3.json` (stage 3, bf16, micro-batch 1, grad accumulation 8, clip 1.0).
- Launch: `deepspeed --num_gpus 3 train.py --deepspeed configs/ds_zero3.json` (your existing launcher). Set `NCCL_ASYNC_ERROR_HANDLING=1`. Keep the 600 s watchdog: raising it would only turn a 10-minute deadlock into a 2-hour one.
- Loop rules (`reference/train_zero3_reference.py`, `PATCH.md`):
  1. Eval runs on all ranks.
  2. `save()` = gather on all ranks, rank 0 writes via tmp + atomic rename, then `safe_barrier()`.
  3. `save(last)` happens before teardown.
  4. `safe_teardown()` is called exactly once, last.
  5. Every barrier is guarded by `dist.is_initialized()`.
  6. `assert zero_stage==3` wherever this logic depends on it.
- Resume: add `engine.save_checkpoint(out/"ds", tag=f"step{n}")` on all ranks every N steps (today `last/` has no optimizer state). Export with `zero_to_fp32.py`.

## 7. Smoke test (~45 min *(est.)*)
`seqs_per_epoch 100, eval_every 10, max_len 65536`, flags at the values you'll run. Pass only if all of these hold:
1. A dev event appears at step 10 and training continues.
2. `best/` is written only by rank 0, once per improvement.
3. `last/` is about 240 MB and rescoring with `score_single`-style loading gives the same score.
4. All ranks exit 0.
5. Loss is finite and the nonfinite count is 0.
6. With all flags at 0, step-1 loss equals the previous run's step-1 loss for the same seed.

## 8. Full run plan
- At 81–99 s/step on 3 ranks, `seqs_per_epoch 7000` is about 875 steps at accumulation 8 *(depends on your batch definition)*, roughly 20–24 h *(est.)*. The full 4,565-step epoch is about 125 h, which isn't viable.
- Order:
  1. **A. Recipe check at ≤8K first (cheap):** about 300–500 steps with flags on, then run the s10 eval against 0.900. If the gap is more than 10 points, stop and diagnose.
  2. **B. Direct 64K with short replay:** 0.40 long + 0.60 short, which is what's running. A curriculum of 16K→32K→64K is an option if 64K loss is unstable.
- Checkpoints: `best/` on dev improvement, `ds/` every 100 steps, `last/` always.

## 9. Single-GPU calibrate + test job (`calibrate.py`)
1. Load the base + `last/` trainables on one GPU and dump per-question logits for the calib and test splits.
2. Fit a temperature per (type × length bucket: ≤8k, 8–16k, 16–32k, 32–64k), minimising ECE (strands-decider found NLL-fit left Noul under-confident).
3. Report acc / ECE / Brier / NLL / AUROC / AURC / Cov@ε for each slice.
4. LTT (fixed sequence, exact binomial) certifies θ per slice. An uncertified slice escalates everything (fail closed).

## 10. The decisive eval (`eval_compare.py`)
- Compare native_26b vs prompted_26b (0.900) vs l1c_e4b (0.215) vs prompted_e2b (0.500) on **identical item_ids**, with a paired McNemar test plus type × bucket slices.
- Rules:
  - Gap ≥ −2 pts: proceed to calibration and 64K slices.
  - −2 to −10: run the diagnostic before any more compute: prompted base vs LoRA-without-head vs head-only.
  - Below −10: stop scaling; the recipe is the problem.
- After that, compare 64K single-pass vs chunked map-reduce per bucket.

## 11. Optional stage 2 (`stage2.enabled`, off by default)
`losses.stage2_selective_reinforce`: sample answers from the option softmax, reward +1 / −c_wrong when answering at conf≥θ, −c_esc when escalating. Uses a leave-one-out baseline, a Brier anchor and KL to the stage-1 model. Only start from a converged stage 1 (in the paper, policy gradient from scratch made things worse). Enable it only if Cov@ε at the certified θ is the KPI, and expect small gains.

## 12. Serving at 64K on 1 GPU — see `gemma26b-jev-64k-impl/SERVING.md`
- Footprint: bf16 50.7 GB + flex_attention, prefill only.
- Latency: about 3–6 s per 64K decision on H100 *(est.)*.
- Endpoint and routing: `/v1/systemone`, with a router that fails closed on certified θ per slice. Chunked map-reduce (0.80 floor) handles inputs above 16K until native 64K wins.

## 13. Troubleshooting
| Symptom | Cause | Fix |
|---|---|---|
| `hidden_size None` / embedding size error | 1: AutoModel on a multimodal checkpoint | AutoModelForCausalLM → text stack → wrap() |
| OOM 77.9 GB | 2: no `net.train()`, so grad checkpointing is off | call `net.train()` |
| 64K **and** 32K backward OOM | 3: ~28 GB fixed MoE overhead | ZeRO-3 |
| pod RAM 103/104 GiB at 5 or 4 ranks | 4/6: every rank tokenises the whole corpus | 3 ranks now; mmap cache to go back to 4–5 |
| shape [32,2560] vs 2816 | 5: stale `init_from` E4B | remove |
| `zero/utils.py:217` dtype assert | 7: mixed-dtype trainables | promote LoRA/norms to fp32 (or PR #8113) |
| NCCL ALLREDUCE NumelIn=1 timeout, 600 s after eval step | 8: rank-0-only eval/save under ZeRO-3 | eval/save on all ranks, rank 0 writes |
| ranks 1–2 `Default process group has not been initialized` after `last/` | leftover `else: dist.barrier()` after destroy (train.py:406) | delete it; `safe_teardown()` last |
| NaN grads with KL | `-inf - -inf` on masked options | mask before subtracting (fixed in losses.py) |
| 64K OOM in attention | SDPA dense mask (~90 GiB) | flex_attention BlockMask |
| silent bad 64K scores | truncation | `pack()` refuses; check `truncated=0` |

## 14. Timeline & GPU-hours (est.)
| Step | Wall | GPU-h |
|---|---|---|
| Patch + CPU tests | 0.5 day | 0 |
| Smoke (s7) | 1 h | 3 |
| ≤8K recipe check + eval vs 0.900 | 0.5–1 day | 30–60 |
| 64K run (7000 seqs) | ~1 day | 60–75 |
| Calibrate/LTT + compare | 2–4 h | 3–5 |
| Optional stage 2 | 0.5–1 day | 30–60 |

## Test results (CPU, `gemma26b-jev-64k-impl/TEST-OUTPUT.txt`)
26 PASS lines covering:
- flags=0 bit-identical CE and gradients.
- Permutation invariance with flags on.
- Calibrated loss and stage 2 run.
- ds config valid; over-length refused.
- Temperature fit per bucket recovers T≈3.4–4.1 (true 3).
- LTT fails closed.
- eval_compare flags a recipe gap.
- mmap shards.
- 11 head tests: permutation err 2.7e-7 at K=255, packed == separate.
- Both ZeRO-3 bugs reproduced.
- Fixed 3-rank trainer exits 0 and reloads to the same score.

These use a stand-in model, not Gemma or DeepSpeed.

## Uncertain
- Exact pins and current `train.py` (diff is against the structure in the log).
- PR #8113 release.
- Cost of the LoRA-disabled ref forward at 64K.
- Serving latency.
- Steps per 7000 sequences.
- LTT coverage on real data. In the synthetic test, coverage was 0 at ε=0.2.
