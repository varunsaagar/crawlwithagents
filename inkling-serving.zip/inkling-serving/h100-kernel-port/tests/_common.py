import os, torch
DEVICE = "cuda" if torch.cuda.is_available() and os.environ.get("TRITON_INTERPRET") != "1" else "cpu"
# Small shapes by default so the CPU interpreter finishes; INKLING_SHAPES=1 uses Mini's real
# expert shapes (H=2304, I=1152, E=128, top-8) - intended for GPU runs.
if os.environ.get("INKLING_SHAPES") == "1":
    E, H, I, TOPK = 128, 2304, 1152, 8
else:
    E, H, I, TOPK = 8, 128, 64, 2


def make_layer(fmt13="nvfp4", fmt2="nvfp4", seed=0):
    from kernels.formats import random_nvfp4, random_mxfp8
    g = torch.Generator().manual_seed(seed)
    mk = {"nvfp4": random_nvfp4, "mxfp8": random_mxfp8}
    w13 = mk[fmt13](E, 2 * I, H, g)
    w2 = mk[fmt2](E, H, I, g)
    mv = lambda t: tuple(x.to(DEVICE) for x in t)
    return mv(w13), mv(w2)


def make_tokens(T, seed=1):
    from kernels.reference import route
    g = torch.Generator().manual_seed(seed)
    x = (torch.randn((T, H), generator=g) * 0.5).to(torch.bfloat16)
    logits = torch.randn((T, E), generator=g)
    w, ids = route(logits, TOPK, scale=8.0)
    return x.to(DEVICE), ids.to(DEVICE), w.to(DEVICE)
