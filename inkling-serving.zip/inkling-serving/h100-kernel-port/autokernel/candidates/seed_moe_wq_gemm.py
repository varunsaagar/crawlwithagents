"""Starter Triton kernel: dequant-fused grouped MoE GEMM for Hopper (sm_90), BF16 activations.

Weights stay in their checkpoint format (NVFP4 e2m1 + E4M3 block-16 scales + fp32 global
scale, or MXFP8 e4m3 + UE8M0 block-32 scales) and are dequantised in registers to BF16
right before `tl.dot` (W4A16 / W8A16). Hopper has no FP4 tensor cores, so this is the
exact-numerics path: e2m1*e4m3 and e4m3*2^k are exactly representable in BF16, and the
fp32 global scale is applied in the fp32 epilogue.

Fusions: gather of the token row (permute) on load, global scale and optional routing
weight in the epilogue, scatter (un-permute) on store.

Determinism discipline (borrowed from RightNow AI's B300 work, adapted):
  * no split-K, no stream-K, no atomics: each output tile owns its full K reduction;
  * K is walked in one fixed order with a fixed BLOCK_K;
  * tile config is a constant, never chosen from the batch size (that is what breaks
    batch invariance in most autotuned kernels);
  * top-k combine happens outside, in fixed j order, in fp32.

STATUS: validated only under TRITON_INTERPRET=1 on CPU (fp32-dot fallback, see INTERPRET). NOT compiled or run on a GPU.
Performance is unknown; on H100 expect to need wgmma-friendly layouts (pre-shuffled
weights, TMA, warp specialisation) before this competes with Humming or Marlin.
"""
import os
import torch
import triton
import triton.language as tl

# Constant tile config (do NOT autotune per batch size if you want batch invariance).
BLOCK_M = 16
BLOCK_N = 64
BLOCK_K = 64

# The Triton CPU interpreter (3.9) mis-handles in-kernel fp32->bf16 casts (verified on box:
# tl.dot after .to(bf16) returns garbage). Under the interpreter we therefore dot in fp32 and
# round to bf16 in torch. Products are identical (the dequantised weights and bf16 inputs are
# exactly representable), so only the hardware path (bf16 wgmma, fp32 accumulate) differs.
INTERPRET = os.environ.get("TRITON_INTERPRET") == "1"


@triton.jit
def _pow2_int(e):
    # exact 2**e for integer e in normal fp32 range, via exponent bits (no ex2.approx)
    return ((e + 127) << 23).to(tl.float32, bitcast=True)


@triton.jit
def _e2m1_to_f32(c):
    c = c.to(tl.int32)
    s = (c >> 3) & 1
    e = (c >> 1) & 3
    m = (c & 1).to(tl.float32)
    mag = tl.where(e == 0, m * 0.5, (1.0 + 0.5 * m) * _pow2_int(e - 1))
    return tl.where(s == 1, -mag, mag)


@triton.jit
def _e4m3fn_to_f32(u):
    u = u.to(tl.int32)
    s = (u >> 7) & 1
    e = (u >> 3) & 15
    m = (u & 7).to(tl.float32)
    normal = (1.0 + m * 0.125) * _pow2_int(e - 7)
    sub = m * 0.001953125  # m/8 * 2^-6 = m * 2^-9
    v = tl.where(e == 0, sub, normal)
    return tl.where(s == 1, -v, v)


@triton.jit
def _ue8m0_to_f32(u):
    return _pow2_int(u.to(tl.int32) - 127)


@triton.jit
def moe_wq_gemm_kernel(
    A, C, Wq, Ws, Wg, TW, sorted_ids, block_expert,
    N, K,
    stride_am, stride_cm,
    stride_we, stride_wn, stride_se, stride_sn,
    A_ROW_DIV: tl.constexpr, MUL_W: tl.constexpr, IS_NVFP4: tl.constexpr,
    LOWP: tl.constexpr,
    BM: tl.constexpr, BN: tl.constexpr, BK: tl.constexpr,
):
    pid_m = tl.program_id(0)
    pid_n = tl.program_id(1)
    e = tl.load(block_expert + pid_m).to(tl.int64)

    offs_m = pid_m * BM + tl.arange(0, BM)
    rid = tl.load(sorted_ids + offs_m)              # flattened (token, j) row id, -1 = pad
    valid = rid >= 0
    rid_safe = tl.where(valid, rid, 0).to(tl.int64)
    arow = rid_safe // A_ROW_DIV                    # fused permute: read x[t] directly

    offs_n = pid_n * BN + tl.arange(0, BN)
    nmask = offs_n < N
    acc = tl.zeros((BM, BN), dtype=tl.float32)

    for k0 in range(0, K, BK):                      # fixed order, full K, no split
        offs_k = k0 + tl.arange(0, BK)
        a = tl.load(A + arow[:, None] * stride_am + offs_k[None, :],
                    mask=valid[:, None] & (offs_k[None, :] < K), other=0.0)
        if IS_NVFP4:
            offs_kh = k0 // 2 + tl.arange(0, BK // 2)
            p = tl.load(Wq + e * stride_we + offs_n[:, None] * stride_wn + offs_kh[None, :],
                        mask=nmask[:, None], other=0)
            codes = tl.join(p & 0xF, p >> 4).reshape(BN, BK)   # low nibble = even k
            w = _e2m1_to_f32(codes)
            offs_g = k0 // 16 + tl.arange(0, BK // 16)
            s = tl.load(Ws + e * stride_se + offs_n[:, None] * stride_sn + offs_g[None, :],
                        mask=nmask[:, None], other=0)
            sf = _e4m3fn_to_f32(s)
            sf = tl.reshape(tl.broadcast_to(sf[:, :, None], (BN, BK // 16, 16)), (BN, BK))
        else:
            p = tl.load(Wq + e * stride_we + offs_n[:, None] * stride_wn + offs_k[None, :],
                        mask=nmask[:, None], other=0)
            w = _e4m3fn_to_f32(p)
            offs_g = k0 // 32 + tl.arange(0, BK // 32)
            s = tl.load(Ws + e * stride_se + offs_n[:, None] * stride_sn + offs_g[None, :],
                        mask=nmask[:, None], other=127)
            sf = _ue8m0_to_f32(s)
            sf = tl.reshape(tl.broadcast_to(sf[:, :, None], (BN, BK // 32, 32)), (BN, BK))
        if LOWP:
            wt = (w * sf).to(tl.bfloat16)           # exact in BF16 (see module docstring)
            acc += tl.dot(a, tl.trans(wt))
        else:                                       # interpreter path, same products
            acc += tl.dot(a.to(tl.float32), tl.trans(w * sf))

    acc = acc * tl.load(Wg + e)                     # fp32 per-expert global scale
    if MUL_W:
        tw = tl.load(TW + rid_safe, mask=valid, other=0.0)
        acc = acc * tw[:, None]
    if LOWP:
        acc = acc.to(tl.bfloat16)
    tl.store(C + rid_safe[:, None] * stride_cm + offs_n[None, :], acc,
             mask=valid[:, None] & nmask[None, :])  # fused un-permute


def align_rows(topk_ids: torch.Tensor, num_experts: int, block_m: int = BLOCK_M):
    """Stable sort of flattened (token, j) rows by expert, each segment padded to block_m.
    Prototype in torch; production needs a GPU kernel (cf. vLLM moe_align_block_size).
    Deterministic: stable sort, so row order inside an expert never depends on timing."""
    flat = topk_ids.reshape(-1).to(torch.int64).cpu()
    order = torch.argsort(flat, stable=True)
    counts = torch.bincount(flat, minlength=num_experts).tolist()
    ids, blocks, start = [], [], 0
    for e, c in enumerate(counts):
        if c == 0:
            continue
        seg = order[start:start + c]
        start += c
        pad = (-c) % block_m
        ids.append(torch.cat([seg, torch.full((pad,), -1, dtype=torch.int64)]))
        blocks += [e] * ((c + pad) // block_m)
    dev = topk_ids.device
    return (torch.cat(ids).to(torch.int32).to(dev),
            torch.tensor(blocks, dtype=torch.int32, device=dev))


def moe_wq_gemm(a, w, fmt, sorted_ids, block_expert, num_rows, a_row_div, topk_w=None):
    """a: [*, K] bf16; w = (packed, scale, gscale). Returns bf16 [num_rows, N] (un-permuted)."""
    packed, scale, gscale = w
    N = packed.shape[1]
    K = a.shape[1]
    assert K % BLOCK_K == 0, "pad K to a multiple of BLOCK_K"
    a = a.contiguous()
    c = torch.zeros((num_rows, N), dtype=torch.float32 if INTERPRET else torch.bfloat16,
                    device=a.device)
    tw = topk_w.reshape(-1).float().contiguous() if topk_w is not None else gscale
    grid = (block_expert.numel(), triton.cdiv(N, BLOCK_N))
    moe_wq_gemm_kernel[grid](
        a, c, packed, scale, gscale, tw, sorted_ids, block_expert,
        N, K, a.stride(0), c.stride(0),
        packed.stride(0), packed.stride(1), scale.stride(0), scale.stride(1),
        A_ROW_DIV=a_row_div, MUL_W=topk_w is not None, IS_NVFP4=(fmt == "nvfp4"),
        LOWP=not INTERPRET, BM=BLOCK_M, BN=BLOCK_N, BK=BLOCK_K,
    )
    return c.to(torch.bfloat16)


def swiglu(h, softcap=None):
    # gate first, then up (layout assumption; Inkling interleaves gate/up rows in w13)
    g, u = h.chunk(2, dim=-1)
    if softcap is not None:
        g = softcap * torch.tanh(g / softcap)
    return torch.nn.functional.silu(g) * u


def fused_moe_wq(x, topk_ids, topk_w, w13, w2, fmt13="nvfp4", fmt2="nvfp4", softcap=None):
    """Two-GEMM MoE: w13 (gather fused) -> SwiGLU (torch for now) -> w2 (routing weight +
    scatter fused) -> fixed-order fp32 combine. Returns bf16 [T, H]."""
    T, H = x.shape
    k = topk_ids.shape[1]
    E = w13[0].shape[0]
    sorted_ids, block_expert = align_rows(topk_ids, E)
    h = moe_wq_gemm(x, w13, fmt13, sorted_ids, block_expert, T * k, a_row_div=k)
    act = swiglu(h.float(), softcap).to(torch.bfloat16)        # TODO: fuse into w13 epilogue
    y = moe_wq_gemm(act, w2, fmt2, sorted_ids, block_expert, T * k, a_row_div=1, topk_w=topk_w)
    y = y.float().view(T, k, H)
    acc = torch.zeros((T, H), dtype=torch.float32, device=x.device)
    for j in range(k):                                           # fixed combine order
        acc = acc + y[:, j]
    return acc.to(torch.bfloat16)
