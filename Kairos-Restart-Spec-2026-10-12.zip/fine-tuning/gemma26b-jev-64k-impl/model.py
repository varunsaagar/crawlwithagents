"""Gemma-4-26B-A4B -> Kairos native Jev model (GPU template; not runnable on the CPU box).
Encodes run-log fixes: defect 1 (load via AutoModelForCausalLM, take the text stack),
defect 2 (net.train() so grad-checkpointing engages), defect 7 (ZeRO-3 single-dtype trainables:
promote LoRA/norm trainables to fp32, keep head fp32), experts frozen (22.84B, not LoRA-targetable)."""
import torch, torch.nn as nn
from pack import JevHead, readout

LORA_TARGETS = ["q_proj", "k_proj", "v_proj", "o_proj", "gate_proj", "up_proj", "down_proj"]

def load_backbone(path="/drafter/gemma-4-26b-a4b-it", attn="flex_attention"):
    from transformers import AutoModelForCausalLM
    full = AutoModelForCausalLM.from_pretrained(path, torch_dtype=torch.bfloat16, attn_implementation=attn)
    lm = getattr(full, "model", full)
    text = getattr(lm, "language_model", lm)          # Gemma4TextModel, hidden 2816
    assert text.config.hidden_size == 2816, text.config.hidden_size
    del full.lm_head                                    # no LM head: never decode
    return text

def add_lora(text, r=32, alpha=64, dropout=0.0):
    from peft import LoraConfig, get_peft_model
    cfg = LoraConfig(r=r, lora_alpha=alpha, lora_dropout=dropout, target_modules=LORA_TARGETS, bias="none")
    m = get_peft_model(text, cfg)
    for n, p in m.named_parameters():               # train norms too (as in the run: 271 norm tensors)
        if "norm" in n and "experts" not in n: p.requires_grad_(True)
    return m

def check_experts_frozen(m):
    ex = [(n, p) for n, p in m.named_parameters() if "experts" in n]
    tot = sum(p.numel() for _, p in ex); tr = sum(p.numel() for _, p in ex if p.requires_grad)
    assert tr == 0, f"expert params trainable: {tr}"
    return tot

def promote_trainables_fp32(m):
    """Defect 7: ZeRO-3 flattens trainables into ONE buffer and asserts one dtype (zero/utils.py:217).
    Promote bf16 trainables (LoRA, norms; ~63.8M params, ~128MB extra) to fp32 rather than downcasting the head.
    On a DeepSpeed release containing PR #8113 (mixed-dtype trainables) this may be unnecessary -- verify first."""
    n = 0
    for p in m.parameters():
        if p.requires_grad and p.dtype != torch.float32: p.data = p.data.float(); n += 1
    return n

class KairosJev(nn.Module):
    def __init__(s, text, hidden=2816, head_d=64, head_layers=1):
        super().__init__(); s.backbone = text; s.head = JevHead(hidden, d=head_d, layers=head_layers)
    def forward(s, packed):
        # packed["allowed"] [L,L] bool -> flex_attention BlockMask built by caller (see pack.to_block_mask notes)
        out = s.backbone(input_ids=packed["ids"][None], position_ids=packed["pos"][None],
                         attention_mask=packed["attn_mask"], use_cache=False)
        h = out.last_hidden_state[0]
        C, A, M, T = readout(h.float(), packed)
        return s.head(C.to(h.device), A, M.to(h.device), T.to(h.device)), T

def build(path, gc=True):
    text = load_backbone(path); m = add_lora(text)
    if gc: m.gradient_checkpointing_enable(gradient_checkpointing_kwargs={"use_reentrant": False})
    net = KairosJev(m); net.train()                    # defect 2
    experts = check_experts_frozen(net); promoted = promote_trainables_fp32(net)
    tr = sum(p.numel() for p in net.parameters() if p.requires_grad)
    assert all(p.dtype == torch.float32 for p in net.parameters() if p.requires_grad)
    print(f"experts frozen {experts/1e9:.2f}B | trainable {tr/1e6:.1f}M | promoted {promoted} tensors to fp32")
    return net
