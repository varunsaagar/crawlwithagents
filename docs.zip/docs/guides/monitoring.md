# Monitoring

A certified threshold is only valid while traffic and models look like the calibration data. jevjudge watches that in two independent ways:

| Signal | Needs | Detects | Action |
|---|---|---|---|
| [Drift statistics](#drift-statistics) (`grader.drift`) | nothing: every served verdict | confidence distribution shift, escalation-rate change, invalid outputs | alarm only (you decide) |
| [Accuracy monitor](#accuracy-monitor) (`grader.monitor`) | an audit slice judged by the fallback (`audit_rate > 0`) | Jev disagreeing with the fallback more than the certificate allows | **freezes** the unit: everything escalates |

Results then go out to your observability stack through [sinks](#sinks), and every report carries [per-stage timings](#per-stage-timings).

## Drift statistics

`jevjudge.calibration.drift_stats.DriftStats` keeps, per metric unit (`<rubric_id>/<criterion>`, verdict criteria only), a baseline window and a rolling current window of three signals:

| Statistic | Definition | Default alarm |
|---|---|---|
| `psi_q` | population stability index of the System One confidence `q` (10 bins on [0.5, 1]) between baseline and current window | `psi_q > 0.2` |
| `escalation_rate` | `{"baseline", "current"}` share of verdicts escalated for any reason; alarm on the relative change | `|current − baseline| / baseline > 0.30` |
| `valid_rate` | share of valid System One outputs in the current window (invalid always escalates) | `valid_rate < 0.999` |

The first `baseline_n` observations of a unit form its baseline, unless you load one with `set_baseline(unit, q, escalated, valid=None)`, for example from calibration data. After that, the last `window` observations form the current window. Statistics are reported once the current window has `min_window` observations (PSI also needs `min_window` valid `q` values on both sides).

```python
from jevjudge.calibration.drift_stats import DriftConfig

DriftConfig(baseline_n=500, window=500, psi_alarm=0.2, escalation_change_alarm=0.30, valid_floor=0.999, min_window=100)
```

The grader feeds `grader.drift` automatically on every `grade()` in `serve` mode, using the last System One answer of each verdict. Read it with:

```python
import random
from jevjudge.calibration.drift_stats import DriftConfig, DriftStats

rng = random.Random(0)
drift = DriftStats(DriftConfig())                 # what grader.drift holds
unit = "output_toxicity/agent_toxic"
for _ in range(500):                              # baseline: confident, about 5% escalations
    drift.observe(unit, q=rng.uniform(0.9, 1.0), escalated=rng.random() < 0.05, valid=True)
for _ in range(300):                              # shift: lower confidence, escalations double
    drift.observe(unit, q=rng.uniform(0.6, 0.95), escalated=rng.random() < 0.12, valid=True)

print(drift.alarms())                             # {'output_toxicity/agent_toxic': ['escalation_rate', 'psi_q']}
r = drift.report()[unit]                          # baseline_n, window_n, psi_q, escalation_rate, valid_rate, alarms
print(r["escalation_rate"], round(r["psi_q"], 2))
```

Where you see drift alarms:

* `jevjudge grade` prints `DRIFT ALARMS: {...}` after the batch;
* `GET /v1/projects/{id}/drift` returns `{"units": grader.drift.report()}` for the project's `/v1/judge` traffic;
* in code, `grader.drift.alarms()` or `grader.drift.report()`.

!!! note "Limits of the current wiring"
    * `CriterionGrader` always creates `DriftStats()` with the default `DriftConfig`, and there is no judge-YAML key for it. To change the thresholds, replace it: `grader.drift = DriftStats(DriftConfig(psi_alarm=0.1))`. Set `grader.drift = None` to turn it off.
    * State is in memory. `DriftStats(cfg, state_path=...)` plus `save()` writes the *report* as JSON, but nothing reloads it, so every new process (and every re-calibration on the Studio server, which rebuilds the grader) starts a new baseline.
    * When the baseline escalation rate is ~0 (≤ 2%, e.g. a unit Jev answers 100% of the time), the alarm uses an absolute change instead (`escalation_abs_alarm`, default 0.10).

Drift alarms do not change routing. Treat them as a prompt to look: a PSI alarm with a stable escalation rate is often a traffic-mix change. A rising escalation rate costs money. A falling valid rate usually means a backend is failing.

## Accuracy monitor

`jevjudge.calibration.monitor.AccuracyMonitor` guards accuracy itself. A deterministic `audit_rate` share of *accepted* verdicts is also judged by System Two. Each audit gives `x = 1[System One disagreed with the fallback]` for the unit `<rubric>/<criterion>@<type>`.

* **Alarm.** A betting e-process tests H0: E[x] ≤ ε, where ε is the certificate's `monitor_eps` if it has one, else `MonitorConfig.eps`. When the e-value reaches 1/α, the unit is **frozen**. Every later item of the unit goes straight to System Two with `escalation_reason: drift_freeze`, in every [migration phase](governance.md#migration-phases).
* **Tighten-only θ.** Between re-certifications, an ACI controller can raise the served θ above the certified one, never below.
* **Shared state.** With `state_path`, freezes and wealth persist to JSON, so a batch job and a service agree.

### Detector: `cusum` vs `cumulative`

`MonitorConfig.detector` selects how the evidence accumulates:

| `detector` | Wealth update | Detection delay | False alarms |
|---|---|---|---|
| `cusum` (default) | restarts: `W ← max(W, 1) · (1 + λ(x − ε))` (e-detector, Shin, Ramdas & Rinaldo 2022) | does not grow with healthy history | controlled in average-run-length terms (ARL ≥ 1/α) |
| `cumulative` | `W ← W · (1 + λ(x − ε))`, never restarted | grows with the length of the healthy period before the shift | anytime-valid type-I control: P(any false alarm) ≤ α |

In both cases the wealth is tracked for each bet λ ∈ {0.5, 1, 2, 4, 8} with λ < 1/ε, and the e-value is the mean over bets. The alarm fires when it reaches 1/α.

The cumulative test spends a long healthy period building up evidence *against* an alarm, so it reacts slowly to a regression that starts late. That is why `cusum` is the default. Use `cumulative` when a false freeze is very expensive and regressions are expected early.

```python
import random
from jevjudge.calibration.monitor import AccuracyMonitor

def audits_until_alarm(detector: str, healthy: int = 5000, seed: int = 1) -> int:
    rng = random.Random(seed)
    mon = AccuracyMonitor(eps=0.05, alpha=0.01, detector=detector)
    for i in range(20000):
        rate = 0.01 if i < healthy else 0.15      # audit disagreement jumps from 1% to 15%
        if mon.observe("output_pii/pii_exposed@noul", disagree=rng.random() < rate):
            return i - healthy

print(audits_until_alarm("cusum"), audits_until_alarm("cumulative"))     # 95 3124
```

### Configure and operate

```yaml
escalation:
  audit_rate: 0.05                # the monitor only learns from audited, accepted verdicts
monitor:
  enabled: true
  eps: 0.05                       # tolerance when the certificate has no monitor_eps
  alpha: 0.01                     # alarm level
  aci_gamma: 0.02                 # tighten-only θ step
  detector: cusum                 # cusum | cumulative
  state_path: registry/monitor_state.json   # relative to the YAML file; put it on shared storage
```

| Call | Use |
|---|---|
| `monitor.summary()` | per unit: `n` audits, `disagree_rate`, `frozen`, `fired_at` |
| `monitor.is_frozen(unit)` | the router's check |
| `monitor.reset(unit)` | unfreeze, after a new certificate is approved |

To unfreeze a unit: re-certify on fresh data, approve the certificate ([Governance](governance.md#certificate-lifecycle)), then call `reset(unit)`. There is no HTTP endpoint for `reset`. Use Python against the shared `state_path`, then restart or reload the serving processes. Each process loads the state file at start-up and then keeps its own copy in memory.

!!! warning "Label-free limits"
    The monitor measures disagreement with the fallback, not errors. When the fallback is weak on a metric (Gemini on hallucination), the certificate's tolerance is too loose to be useful. Back such metrics with the [human review queue](review-queue.md) `audit` slice.

### Alarms to set up

| Alert on | Source | Meaning |
|---|---|---|
| any unit frozen | `monitor.summary()`, or `jev.escalation.reason = drift_freeze` events | accuracy regression: re-certify |
| `jev.escalation.reason = uncertified` rate | OTel events | certificate expired, rubric edited, tier renamed, or new stratum |
| `jev.policy.source` changes | OTel events | phase change or certificate rollover (see [Governance](governance.md)) |
| `grader.drift.alarms()` non-empty | CLI output, `/v1/projects/{id}/drift` | traffic or model shift: investigate |
| `review_queue` `judge_human_agreement` on `audit` items | `ReviewQueue.stats()` | live accuracy against people |

## Sinks

Every report can be written to several destinations at once. A sink is a callable `sink(report)` that you pass to `grade_many(on_result=...)`, or that the CLI builds from `emit:` in the judge YAML.

| `emit:` value | Sink | Writes |
|---|---|---|
| `jsonl` | `otel.emit.JsonlSink(path)` | one line per subject with the `gen_ai.evaluation.result` events (`--out`) |
| `otel` | `otel.emit.OtelSink(tracer_provider=None)` | an `evaluation` span per subject on the global (or given) TracerProvider |
| `langfuse` | `otel.sinks.LangfuseSink(host=None, public_key=None, secret_key=None)` | one Langfuse score per criterion |
| `phoenix` | `otel.sinks.PhoenixSink(host=None, api_key=None)` | span annotations on the subject span |
| `cmcs` | CMCS blob lines | `{"session_id", "metrics"}` to `--cmcs`, or `<out>.blob.jsonl` |

```yaml
emit: [jsonl, langfuse, cmcs]    # used by `jevjudge grade`
```

### Langfuse

`LangfuseSink` posts to `{host}/api/public/scores` with basic auth. One score per criterion with a valid final answer:

* `name` is `<rubric_id>.<criterion>`. Noul questions are `NUMERIC` scores with value P(true). Choice and Score questions are `CATEGORICAL` with the label;
* `traceId` is the subject's trace id (or the subject id), and `observationId` is its span id;
* `comment` is the deterministic reason (verdict criteria);
* `metadata` holds `probabilities`, `confidence`, `decision`, `final_source`, `rubric_revision`, `threshold` and `backend`.

Configuration comes from the arguments or from `LANGFUSE_HOST` (default `http://localhost:3000`), `LANGFUSE_PUBLIC_KEY` and `LANGFUSE_SECRET_KEY`.

### Phoenix

`PhoenixSink` posts all of a report's criteria in one request to `{host}/v1/span_annotations`. `annotator_kind` is `CODE` when System One answered and `LLM` when System Two did. It needs the subject's span id (`report.meta["span_id"]`, from OTLP input or `Session.span_id`). Reports without one are skipped with a warning. Configuration: `PHOENIX_HOST` (default `http://localhost:6006`) and `PHOENIX_API_KEY` (sent as a bearer token).

Both sinks are fire-and-forget. HTTP failures are logged on the `jevjudge.sinks` logger and never raised, and each call returns the number of objects written. The example below runs offline with an `httpx.MockTransport`:

```python
import asyncio
import httpx
from jevjudge import CriterionGrader, EscalationConfig, Session, preset
from jevjudge.backends.mock import MockBackend
from jevjudge.otel.sinks import LangfuseSink, PhoenixSink

posted = []
def fake_server(request: httpx.Request) -> httpx.Response:
    posted.append(request.url.path)
    return httpx.Response(200, json={})

langfuse = LangfuseSink(host="http://langfuse.local", public_key="pk", secret_key="sk",
                        transport=httpx.MockTransport(fake_server))
phoenix = PhoenixSink(host="http://phoenix.local", transport=httpx.MockTransport(fake_server))

grader = CriterionGrader([MockBackend("jev")], EscalationConfig(judges=[], threshold=0.0))
session = Session.from_turns("s1", [{"speaker": "user", "text": "hi"}, {"speaker": "agent", "text": "Hello!"}],
                             trace_id="4bf92f3577b34da6a3ce929d0e0e4736", span_id="00f067aa0ba902b7")
asyncio.run(grader.grade_many([session], preset("voice"), on_result=lambda rep: (langfuse(rep), phoenix(rep))))
print(len(posted), posted[0], posted[-1])        # 12 /api/public/scores /v1/span_annotations
```

For OTLP-native backends (an OpenTelemetry collector, Galileo), use `OtelSink` instead. See [OpenTelemetry](otel.md#emit-gen_aievaluationresult-events).

## Per-stage timings

Every report has `report.meta["timings_ms"]`: wall-clock milliseconds per judge-graph node, summed over the cascade.

```python
{"pack": 77.4, "route": 0.0, "decide:djev": 41.2, "gate": 0.0, "escalate": 2210.5, "audit": 0.0, "aggregate": 0.5}
```

| Key | Stage |
|---|---|
| `pack` | session → packed, chunked states for every backend (tokenizers, segmenter, BM25) |
| `route` | workload routing and freeze checks |
| `decide:<tier>` | one key per System One tier that was called |
| `gate` | threshold lookups and decisions |
| `escalate` | System Two calls (present only when something escalated) |
| `audit` | shadow judging of the audit slice |
| `aggregate` | DeepEval-style scoring and reasons |

`report.latency_ms` is the end-to-end total. The first `pack` in a process includes loading tokenizers, so it is much slower than later ones.
