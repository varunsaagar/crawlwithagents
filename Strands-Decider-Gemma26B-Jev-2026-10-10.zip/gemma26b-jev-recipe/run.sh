#!/usr/bin/env bash
# Jev on Gemma-4-26B-A4B with the strands-decider trainer, ONE H100 80GB. Not executed here.
# Usage: run.sh STAGE...   stages: setup validate smoke teacher s1 s2 s3 calibrate eval buckets serve
set -euo pipefail
REPO="${REPO:-/workspace/refs/strands-decider}"; HERE="$(cd "$(dirname "$0")" && pwd)"
PY="${PY:-python}"; TEACHER="${TEACHER:-google/gemma-4-31B-it}"
sd() { "$PY" -u -m strands_decider.cli "$@"; }
for step in "$@"; do case "$step" in
 setup)    "$PY" -m pip install -e "$REPO[train,dev]" ;;   # pin transformers>=5.15 (Gemma 4 classes)
 validate) "$PY" "$HERE/validate_configs.py" "$HERE"/stage*.yaml ;;
 smoke)    # measure peak memory per window before committing GPU hours
           for c in stage1-8k stage2-32k stage3-64k; do
             sd train --config "$HERE/$c.yaml" --max-steps 20 --output-dir "checkpoints/smoke-$c" || echo "OOM/err at $c"; done ;;
 teacher)  # Gemma-4-31B option distributions (replaces Qwen3.5-4B). One file per stage's concatenated train_files.
           # 31B bf16 ~62GB: on 1 GPU use FP8/sharded or label on a separate host. Lower --max-batch-tokens for 64K rows.
           for n in 1 2 3; do "$PY" -m strands_decider.data.teacher --model "$TEACHER" --revision main \
             --src "data/jev/concat_stage$n.jsonl" --out "data/jev/teacher31b_stage$n.jsonl" --max-batch-tokens 70000; done ;;
 s1) sd train --config "$HERE/stage1-8k.yaml" ;;
 s2) sd train --config "$HERE/stage2-32k.yaml" ;;
 s3) sd train --config "$HERE/stage3-64k.yaml" ;;
 calibrate) sd calibrate checkpoints/jev-26b-a4b-s3-64k --data data/jev/calib_heldout.jsonl ;;  # per-kind temperature
 eval)     sd eval checkpoints/jev-26b-a4b-s3-64k --data data/jev/calib_heldout.jsonl ;;
 buckets)  "$PY" "$HERE/ltt_length_buckets.py" --preds data/jev/preds_heldout.jsonl --eps 0.02 --delta 0.05 ;;
 serve)    sd serve checkpoints/jev-26b-a4b-s3-64k --port 8000 --max-batch 4 --max-batch-tokens 68000 ;;
 *) echo "unknown stage $step"; exit 2 ;;
esac; done
