"""UNVERIFIED SKETCH: register the autokernel winner into vLLM's Inkling Hopper path.

Off by default. Enable with INKLING_H100_MOE=1 and point INKLING_H100_MOE_KERNEL at a
candidate file that passed the harness (including --holdout) AND human review.

What it does: vLLM loads `vllm.general_plugins` entry points in every process (API server and
workers). register() wraps the Hopper experts forward used for Inkling
(vllm/models/inkling2/nvidia/ops/moe_sm90.py, `HummingExperts` per PR #68761) so that, for the
shapes and formats the candidate supports, the candidate runs instead; anything else falls
through to Humming.

Not verified: the module path, the class name, the forward signature, and the weight layout
the Humming path keeps after loading (it may pre-shuffle weights, in which case the candidate
must consume that layout or the plugin must keep an unshuffled copy, costing memory).
Read the current source and adapt `_adapt_args` before trusting any of this.
"""
import importlib.util
import logging
import os

log = logging.getLogger("inkling_h100_moe")
TARGET_MODULE = "vllm.models.inkling2.nvidia.ops.moe_sm90"   # verify on current main
TARGET_CLASS = "HummingExperts"                              # verify on current main


def _load_candidate(path):
    spec = importlib.util.spec_from_file_location("inkling_h100_candidate", path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod.fused_moe_wq


def _adapt_args(self, *args, **kwargs):
    """Map the real forward's arguments to the candidate contract
    (x, topk_ids, topk_w, w13, w2, fmt13, fmt2, softcap). Must be written against the real
    signature; returning None means 'fall through to the original'."""
    return None


def register():
    if os.environ.get("INKLING_H100_MOE") != "1":
        return
    path = os.environ.get("INKLING_H100_MOE_KERNEL")
    if not path or not os.path.exists(path):
        log.warning("INKLING_H100_MOE=1 but INKLING_H100_MOE_KERNEL not set or missing; skipping")
        return
    try:
        import importlib
        mod = importlib.import_module(TARGET_MODULE)
        cls = getattr(mod, TARGET_CLASS)
    except (ImportError, AttributeError) as ex:
        log.warning("Inkling Hopper MoE target not found (%s); plugin inactive", ex)
        return
    kernel = _load_candidate(path)
    original = cls.forward

    def forward(self, *args, **kwargs):
        mapped = _adapt_args(self, *args, **kwargs)
        if mapped is None:
            return original(self, *args, **kwargs)
        return kernel(*mapped)

    cls.forward = forward
    log.info("inkling_h100_moe: %s.%s.forward wrapped with %s", TARGET_MODULE, TARGET_CLASS, path)
