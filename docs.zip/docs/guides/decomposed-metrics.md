# Decomposed metrics

Some metrics are too broad for one yes/no question. "Was the customer's action completed?" folds a dozen outcomes into one verdict: handed off, told the result, explained a refusal, redirected to self-service, looped, hit a tool error… A small decision model answers each of those narrow questions much better than the broad one.

A **decomposed metric** keeps the verdict question and adds narrow *read-off* detail questions. Every member of the `jev-stack` answers all of them, and a **learned verdict model** combines the answers into the final verdict. In v2 this is how `action_completion` and `output_toxicity` are judged (preset `voice_v2`, config `configs/judge_v2.yaml`).

## Why it works

On 906 real Sierra sessions (out-of-fold, 5-fold), from `REPORT.md`:

| Model | Agreement | Consensus labels | F1 | AUROC |
|---|---|---|---|---|
| gemini-3.8-flash (verdict) | 0.837 | 0.927 | 0.557 | 0.771 |
| djev (verdict only) | 0.784 | 0.846 | 0.039 | 0.795 |
| djev (decomposed, fitted) | 0.864 | 0.960 | 0.672 | 0.777 |
| kev-gemma (verdict only) | 0.852 | 0.929 | 0.562 | 0.765 |
| kev-gemma (decomposed, fitted) | 0.871 | 0.957 | 0.672 | 0.781 |
| jev-stack (4 verdicts) | 0.864 | 0.947 | 0.631 | 0.734 |
| **jev-stack (4 × 12 decomposed)** | **0.868** | **0.961** | **0.679** | **0.788** |

* **Decomposition is the lever.** djev goes from 0.78 to 0.86 agreement and from F1 0.04 to 0.67. On its own, it almost never said "not completed".
* **The decomposed stack beats the LLM** on every column: 96% vs 93% on consensus labels.
* **More features did not help.** Adding the incumbent's 15-way `reason_category` as a Choice feature added at most 0.6 pp, so it is not shipped.

Toxicity, decomposed the same way into 8 read-off questions, reaches 0.971 accuracy / F1 0.69 (precision 0.96) out-of-fold on 826 sessions, against 0.947 / 0.57 for gemini-3.8-flash.

Certified and evaluated on a 40% holdout that was never used to fit or certify (ε = 3 pp, δ = 0.05, reference gemini-3.8-flash):

| Metric | Model | n cal | θ | Holdout n | Share Jev | Acc cascade | Acc reference | Acc Jev only | $/1k vs reference |
|---|---|---|---|---|---|---|---|---|---|
| action_completion | decomposed `verdict_model` | 544 | 0.60 | 362 | 0.96 | 0.881 | 0.851 | 0.873 | 0.056 vs 1.000 |
| output_toxicity | decomposed `verdict_model` | 496 | 0.50 | 330 | 1.00 | 0.967 | 0.958 | 0.967 | 0.017 vs 1.000 |

Action completion went from 44% answered by Jev (v1, single verdict, θ = 0.93) to 96%, and the cascade beats the fallback on the holdout. See [Results](../results.md) for all five metrics.

!!! note "Labels"
    The real-traffic labels are the incumbent's Gemini-lite verdicts, not human gold. The incumbent's own prompt variants agree with each other on action completion only about 90% of the time, so agreement on *consensus* items (all variants agree) is the cleaner target.

## How it works

### The rubric

A decomposed rubric is an ordinary rubric with more criteria:

* the **verdict** criterion (`verdict: true`), unchanged;
* **detail** criteria with `weight: 0.0`. Each is a narrow, read-off Noul question that a person could answer by pointing at one line;
* a `verdict_model` block.

The `voice_v2` `action_completion` rubric has the `action_completed` verdict plus 11 details mirroring the CMCS outcome categories: `ac_handoff`, `ac_outcome_told`, `ac_refusal_explained`, `ac_selfservice`, `ac_human_request`, `ac_unresolved_end`, `ac_customer_left`, `ac_loop`, `ac_data_failure`, `ac_intent_missed`, `ac_wrong_info`. All of them use windowed chunking over the `grounded` view. `output_toxicity` has the `agent_toxic` verdict plus `tx_insult`, `tx_profanity`, `tx_mocking`, `tx_dismissive`, `tx_aggressive`, `tx_hateful`, `tx_empathetic` (agent-only view) and `tx_customer_hostile` (dialogue view).

Questions that share a view and chunking are packed into **one multi-question request** per member and chunk, so the 12 action-completion questions cost one Kairos call per chunk, not 12. Per-criterion chunk aggregation (`max`, `last`, …) still applies.

### The verdict model

```yaml
verdict_model:
  tier: jev-stack                 # applied only when this tier answers
  features:                       # [member, criterion]: every member × every Noul criterion
    - [kairos-jev, action_completed]
    - [kairos-jev, ac_handoff]
    # ... 36 pairs for action_completion (3 members × 12 criteria)
  weights: [-0.0435, 0.2908, ...]
  bias: 2.978
  n_train: 544
```

`P(verdict positive) = σ(bias + Σ wᵢ · logit(pᵢ))`, where `pᵢ` is P(positive label of criterion i) from member i, after chunk aggregation. The judge graph fans the ensemble out, so each member is packed with its own tokenizer and budget. `Answer.members` keeps every member's probabilities, and `apply_verdict_model` replaces the stack's verdict answer with the model's output. The confidence gate then compares `q = max(p, 1 − p)` with the certified θ as usual.

Fail-closed behaviour:

* If any feature is missing or invalid (a member timed out, say), the verdict answer is invalid and the item escalates (`verdict_model feature missing: <member>:<criterion>`).
* The weights are part of the rubric, so they are part of its **revision**. Refitting changes the revision, and the old certificate stops applying (`fingerprint_mismatch`) until you certify the new rubric.
* Detail criteria are reported but not escalated (they have no `escalate: true`). The fallback only answers the verdict question.

## Fit and certify your own

The workflow is: collect every member's answer to every criterion on labelled sessions, fit the verdict model, certify the rubric that carries it, approve the certificate, serve.

### 1. Collect

Grade labelled sessions in `collect` mode, where every tier answers every criterion and the gate never stops early. Put each member in its own tier, so each answer is attributed to a member:

```bash
.venv/bin/python experiments/run_board.py --mode collect --rubrics configs/rubrics/ac \
    --backends kairos-jev kev-gemma djev --data <labelled sessions>.jsonl --out experiments/runs/ac_collect.jsonl
```

Each board row has `labels[rubric_id]` (1 = fired) and `answers_all[rubric_id][criterion][member] = {label, probabilities, valid, chunks}`. You also need the reference's verdict for the same sessions, from a normal (`calibrate` mode) board run with the reference as a backend.

### 2. Fit

`jevjudge.calibration.combiner.fit_verdict_model(rows, rubric, members, tier="jev-stack", l2=3.0)` fits an L2-regularised logistic regression on the logits of every (member, Noul criterion) probability. Rows missing any feature are dropped (`feature_matrix` returns the kept indices).

### 3. Certify

Certify the verdict model's output as a single `jev-stack` tier against the reference. Use **out-of-fold** scores on the calibration split, so the certificate never sees a score the model was trained on, and keep a holdout you only evaluate on. `experiments/build_registry_v2.py` does exactly this for v2: a stratified 60/40 split, 5-fold out-of-fold scores on the 60% for the certificate, the final model fitted on the whole 60%, and the 40% only scored.

The example below runs the whole flow offline on synthetic rows. For brevity, it certifies on in-sample scores.

```python
import asyncio
import numpy as np

from jevjudge import CriterionGrader, EscalationConfig, Session, preset
from jevjudge.backends.ensemble import JevEnsemble
from jevjudge.backends.mock import MockBackend
from jevjudge.calibration.combiner import feature_matrix, fit_verdict_model, logit
from jevjudge.calibration.engine import CalibrationEngine, JudgmentRecord, TierObs
from jevjudge.calibration.registry import CertificateRegistry
from jevjudge.core.rubric import Rubric

shipped = next(r for r in preset("voice_v2") if r.id == "action_completion")
base = Rubric.from_dict({**shipped.model_dump(mode="json"), "verdict_model": None})   # drop the shipped weights
MEMBERS = ["jev-a", "jev-b"]

# 1. collect-mode rows (synthetic here): labels + answers_all + the reference's verdict
rng = np.random.default_rng(0)
rows = []
for i in range(400):
    y = int(rng.random() < 0.3)                               # 1 = fired (action NOT completed)
    aa = {}
    for c in base.criteria:
        pos = (c.positive_label or "true").split("|")[0].strip()
        neg = "false" if pos == "true" else "true"
        signal = {"ac_unresolved_end": 0.25, "ac_loop": 0.25, "ac_outcome_told": -0.25}.get(c.name, 0.0) * (2 * y - 1)
        aa[c.name] = {}
        for m in MEMBERS:
            p = float(np.clip(0.5 + signal + rng.normal(0, 0.15), 0.01, 0.99))
            aa[c.name][m] = {"label": pos if p >= 0.5 else neg, "probabilities": {pos: p, neg: 1 - p}, "valid": True}
    rows.append({"item_id": f"s{i}", "labels": {base.id: y}, "answers_all": {base.id: aa},
                 "reference_fired": y if rng.random() < 0.85 else 1 - y})
cal = rows[:240]                                              # rows[240:] = holdout, evaluate only

# 2. fit, and write the weights into the rubric (new revision)
vm = fit_verdict_model(cal, base, MEMBERS, tier="jev-stack", l2=3.0)
fitted = Rubric.from_dict({**base.model_dump(mode="json"), "verdict_model": vm.model_dump(mode="json")})
print(len(vm.features), vm.n_train, fitted.revision != base.revision)       # 24 240 True
# fitted.to_yaml() is what you ship (src/jevjudge/metrics/voice_v2/action_completion.yaml)

# 3. certify the verdict model's scores against the reference, then approve
feats, X, keep = feature_matrix(cal, fitted, MEMBERS)
p_fired = 1 / (1 + np.exp(-(logit(X) @ np.array(vm.weights) + vm.bias)))
vc = fitted.verdict_criterion
pos = vc.positive_label                                       # "false": not completed = fired
records = []
for r, p in zip([cal[i] for i in keep], p_fired):
    probs = {pos: float(p), "true": float(1 - p)}
    ref = pos if r["reference_fired"] else "true"
    records.append(JudgmentRecord(
        subject_id=r["item_id"], rubric_id=fitted.id, revision=fitted.revision, criterion=vc.name, qtype="noul",
        positive_labels=[pos], tiers={"jev-stack": TierObs(max(probs, key=probs.get), probs)},
        reference=TierObs(ref, {ref: 1.0}), reference_name="llm", gold=r["labels"][fitted.id]))
cert, analysis = CalibrationEngine(records, eps=0.03, delta=0.05, min_n=100,
                                   fit_temperature=False).certify_unit(records, ["jev-stack"])
reg = CertificateRegistry()                                   # CertificateRegistry("registry/certificates.json")
reg.propose(cert)
reg.approve(cert.certificate_id, approver="alice@example.com", note="decomposed AC; holdout reviewed")
print(cert.mode, cert.thetas)                                 # parity_gold [0.8]

# 4. serve: the tier must be named like verdict_model.tier, and the reference like the certificate's
stack = JevEnsemble([MockBackend("jev-a"), MockBackend("jev-b")], name="jev-stack")
grader = CriterionGrader([stack], EscalationConfig(judges=[], threshold="certified"),
                         judges=[MockBackend("llm", kind="llm")], registry=reg)
session = Session.from_turns("s1", [{"speaker": "user", "text": "cancel my add-on"},
                                    {"speaker": "agent", "text": "Done, it is removed."}])
v = asyncio.run(grader.grade(session, [fitted])).rubric("action_completion").criteria[0]
print(v.system_one[-1].backend, v.policy_source, v.decision.value)    # jev-stack certified accept
```

For a real deployment, change the member names to `kairos-jev`, `kev-gemma`, `djev`, write `fitted.to_yaml()` to your rubric directory, save the registry, and point the judge YAML at both. `configs/judge_v2.yaml` is the reference:

```yaml
tiers:
  - model: jev-stack
    members: [kairos-jev, kev-gemma, djev]
    combiner: ../experiments/registry/v2/combiner.json   # used by the non-decomposed metrics
escalation:
  judges: [{model: gemini-3.8-flash}, {model: gemma-26b, timeout: 60}]
  threshold: certified
  audit_rate: 0.05
  use_fallback_rubric: false     # matches how the reference was measured when certifying
registry: ../experiments/registry/v2/certificates.json
rubrics: [../src/jevjudge/metrics/voice_v2]
```

!!! warning "Names must match exactly"
    * `verdict_model.tier` must equal the tier's name (`jev-stack`). Otherwise the model is silently skipped, and the stack's plain verdict answer is used instead.
    * The feature member names must equal the ensemble member names.
    * The certificate fingerprint pins the rubric revision (which includes the weights), the tier names and the reference name.

### Analyse a candidate decomposition

`experiments/decomp_analysis.py` compares, out-of-fold, for any rubric: each member's verdict only, each member decomposed, the stacked verdicts, and the full decomposed stack, optionally against the reference. Run it before you ship a new decomposition:

```bash
.venv/bin/python experiments/decomp_analysis.py --rubrics configs/rubrics/tox --rid output_toxicity \
    --collect experiments/runs/tox_collect_fast_real.jsonl experiments/runs/tox_collect_kev_real.jsonl \
    --reference experiments/runs/real_board_gemini38.jsonl --ref-name gemini-3.8-flash
```

## Writing good detail questions

* **Read-off, not judgement.** "The AGENT transferred the CUSTOMER to a live agent" beats "The agent handled the escalation well".
* **One fact per question.** Split "looped or gave wrong information" into two questions.
* **Cover the failure *and* the success outcomes.** The model learns from both sides (`ac_outcome_told` vs `ac_unresolved_end`).
* **Add context questions** that change the meaning of others. `tx_customer_hostile` lets the model discount a firm reply to an abusive caller.
* **Expect diminishing returns.** Check each new question with `decomp_analysis.py`. If it adds less than a point, leave it out: every question adds tokens to every request.
