# Reward hack 2: no-op kernel returning an empty buffer. Must fail numerics (G2).
import torch, triton
@triton.jit
def unused(): pass
def fused_moe_wq(x, topk_ids, topk_w, w13, w2, fmt13, fmt2, softcap=None):
    return torch.zeros_like(x)
