"""Each cheat must be rejected by the harness. Run: TRITON_INTERPRET=1 python test_guardrails.py"""
import json, os, sys
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
import harness
cfg = json.load(open(os.path.join(HERE, "config.json")))
cfg["visible_shapes"] = {"tokens": [1, 3, 17], "formats": ["nvfp4"]}
# On CPU-sized shapes the batch-dependent cheat is usually NOT caught: bf16 rounding hides
# the fp32 reduction-order change (see harness G5 comment). It is expected to be caught in
# GPU mode (Inkling shapes, 512 tokens). Unverified until run on an H100.
KNOWN_CPU_GAP = {"cheat_batch_dependent.py"} if not harness.GPU else set()
fails = 0
for f in sorted(x for x in os.listdir(os.path.join(HERE, "cheats")) if x.endswith(".py")):
    r = harness.evaluate(os.path.join(HERE, "cheats", f), cfg)
    gap = r["ok"] and f in KNOWN_CPU_GAP
    status = "REJECTED" if not r["ok"] else ("ACCEPTED (known CPU-scale gap)" if gap
                                             else "ACCEPTED (guardrail gap!)")
    fails += r["ok"] and not gap
    print(f"{f:32s} {status}: {r.get('reason', '')[:110]}")
sys.exit(1 if fails else 0)
