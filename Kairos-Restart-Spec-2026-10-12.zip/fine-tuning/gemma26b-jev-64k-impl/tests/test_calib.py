import torch, math, torch.nn.functional as F
from pack import JevHead
from losses import *
torch.manual_seed(0)
B,K,H=64,12,32
head=JevHead(H); head.train()
C=torch.randn(B,K,H); A=torch.randn(B,H); T=torch.randint(0,3,(B,))
mask=torch.rand(B,K)>0.3; mask[:,0]=True; labels=torch.zeros(B,dtype=torch.long)
for b in range(B):
    v=mask[b].nonzero().flatten(); labels[b]=v[torch.randint(len(v),(1,))]
# make labels learnable: add signal to gold option
C[torch.arange(B),labels]+=A*0.5
opt=torch.optim.Adam([p for p in head.parameters() if p.requires_grad],1e-2)
ref=head(C,A,mask,T).detach()
l0=None
for s in range(60):
    lg=head(C,A,mask,T); L=stage1_loss(lg,labels,mask,ref_logits=ref)
    opt.zero_grad(); L.backward()
    g=sum(p.grad.norm()**2 for p in head.parameters() if p.grad is not None)**.5
    assert torch.isfinite(L) and g>0
    l0=l0 or L.item(); opt.step()
print(f"stage1 loss {l0:.4f} -> {L.item():.4f}, grad_norm {g:.3e}")
lg=head(C,A,mask,T); assert (F.softmax(lg,-1)[~mask]==0).all(); print("masked options prob=0: OK")
assert (smoothed_ce(lg,labels,mask)>=0).all(); print("smoothing mass only on valid options: OK")
# permutation equivariance of loss
perm=torch.randperm(K); inv=perm.argsort()
lp=head(C[:,perm],A,mask[:,perm],T); assert torch.allclose(stage1_loss(lp,inv[labels],mask[:,perm]),stage1_loss(lg,labels,mask),atol=1e-5); print("loss invariant to option order: OK")
for s in range(30):
    lg=head(C,A,mask,T); L,r=stage2_selective_reinforce(lg,labels,mask,ref_logits=ref)
    opt.zero_grad(); L.backward(); assert all(torch.isfinite(p.grad).all() for p in head.parameters() if p.grad is not None); opt.step()
print(f"stage2 REINFORCE runs, mean reward {r:.3f}")
print("metrics", {k:round(v,3) for k,v in calib_metrics(F.softmax(head(C,A,mask,T),-1).detach(),labels).items()})
print("ALL TESTS PASSED")
