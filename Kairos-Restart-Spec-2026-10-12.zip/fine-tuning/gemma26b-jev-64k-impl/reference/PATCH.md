# Kairos 26B (Gemma-4-26B-A4B, ZeRO-3, 3 ranks): teardown crash fix

## Diagnosis
Screenshot: `last/` saved correctly (243.6 MB of real fp32 gathered weights), then ranks 1 and 2 crash:
`train.py:423 <module> -> 419 main -> 406 train -> dist.barrier() -> _get_default_group -> ValueError: Default process group has not been initialized`.

`_get_default_group()` raises this error **only when the default process group no longer exists**. So `destroy_process_group()` had already run on those ranks, and a `dist.barrier()` followed it at line 406. This is a follow-on from the Failure #8 patch. That patch moved `save(last/)` before `destroy_process_group()`, which is correct. But a barrier that was meant to sync around the old rank-0 teardown/post-eval block still sits after the destroy. It is probably the "else" path of `if rank == 0: <post-eval/calibrate/test> ; dist.barrier()` or `if rank != 0: dist.barrier()`. Rank 0 doesn't crash because it takes the other branch (or returns early), which is why only ranks 1–2 fail. **The weights are safe.** Only the exit code is wrong, but torchrun treats it as a job failure (ChildFailedError), and so would any pipeline step that runs next.

Reproduced on CPU/gloo with 3 ranks (`--bug post_destroy_barrier`): the same `ValueError`, exit 1, and `last/` already written.

The same failure class is known upstream. pytorch/pytorch#126379 hits it from `get_rank()` after destroy (fixed in PR #126739), and NVIDIA/Megatron-LM#3775 / PR #3781 fixes it by guarding with `is_initialized()`.

## Fix (template; apply to your train.py, which I have not seen)
```diff
+def _dist_ready():
+    return dist.is_available() and dist.is_initialized()
+
+def safe_barrier():
+    if _dist_ready():
+        dist.barrier()
+
+def safe_teardown():
+    """Exactly once, every rank, the LAST distributed call in the process."""
+    if _dist_ready():
+        dist.barrier()
+        dist.destroy_process_group()

 def train(cfg):
+    assert cfg.zero_stage == 3, "eval/save control flow below assumes ZeRO-3 (collective forward/gather)"
     ...
     if step % cfg.eval_every == 0:
-        if rank == 0:
-            score = evaluate(net, dev)
-            if score > best: save(net, out/"best")
-        dist.barrier()
+        score = evaluate(net, dev)              # ALL ranks: every ZeRO-3 forward is collective
+        log_dev(step, score) if rank == 0 else None
+        if score > best:                         # deterministic eval -> same decision on all ranks
+            best = score; save(net, out/"best")  # collective gather inside, rank-0 write
     ...
-    dist.destroy_process_group()
-    save(net, out/"last")
+    save(net, out/"last")                        # all ranks, BEFORE teardown
-    if rank == 0 and not cfg.skip_post_eval:
-        calibrate_and_test(...)
-    else:
-        dist.barrier()                           # <- train.py:406: barrier on a destroyed group
-    dist.destroy_process_group()
+    if not cfg.skip_post_eval:
+        raise SystemExit("post-eval inside ZeRO-3 run unsupported; run the single-GPU scorer job")
+    safe_teardown()                              # nothing distributed after this line
+    return

 def save(net, path):
+    assert cfg.zero_stage == 3
-    if rank == 0:
-        sd = trainable_state(net)                # GatheredParameters = collective!
-        torch.save(sd, path/"weights.pt")
+    sd = trainable_state(net)                    # ALL ranks (GatheredParameters(modifier_rank=None))
+    if rank == 0:
+        torch.save(sd, path/"weights.pt.tmp"); os.replace(path/"weights.pt.tmp", path/"weights.pt")
+    safe_barrier()
```
Rules:
1. `destroy_process_group()` appears **once**, inside `safe_teardown()`, and is the last distributed call on every rank. Delete any other destroy.
2. Every `dist.barrier()`/`all_reduce` that is not on the hot path goes through `safe_barrier()`. That includes logging, exception handlers and `finally:` blocks.
3. No collective (forward, `evaluate`, `GatheredParameters`, `save`, `engine.save_checkpoint`) sits under `if rank == 0`. Only file I/O and logging may.
4. `assert zero_stage == 3` wherever the control flow depends on it (Lesson 14).
5. Raise the NCCL timeout only around the save/gather if a 64K gather is slow, e.g. a `new_group(timeout=...)` for save, or `init_process_group(timeout=timedelta(minutes=30))`. **This is not the fix.** A bigger timeout turns a deadlock into a longer deadlock.
6. Don't let `main()` call `destroy_process_group()` again after `train()` returns, and don't call it in an `atexit`/`finally` unless it is guarded.

## What to grep in train.py
```
grep -nE "barrier|destroy_process_group|init_process_group|is_initialized" train.py
grep -nE "if (self\.)?(rank|local_rank|is_main|global_rank) ?(==|!=) ?0|is_main_process" train.py
grep -nE "GatheredParameters|trainable_state|save\(|save_checkpoint|evaluate\(|calibrat|skip_post_eval|zero_stage" train.py
```
Expected fixed form: one `destroy_process_group` (inside `safe_teardown`). Every barrier either sits in the hot loop with all ranks provably present, or goes through `safe_barrier`. Each `if rank == 0` body contains only `torch.save`/`json.dump`/`print`/`log`. `evaluate(` and `save(` are called unconditionally. Look at line 406 and the 10 lines above it: you should find the destroy, then a barrier on a branch rank 0 doesn't take.

## Verified vs not
- Verified on CPU/gloo with 3 ranks and a ZeRO-3 emulation (every forward all-gathers sharded weights): both original bugs reproduce, and the fixed flow exits 0 on all ranks, with best/ and last/ written by rank 0 only and reloading to the identical score.
- Not verified: your actual train.py, real DeepSpeed (not installed/tested here; the emulation is not DeepSpeed), NCCL, and the 26B on GPU.
