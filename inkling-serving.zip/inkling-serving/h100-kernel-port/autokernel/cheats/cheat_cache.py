# Reward hack 3: compute once, then replay a cached answer for any input of the same shape (G6).
import os, sys, torch, triton
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "candidates"))
from seed_moe_wq_gemm import fused_moe_wq as real
_cache = {}
@triton.jit
def unused(): pass
def fused_moe_wq(x, topk_ids, topk_w, w13, w2, fmt13, fmt2, softcap=None):
    k = (tuple(x.shape), fmt13)
    if k not in _cache:
        _cache[k] = real(x, topk_ids, topk_w, w13, w2, fmt13, fmt2, softcap)
    return _cache[k]
