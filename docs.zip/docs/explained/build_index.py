#!/usr/bin/env python3
"""Build `index.html` — the landing page for the jevjudge visual docs (same shell as kairos/docs/index.html)."""
from pathlib import Path

from docshell import page, section

HERE = Path(__file__).parent

WALK = [
    ("jevjudge-explained.html", "How jevjudge judges a conversation",
     "One conversation from trace to verdict, in 14 stages: onboarding, ingest, packing, typed questions, the "
     "3-model stack, the certified gate, Learn-then-Test calibration, drift monitoring, governance and the prod "
     "results. 21 animated figures, each explained three ways.", "walkthrough", "ok"),
]
DIAGRAMS = [
    ("arch/jevjudge-architecture.html", "The judge plane — architecture",
     "Server and SDK, System One on the Kairos gateway, System Two, the calibration loop and the sinks.",
     "diagram", "info"),
    ("arch/jevjudge-flow.html", "End to end — dataflow",
     "Onboarding to recalibration: every stage a trace passes through, and the loop back to the gate.",
     "diagram", "info"),
    ("arch/jevjudge-certificate.html", "Certificate lifecycle",
     "Propose, approve, migrate phase, freeze on alarm, recalibrate, supersede, roll back, revoke.",
     "diagram", "info"),
]
FIGURES = [
    ("figures/jevjudge-pipeline.svg", "Pipeline", "Five stages and the two feedback loops, on one strip."),
    ("figures/jevjudge-onepager.svg", "One-pager", "Serving, onboarding, calibration and prod results."),
    ("figures/jevjudge-one-vs-stack.svg", "One model vs the stack", "Latency, budgets, combiner and verdict model."),
    ("figures/jevjudge-lifecycle.svg", "Lifecycle", "Certificates, migration phases and the monitor loop."),
]


def card(href, title, blurb, pill, cls):
    return (f'<a href="{href}" style="display:block;text-decoration:none;color:inherit;'
            f'border:1px solid var(--line);border-radius:10px;padding:22px 24px;background:#fff">'
            f'<span class="pill {cls}">{pill}</span>'
            f'<div style="font-family:var(--ds);font-size:21px;line-height:1.2;margin:12px 0 8px">{title}</div>'
            f'<div style="font-size:14px;color:var(--mut);line-height:1.6">{blurb}</div></a>')


def grid(cards, cols=2):
    return (f'<div style="display:grid;grid-template-columns:repeat({cols},1fr);gap:20px;margin-top:8px;align-items:start">'
            + "".join(cards) + "</div>")


figs = grid([f'<a href="{h}" style="display:block;text-decoration:none;color:inherit;border:1px solid var(--line);'
             f'border-radius:10px;overflow:hidden;background:#fff"><img src="{h}" alt="{t}" '
             f'style="display:block;width:100%;border-bottom:1px solid var(--line)">'
             f'<div style="padding:14px 18px"><div style="font-family:var(--ds);font-size:18px">{t}</div>'
             f'<div style="font-size:13.5px;color:var(--mut)">{b} PNG beside it at 2×.</div></div></a>'
             for h, t, b in FIGURES])

HTML = page(
    title="jevjudge — visual docs",
    kicker="jevjudge · visual docs",
    h1="How jevjudge works",
    lede="Start with the walkthrough. Use the diagrams to explore one part. Use the figures in slides. "
         "Every number traces to <code>FACTS.md</code> in this folder.",
    facts=[("1", "walkthrough"), ("3", "explorable diagrams"), ("4", "figures"), ("21", "animations")],
    nav=[("w", "walkthrough"), ("d", "diagrams"), ("f", "figures")],
    sections=[section(1, "w", "Learn it", "Read top to bottom. Each figure replays.", grid([card(*c) for c in WALK], 1)),
              section(2, "d", "Explore it", "Click a block, trace a path, switch light and dark.",
                      grid([card(*c) for c in DIAGRAMS], 3)),
              section(3, "f", "Show it", "Static SVG for decks and one-pagers.", figs)])

if __name__ == "__main__":
    (HERE / "index.html").write_text(HTML, encoding="utf-8")
    print(f"wrote index.html ({(HERE / 'index.html').stat().st_size / 1024:.0f} KB)")
