"""Single-GPU calibrate + test job (runs AFTER the ZeRO-3 run, on last/ or best/ weights).
1) dump per-question logits on calib + test splits (score with model on 1 GPU; see GUIDE s9)
2) fit temperature per (type x length bucket) minimising ECE (strands-decider) or NLL
3) report acc / ECE / Brier / NLL / AUROC / AURC / Cov@eps per slice
4) Learn-then-Test (LTT) certify a confidence threshold theta per slice: P(risk <= eps) >= 1-delta."""
import math, json, torch, torch.nn.functional as F
from losses import calib_metrics

BUCKETS = [(0, 8192, "<=8k"), (8192, 16384, "8-16k"), (16384, 32768, "16-32k"), (32768, 65537, "32-64k")]
def bucket(n):
    for lo, hi, name in BUCKETS:
        if lo <= n < hi: return name
    return "over"

def ece(probs, y, bins=15):
    return calib_metrics(probs, y, n_bins=bins)["ece"]

def fit_temperature(logits, y, objective="ece", grid=None):
    grid = grid or [0.25 * 1.06 ** i for i in range(60)]        # 0.25 .. ~8
    best = (float("inf"), 1.0)
    for T in grid:
        p = F.softmax(logits / T, -1)
        v = ece(p, y) if objective == "ece" else F.nll_loss(torch.log(p.clamp_min(1e-12)), y).item()
        best = min(best, (v, T))
    return best[1]

def binom_tail_pvalue(errors, n, eps):
    """P(Binom(n,eps) <= errors): small => evidence that true risk < eps (Hoeffding-Bentkus style, exact binomial)."""
    return sum(math.comb(n, k) * eps ** k * (1 - eps) ** (n - k) for k in range(errors + 1))

def ltt_certify(conf, correct, eps=0.05, delta=0.1, grid=None, min_n=30):
    """Fixed-sequence LTT: scan thresholds from strict to loose, stop at first non-rejection.
    Returns the loosest theta whose answered-set risk is certified <= eps, or None (=> always escalate)."""
    grid = grid or [1 - i * 0.01 for i in range(1, 100)]
    cert = None
    for th in grid:
        m = conf >= th; n = int(m.sum())
        if n < min_n: continue          # too few answered items to test; not a rejection failure
        err = int((~correct[m]).sum())
        if binom_tail_pvalue(err, n, eps) <= delta: cert = (th, n / len(conf), err / n)
        else: break
    return cert

def run(records, eps=0.05, delta=0.1, objective="ece"):
    """records: list of dict(type, n_tokens, logits[K] (with -inf masked), label, split in {calib,test})."""
    out = {}
    slices = {}
    for r in records: slices.setdefault((r["type"], bucket(r["n_tokens"])), []).append(r)
    for (typ, b), rs in sorted(slices.items()):
        K = max(len(r["logits"]) for r in rs)
        def tens(split):
            sel = [r for r in rs if r["split"] == split]
            if not sel: return None, None
            L = torch.full((len(sel), K), float("-inf"))
            for i, r in enumerate(sel): L[i, :len(r["logits"])] = torch.tensor(r["logits"], dtype=torch.float)
            return L, torch.tensor([r["label"] for r in sel])
        Lc, yc = tens("calib"); Lt, yt = tens("test")
        if Lc is None or Lt is None or len(yc) < 30:
            out[f"{typ}|{b}"] = {"status": "too few rows -> escalate all (fail closed)"}; continue
        T = fit_temperature(Lc, yc, objective)
        pc = F.softmax(Lc / T, -1); conf_c, pred_c = pc.max(-1)
        cert = ltt_certify(conf_c, pred_c == yc, eps, delta)
        pt = F.softmax(Lt / T, -1); m = calib_metrics(pt, yt, eps_risk=eps)
        conf_t, pred_t = pt.max(-1)
        if cert:
            ans = conf_t >= cert[0]
            m.update(theta=cert[0], test_coverage=ans.float().mean().item(),
                     test_risk=((pred_t != yt) & ans).sum().item() / max(1, ans.sum().item()))
        else:
            m.update(theta=None, test_coverage=0.0, note="not certified -> escalate all")
        m.update(T=T, n_calib=len(yc), n_test=len(yt)); out[f"{typ}|{b}"] = m
    return out

if __name__ == "__main__":
    import sys; recs = [json.loads(l) for l in open(sys.argv[1])]
    print(json.dumps(run(recs), indent=1))
