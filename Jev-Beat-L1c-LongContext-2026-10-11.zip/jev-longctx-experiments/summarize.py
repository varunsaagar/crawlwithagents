import json, os, collections
R = []
for f in ["results_toy.json", "results_toy2.json"]:
    if os.path.exists(f): R += json.load(open(f))
lines = ["# Toy results (CPU proxy, NOT E4B)\n", "acc [95% CI], n per cell. Train length 64 -> eval 64..512 (8x, mirrors 8K->64K).\n"]
def table(title, rows, keys):
    lines.append(f"\n## {title}\n"); lines.append("| " + " | ".join(keys + ["noul", "choice", "score"]) + " |"); lines.append("|" + "---|" * (len(keys) + 3))
    g = collections.OrderedDict()
    for r in rows: g.setdefault(tuple(r[k] for k in keys), {})[r["qtype"]] = f'{r["acc"]:.2f} [{r["ci95"][0]:.2f},{r["ci95"][1]:.2f}]'
    for k, v in g.items(): lines.append("| " + " | ".join(map(str, k)) + " | " + " | ".join(v.get(q, "") for q in ["noul", "choice", "score"]) + " |")
table("(a)(c) Length sweep, base seed 0: single vs log-n temperature vs chunked", [r for r in R if r["exp"] == "length" and r["model"] == "base" and r["seed"] == 0], ["L", "k", "mode"])
table("(b)(d) Training variants, single-pass length sweep (distractors k = L/16)", [r for r in R if r["exp"] == "length" and r["mode"] == "single"], ["model", "seed", "L", "k"])
table("(d) Distractors at fixed length 64", [r for r in R if r["exp"] == "distract_fixL"], ["model", "seed", "k"])
table("(d) Length at fixed distractors k=4", [r for r in R if r["exp"] == "length_fixk"], ["model", "seed", "L"])
lines.append("\n## (e) Option count, Choice, L=64, k=4 (trained with 8 options)\n\n| model | seed | n_opt | acc [CI] | chance |\n|---|---|---|---|---|")
for r in R:
    if r["exp"] == "options": lines.append(f'| {r["model"]} | {r["seed"]} | {r["n_opt"]} | {r["acc"]:.2f} [{r["ci95"][0]:.2f},{r["ci95"][1]:.2f}] | {1/r["n_opt"]:.2f} |')
open("RESULTS.md", "w").write("\n".join(lines) + "\n"); print("\n".join(lines))
