# jevjudge explained: the facts sheet

This is the only source of numbers for the visual docs. If a number is not here, read it from the code or a report
that is cited below. Never invent a number. Mark anything illustrative as "shape is illustrative".

## What jevjudge is

- An SDK, Python only, that replaces an LLM-as-judge for voice and chat agents.
- Kairos decision models answer typed questions in one forward pass. There is no decode loop and nothing to parse.
- Metrics: PII, sexism, toxicity, action completion, hallucination.
- Code: `src/jevjudge/`. Guides that explain each component already exist in `docs/` (concepts/, guides/).

## Models (System One: one forward pass, real probabilities)

| model | backbone | context budget | measured |
|---|---|---|---|
| kairos-jev | Granite 311M (ModernBERT family) | ~30k tokens | p50 member call 0.5 s / p95 2.8 s on the prod gateway |
| kev-gemma | Gemma 4 (gran-c) | ~6.5k tokens, so it chunks the most | p50 4.9 s / p95 5.8 s: the latency bottleneck |
| djev | Diffusion Gemma 26B | ~19k chars | p50 0.7 s / p95 1.5 s |
| laya | ModernBERT-large | 7.5k tokens | pod down, excluded from the v2 stack |

- Kairos server-side time is 20–70 ms. The rest is the gateway hop and queueing.
- System Two (escalation only): gemini-3.8-flash on the Kairos gateway, then gemma-26b.
- Wire format: POST `{base}/v1/systemone` with `{"model","state","questions":{id:{type: noul|choice|score, instructions, criteria}}}`.
  Many questions go in one request.

## One model vs the 3-model stack

- **One model:** a single tier answers each question, and temperature calibrates its probabilities.
- **jev-stack:** kairos-jev, kev-gemma and djev answer in parallel. Each member packs and chunks with its own budget.
  A fitted logistic combiner joins the member logits per question (`calibration/combiner.py`, `fit_logistic`, L2).
- **Decomposition:** action completion has 12 criteria (about 11 read-off sub-questions plus a verdict). Toxicity has 9.
  A learned `verdict_model` (logistic over member × sub-question logits) gives the verdict.
  This was the lever: action-completion agreement went from 0.837 to 0.868, and 0.96 on consensus labels.

## End-to-end flow (each stage is a section)

1. **Onboard:** the team runs `jevjudge otel-check` (compatibility verdict: ready / partial / unsupported, plus a
   derived profile) and `jevjudge otel-validate` (the jev.trace/v1 contract). Fixes come from the BLOCKER hints.
2. **Collect:** traces arrive in one of three ways:
   - an OTel Collector config, `deploy/otel-collector/jev-collector.yaml`, that stamps the use case, maps the
     conversation id, scrubs identifiers, keeps only GenAI spans, and exports to the judge;
   - the judge's `POST /v1/traces` endpoint;
   - `ContractRecorder`, or `jevjudge otel-normalize`.
3. **Ingest:** a convention layer reads several OTel dialects: genai_semconv, genai_events, langsmith, openllmetry,
   openinference, vertex_adk, plus Sierra / Decagon / CES. Envelopes are grouped into conversations by union-find on
   conversation id and traceId (`otel/grouping.py`). The output is a `Session` (turns, tool calls, tool errors).
4. **Pack:** views give each criterion only the part of the session it needs. Text is counted in the model's own
   tokenizer (HF tokenizers / tiktoken / chars). Chunking strategies: none / window / units. Chunk verdicts are joined
   with max / noisy_or / mean / last / first.
5. **Ask:** rubrics are YAML (`metrics/voice_v2/*.yaml`). Each criterion is a typed question. Rubric revisions are
   hash-pinned, and certificates pin a revision.
6. **Decide:** the stack answers, the combiner or verdict model gives p, and a confidence gate compares p with the
   certified threshold θ.
7. **Escalate:** only when JEV is not confident does it ask System Two. A rationale is written only on escalation.
8. **Emit:** OTel `gen_ai.evaluation.result` events plus `jev.*` attributes, and the CMCS sink.
9. **Calibrate:** Learn-then-Test certificates (`calibration/bounds.py`, `engine.py`):
   - Hypothesis H0 is "the policy is not safe": the cascade error exceeds the reference error by more than ε.
   - The p-value is WSR (the betting / Waudby-Smith–Ramdas test), with Hoeffding–Bentkus and Clopper–Pearson
     available.
   - Thresholds are searched in a fixed sequence with multiplicity control (Holm / fixed-sequence testing).
     Rejecting H0 at δ certifies θ.
   - Modes: parity_gold and parity_ref.
   - Defaults: ε = 0.02, δ = 0.05, min_n = 100.
10. **Monitor:** AccuracyMonitor (`calibration/monitor.py`) runs an e-process with a CUSUM e-detector on audit
    disagreements: eps 0.05, alpha 0.01. On alarm the unit freezes and every item escalates. Adaptive conformal
    inference (ACI) only ever tightens θ (aci_gamma 0.02). DriftStats (`drift_stats.py`) tracks PSI of the confidence
    distribution, the escalation rate and the valid-answer rate against a baseline.
11. **Govern:**
    - Certificate lifecycle: propose → approve → supersede / rollback / revoke, with full history.
    - Migration phases: legacy_shadow → tighter_of → certified_preferred → enforce.
    - Mondrian strata (per project / channel); a human review queue.
12. **Use:** `CriterionGrader.from_config("configs/judge_v2.yaml")`, LangGraph node (`integrations/langgraph.py`),
    DeepEval metric adapter, Calibration Studio UI (`jevjudge serve`), HTTP API.

## Trace contract jev.trace/v1 (validated on prod, 2026-10-09)

- Resource: `service.name`, `vz.project_slug.use_case`. Every span: `gen_ai.conversation.id`.
- Turn = one `invoke_agent` span (`jev.turn.index`, input = new user message, output = reply).
  Tool call = one `execute_tool` span under its turn.
- Prod (27 projects, 1,806 conversations): raw conformant 0. After normalize: 1,499 / 1,520 = 98.6% conformant,
  fidelity 1,520 / 1,520 exact, 0 wrong merges, 281 refused (no content).
- otel-check found 25 of 27 projects ready. Blocked: otel-unknown-agent (LangSmith exports `{}`, 97% of spans).
  GNT_KP_AI_WIRELESS is not chat.

## Accuracy history

- **v2 holdout vs gemini-3.8-flash** (cascade vs Gemini, agreement with reference):
  - AC 0.881 vs 0.851, with JEV deciding 96%;
  - toxicity 0.967 vs 0.958;
  - PII 0.916 vs 0.894;
  - sexism 0.981 vs 0.963;
  - hallucination 0.948 vs 0.571.
- **Production validation run 1 (2026-09-29, prod_eval_hub_sessions):**
  - Scope: 16,511 sessions (Sierra, Decagon, CES voice + nonbilling, both chat projects), 82,555 verdicts, 0 errors.
  - Agreement with production, final:

    | metric | agreement | escalation |
    |---|---|---|
    | AC | 0.731 (population-weighted 0.762) | 9.9% |
    | PII | 0.980 | 0.6% |
    | hallucination | 0.958 | |
    | toxicity / sexism | 1.000 | |

  - Blind adjudication by gemini-3.8-flash sides with JEV on AC 69% (104 / 150), PII 78% (116 / 149) and
    hallucination 40% (60 / 149).
  - Estimated accuracy with the adjudicator as truth, JEV vs production: AC ≈ 0.92 vs 0.81; PII ≈ 0.996 vs 0.984;
    hallucination ≈ 0.975 vs 0.983.
  - Latency under batch load: p50 8.9 s / p95 30.8 s per session (5 metrics). This is mostly kev-gemma queueing:
    16 slots shared by about 24 sessions.
- **Calibration v3 (System One only):** IN PROGRESS. The calibration days are 09-28 and 09-29, the holdout day is
  09-27, and the reference is Gemini labels on every holdout session. Show it as "in progress, results pending". Do not
  invent v3 numbers.

## Style rules (from the user)

- **Match the existing template exactly.** Use `kairos/docs/docshell.py` + `shell.css`: the Verizon fonts inlined,
  red #F50A23, stone #F3EDE0. Each section is explained three ways: plain English, the maths, under the hood. Use
  animated SVG with a replay button, as `build_laya8k.py` does.
- **Diagrams first, minimal text.** Explain with a picture and a moving picture before words. This is the
  3Blue1Brown style: show the idea, then name it; build up one step at a time; animate the transformation.
- **Text follows ASD-STE100 about 80% of the way.** Use short sentences (≤ 20 words), active voice, one idea per
  sentence, approved simple words, and consistent terms. Stay technical where text is needed: equations, real
  parameter names.
- **Karpathy style:** build from first principles, the smallest working picture first, then add a part at a time.
- **Show the four-model and one-model paths side by side** wherever it matters.
