import sys, os, json, random, tempfile, torch, numpy as np
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import calibrate as C, eval_compare as E, mmap_cache as MC
from pack import pack
torch.manual_seed(0); rng = random.Random(0); ok = lambda m: print("[PASS]", m)
# ds config valid
cfg = json.load(open(os.path.join(os.path.dirname(__file__), "..", "configs", "ds_zero3.json")))
assert cfg["zero_optimization"]["stage"] == 3 and cfg["bf16"]["enabled"]; ok("ds_zero3.json parses, stage 3, bf16")
# 64k pack: 63k state + 3 questions fits; 66k refused
TOK = {"ANS": 1}
qs = [dict(type="choice", q_ids=[2, 3], options=[[10 + i] for i in range(40)]), dict(type="noul", q_ids=[2, 4], options=[[5], [6]]),
      dict(type="score", q_ids=[2, 7], options=[[8, 0], [8, 1], [8, 2]])]
import pack as P
def pack_len(S):
    # length-only check (avoid building a 64k x 64k bool mask on CPU)
    return S + sum(len(q["q_ids"]) + sum(map(len, q["options"])) + 1 for q in qs)
assert pack_len(65000) <= 65536 and pack_len(65500) > 65536
try: pack(list(range(20, 220)), qs, TOK, max_len=200); raise SystemExit("not refused")
except ValueError as e: ok(f"over-length refused: {e}")
# temperature fit recovers overconfidence
n, K = 2000, 5; y = torch.randint(0, K, (n,)); true = torch.randn(n, K); true[torch.arange(n), y] += 1.0
over = true * 3.0   # overconfident logits
recs = []
for i in range(n):
    recs.append(dict(type="choice", n_tokens=rng.choice([4000, 12000, 30000, 60000]), logits=over[i].tolist(),
                     label=int(y[i]), split="calib" if i % 2 else "test"))
res = C.run(recs, eps=0.2, delta=0.1)
for k, m in res.items(): assert 1.5 < m["T"] < 5, (k, m["T"])
ok("per-(type x bucket) temperature fitted (true T=3): " + ", ".join(f'{k}:T={m["T"]:.2f},ECE={m["ece"]:.3f},cov={m["test_coverage"]:.2f},risk={m.get("test_risk",0):.3f}' for k, m in res.items()))
# LTT: impossible eps -> None
conf = torch.rand(500); cor = torch.rand(500) > 0.5
assert C.ltt_certify(conf, cor, eps=0.01) is None; ok("LTT fails closed when risk cannot be certified")
# eval_compare
ids = [f"i{j}" for j in range(200)]
def sysm(acc, seed):
    r = random.Random(seed); return {i: dict(item_id=i, type=r.choice(["choice", "noul", "score"]), n_tokens=8000, gold=1, pred=1 if r.random() < acc else 0) for i in ids}
out = E.compare({"prompted_26b": sysm(0.9, 1), "native_26b": sysm(0.6, 2), "l1c_e4b": sysm(0.215, 3)})
assert "RECIPE GAP" in out["verdict"]; ok(f"eval_compare paired on 200 ids: {out['acc']} p={out['paired']['p']:.1e} -> {out['verdict'][:30]}")
# mmap cache
d = tempfile.mkdtemp(); rows = [dict(state="x" * rng.randint(5, 50), label=1) for _ in range(100)]
tot = MC.build_cache(rows, lambda r: list(range(len(r["state"]))), d); M = MC.MmapRows(d)
assert len(M) == 100 and len(M.ids(7)) == len(rows[7]["state"]) and sum(len(M.shard(r, 3)) for r in range(3)) == 100
ok(f"mmap cache: {tot} tokens, 3 disjoint rank shards, zero-copy reads")
print("ALL IMPL TESTS PASSED")
