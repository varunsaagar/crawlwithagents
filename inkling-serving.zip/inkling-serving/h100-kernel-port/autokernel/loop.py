"""AutoKernel-style search loop for the Inkling 2 Mini H100 MoE kernel.

propose (LLM or mutation) -> write candidates/current.py -> harness in a fresh subprocess
(static check, numerics, determinism, batch invariance, harness-owned timing, roofline sanity)
-> keep if faster AND passes the hidden holdout in another fresh subprocess -> else revert.
Every attempt is logged in a SQLite results DB. Frozen files are hashed every iteration.

  python loop.py --dry-run 2            # CPU smoke test: mutation proposer, no timing
  python loop.py                        # on an H100, proposer from config.json

Proposers: "mutate" (offline tile/warp mutations), "command" (any LLM CLI: prompt on stdin,
code in a ```python block on stdout), "openai" (OpenAI-compatible /chat/completions; base
URL, key and model from env/config). No LLM call is made unless you configure one.
"""
import argparse, hashlib, json, math, os, random, re, shutil, sqlite3, subprocess, sys, time, urllib.request

HERE = os.path.dirname(os.path.abspath(__file__))


def sha(path):
    return hashlib.sha256(open(path, "rb").read()).hexdigest()


def db_open(path):
    con = sqlite3.connect(path)
    con.execute("""CREATE TABLE IF NOT EXISTS runs(
        id INTEGER PRIMARY KEY, ts REAL, iter INT, proposer TEXT, src_sha TEXT,
        ok INT, kept INT, score REAL, reason TEXT, result_json TEXT, src TEXT)""")
    return con


# ---------------------------------------------------------------- proposers
def propose_mutate(src, rng, **_):
    choices = {"BLOCK_M": [16, 32, 64], "BLOCK_N": [32, 64, 128, 256], "BLOCK_K": [32, 64, 128]}
    name = rng.choice(list(choices))
    val = rng.choice(choices[name])
    new = re.sub(rf"^{name} = \d+", f"{name} = {val}", src, count=1, flags=re.M)
    return new, f"mutate {name}={val}"


def _extract_code(text):
    m = re.findall(r"```(?:python)?\n(.*?)```", text, flags=re.S)
    return max(m, key=len) if m else text


def _prompt(src, history, brief):
    hist = "\n".join(f"- iter {h['iter']}: ok={h['ok']} kept={h['kept']} score={h['score']} reason={h['reason']}"
                     for h in history[-12:])
    return (f"{brief}\n\n## Recent attempts\n{hist or '(none)'}\n\n## Current best candidate\n"
            f"```python\n{src}\n```\n\nReturn the full new file in one ```python block, then one "
            f"line explaining the single idea you tried.")


def propose_command(src, rng, history, brief, opts, **_):
    p = subprocess.run(opts["command"], shell=True, input=_prompt(src, history, brief),
                       capture_output=True, text=True, timeout=900)
    return _extract_code(p.stdout), "llm(command)"


def propose_openai(src, rng, history, brief, opts, **_):
    base = os.environ[opts["openai_base_url_env"]].rstrip("/")
    key = os.environ[opts["openai_api_key_env"]]
    body = json.dumps({"model": opts["openai_model"], "temperature": 0.7,
                       "messages": [{"role": "user", "content": _prompt(src, history, brief)}]}).encode()
    req = urllib.request.Request(base + "/chat/completions", data=body,
                                 headers={"Authorization": f"Bearer {key}", "Content-Type": "application/json"})
    with urllib.request.urlopen(req, timeout=900) as r:
        text = json.load(r)["choices"][0]["message"]["content"]
    return _extract_code(text), "llm(openai)"


PROPOSERS = {"mutate": propose_mutate, "command": propose_command, "openai": propose_openai}


# ---------------------------------------------------------------- evaluation
def run_harness(path, cfg_path, holdout, timeout):
    out = os.path.join(HERE, ".last_eval.json")
    cmd = [sys.executable, os.path.join(HERE, "harness.py"), path, "--config", cfg_path, "--json", out]
    if holdout:
        cmd.append("--holdout")
    try:
        subprocess.run(cmd, capture_output=True, text=True, timeout=timeout, env=os.environ.copy())
        return json.load(open(out))
    except subprocess.TimeoutExpired:
        return {"ok": False, "reason": f"timeout after {timeout}s"}
    except Exception as ex:  # noqa: BLE001
        return {"ok": False, "reason": f"harness crashed: {ex!r}"}
    finally:
        if os.path.exists(out):
            os.remove(out)


def score(res):
    """Geometric mean of median seconds over bench token counts (lower is better)."""
    perf = res.get("perf")
    if not perf:
        return None
    ts = [v["seconds"] for v in perf.values()]
    return math.exp(sum(math.log(t) for t in ts) / len(ts))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default=os.path.join(HERE, "config.json"))
    ap.add_argument("--dry-run", type=int, default=0, help="N iterations with the mutation proposer")
    a = ap.parse_args()
    cfg = json.load(open(a.config))
    os.chdir(HERE)
    frozen = {f: sha(f) for f in cfg["frozen_files"]}
    brief = open("program.md").read()
    con = db_open(cfg["results_db"])
    rng = random.Random(0)
    proposer = "mutate" if a.dry_run else cfg["proposer"]
    iters = a.dry_run or cfg["max_iters"]

    best_path = "candidates/best.py"
    if not os.path.exists(best_path):
        shutil.copy(cfg["seed_candidate"], best_path)
    base = run_harness(best_path, a.config, False, cfg["candidate_timeout_s"])
    if not base.get("ok"):
        sys.exit(f"seed candidate fails the harness: {base.get('reason')}")
    best_score = score(base)
    print(f"[seed] ok, score={best_score} ({base.get('perf_note')}; {base.get('numerics')})")

    history, reverts = [], 0
    for it in range(1, iters + 1):
        for f, h in frozen.items():                                   # G9
            if sha(f) != h:
                sys.exit(f"frozen file changed: {f}; aborting run")
        src = open(best_path).read()
        try:
            new_src, note = PROPOSERS[proposer](src, rng, history=history, brief=brief,
                                                opts=cfg["proposer_options"])
        except Exception as ex:  # noqa: BLE001
            new_src, note = src, f"proposer error {ex!r}"
        open(cfg["editable_file"], "w").write(new_src)
        res = run_harness(cfg["editable_file"], a.config, False, cfg["candidate_timeout_s"])
        s = score(res) if res.get("ok") else None
        kept = False
        if res.get("ok") and s is not None and best_score is not None and best_score / s >= cfg["min_speedup_to_keep"]:
            hold = run_harness(cfg["editable_file"], a.config, True, cfg["candidate_timeout_s"])   # G6
            if hold.get("ok"):
                shutil.copy(cfg["editable_file"], best_path)
                best_score, kept = s, True
            else:
                res["reason"] = "holdout failed: " + str(hold.get("reason"))
        reason = res.get("reason") or ("kept" if kept else ("no timing on this box" if s is None else "not faster"))
        reverts = 0 if kept else reverts + 1
        row = dict(iter=it, ok=bool(res.get("ok")), kept=kept, score=s, reason=reason)
        history.append(row)
        con.execute("INSERT INTO runs(ts,iter,proposer,src_sha,ok,kept,score,reason,result_json,src) "
                    "VALUES(?,?,?,?,?,?,?,?,?,?)",
                    (time.time(), it, note, hashlib.sha256(new_src.encode()).hexdigest(), int(row["ok"]),
                     int(kept), s, reason, json.dumps(res, default=str), new_src))
        con.commit()
        print(f"[{it}] {note}: ok={row['ok']} kept={kept} score={s} reason={reason}")
        if reverts >= cfg["max_consecutive_reverts"]:
            print("stopping: too many consecutive reverts"); break
    print(f"best: {best_path} score={best_score}. Human review + vLLM end-to-end gate before registering.")


if __name__ == "__main__":
    main()
