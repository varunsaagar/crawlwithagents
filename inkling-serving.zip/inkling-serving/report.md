# Inkling 2 Mini: how it is served, and a custom H100 stack on vLLM

Prepared 22 Nov 2026 (IST). Sources at the end. "Verified" means seen in a source this session. "Unverified" means my inference.

## 1. Which model

**Inkling 2 Mini** by Thinking Machines Lab (`thinkingmachines/Inkling-2-Mini`). Confidence: high (~95%). Released 20 Nov 2026, Apache 2.0. No other candidate (Ling-mini-2.0, Ring-mini, Kimi, MiniMax) matches "Inkling" and "Mini 2".

| Property | Value |
|---|---|
| Type | Multimodal (text and image in, text out) **looped** MoE transformer |
| Size | 26.4B total, 3.4B active (vLLM says 3.5B). About **5.4B effective** per token because of looping |
| Layers | 24 physical layers. Layers 6–17 run **3 passes** with shared weights, so 48 layer visits per token |
| Experts | 128 per layer, top-8, no shared expert. Hidden size 2,304, expert width 1,152 |
| Attention | 20 sliding-window layers (1,024 tokens) and 4 full-attention layers. 24 Q heads, 8 KV heads. Learned sink and output gate. Short convolutions |
| Loop mechanics | Each pass starts from the prelude output and reads gated "messages" from the previous pass. **Every pass has its own KV and conv-state cache** (48 of each) |
| Context | Up to 1M tokens. KV costs about 69 KB/token (about 69 GB for 1M) |
| Precision | Experts in NVFP4 (layers 0–19) and MXFP8 (layers 20–23). Attention, router and loop controllers in BF16/FP32. About 20 GB checkpoint, including a 0.6 GB **DSpark** drafter |

## 2. How it is officially served

- **vLLM** has the main day-0 recipe. It runs from the `vllm/vllm-openai:inkling-2-mini` image until a release (0.35+) carries the support. The recipe verifies GB200, B300, GB300, **H100**, H200 and DGX Spark.
  - TP1 is "the most efficient way to serve the model". TP4 gives lower output per GPU.
  - H100 is capped at 262,144 tokens of context to fit the KV cache. Blackwell and H200 get the full 1M.
  - Parsers are `--reasoning-parser inkling` and `--tool-call-parser inkling --enable-auto-tool-choice`.
  - Speculative decoding uses the bundled drafter: `{"method":"dspark","num_speculative_tokens":7,"draft_sample_method":"probabilistic"}`.
  - Prefix caching and CUDA graphs work as usual, because each pass's caches are registered as ordinary cache layers.
- **Kernels already shipped in vLLM** (so this is not a gap for you to fill):
  - Fused all-reduce + short-conv + residual + attention-residual mix + RMSNorm, used even at TP1.
  - One fused kernel reads all four loop messages. The loop controllers run as batched GEMMs, with Triton kernels for the RMSNorm and merge. The merge is FP32.
  - **Hopper path:** Blackwell has native FP4, but H100 does not. On H100 the NVFP4 and MXFP8 expert weights are dequantised exactly and run through **Humming** W4A16 / W8A16 indexed MoE GEMMs with BF16 activations. That is a weight-only path.
  - On Inkling 2 *Small* (H200), Humming gave 1.48× at concurrency 1 and 2.71× at concurrency 64 over the earlier Triton path. Mini-on-H100 numbers are not published.
- **SGLang** has day-0 support but its cookbook lists **H200**, Blackwell, RTX 5090, RTX PRO 6000, DGX Spark, MI350X/MI355X and TPU7x. It does not list H100, so it is not the H100 route today.
  - SGLang notes that NVFP4 experts cannot be TP-sharded (keep EP = TP).
  - It uses Marlin GEMV on H200 and zero-pads experts from 1,152 to 1,280 for MegaMoE prefill on Blackwell (TTFT for 8K prompts down 24%).
  - The Hugging Face blog's SGLang snippet needs SM103 (Blackwell).
- **NVIDIA Dynamo + SGLang:** an experimental recipe exists, but only for B200 and VR200 (TP2/EP2, with disaggregated prefill/decode using NIXL or Mooncake). Nothing for H100.
- **Also listed on the model card:** Hugging Face, TokenSpeed, llama.cpp/Unsloth GGUF, Ollama, Exo. Post-training: Miles, SkyRL, NeMo AutoModel (fine-tuning only).

### Blocker on H100 right now (verified)

vLLM issue #69046 is **open**. The published `inkling-2-mini` image (amd64 digest `a485440c…`, last pushed 20 Nov 21:36 UTC) was built **without sm_90 kernels**.
- **Crash on H100/H200:** `conv_mix.cu: no kernel image is available`. The Humming expert path fails the same way.
- **Silent corruption:** FlashAttention-3 in that image is built for sm_75 only, so **image input returns garbage with no error on Hopper**. Text is fine.
- The source fix (#67880, adds `9.0a`) is already merged. The image was just built from an older tree.
- A reporter fixed it by rebuilding from the #69028 source with `TORCH_CUDA_ARCH_LIST=9.0` (CUDA 13.0, torch 2.14.0+cu130) and mounting the rebuilt libraries over the image.
- I checked Docker Hub today: the tag is still the old build.

**Action:** rebuild vLLM from main with `TORCH_CUDA_ARCH_LIST="9.0"` (or wait for a refreshed image). Smoke-test text **and** image input on H100 before trusting the image.

## 3. "run ak nhme"

Unclear. My reading is **NVIDIA NeMo**, meaning the NVIDIA stack around the model. For serving, that is **NVIDIA Dynamo** (KV-aware routing, disaggregated prefill/decode). NeMo AutoModel is fine-tuning only. The second reading is **auto-tune**, covered below with `vllm bench sweep serve`. Say if you meant something else, such as RadixAttention or NVMe KV offload.

## 4. Custom stack on vLLM for H100, ranked

Honest framing: the model-specific kernel work (fused loop kernels, Humming expert GEMMs) is already in vLLM. Your custom gains come from configuration, routing and workload tuning, not new CUDA. Gains are indicative. The only published Mini numbers are on GB200.

| # | Layer | Expected gain | Maturity | How to plug in |
|---|---|---|---|---|
| 0 | **Correct H100 build** (sm_90 kernels, FA3 for sm_90) | Prerequisite (it crashes without it) | Bug open | Build from main with `TORCH_CUDA_ARCH_LIST=9.0`, or wait for an image refresh. Test image input |
| 1 | **TP1 replicas, one per GPU, behind a prefix-aware router** (llm-d / Gateway API Inference Extension, or Dynamo KV router) | Best throughput per GPU (the recipe says TP1 beats TP4). Scales linearly across the node | High | One pod per GPU. Route by session affinity or prefix hash so the cache hits. Fits your shared-namespace and Kueue plan |
| 2 | **DSpark speculative decoding** (bundled drafter) | GSM8K mean acceptance length about 3.6 (GB200). Biggest decode win at low and medium concurrency | Medium. Works on Hopper per the recipe, but Mini-on-H100 speed-up is unmeasured | Already in the serve command. Benchmark on real prompts: **random-token prompts accept almost nothing**. Needs the fixed 3-pass loop |
| 3 | **DSpark adaptive verification** (`"enable_adaptive_verification": true`) | Keeps the speculative gain at high concurrency (tested to 256 on DeepSeek-V4) | New. Needs full CUDA graphs, rejects `--enforce-eager`, LoRA and pipeline parallelism. Documented on SM100. **Unverified** for Inkling or Hopper | Try on a canary. Otherwise cap `num_speculative_tokens` (about 3–5) at high load |
| 4 | **Prefix caching + chunked prefill tuning + auto-tune** | Large for agentic multi-turn (long shared prefixes). Tuning TTFT against inter-token latency | High | Prefix caching is on by default in V1. Sweep `max_num_batched_tokens` (2048 favours latency, 8192+ favours throughput) and `max_num_seqs` with `vllm bench sweep serve --serve-params params.json`, or `benchmarks/auto_tune/auto_tune.sh` for a P99 target |
| 5 | **KV budget: context cap and FP8 KV cache** | KV is about 69 KB/token, and H100 leaves about 50 GB for it. FP8 KV could roughly double cached tokens | Medium. FP8 KV is only anecdotally accepted on RTX 5090 reports. **Unverified** on Hopper and for the loop and conv caches | Start with `--max-model-len 262144` (or lower, such as 131072, for more sessions). Test `--kv-cache-dtype fp8` and check accuracy before using it |
| 6 | **KV offload to CPU, then LMCache or NVMe** | Helps long idle agent sessions that exceed GPU KV | vLLM `OffloadingConnector` is generic. **Unverified** with Inkling's per-pass and conv-state caches | `--kv-transfer-config` with OffloadingConnector and `cpu_bytes_to_use`. Pilot only |
| 7 | **Custom kernels via vLLM plugin** (Triton/CUDA, `CustomOp.register_oot` through a `vllm.general_plugins` entry point) | Low until profiling shows a hot spot. Fusions and Humming are already in | Mechanism is stable. Inkling's ops are inside the model, not standard `CustomOp`s | Profile first (`vllm bench forward`, Nsight). Candidates: Humming config tuning for 1,152-wide experts at small M, and a sm_90 version of the Blackwell-only expert padding |
| 8 | **Disaggregated prefill/decode** (NIXL, Dynamo, llm-d) | Low for a 20 GB model that fits one GPU. Replicas win | Dynamo recipe is B200/VR200 only. **Unverified** for Inkling on Hopper | Revisit only if long-prompt TTFT starves decode |
| 9 | **Variable-loop research checkpoint** (`TML-d24-varloop-research`) for a latency tier | GB200 decode step at batch 1: 3.85 ms (3 passes) → 2.67 ms (2) → 1.51 ms (1). Fewer passes lower quality | Research checkpoint. Can't combine with DSpark (needs 3 passes). Rejected on the standard Mini | `--hf-overrides '{"text_config":{"loop_num_passes":2,"loop_share_cache":true}}'` |

Not worth it here: expert parallelism, TP>1 (the experts are small), W8A8 FP8 re-quantisation (the checkpoint is already 4-bit and H100 runs it weight-only; compressed-tensors W4A8/W8A8 loading is an open PR, #69141, untested on Hopper), and MIG slices below 3g.40gb (weights plus KV need more than 10–20 GB).

### Sample `vllm serve` for H100 (single GPU, after fixing the build)

```bash
docker run --gpus all --ipc=host -p 8000:8000 \
  -v ~/.cache/huggingface:/root/.cache/huggingface \
  <your-sm90-build-of>/vllm-openai:inkling-2-mini \
  thinkingmachines/Inkling-2-Mini \
  --tensor-parallel-size 1 \
  --max-model-len 262144 \
  --gpu-memory-utilization 0.92 \
  --max-num-seqs 128 \
  --max-num-batched-tokens 8192 \
  --reasoning-parser inkling \
  --tool-call-parser inkling --enable-auto-tool-choice \
  --speculative-config '{"method":"dspark","num_speculative_tokens":7,"draft_sample_method":"probabilistic"}'
# canary only: add "enable_adaptive_verification": true inside the speculative-config JSON
# experiment only: --kv-cache-dtype fp8
```

The recipe's own defaults are `max-num-batched-tokens 8192`, `max-num-seqs 256` and `gpu-memory-utilization 0.95`. I lowered the last two for headroom and they are not tuned. Sampling per Unsloth: temperature 1.0, top-p 1.0, top-k 0. The model card warns the model can get stuck in long reasoning loops, so set max output tokens and agent-turn limits.

Benchmark with:
```bash
vllm bench serve --backend openai-chat --endpoint /v1/chat/completions \
  --model thinkingmachines/Inkling-2-Mini --dataset-name speed_bench \
  --speed-bench-dataset-subset throughput_1k --speed-bench-output-len 1024 \
  --max-concurrency 16 --num-prompts 64
```

## 5. Caveats
- Everything is days old (release 20 Nov). Issues and PRs are moving: #69046 (Hopper image), #69141 (compressed-tensors experts), #69053 (arch test).
- I found no published H100 throughput for Mini. Published figures are GB200 (about 4,400 / 3,200 / 2,100 output tok/s/GPU at 100 tok/s/user, 32K / 64K / 128K sessions) and Small on H200.
- I did not run anything on a GPU.

## Sources
- Model card: https://huggingface.co/thinkingmachines/Inkling-2-Mini
- Announcement: https://thinkingmachines.ai/news/inkling-2-mini/
- Hugging Face blog: https://huggingface.co/blog/inkling2mini
- vLLM blog (day 0): https://vllm.ai/blog/2026-11-20-inkling2-mini
- vLLM recipe: https://recipes.vllm.ai/thinkingmachines/Inkling-2-Mini
- vLLM PRs: #69028 (model), #69027 (recipe), #69039 (1M context on one GPU), #68761 (Humming on Hopper), #67880 (Hopper support), #69141 (compressed-tensors experts); issue #69046 (H100 image bug), PR #69053 — https://github.com/vllm-project/vllm/issues/69046
- SGLang cookbook: https://docs.sglang.io/cookbook/autoregressive/ThinkingMachines/Inkling-2-Mini
- SGLang blog: https://www.sglang.io/blog/inkling-2-small-day0-support
- NVIDIA Dynamo recipe: https://docs.nvidia.com/dynamo/dev/recipes/inkling-2-mini.md
- NeMo AutoModel: https://docs.nvidia.com/nemo/automodel/model-coverage/vision-language-models/thinkingmachines/Inkling-2-Mini
- Unsloth guide: https://unsloth.ai/docs/models/inkling-2-mini
- GPUJournal deployment guide: https://gpujournal.ai/guide/deploy-inkling-2-mini
- DSpark adaptive verification: https://docs.vllm.ai/en/stable/features/speculative_decoding/adaptive_verification/ and https://vllm.ai/blog/2026-08-14-dspark-adaptive-verification
- vLLM sweeps and auto-tune: https://docs.vllm.ai/en/stable/benchmarking/sweeps/ and https://github.com/vllm-project/vllm/blob/main/benchmarks/auto_tune/README.md
- KV offload: https://docs.vllm.ai/en/latest/features/kv_offloading_usage/; NIXL: https://docs.vllm.ai/en/latest/features/nixl_connector_usage/
- Plugin system: https://docs.vllm.ai/en/stable/design/plugin_system/


---
See also `comparison.md` (best-in-world engine comparison, nnsight/NDIF and RightNow AI posts, in-house build plan).


## H100 kernel port and autokernel loop
See `h100-kernel-port/design.md` (recommended path, plan, gates), `h100-kernel-port/kernel_dataflow.png`, and `h100-kernel-port/autokernel/README.md`. Not run on a GPU yet.
