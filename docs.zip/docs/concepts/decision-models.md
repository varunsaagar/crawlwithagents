# Decision models

Every backend implements the same `Backend.decide(DecideRequest) -> {question_id: Answer}` contract. The gate, the calibration engine and the scorer therefore never branch on vendor.

* **System One**: the fast tiers that answer first, usually Kairos decision models.
* **System Two**: the fallback judges (Gemma / Gemini) that get escalations and audits.

## The System One contract

Kairos routes speak the TypeSafe System One wire:

```text
POST {base_url}/v1/systemone
{"model": "kairos-jev", "state": "<packed transcript>",
 "questions": {"output_pii__pii_exposed": {"type": "noul", "instructions": "..."},
               "output_pii__pii_category": {"type": "choice", "instructions": "...", "criteria": {"none": "...", ...}}}}
→ {"answers": {"output_pii__pii_exposed": {"type": "noul", "noul": 0.03}, ...}, "latency_ms": ...}
```

One request answers **every question that shares the same state view and chunk plan**. The five voice metrics use three views, so a Kairos tier makes 3 requests per session. Decision models return probabilities only and never write a rationale. Every answer is normalised to an `Answer`:

| Field | Meaning |
|---|---|
| `label`, `probabilities` | argmax label and the label → probability distribution |
| `q` (property) | `max(probabilities)`: the routing signal compared with θ (−∞ if invalid) |
| `p_true` (property) | P(true) for Noul questions |
| `native_confidence` | the backend's own confidence, when it reports one |
| `valid`, `error` | malformed, missing or failed answers are `valid=False` and are escalated |
| `backend`, `latency_ms`, `chunks`, `rationale` | provenance; `rationale` is System Two only |

## Model registry

Model names resolve through `resources/models.yaml`. You can extend it with `$JEVJUDGE_MODELS` or with a `models:` section in the judge YAML. A registry entry holds the provider, endpoint, model id, key variable, tokenizer and token budget. Any field can be overridden inline on the config object.

| Alias | Provider | Tokenizer | `max_state_tokens` | Notes |
|---|---|---|---|---|
| `kairos-jev` | kairos | `hf:ibm-granite/granite-embedding-311m-multilingual-r2` | 30000 | granite-311M encoder; not usable alone for hallucination |
| `kev-gemma`, `kev-gemma-granc` | kairos | `tiktoken:cl100k_base` | 6500 | best single model on action completion; the throughput bottleneck |
| `laya` | kairos | `hf:answerdotai/ModernBERT-large` | 7500 | |
| `djev` | kairos | `chars:1` | 19000 | 20k-**character** limit; best single model on PII / sexism / hallucination |
| `clm-gemma` | kairos | `tiktoken:cl100k_base` | 6500 | route `kairos-clm-gemma` |
| `gw/kairos-jev`, `gw/kev-gemma`, `gw/laya`, `gw/djev` | kairos via gateway | as above | as above | key `KAIROS_JWT_NP` |
| `jev-stack` | ensemble | per member | per member | members `[kairos-jev, kev-gemma, laya, djev]`; each member packed with its own budget |
| `gemini-3.8-flash`, `gemini-3.5-flash-lite`, `gemini-3.8-flash-prod` | openai (gateway) | `tiktoken:cl100k_base` | 200000 | logprobs on; `reasoning_effort: disable` |
| `gemma-26b` | openai (vLLM) | `tiktoken:cl100k_base` | 100000 | logprobs on |
| `kairos-per-hub` | openai | `tiktoken:cl100k_base` | 50000 | |
| `gemini-2.5-flash`, `gemini-3.5-flash` | vertex | `tiktoken:cl100k_base` | 400000 | ADC; 3.x has no logprobs |

Aliases: `jev-latest` → `kairos-jev`, `gemma-4-26b-a4b-it-fp8-dynamic` → `gemma-26b`.

You can also use **provider-prefixed ids** without a registry entry: `kairos/<route>`, `openai/<model>` (needs `base_url` or `OPENAI_BASE_URL`), `vertex/<model>`, `mock/<name>`.

```python
from jevjudge import DecisionModelConfig, LLMConfig
from jevjudge.config import registry

print(registry().names())                                            # every registered alias
tier = DecisionModelConfig(model="djev", timeout=10, max_concurrency=4)         # inline overrides
llm = LLMConfig(model="openai/my-model", base_url="https://litellm.example.com/v1", api_key_env="MY_KEY")
fb = LLMConfig(model="gemma-26b", two_order=True)                    # average both option orders
```

## Backends

| Provider | Class | How it answers |
|---|---|---|
| `kairos` | `backends.kairos.KairosSystemOne` | native multi-question System One call; retries 429/5xx with backoff |
| `ensemble` | `backends.ensemble.JevEnsemble` | members called in parallel. For a Noul with fitted weights: logistic combiner over member P(positive). Otherwise: mean of member distributions. Latency is the slowest member; cost is the sum of members |
| `openai` | `backends.openai_compat.OpenAICompatLLM` | any `/chat/completions` endpoint. Each question becomes a lettered multiple-choice prompt, and probabilities come from the first answer token's top logprobs |
| `vertex` | `backends.vertex.VertexGemini` | Gemini through `google-genai` with the same letter protocol; logprobs on 2.x |
| `mock` | `backends.mock.MockBackend` | deterministic, offline; rules or a stable hash-based distribution |

### LLMs in the decision contract

An LLM can be a gated **tier** (`tiers: [{model: gemma-26b}]`) as well as a fallback. Its probabilities come from the answer letter's logprobs, renormalised over the option letters. Without logprobs, the parsed letter gets probability 1 and `native_confidence=None`. Such a model should be a fallback, not a gated tier.

When a rationale is requested, the model writes `Answer: <letter>` **before** `Rationale: …` (`reasoning: after`, the default). The verdict is then identical with and without rationale. With reasoning first, Gemini-2.5-flash fired on 60% of synthetic hallucination items, and accuracy fell from 0.74 to 0.48.

The prompt text (system message, Noul lead-in, answer formats) lives in `resources/prompts.yaml` and can be overridden with `prompts:` in the judge YAML.

### Stacked tier: `jev-stack`

```yaml
tiers:
  - model: jev-stack
    members: [kairos-jev, kev-gemma, laya, djev]
    combiner: ../experiments/registry/combiner.json      # fitted per-metric logistic weights
    max_concurrency: 8                                   # passed to each member
```

The combiner computes `P(fired) = σ(Σ_k w_k · logit(p_k) + b)` per verdict question (`calibration/combiner.py`). It is fitted on labelled, retained probabilities with `fit_from_board`. If a member's answer is missing for a question that has fitted weights, the ensemble returns an invalid answer, and the item escalates (fail closed).

Inside the judge graph, an ensemble tier is **fanned out**: each member gets its own state, packed and chunked with its own tokenizer and token budget. Its chunk answers are merged per member, and only then are the members combined. Each member's probabilities are kept on `Answer.members`, which is what a rubric's [`verdict_model`](rubrics.md#learned-verdict-model-verdict_model) consumes. Calling `JevEnsemble.decide()` directly, outside the graph, sends the same state to every member. The combined score is a new signal: certify `jev-stack` like any tier, and refit when any member's version changes.

## Writing your own backend

```python
from jevjudge.backends.base import Backend, DecideRequest, answer_from_probs
from jevjudge import CriterionGrader, EscalationConfig

class KeywordJudge(Backend):
    name, version, kind = "keyword", "1", "system_one"
    tokenizer, max_state_tokens = "chars:3.2", 8000

    async def decide(self, req: DecideRequest):
        out = {}
        for qid, q in req.questions.items():
            p = 0.95 if "refund" in req.state.lower() else 0.05
            probs = {"true": p, "false": 1 - p} if q.type == "noul" else {l: 1 / len(q.labels) for l in q.labels}
            out[qid] = answer_from_probs(qid, q, probs, self.name)
        return out

grader = CriterionGrader([KeywordJudge()], EscalationConfig(judges=[], threshold=0.9))
```

You can pass `Backend` instances anywhere a config is accepted: `CriterionGrader(judge_model_config=[...])` and `CriterionGrader(judges=[...])`.
