# Quickstart

There are three ways to build a judge. All of them produce the same `CriterionGrader` and the same `GradeReport`.

| Entry point | Style | Best for |
|---|---|---|
| `Judge.from_preset(...)` | synchronous | scripts, notebooks, non-async services |
| `CriterionGrader(...)` | `async` | services, batch jobs, LangGraph |
| `CriterionGrader.from_config("judge.yaml")` / `Judge.from_config(...)` | YAML | deployments (swap models without code changes) |

What you can pass as the item to grade (`to_subject` in `judge/grader.py`):

* a `Session`;
* an OTLP envelope (`{"resourceSpans": [...]}`) or a BigQuery row with `spans_json` / `all_spans_data`;
* `{"session_id": ..., "turns": [{"speaker"|"role": ..., "text"|"content": ...}, ...]}`;
* a DeepEval-style dict (`input`, `actual_output`, `expected_output`, `context`, `retrieval_context`, `tools_called`);
* a plain string.

## 1. Synchronous: `Judge.from_preset`

```python
from jevjudge import Judge

judge = Judge.from_preset(
    "voice",                              # output_pii, output_toxicity, output_sexism, hallucination, action_completion
    tiers=["djev"],                       # System One cascade, cheapest first (default: ["djev"])
    fallback="gemini-3.8-flash",          # one name or a list (availability chain); None = Jev only
    threshold=0.9,                        # float | "certified" | {"output_pii": 0.97, "default": 0.9}
    rationale="on_escalation",            # never | on_escalation | always
)
trace = {"session_id": "s1", "turns": [
    {"speaker": "user", "text": "What's my balance?"},
    {"speaker": "agent", "text": "Your balance is $84.10, due on the 21st."},
]}
report = judge.grade(trace)
for r in report.rubrics:
    v = r.criteria[0]                     # the verdict criterion is first in every voice rubric
    print(r.rubric_id, r.verdict, round(r.verdict_probability or 0, 3), v.final_source.value, v.escalation_reason)
judge.close()
```

`Judge` runs a private event loop on a daemon thread, so `judge.grade()` also works inside Jupyter. If you are already in async code, use `await judge.agrade(item)`.

Extra keyword arguments to `from_preset` go to `CriterionGrader`, for example `registry=`, `monitor=`, `review=`, `concurrency=` or `packing=`.

The presets are `voice` (single-verdict rubrics), `voice_decomposed` and `voice_v2`. `voice_v2` carries the decomposed action-completion and toxicity rubrics with their learned verdict models, fitted for a `jev-stack` tier of kairos-jev, kev-gemma and djev (see [Decomposed metrics](guides/decomposed-metrics.md)). With any other tier, those two verdict models are skipped.

## 2. Async: `CriterionGrader`

```python
import asyncio
from jevjudge import CriterionGrader, DecisionModelConfig, EscalationConfig, LLMConfig, preset

async def main(session):
    rubrics = preset("voice")

    # Jev only: one Kairos request per state view, covering all five metrics
    jev_only = CriterionGrader(judge_model_config=DecisionModelConfig(model="kairos-jev"))
    report = await jev_only.grade(session, rubrics)
    print(report.report[0].criteria[0].final.probabilities)      # {'false': 0.97, 'true': 0.03}

    # Jev first; escalate to Gemini, then Gemma, when q < θ
    grader = CriterionGrader(
        judge_model_config=[DecisionModelConfig(model="kairos-jev"), DecisionModelConfig(model="kev-gemma")],
        escalation=EscalationConfig(
            judges=[LLMConfig(model="gemini-3.8-flash"), LLMConfig(model="gemma-26b")],
            threshold={"output_pii": 0.97, "default": 0.9},
            rationale="on_escalation",
        ),
    )
    report = await rubrics[0].grade(session, grader)              # AutoRubric style: one rubric
    reports = await grader.grade_many([session], rubrics)         # many items, bounded by `concurrency`
    await jev_only.aclose(); await grader.aclose()

# asyncio.run(main(session))
```

!!! note "Defaults"
    * `Judge.from_preset()` and `POST /v1/judge` default to `tiers=["djev"]`, `fallback="gemini-3.8-flash"` and `threshold=0.9`.
    * `CriterionGrader()` with no `judge_model_config` uses `DecisionModelConfig()`, which is `kairos-jev`. With no `escalation`, it has **no fallback and θ = 0**: it accepts every valid Jev answer.
    * `EscalationConfig()` with no arguments has `judges=[gemini-3.8-flash]`, `threshold=0.7` and, for certified thresholds, `phase="enforce"`.

    Config objects are pydantic models, so always use keyword arguments: `DecisionModelConfig(model="djev")`.

### Offline variant

Use the `mock/<name>` provider or `MockBackend` to try the API without network access:

```python
import asyncio
from jevjudge import CriterionGrader, EscalationConfig, Session, preset
from jevjudge.backends.mock import MockBackend, keyword_rule

session = Session.from_turns("s1", [{"speaker": "user", "text": "fix my bill"},
                                    {"speaker": "agent", "text": "You idiot, read it yourself."}])
jev = MockBackend("jev", rules=[keyword_rule("output_toxicity__agent_toxic", ["idiot"], 0.99, 0.01)])
llm = MockBackend("llm", kind="llm")
grader = CriterionGrader([jev], EscalationConfig(judges=[], threshold=0.9), judges=[llm])
report = asyncio.run(grader.grade(session, preset("voice")))
print(report.rubric("output_toxicity").verdict)                   # fired
print(report.calls)                                               # {'jev': 3, 'llm': ...}
```

On the wire, question ids are `<rubric_id>__<criterion>` with `.` and `-` replaced by `_`.

## 3. YAML: `from_config`

```yaml
# configs/judge_v2.yaml
tiers:
- model: jev-stack
  members: [kairos-jev, kev-gemma, djev]
  combiner: ../experiments/registry/v2/combiner.json
escalation:
  judges:
  - model: gemini-3.8-flash
  - model: gemma-26b
    timeout: 60
  threshold: certified
  rationale: on_escalation
  audit_rate: 0.05
  use_fallback_rubric: false
registry: ../experiments/registry/v2/certificates.json
monitor: {enabled: true, eps: 0.05, alpha: 0.01, detector: cusum, state_path: ../experiments/registry/v2/monitor_state.json}
rubrics: [../src/jevjudge/metrics/voice_v2]
```

```python
from jevjudge import CriterionGrader, Judge

grader, rubrics = CriterionGrader.from_config("configs/judge_v2.yaml")   # async
judge = Judge.from_config("configs/judge_v2.yaml")                       # sync
```

Relative paths in the YAML (`rubrics`, `registry`, `combiner`, `monitor.state_path`) resolve against the YAML file's directory. Every key, including the governance (`phase`, `strata`) and `review` keys, is described in [Configuration](configuration.md).

## Reading a report

```python
r = report.rubric("output_pii")
r.verdict                    # "fired" | "clean" | None (no valid verdict answer)
r.verdict_probability        # P(positive label) of the final verdict answer
r.score, r.success           # DeepEval-style aggregate; success = passed (verdict clean)
r.reason                     # deterministic text assembled from probabilities (never generated)
v = r.criteria[0]
v.decision, v.escalation_reason, v.final_source, v.threshold, v.tier_answered
v.policy_source, v.shadow_threshold, v.stratum   # which governance branch set θ (certified thresholds)
v.system_one                 # one Answer per tier tried
v.system_two                 # fallback Answer (with .rationale when requested)
report.calls, report.cost_usd, report.latency_ms
report.meta["timings_ms"]    # per-stage latency: pack, route, decide:<tier>, gate, escalate, audit, aggregate
report.meta.get("review_enqueued")   # items sent to the human review queue (when one is configured)
```

!!! note "`success` means passed"
    For rubrics with a verdict, `success` is `verdict == "clean"`, so it respects `positive_label`. `score` is the DeepEval-style aggregate (P(true) for a Noul verdict).
