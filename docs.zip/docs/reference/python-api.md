# Python API

## Top-level exports (`import jevjudge`)

```python
from jevjudge import (
    Judge, CriterionGrader,                                   # judges
    DecisionModelConfig, LLMConfig, EscalationConfig, MonitorConfig, JudgeConfig,   # config
    Rubric, Criterion, load_rubrics, preset, presets,         # rubrics
    Noul, Choice, Score, Answer, GradeReport, WorkloadClass,  # types
    Session, Turn, ToolCall,                                  # subjects
)
import jevjudge; print(jevjudge.__version__)                  # 0.2.0
```

## Judges

### `Judge` (sync facade, `jevjudge.judge.sync`)

| Member | Signature |
|---|---|
| `Judge(grader, rubrics)` | wrap an existing `CriterionGrader` |
| `Judge.from_preset` | `(name="voice", tiers=("djev",), fallback="gemini-3.8-flash", threshold=0.9, rationale="on_escalation", **grader_kw)`; `fallback=None` gives Jev only (θ = 0) |
| `Judge.from_config` | `(path: str \| JudgeConfig)` |
| `Judge.from_rubrics` | `(rubrics: str \| list[Rubric], **from_preset_kw)` |
| `grade` | `(item, rubrics=None, mode="serve") -> GradeReport` |
| `grade_many` | `(items, rubrics=None) -> list[GradeReport]` |
| `agrade` | `async (item, rubrics=None) -> GradeReport` |
| `close` | `()`: closes backend HTTP clients |
| `.grader`, `.rubrics` | attributes |

### `CriterionGrader` (`jevjudge.judge.grader`)

```text
CriterionGrader(
    judge_model_config: DecisionModelConfig | list[DecisionModelConfig] | Backend | list[Backend] | None = None,  # default kairos-jev
    escalation: EscalationConfig | None = None,            # default: no judges, θ = 0
    *, registry: CertificateRegistry | str | None = None,
    monitor: AccuracyMonitor | MonitorConfig | None = None,
    code_checks: dict[str, Callable[[Session | None], str]] | None = None,
    judges: list[Backend] | None = None,                   # explicit System Two backends (overrides escalation.judges)
    max_state_tokens: int = 30000, concurrency: int = 16,
    packing: PackingConfig | dict | None = None, prompts: dict | None = None,
    review: ReviewConfig | ReviewQueue | str | None = None,  # human review queue (str = queue path)
)
```

| Member | Description |
|---|---|
| `from_config(cfg: JudgeConfig \| str) -> (grader, rubrics)` | classmethod; also applies `models:` overrides to the global registry |
| `await grade(item, rubrics, mode="serve") -> GradeReport` | `mode`: `serve`, `calibrate` or `collect` |
| `await grade_many(items, rubrics, mode="serve", on_result=None) -> list[GradeReport]` | `on_result(report)` callback per item |
| `await aclose()` | close HTTP clients |
| `records(report, rubrics, gold=None, stratum="all") -> list[JudgmentRecord]` | calibration records from a `calibrate` report; `gold` maps `rubric_id → 0/1` |
| `threshold_for(rubric, criterion, tier_idx, stratum="all") -> dict` | the θ policy used by the gate: `theta`, `source`, `certificate_id`, `calibration_version`, `monitor_eps`, `temperatures`, plus `shadow_theta`, `phase`, `stratum` when certified (see [Governance](../guides/governance.md#migration-phases)) |
| `stratum_of(session) -> str` | the Mondrian stratum key from `escalation.strata`, e.g. `"project=acme"`; `"all"` without strata |
| `tiers`, `judges`, `escalation`, `registry`, `monitor`, `reference_name` | attributes (`reference_name` = `judges[0].name`) |
| `review` | `ReviewQueue \| None`: offered every `serve`-mode report |
| `drift` | `DriftStats`: fed by every `serve`-mode report; replace it or set it to `None` to change or disable |
| `trace_profile`, `sink_mapping` | set by `from_config` from `ingest.profile` and `sinks.cmcs` |

`grade()` fills `report.meta` with `mode`, `tiers` and `judges` (backend fingerprints), `timings_ms` (per graph node, `decide:<tier>` per tier), the session's `project`, `source`, `trace_id` and `span_id`, and `review_enqueued` when a review queue is set.

`jevjudge.judge.grader.to_subject(item) -> (subject_id, session | None, raw_state | None)` normalises inputs.

## Configuration (`jevjudge.config`)

| Class | Fields |
|---|---|
| `DecisionModelConfig` | `model="kairos-jev"`, `name=None`, plus any registry override (extra keys allowed). `.build(reg=None) -> Backend` |
| `LLMConfig` | `model="gemini-3.8-flash"`, `name=None`, plus overrides (e.g. `two_order=True`, `timeout=60`). `.build()` |
| `EscalationConfig` | `judges` (one or many; str / dict / `LLMConfig`), `threshold=0.7` (float \| `"certified"` \| dict), `rationale="on_escalation"`, `reasoning="after"`, `audit_rate=0.0`, `style_sensitive_floor=0.95`, `derive_direct=True`, `max_escalations_per_subject=None`, `use_fallback_rubric=True`, `phase="enforce"` (`legacy_shadow` \| `tighter_of` \| `certified_preferred` \| `enforce`), `static_thresholds=None` (float \| dict), `strata=[]`, `pooled_fallback=False` |
| `MonitorConfig` | `enabled=True`, `eps=0.05`, `alpha=0.01`, `aci_gamma=0.02`, `state_path=None`, `detector="cusum"` (\| `"cumulative"`) |
| `JudgeConfig` | `tiers`, `escalation`, `registry`, `monitor`, `rubrics`, `concurrency=16`, `emit` (list of `jsonl` \| `otel` \| `langfuse` \| `phoenix` \| `cmcs`), `models`, `packing`, `prompts`, `ingest`, `sinks`, `review` (dict → `ReviewConfig`); `JudgeConfig.from_yaml(path)`, `.packing_config()` |
| `ModelRegistry(override=None)` | `.names()`, `.spec(name)`, `.resolve_url(url, route=None)`, `.endpoints`, `.models`, `.aliases` |
| `registry(override=None) -> ModelRegistry` | the process-wide registry; passing `override` replaces it |

All config classes are pydantic models, so construct them with keyword arguments.

## Rubrics and types

| Name | Module | Notes |
|---|---|---|
| `Rubric` | `core.rubric` | `id, version, description, guidelines, criteria, aggregate, threshold, output_alias, verdict_model, owner`; `.revision`, `.verdict_criterion`, `.criterion(name)`, `await .grade(item, grader)`, `Rubric.from_dict`, `Rubric.from_yaml`, `.to_yaml()` |
| `Criterion` | `core.rubric` | `name, question, weight, workload_class, view, chunking, verdict, escalate, positive_label, pass_label, high_stakes, fallback_instructions`; `.type`, `.should_escalate`, `.binary(label) -> 1 \| 0 \| None` |
| `load_rubrics(path)` | `core.rubric` | file, directory, multi-document YAML, or `rubrics:` list |
| `preset(name="voice")`, `presets()` | `metrics` | packaged rubric sets |
| `Noul`, `Choice`, `Score` | `core.types` | questions (`instructions`, plus `options/credits/escape` or `levels/higher_is_better`); `.labels`, `.wire()` |
| `VerdictModel` | `core.rubric` | `features: list[(member, criterion)], weights, bias, tier="jev-stack", n_train, note` (see [Rubrics](../concepts/rubrics.md#learned-verdict-model-verdict_model)) |
| `Answer` | `core.types` | `question_id, type, label, probabilities, native_confidence, expected_level, valid, error, backend, latency_ms, rationale, chunks, members` (ensemble: per-member probabilities); `.q`, `.p_true` |
| `CriterionResult` | `core.types` | `criterion, rubric_id, type, final, system_one, system_two, decision, escalation_reason, final_source, threshold, value, applied, passed, weight, calibration_version, tier_answered, policy_source, shadow_threshold, stratum, audit_sampled` |
| `RubricResult` | `core.types` | `rubric_id, revision, score, success, strict, verdict ("fired"/"clean"/None), verdict_probability, reason, criteria` |
| `GradeReport` | `core.types` | `subject_id, rubrics, latency_ms, calls, cost_usd, meta`; `.rubric(id)`, `.report` (alias of `rubrics`), `.verdicts()`, `.to_events()`, `.to_blob(mapping=None)` |
| `QuestionType`, `WorkloadClass`, `Decision`, `EscalationReason`, `FinalSource` | `core.types` | enums (`Decision.HUMAN` is defined but not produced) |
| `Session`, `Turn`, `ToolCall` | `core.session` | `Session.from_turns(session_id, turns, **kw)`, `.agent_turns`, `.tool_calls` |

## Scoring (`jevjudge.core.scoring`)

`value_of(criterion, answer) -> (value | None, applied)`, `passed(criterion, answer) -> bool | None`, `aggregate(rubric, results) -> (score, success)`, `deterministic_reason(rubric, results, score) -> str`.

## Packing and text

| Name | Signature |
|---|---|
| `packing.views.pack` | `(session, view="dialogue", opts=None) -> str` |
| `packing.views.PackOptions` | dataclass `(max_tokens=6000, tokenizer="tiktoken:cl100k_base", cfg=default_packing(), header=True)`; `.counter` |
| `packing.views.VIEWS` | `("agent_only", "dialogue", "grounded")` |
| `packing.chunking.ChunkSpec` | see [Chunking](../concepts/chunking.md); `.key`; `NO_CHUNKING` |
| `packing.chunking.chunk` | `(session, view, spec, opts) -> list[str]` (at least one state) |
| `packing.chunking.aggregate_p` | `(ps, how) -> float` |
| `packing.config.PackingConfig` | `PackingConfig.load(override=None)` |
| `text.get_counter(spec)` | `TokenCounter` with `.count(text)`, `.truncate(text, max_tokens)`, `.name` |
| `text.get_segmenter(spec)` | `.split(text) -> list[str]` |
| `text.get_retriever(spec)` | `Retriever.rank(query, passages, k) -> [(idx, score)]`, `.best_scores(queries, passages)` |

## Backends (`jevjudge.backends`)

| Class | Constructor |
|---|---|
| `base.Backend` | abstract: `name, version, kind, tokenizer, max_state_tokens, cost_per_call_usd, native_multi_question`; `async decide(DecideRequest) -> dict[str, Answer]`, `async aclose()`, `.fingerprint` |
| `base.DecideRequest` | dataclass `(state, questions, rationale=False, fallback_instructions={}, guidelines="")` |
| `base.answer_from_probs` | `(qid, question, probs, backend, **kw) -> Answer` (normalises; invalid if empty) |
| `kairos.KairosSystemOne` | `(base_url, model, *, name=None, route=None, api_key=None, api_key_env="JEV_API_KEY", timeout=30.0, retries=3, tokenizer=..., max_state_tokens=6000, cost_per_call_usd=0.0, max_concurrency=16, version=None)`; also `await health()`, `await raw(state, questions)` |
| `openai_compat.OpenAICompatLLM` | `(model, base_url, *, name=None, api_key=None, api_key_env=None, logprobs=True, top_logprobs=20, temperature=0.0, timeout=120.0, retries=3, max_state_tokens=100000, tokenizer=..., prompts=None, cost_per_call_usd=0.0, max_concurrency=8, two_order=False, version=None, extra_body=None, reasoning="after")` |
| `vertex.VertexGemini` | `(model="gemini-2.5-flash", *, name=None, project=None, location=None, logprobs=None, temperature=0.0, max_concurrency=8, max_state_tokens=400000, tokenizer=..., cost_per_call_usd=0.0, version=None, reasoning="after", timeout=90.0, retries=2)` |
| `ensemble.JevEnsemble` | `(members: list[Backend], combiner: Combiner \| None = None, name="jev-stack")`; `.combine(qid, question, member_answers) -> Answer` |
| `mock.MockBackend` | `(name="mock", rules=None, sharpness=0.8, kind="system_one", rationale_text="mock rationale", fail=False)`; `mock.keyword_rule(qid, keywords, p_hit=0.97, p_miss=0.03)` |

## Calibration (`jevjudge.calibration`)

| Name | Signature |
|---|---|
| `engine.TierObs` | dataclass `(label, probabilities, valid=True, latency_ms=None)` |
| `engine.JudgmentRecord` | dataclass `(subject_id, rubric_id, revision, criterion, qtype, positive_labels, tiers={}, reference=None, reference_name=None, gold=None, stratum="all", meta={})`; `.to_json()`, `from_json()` |
| `engine.RunStore(path)` | `.append(records)`, `.load()` (JSONL) |
| `engine.CalibrationEngine` | `(records, *, eps=0.02, delta=0.05, method="auto", grid=DEFAULT_GRID, min_n=100, ttl_days=30, costs=None, fit_temperature=True, seed=0)`; `.analyse(recs, tiers=None)`, `.certify_unit(recs, tiers, *, eps=None, mode=None, method=None) -> (Certificate, analysis)`, `.run(tiers=None) -> (certs, reports)` |
| `engine.Certificate` | dataclass (`certificate_id, unit_id, rubric_revision, criterion, tier_models, reference_model, fingerprint, mode, method, eps, delta, n_cal, n_valid, thetas, temperatures, state, issued_at, expires_at, summary, stratum, approver, approved_at, supersedes, history`); `.theta(k)`. `state`: `PROPOSED`, `ACTIVE`, `SUPERSEDED`, `ROLLED_BACK`, `REVOKED` |
| `engine.dump_report(reports, certs, path)` | JSON report |
| `engine.unit_id`, `engine.fingerprint` | `unit_id(rubric, criterion, qtype)`, `fingerprint(revision, tiers, reference)` |
| `registry.CertificateRegistry(path=None)` | `.load()`, `.save()`, `.propose(cert)`, `.approve(cert_id, approver, note="")`, `.rollback(unit_id, stratum="all", by=None, note="") -> Certificate \| None`, `.revoke(cert_id, by=None, note="")`, `.history(unit_id) -> list[dict]`, `.promote(cert)` (activate without approval), `.active(uid, stratum="all")`, `.all()`, `.policy(rubric_id, criterion, qtype, revision, tiers, reference, stratum="all", pooled_fallback=False) -> Policy`. See [Governance](../guides/governance.md#certificate-lifecycle) |
| `registry.Policy` | `thetas, source, certificate_id, calibration_version, temperatures, monitor_eps` |
| `monitor.AccuracyMonitor` | `(eps=0.05, alpha=0.01, aci_gamma=0.02, state_path=None, detector="cusum")`; `.observe(unit, disagree, certified_theta=None, eps=None) -> frozen`, `.is_frozen(unit)`, `.theta(unit, certified)`, `.reset(unit)`, `.summary()` |
| `drift.EProcessAlarm`, `drift.ACIThreshold` | the online alarm and the tighten-only controller |
| `drift_stats.DriftConfig` | `baseline_n=500, window=500, psi_alarm=0.2, escalation_change_alarm=0.30, valid_floor=0.999, min_window=100` |
| `drift_stats.DriftStats(cfg=None, state_path=None)` | `.observe(unit, q, escalated, valid)`, `.set_baseline(unit, q, escalated, valid=None)`, `.report() -> {unit: {baseline_n, window_n, psi_q, escalation_rate, valid_rate, alarms}}`, `.alarms() -> {unit: [alarm]}`, `.save()`. See [Monitoring](../guides/monitoring.md#drift-statistics) |
| `drift_stats.psi(a, b, bins=BINS)` | population stability index of two confidence samples |
| `combiner.Combiner` | `(members, weights={}, positive={}, meta={})`; `.combine(key, member_p_pos)`, `.version`, `.save(path)`, `Combiner.load(path)` |
| `combiner.fit_from_board(rows, rubrics, members, l2=1.0)` | fit per-metric logistic weights from board rows |
| `combiner.qkey(rubric_id, criterion)` | the wire question id |
| `combiner.feature_matrix(rows, rubric, members, key="answers_all")` | per-member, per-criterion P(positive) features from collect-mode board rows |
| `combiner.fit_verdict_model(rows, rubric, members, tier="jev-stack", l2=3.0) -> VerdictModel` | fit a rubric's learned verdict (see [Decomposed metrics](../guides/decomposed-metrics.md)) |
| `combiner.logit(p)`, `combiner.fit_logistic(X, y, l2=1.0, iters=50)` | helpers (clipped logit; L2 logistic regression, last weight = bias) |
| `solver.solve(data, mode, method, eps, delta, ...)` | the vendored LTT / SGR / CMU-LCB solver |

## OTel and adapters

| Name | Signature |
|---|---|
| `otel.ingest.session_from_otlp` | `(payload, session_id=None, profile: TraceProfile \| str \| Path \| None = None) -> Session` |
| `otel.ingest.TraceProfile` | `TraceProfile.load(path=None)` |
| `otel.ingest.iter_spans(payload)` | yields `(resource_attrs, span)` |
| `adapters.cmcs.session_from_prod_transcript` | `(session_id, text, system_prompt="", **session_kw) -> Session` (also importable from `otel.ingest`) |
| `otel.emit.events(report)` | list of `gen_ai.evaluation.result` events |
| `otel.emit.metrics_blob(report, mapping=None)`, `otel.emit.cmcs_blob(report)` | mapped blob |
| `otel.emit.JsonlSink(path)`, `otel.emit.OtelSink(tracer_provider=None, scope="jevjudge")` | callables `sink(report)` |
| `otel.sinks.LangfuseSink(host=None, public_key=None, secret_key=None, transport=None)` | callable `sink(report) -> int` (scores written); env `LANGFUSE_HOST`, `LANGFUSE_PUBLIC_KEY`, `LANGFUSE_SECRET_KEY` |
| `otel.sinks.PhoenixSink(host=None, api_key=None, transport=None)` | callable `sink(report) -> int` (annotations written); env `PHOENIX_HOST`, `PHOENIX_API_KEY`; needs `report.meta["span_id"]` |

## Converter, Studio, integrations

| Name | Signature |
|---|---|
| `converter.agent.convert` | `async (prompt, llm, decider=None, cases=None, *, target_acc=0.9, max_refine=2, max_lint=3) -> (list[Rubric], log)` |
| `converter.agent.build_converter` | `(llm, decider=None, *, target_acc=0.9, max_refine=2, max_lint=3)`: the compiled graph |
| `converter.agent.lint_rubric(d)` | `list[str]` of issues |
| `studio.Project` | `Project.create(name, root=None, description="")`, `Project.open(pid, root=None)`, `Project.list(root=None)`, `.add_traces(src, filename=None)`, `.add_labels(src, filename=None)`, `.use_preset(name)`, `.save_rubric(r)`, `.rubrics()`, `.sessions()`, `.labels()`, `await .convert_prompt(prompt, llm="gemini-3.8-flash", decider=None, max_refine=1)`, `await .run(tiers, reference, on_progress=None, concurrency=8, limit=None)`, `.board()`, `.calibrate(eps=0.03, delta=0.05, min_n=50, stack=False, approve_as="studio:auto")` (`approve_as=None` only proposes), `.registry()`, `.certificates()`, `.approve_certificate(cert_id, approver, note="")`, `.rollback_certificate(unit_id, stratum="all", by=None, note="")`, `.review_queue() -> ReviewQueue`, `.import_review_labels() -> int`, `.report()`, `.export(base_url=...)`, `.delete()` |
| `studio.loaders.load_sessions(src, filename=None)` | auto-detected trace loading |
| `integrations.langgraph` | `jev_judge_node(config, input_key="trace", output_key="evaluation", rubrics=None, full_report=False)`, `jev_route(metric, on_fired, on_clean, on_unknown=None, output_key="evaluation")`, `judge_subgraph(grader)`, `compact(report)` |
| `integrations.deepeval.JevRubricMetric` | `(judge, rubric_id, threshold=0.5, higher_is_better=False)` |

## Human review (`jevjudge.review`)

| Name | Signature |
|---|---|
| `ReviewConfig` | `path="review_queue.jsonl", audit_rate=0.01, unsure_margin=0.7, near_threshold=0.05, high_stakes=True` |
| `ReviewQueue(cfg: ReviewConfig \| str \| Path \| None = None)` | `.offer(report, rubrics, trace_ref=None) -> int`, `.reasons(report, rubric, criterion_result) -> list[str]`, `.pending(limit=50, reason=None) -> list[dict]`, `.label(item_id, fired, reviewer, note="", new_failure_mode=None) -> dict`, `.stats() -> dict`, `.export_labels(path) -> int`. See [Human review queue](../guides/review-queue.md) |

## Errors (`jevjudge.errors`)

`JevJudgeError` → `ConfigError(ValueError)`, `BackendError(RuntimeError)`, `CalibrationError(ValueError)`. Judging itself never raises on backend failure: failed answers become invalid answers and escalate. `ConfigError` is raised for an unknown model or provider and for `threshold="certified"` without a registry. Elsewhere the code still raises plain `ValueError`, `KeyError` and `TypeError` (for example `CertificateRegistry.approve` on an unknown id or a wrong state), so catch `ValueError` / `KeyError` as well.
