import json, sys, time, torch, random
from toy_pointer import *
torch.set_num_threads(8)
SEEDS = [0, 1]; STEPS = int(sys.argv[1]) if len(sys.argv) > 1 else 3500
L0 = 64; LENS = [64, 128, 256, 512]; QT = ["noul", "choice", "score"]
MODELS = {
  "base":         dict(L0=L0, steps=STEPS, k_train=(2, 6)),               # few distractors in training (like 8K-trained baseline)
  "hard_distract":dict(L0=L0, steps=STEPS, k_train=(6, 30)),              # same length, many distractors (IN2/FILM-style)
  "length_mix":   dict(L0=L0, steps=STEPS, k_train=(2, 6), L_mix=[64, 64, 128, 256]),   # train at length (ProLong/IN2-style ladder)
  "ssmax_trained":dict(L0=L0, steps=STEPS, k_train=(2, 6), ssmax_train=True),
  "sandwich":     dict(L0=L0, steps=STEPS, k_train=(2, 6), sandwich=True),
}
out = []; t0 = time.time()
def log(**r):
    out.append(r); print(json.dumps(r), f"t={time.time()-t0:.0f}s", flush=True); json.dump(out, open("results_toy.json", "w"), indent=1)
for name, cfg in MODELS.items():
    for seed in SEEDS:
        m = train(cfg, seed).eval(); torch.save(m.state_dict(), f"ckpt_{name}_s{seed}.pt")
        for L in LENS:
            kL = L // 16                                          # realistic: distractors grow with length
            for qt in QT:
                log(exp="length", model=name, seed=seed, L=L, k=kL, qtype=qt, mode="single", **evaluate(m, cfg, L, kL, qt, n=200))
                if name == "base" and L > L0:
                    for tau in [1.0, 0.5]:
                        log(exp="length", model=name, seed=seed, L=L, k=kL, qtype=qt, mode=f"tau{tau}", **evaluate(m, dict(cfg, tau=tau), L, kL, qt, n=200))
                    for md in ["chunk_max", "chunk_logsum"]:
                        log(exp="length", model=name, seed=seed, L=L, k=kL, qtype=qt, mode=md, **evaluate(m, cfg, L, kL, qt, n=200, mode=md, chunk=L0))
        if name in ("base", "hard_distract"):
            for k in [2, 6, 14, 30]:                              # (d) distractors at fixed length 64
                for qt in QT: log(exp="distract_fixL", model=name, seed=seed, L=64, k=k, qtype=qt, mode="single", **evaluate(m, cfg, 64, k, qt, n=200))
            for L in LENS:                                        # (d) length at fixed distractors k=4
                for qt in QT: log(exp="length_fixk", model=name, seed=seed, L=L, k=4, qtype=qt, mode="single", **evaluate(m, cfg, L, 4, qt, n=200))
            for no in [2, 4, 8, 16, 31]:                          # (e) option count, L=128,k=4 (trained with 8)
                log(exp="options", model=name, seed=seed, L=64, k=4, qtype="choice", n_opt=no, mode="single", **evaluate(m, cfg, 64, 4, "choice", n=200, n_opt=no))
