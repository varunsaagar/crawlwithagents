# Onboarding a use case: the JEV trace contract

Every use case sends the judge one trace shape: **`jev.trace/v1`**. It is a strict subset of the
[OpenTelemetry GenAI semantic conventions](https://opentelemetry.io/docs/specs/semconv/gen-ai/), so any OTel SDK or
Collector can produce it, and other GenAI tools still read it. The rules are data, in
`src/jevjudge/resources/contract/v1.yaml` (`GET /v1/otel/contract` serves the same file).

## The shape

| What | Span | Required attributes (MUST) | Recommended (SHOULD) |
|---|---|---|---|
| resource | — | `service.name`, `vz.project_slug.use_case` | `gen_ai.agent.channel` (voice/chat), `jev.contract.version` |
| every span | — | `gen_ai.conversation.id` (same value on all spans of a conversation) | start/end timestamps |
| turn | `invoke_agent {agent}`, `gen_ai.operation.name=invoke_agent` | `jev.turn.index` (1, 2, …), `gen_ai.input.messages` (only the new user message), `gen_ai.output.messages` (the reply the user heard or saw) | `gen_ai.agent.name`, `gen_ai.system_instructions` |
| tool call | `execute_tool {tool}`, `gen_ai.operation.name=execute_tool`, child of its turn | `gen_ai.tool.name`, `gen_ai.tool.call.result` (status ERROR on failure) | `gen_ai.tool.call.arguments`, `gen_ai.tool.call.id` |

Messages are JSON arrays: `[{"role": "user", "parts": [{"type": "text", "content": "..."}]}]`. An empty payload (`{}`)
means content capture is off, and the conversation is not conformant.

## Three ways to get there

**1. Emit it directly.** Use this for new agents.

```python
from jevjudge.otel.contract import ContractRecorder

rec = ContractRecorder("call-123", use_case="ces_hotline", service="hotline-agent", channel="voice")
rec.turn(user="cancel my add-on", agent="Done, it is removed.",
         tools=[{"name": "cancel_addon", "arguments": {"id": 1}, "result": {"success": True}}])
requests.post(f"{JEVJUDGE}/v1/traces", json=rec.to_otlp())     # or rec.emit(tracer) through your OTel SDK
```

**2. Keep your exporter and route it through the JEV collector.** Use this for existing agents.
`deploy/otel-collector/jev-collector.yaml` does the following:

- stamps the use case and channel;
- maps every known conversation-id key to `gen_ai.conversation.id`;
- removes identity attributes the judge does not need;
- drops spans that are not GenAI;
- exports to the judge's `POST /v1/traces`.

The judge converts every dialect that `otel-check` reports as ready (OTel GenAI attributes or events, OpenLLMetry,
OpenInference, LangSmith/LangGraph, Google ADK, Sierra / Decagon / CES) into `jev.trace/v1`. It stores the result under
`$JEVJUDGE_TRACE_STORE/<use case>.jsonl`. Collector batches split conversations, so readers regroup by
`gen_ai.conversation.id`; `jevjudge otel-validate`, `otel-normalize` and `grade` already do.

**3. Convert offline.** Use this for backfills: `jevjudge otel-normalize exported.jsonl contract.jsonl --use-case ces_hotline`.

## Will it work for my team?

```bash
jevjudge otel-check  sample.jsonl     # can the judge read these traces? verdict + reasons + derived profile
jevjudge otel-validate sample.jsonl   # are they already jev.trace/v1? which MUST rules fail
```

| `otel-check` says | Meaning | Do |
|---|---|---|
| ready | the judge reads your traces as they are | route 2 or 3 |
| partial / unsupported, with **BLOCKER: message content is not exported** | your exporter redacts the messages; no parser can recover them | apply the fix printed with it (e.g. unset `LANGSMITH_HIDE_INPUTS`/`_OUTPUTS`, `OTEL_INSTRUMENTATION_GENAI_CAPTURE_MESSAGE_CONTENT=true`) |
| "user text but no agent reply in any span" | the reply is never recorded (last LLM output is only a function call, or a sub-agent run as a tool exports no content) | record the final reply: emit a turn span (route 1) or enable content capture for the sub-agent |
| unclassified spans carry messages | a span naming scheme the default profile does not know | use the derived profile (`--write-profile`) |

## Prod validation (2026-10-09, 27 projects / 1,806 conversations from `vz_aid_otel_traces_tbl`, Dataproc)

| | Result |
|---|---|
| raw traces already conformant | 0 / 1,806 (nobody emits the contract yet) |
| after `otel-normalize` | **1,499 / 1,520 conformant (98.6%)**; 281 refused (no message content at all) |
| fidelity (agent text, user text, tools, tool errors, agent turns: raw vs normalized) | 1,520 / 1,520 exact |
| batch splitting (`split_envelope` + `group_conversations`) | 0 wrong merges |

By project: 100% conformant are CES_VOICE_AGENT, SIERRA_PILOT (299/300), ces_hotline (299/300), CES_VOICE_AGENT_NONBILLING
(297/300) and 18 smaller agents. vz-gpt reaches 149/153, VCG_ORION_AGENT_PROD 14/16 and VCG_ORION_AGENT_PREPROD 10/17.

Every remaining failure is content that the source never sent:

- **No agent reply** (13 conversations). Examples: a Google ADK sub-agent run as a tool exports no content, or the
  conversation ends in a tool call.
- **No user input** (7 conversations, VCG_ORION_AGENT_PREPROD).
- **A tool span without a result** (1 conversation).
- **Refused, no content at all** (281 conversations):
  - otel-unknown-agent (LangSmith exports `{}`) blocks 254.
  - GNT_KP_AI_WIRELESS (not a conversation) accounts for 26.
