# Changelog

## Unreleased (after 0.2.0)

`jevjudge.__version__` is still `0.2.0`.

### Added

* **Threshold governance** ([guide](guides/governance.md)):
    * migration phases `EscalationConfig.phase` (`legacy_shadow`, `tighter_of`, `certified_preferred`, `enforce`) with `static_thresholds`;
    * Mondrian strata (`EscalationConfig.strata`, `pooled_fallback`, `CriterionGrader.stratum_of`) and a stratum-aware `threshold_for(..., stratum)`;
    * certificate lifecycle in `CertificateRegistry`: `propose`, `approve(approver)` (with `supersedes`), `rollback`, `revoke`, `history`, and `policy(..., stratum, pooled_fallback)`. Certificates gain `approver`, `approved_at`, `supersedes` and an event `history`;
    * `CriterionResult.policy_source`, `shadow_threshold` and `stratum`, emitted as `jev.policy.source`, `jev.shadow_threshold` and `jev.stratum`.
* **Human review queue** ([guide](guides/review-queue.md)): `jevjudge.review` (`ReviewConfig`, `ReviewQueue` with `offer`, `pending`, `label`, `stats`, `export_labels`), `JudgeConfig.review`, `CriterionGrader(review=...)`, `report.meta["review_enqueued"]`, and per-project queues in the Studio (`Project.review_queue`, `import_review_labels`).
* **Drift statistics** ([guide](guides/monitoring.md#drift-statistics)): `jevjudge.calibration.drift_stats` (`DriftConfig`, `DriftStats`: PSI of q, escalation-rate change, valid rate), fed by every served report into `grader.drift`. `jevjudge grade` prints drift alarms.
* **Monitor detector**: `MonitorConfig.detector` / `AccuracyMonitor(detector=...)`, `cusum` (default, restarting e-detector) or `cumulative` (the previous behaviour).
* **Sinks**: `jevjudge.otel.sinks.LangfuseSink` and `PhoenixSink`. `emit:` in the judge YAML now selects the `jevjudge grade` sinks (`jsonl`, `otel`, `langfuse`, `phoenix`, `cmcs`), and `ingest.profile` / `sinks.cmcs` are applied by `from_config`.
* **Per-stage timings**: `report.meta["timings_ms"]` (`pack`, `route`, `decide:<tier>`, `gate`, `escalate`, `audit`, `aggregate`).
* **v2 serving artifacts** ([guide](guides/decomposed-metrics.md), [results](results.md)): preset `voice_v2` with decomposed `action_completion` (11 detail questions) and `output_toxicity` (8 detail questions), each with a learned `verdict_model` for a 3-member `jev-stack` (kairos-jev, kev-gemma, djev); `configs/judge_v2.yaml`; `experiments/build_registry_v2.py` (60/40 split, out-of-fold certification against gemini-3.8-flash); `experiments/decomp_analysis.py`.
* **HTTP API** ([reference](reference/http-api.md#governance)): `GET /v1/projects/{id}/certificates`, `POST .../certificates/{cert_id}/approve`, `POST .../certificates/rollback`, `GET /v1/projects/{id}/review`, `POST .../review/{item_id}`, `POST .../review/import`, `GET /v1/projects/{id}/drift`, `GET /v1/projects/{id}/sessions`.

### Changed

* **Default tier is `djev`** for `Judge.from_preset` and `POST /v1/judge` (was `kairos-jev`). `CriterionGrader()` and `DecisionModelConfig()` still default to `kairos-jev`.
* **Studio calibration proposes, then approves** each certificate as `studio:auto`. `Project.calibrate(approve_as=None)` only proposes.
* **Calibrate mode keeps verdict-model features**: in `mode="calibrate"`, detail criteria that feed a rubric's `verdict_model` are now answered, so such rubrics no longer return invalid verdicts there.
* **The monitor's default detector is `cusum`**: detection delay no longer grows with the length of the healthy period. Set `detector: cumulative` for the previous anytime-valid test.
* `threshold="certified"` without a registry, and unknown models or providers, raise `ConfigError` (a `ValueError` subclass).

## 0.2.0 (2026-10-09)

### Added

* **Library-based text layer** (`jevjudge.text`):
    * exact backend tokenizers (`hf:<repo>` via Hugging Face `tokenizers`, `tiktoken:<enc>`, `chars:<ratio>` fallback);
    * pysbd sentence segmentation;
    * BM25 retrieval (`bm25s`, library stop-words).

    Hand-written regexes and word lists are gone, and every component is chosen by a spec string from YAML.
* **Token budgets.** Each backend has a `max_state_tokens` budget counted with its own tokenizer, set in the registry. These replace character budgets.
* **Multi-chunk packing** (`Criterion.chunking`, `ChunkSpec`):
    * `window`: turn windows with overlap and `carry: user | opening`; oversized lines split with LangChain's `RecursiveCharacterTextSplitter`;
    * `units`: sentence units paired with BM25-retrieved evidence passages;
    * per-criterion aggregation: `max`, `noisy_or`, `mean`, `last`, `first`.
* **Everything configurable in YAML.** These are packaged resources that you can override:
    * model registry (`models.yaml`), including the Kairos gateway models (`gw/*`, `gemini-3.8-flash*`);
    * packing (`packing.yaml`) and LLM prompts (`prompts.yaml`);
    * OTel trace profiles (`profiles/default.yaml`) and sink mappings (`sinks/cmcs.yaml`);
    * converter prompts and lint rules (`converter.yaml`).

    Endpoints use `${VAR:-default}` expansion, `$JEVJUDGE_MODELS` adds a registry overlay, and `models:` / `packing:` / `prompts:` work in judge YAML.
* **Profile-driven OTel ingest**, with structural tool-error detection and a stripper for echoed tool-call syntax.
* **Calibration Studio**:
    * the `jevjudge.studio.Project` workflow (traces → labels → rubrics → run → calibrate → export);
    * the FastAPI server with web UI (`jevjudge serve`, `jevjudge.server.app`);
    * export of copy-paste Python, LangGraph, curl and `judge.yaml`.
* **Sync `Judge` facade** (`Judge.from_preset`, `from_config`, `from_rubrics`), plus `GradeReport.to_blob()`, `.to_events()` and `.verdicts()`.
* **Integrations**: LangGraph (`jev_judge_node`, `jev_route`, `judge_subgraph`) and DeepEval (`JevRubricMetric`).
* **Packaged presets** (`jevjudge.metrics.preset("voice")`, `"voice_decomposed"`), including the decomposed action-completion rubric.
* **`collect` grading mode**: every tier answers every criterion, for feature collection.
* **Learned verdict model** (`Rubric.verdict_model`, `calibration.combiner.fit_verdict_model`): a logistic verdict over per-member, per-criterion probabilities. Ensemble tiers are fanned out in the graph, so each member is packed and chunked with its own budget, and `Answer.members` keeps each member's probabilities.
* **Packaging**:
    * extras `studio`, `vertex`, `otel`, `bigquery`, `deepeval`, `notebooks`, `docs`, `dev`, `all`;
    * `py.typed`;
    * the `jevjudge.errors` hierarchy;
    * a Makefile and this documentation site.

### Changed

* **Package layout.** Modules moved into subpackages:
    * `jevjudge.types`, `rubric`, `scoring`, `session` → `jevjudge.core.*`;
    * `grader`, `graph` → `jevjudge.judge.*`;
    * `packer` → `jevjudge.packing.views`;
    * `backends.llm` → `backends.openai_compat`.

    The top-level imports (`from jevjudge import CriterionGrader, ...`) are unchanged.
* **Model resolution** now goes through the YAML registry. Endpoints, keys, tokenizers and budgets are no longer in code.
* **Gateway Gemini** runs with thinking disabled (`extra_body: {reasoning_effort: disable}`), because thinking consumed the one-token verdict.

### Fixed

* **Stable revisions.** Rubric revisions don't change across schema additions: a default `chunking` block is left out of the hash, so existing certificates stay valid. A regression test covers this.

## 0.1.0 (2026-10-08)

The MVP:

* typed rubrics (Noul / Choice / Score) and the LangGraph judge graph (pack → route → decide ⇄ gate → escalate → audit → aggregate);
* Kairos, OpenAI-compatible, Vertex, ensemble and mock backends;
* the Learn-then-Test calibration engine, the fail-closed certificate registry, the logistic combiner and the e-process accuracy monitor;
* OTel `gen_ai.evaluation.result` emit and the CMCS blob;
* the converter agent and the five voice metrics;
* the experiments and REPORT.
