import os, sys, cairosvg
import svgkit2 as K
from svgkit2 import SVG
OUT="/workspace/fine-tuning/diagrams/jev-64k-recipe"; os.makedirs(OUT,exist_ok=True)
W,H=1600,640; s=SVG(W,H)
s.text(50,60,"Jev 64K recipe: build, teach, stretch, calibrate, serve",30,"bold")
cols=["#eef3f8","#f6eef6","#fdf6e9","#eef4ee","#eef5f5"]
nodes=[("Data build",["Short Jev rows","Pad to 8K-64K","Evidence 3 spots","2-300 options"]),
       ("Teacher",["Gemma-4-31B","Keep if = gold","No Qwen"]),
       ("Curriculum",["8K, 32K, 64K","25% short mix","LoRA r16 + KL"]),
       ("Calibrate",["3-seed soup","Temp per kind","LTT per bucket"]),
       ("Serve",["Doc once, many Qs","Prefix cache","FP8 KV, <=8K"])]
bw,gap,y,h=266,50,140,300
for i,(t,ls) in enumerate(nodes):
    x=50+i*(bw+gap); s.node(i+1,x,y,bw,h,t,ls,fill=cols[i],ls=19,gap=34)
    if i<4: s.path([(x+bw+4,y+h/2),(x+bw+gap-4,y+h/2)])
s.path([(50+3*(bw+gap)+bw/2,y+h+8),(50+3*(bw+gap)+bw/2,y+h+70),(50+2*(bw+gap)+bw/2,y+h+70),(50+2*(bw+gap)+bw/2,y+h+8)],color=s.MUTE,head="ahm",dash="8 6")
s.label(50+2*(bw+gap)+bw/2+150,y+h+100,"Bucket fails ECE gate: retrain",18,anchor="middle")
s.text(50,600,"E4B = fast tier.  26B-A4B = 64K tier.  31B = teacher and escalation.",19,fill=s.SUB)
p=s.save(f"{OUT}/jev-64k-recipe.svg")
cairosvg.svg2png(url=p,write_to=f"{OUT}/jev-64k-recipe.png",output_width=2400)
cairosvg.svg2png(url=p,write_to=f"{OUT}/jev-64k-recipe-1000px.png",output_width=1000)
if K.WARN: print("\n".join(K.WARN)); sys.exit(1)
print("ok")
