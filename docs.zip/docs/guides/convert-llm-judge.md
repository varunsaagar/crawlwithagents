# Convert an LLM judge

The converter (`jevjudge.converter.agent`) is a LangGraph agent. It reads an existing LLM-as-judge prompt and writes **one validated Jev rubric per metric**. The prompt can be in any style: G-Eval, POML, or a JSON-schema judge with system and user templates. Each rubric carries the original rubric text as `fallback_instructions`, so the escalation judge keeps the incumbent's exact criteria.

```mermaid
flowchart LR
    A[analyze] --> D[draft + polarity check]
    D --> L{lint}
    L -->|"issues, ≤ max_lint rounds"| D
    L -->|clean, cases given| P["probe<br/>(decider on labelled cases)"]
    L -->|clean, no cases| E[emit]
    P -->|"acc < target, ≤ max_refine"| R[refine]
    R --> L
    P --> E["emit<br/>(best draft per metric)"]
```

* **analyze**: the LLM lists every metric in the prompt, with its output type, polarity, violations, exemptions, levels or categories, and evidence view.
* **draft**: one proposition per metric (60–170 words), ending with "It does NOT count …". A **polarity check** asks the LLM whether `true` means a failure. If `true` means good behaviour, `positive_label` is set to `false`.
* **lint**: schema validity, one verdict, question length (≤ 1,200 characters, ≥ 60 for a verdict), no formatting or reasoning phrases, an escape label on Choice verdicts, and an explicit exemption clause.
* **probe / refine**: with labelled cases and a decider, the agent measures each draft's accuracy, shows the LLM the misses, and rewrites the question (the version bumps from 1.0 to 1.1). **emit** keeps the best-scoring draft, so a refinement that hurts is discarded.

The prompts and lint rules live in `resources/converter.yaml`: the `prompts.{analyze,draft,polarity,refine}`, `lint.*` and `defaults.*` keys.

## CLI

```bash
jevjudge convert --prompt judge_prompt.txt --out configs/rubrics/new
jevjudge convert --prompt judge_prompt.txt --cases labelled.jsonl --decider djev --llm gemma-26b \
                 --target-acc 0.9 --max-refine 2 --out configs/rubrics/new
```

Each rubric is written to `<out>/<id>.yaml` with a `# <revision> (converted)` header line, and the agent's log is printed.

## Python

```python
import asyncio
from pathlib import Path
from jevjudge import DecisionModelConfig, LLMConfig
from jevjudge.converter.agent import convert, lint_rubric

async def main():
    llm = LLMConfig(model="gemma-26b", timeout=300).build()        # writes the rubrics (OpenAI-compatible or Vertex)
    decider = DecisionModelConfig(model="djev").build()             # probes drafts on cases (optional)
    cases = [
        {"session": {"session_id": "a", "turns": [{"index": 1, "speaker": "agent", "text": "You idiot."}]},
         "labels": {"output_toxicity": 1}},
        {"state": "AGENT: Happy to help with your bill.", "labels": {"output_toxicity": 0}},
    ]
    rubrics, log = await convert(Path("judge_prompt.txt").read_text(), llm, decider, cases,
                                 target_acc=0.9, max_refine=2)
    for r in rubrics:
        Path(f"out/{r.id}.yaml").write_text(r.to_yaml())
    print("\n".join(log))
    await llm.aclose(); await decider.aclose()

# asyncio.run(main())
```

`convert(prompt, llm, decider=None, cases=None, *, target_acc=0.9, max_refine=2, max_lint=3) -> (list[Rubric], list[str])`

Case format: a `session` (a `Session` dict) or a raw `state` string, plus `labels: {metric_name: 0|1}`, where 1 means the metric fired. If the prompt has a single metric, a top-level `label` is accepted. Metric names are the snake_case ids the analyzer derives, for example `output_toxicity`.

You can also lint a rubric you wrote by hand:

```python
from jevjudge.converter.agent import lint_rubric
print(lint_rubric({"id": "rudeness", "criteria": [{"name": "agent_rude", "type": "noul", "verdict": True,
                                                   "instructions": "The agent was rude. Respond with JSON."}]}))
# ['agent_rude: verdict question too short to be unambiguous', "agent_rude: question asks for output formatting/reasoning ('respond with')",
#  "agent_rude: no explicit exemption clause ('It does NOT count ...')"]
```

## What to expect

From the experiments (REPORT §6):

* On an **unseen prompt** (the CMCS quality judge, 6 metrics), the agent produced 6 valid rubrics. It caught a lint false positive, and the polarity check fixed two drafts that had been phrased as the pass case. The output is in `configs/rubrics/converted/`.
* **Refinement against cases did not help a weak decider.** kairos-jev train accuracy went from 0.64 to 0.40–0.47, and keep-best correctly kept the first draft. With djev, held-out accuracy went from 0.70 to 0.73. The hand-converted CMCS question still scored higher (0.88).
* **The agent is good at structure:** typed questions, escape labels, polarity and the verbatim fallback rubric. Question wording is not the main lever for weak models. Model choice and stacking matter more, so calibrate the converted rubrics before serving them.

In the [Calibration Studio](calibration-studio.md), conversion is step 3, "Judge definition" (`POST /v1/projects/{id}/convert`). There the project's labelled sessions are used as cases when you pick a decider.
