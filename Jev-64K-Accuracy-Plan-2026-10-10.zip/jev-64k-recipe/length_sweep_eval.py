"""Accuracy/ECE vs context length for a Jev endpoint (/v1/systemone-style). Pads each eval item to 4/8/16/32/64K with
same-source distractors (reuses build_long_context.build_row) at start/middle/end; reports acc, ECE per (len, pos).
Gate: acc(8K) - acc(64K) <= 2pp and ECE <= 0.03 per bucket."""
import argparse, json, random, statistics, urllib.request
from build_long_context import build_row

def ece(conf, ok, bins=10):
    e = 0.0
    for b in range(bins):
        idx = [i for i, c in enumerate(conf) if b / bins <= c < (b + 1) / bins or (b == bins - 1 and c == 1.0)]
        if idx: e += len(idx) / len(conf) * abs(statistics.mean(ok[i] for i in idx) - statistics.mean(conf[i] for i in idx))
    return e

def call(url, row):
    body = json.dumps({"text": row["text"], "question": row["question"], "kind": row.get("kind", "choice"),
                       "options": row["options"]}).encode()
    r = json.load(urllib.request.urlopen(urllib.request.Request(url, body, {"Content-Type": "application/json"}), timeout=600))
    return r["answer"], float(r["confidence"])

def main():
    ap = argparse.ArgumentParser(); ap.add_argument("--eval", required=True); ap.add_argument("--pool", required=True)
    ap.add_argument("--url", default="http://localhost:8000/v1/systemone"); ap.add_argument("--n", type=int, default=300)
    ap.add_argument("--lens", default="4096,8192,16384,32768,65536"); ap.add_argument("--dry", action="store_true")
    a = ap.parse_args(); rng = random.Random(0)
    ev = [json.loads(l) for l in open(a.eval)][: a.n]; pool = [json.loads(l) for l in open(a.pool)]
    res = {}
    for L in map(int, a.lens.split(",")):
        for pos in ("start", "middle", "end"):
            conf, ok = [], []
            for r in ev:
                row = build_row(r, pool, L - 512, pos, rng, None, len(r["options"]))
                if a.dry: ans, c = r["answer"], 1.0
                else: ans, c = call(a.url, row)
                conf.append(c); ok.append(int(ans == r["answer"]))
            res[(L, pos)] = (statistics.mean(ok), ece(conf, ok))
            print(f"{L:>6} {pos:6} acc={res[(L,pos)][0]:.3f} ece={res[(L,pos)][1]:.3f}")
    a8 = statistics.mean(res[(8192, p)][0] for p in ("start", "middle", "end"))
    a64 = statistics.mean(res[(65536, p)][0] for p in ("start", "middle", "end")) if (65536, "start") in res else a8
    print(f"drop 8K->64K = {100*(a8-a64):.1f}pp  GATE {'PASS' if a8 - a64 <= 0.02 else 'FAIL'}")

if __name__ == "__main__": main()
