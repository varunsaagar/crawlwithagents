# Escalation and calibration

## The gate

For each tier k and each open criterion, the `gate` node compares the answer's confidence `q = max p` with a threshold θ:

| Condition | Decision | `escalation_reason` |
|---|---|---|
| θ = ∞ (tier disabled for this unit) | `escalate` | `uncertified` (no, expired or mismatched certificate) or `policy` (certified θ = ∞) |
| answer invalid (HTTP error, parse failure, missing ensemble member) | `invalid` | `invalid` |
| Choice escape label chosen | `abstain` | `abstain` |
| `q ≥ θ` | `accept` | none |
| otherwise | `escalate` | `low_conf` |

An item that is not accepted moves to the next tier. After the last tier it goes to **System Two**. The router can also escalate directly with `route_derive` or `drift_freeze`. If a tier is disabled (θ = ∞), it is not called and not charged for that criterion.

## Thresholds

`EscalationConfig.threshold` takes one of three forms:

```python
from jevjudge import EscalationConfig, LLMConfig

EscalationConfig(judges=[LLMConfig(model="gemini-2.5-flash")], threshold=0.9)            # fixed, AutoRubric style
EscalationConfig(judges=["gemini-2.5-flash"], threshold={                                 # per unit
    "output_pii/pii_exposed@noul": 0.97,   # most specific: rubric/criterion@type
    "output_toxicity": 0.8,                # rubric id (or criterion name)
    "default": 0.9,                        # fallback (0.7 if absent)
})
EscalationConfig(judges=["gemini-2.5-flash"], threshold="certified")    # needs registry=... on the grader
```

A dict is searched in this order: `rubric/criterion@type`, then `rubric/criterion`, then `rubric`, then `criterion`, then `default`, then 0.7. Criteria with `workload_class: style_sensitive` get `θ = max(θ, style_sensitive_floor)` (default 0.95).

## System Two (fallback)

* **Availability chain.** `judges` are tried in order. The next judge only gets the items whose answer was invalid. It is not a vote.
* **Independent.** The fallback never sees Jev's verdict or probabilities.
* **Rubric text.** By default (`use_fallback_rubric: true`) it also gets the criterion's `fallback_instructions`, for example the verbatim CMCS rubric. On real traffic this raised hallucination agreement from 0.73 to 0.86.
* **Rationale.** `rationale: never | on_escalation | always`. With `on_escalation` (the default), the escalated items get a rationale. With `always`, audited items get one too. `reasoning: after` (the default) emits the verdict before the rationale.
* **Caps.** `max_escalations_per_subject` limits the escalated criteria per item.
* **No valid fallback answer.** If no judge returns a valid answer, the best valid System One answer is used (`final_source: system_one`) and the decision stays `escalate` or `invalid`.

## Calibration engine

Certified thresholds come from `jevjudge.calibration.engine.CalibrationEngine`.

**Calibration unit** = rubric revision × criterion × output type × tier backends (in order) × reference judge. The certificate **fingerprint** hashes the revision, the tier names and the reference name. A change to any of them makes the router fail closed.

Workflow:

1. **Retain.** Grade labelled or unlabelled items with `mode="calibrate"`: every tier and the reference answer every verdict question, and the gate never stops early. `CriterionGrader.records(report, rubrics, gold=...)` turns a report into `JudgmentRecord`s, which you store with `RunStore`.
2. **Report.** `engine.analyse(records)` gives, per tier: accuracy vs gold, agreement and κ vs the reference, error-detection AUROC, ECE, Brier, NLL, coverage at q ≥ 0.9, confident-error rate, coverage at 95% accuracy, valid rate, and latency p50/p95.
3. **Temperature (optional).** A temperature is fitted per tier and kept only if held-out NLL improves.
4. **Certify.** Learn-then-Test (LTT) over the threshold grid `(0.5, 0.6, 0.7, 0.8, 0.85, 0.9, 0.93, 0.95, 0.97, 0.99, ∞)`:

    | Mode | When | Guarantee |
    |---|---|---|
    | `parity_gold` | ≥ `min_n` gold labels | `P[Acc(cascade) ≥ Acc(reference) − ε] ≥ 1 − δ`, measured against human gold |
    | `parity_ref` | no gold (label-free) | the same statement for *any* labelling, through the disagreement mass with the reference |

    With `method="auto"`, the solver uses split fixed-sequence testing (`ltt_sfst`) when n < 600 and Holm step-down (`ltt_holm`) otherwise, with WSR p-values. Other methods: `point`, `cmu_lcb`, `cmu_lcb_bonf`, `ltt_bonferroni`, `ltt_fst`, `pareto_fst`, `pareto_bonf`. The solver also supports `joint_error` and `selective` modes. The solver picks the cheapest valid policy. If nothing certifies, or n < `min_n`, every θ is ∞ and everything goes to the fallback.
5. **Monitor tolerance.** Each certificate stores `monitor_eps`: the 95% Clopper-Pearson upper bound on accepted-item disagreement with the reference, plus 2 pp. The monitor uses it as its tolerance.

```python
from jevjudge.calibration.engine import CalibrationEngine, RunStore, dump_report
from jevjudge.calibration.registry import CertificateRegistry

async def certify(grader, rubrics, items, gold_by_subject):
    store = RunStore("runs/calib.jsonl")
    for item, gold in zip(items, gold_by_subject):            # gold: {rubric_id: 0/1} or None
        rep = await grader.grade(item, rubrics, mode="calibrate")
        store.append(grader.records(rep, rubrics, gold=gold))

    recs = store.load()
    reg = CertificateRegistry("registry/certificates.json")
    tiers = [t.name for t in grader.tiers]
    certs, reports = [], []
    for rub in rubrics:
        unit = [r for r in recs if r.rubric_id == rub.id and r.reference is not None]
        if not unit:
            continue
        cert, analysis = CalibrationEngine(unit, eps=0.03, delta=0.05, min_n=100).certify_unit(unit, tiers)
        reg.promote(cert)                                     # supersedes the previous ACTIVE certificate
        certs.append(cert); reports.append(analysis)
    reg.save()
    dump_report(reports, certs, "registry/report.json")
```

`CalibrationEngine(records, eps=0.02, delta=0.05, method="auto", min_n=100, ttl_days=30, costs=None, fit_temperature=True, seed=0)` also has `run()`, which certifies every unit found in the records.

## Certificate registry (fail-closed)

`CertificateRegistry(path).policy(rubric_id, criterion, qtype, revision, tiers, reference, stratum="all", pooled_fallback=False)` never raises. It returns a `Policy` whose `source` is one of:

| `source` | θ |
|---|---|
| `certified` | the certificate's per-tier θ (`None` in JSON = ∞) |
| `uncertified` | ∞ for every tier |
| `expired` (past `expires_at`, default TTL 30 days) | ∞ |
| `fingerprint_mismatch` (rubric edited, tiers changed, different reference) | ∞ |

Only ACTIVE certificates are served. `propose(cert)` stores a certificate as PROPOSED, and `approve(cert_id, approver)` activates it and marks the previous ACTIVE certificate of the same unit and stratum as SUPERSEDED. `rollback`, `revoke` and `history` complete the lifecycle. `promote(cert)` is the shortcut that activates a certificate without approval. `save()` writes `{"certificates": [...]}`.

With `threshold: certified`, the grader can also phase certificates in over hand-set thresholds (`phase`, `static_thresholds`) and look them up per traffic segment (`strata`). Both are covered in [Threshold governance](../guides/governance.md).

```python
from jevjudge import CriterionGrader, DecisionModelConfig, EscalationConfig, MonitorConfig

grader = CriterionGrader(
    [DecisionModelConfig(model="djev")],
    EscalationConfig(judges=["gemini-2.5-flash"], threshold="certified", audit_rate=0.05),
    registry="experiments/registry/certificates.json",
    monitor=MonitorConfig(eps=0.05, alpha=0.01, state_path="registry/monitor_state.json"),
)
```

!!! warning "Reference name is part of the fingerprint"
    The reference is `judges[0].name`. A registry certified against `gemini-2.5-flash` does not apply when Gemma is first in the chain. That is why the repo ships two configs: `configs/judge.yaml` uses `certificates.json` (Gemini first) and `configs/judge_gemma.yaml` uses `certificates_gemma.json` (Gemma first).

## Accuracy monitor (drift freeze)

`AccuracyMonitor(eps=0.05, alpha=0.01, aci_gamma=0.02, state_path=None, detector="cusum")`:

* **Audit slice.** A deterministic hash picks `audit_rate` of the *accepted* verdicts per subject and criterion. System Two shadow-judges them.
* **Signal.** `x = 1[System One disagreed with the fallback]`.
* **Alarm.** `EProcessAlarm` is a betting e-process testing H0: E[x] ≤ eps, where eps is the certificate's `monitor_eps` when present. With `detector="cusum"` (the default), the wealth restarts so a late regression is caught quickly. With `detector="cumulative"`, it is the anytime-valid running test. See [Monitoring](../guides/monitoring.md#detector-cusum-vs-cumulative). When the e-value reaches 1/α, the unit is **frozen**. From then on, every item of that unit goes to System Two (`drift_freeze`) until you call `monitor.reset(unit)` after promoting a new certificate.
* **ACI.** `ACIThreshold` is a tighten-only θ controller between re-certifications. θ never drops below the certified value.
* **Shared state.** State persists to `state_path`, so a batch job and a service share freeze decisions.

```python
from jevjudge.calibration.monitor import AccuracyMonitor

mon = AccuracyMonitor(eps=0.05, alpha=0.01, state_path="/tmp/monitor_state.json")
mon.observe("output_pii/pii_exposed@noul", disagree=False, certified_theta=0.5)
print(mon.is_frozen("output_pii/pii_exposed@noul"), mon.summary())
mon.reset("output_pii/pii_exposed@noul")       # after a fresh certificate is promoted
```

In the drift drill (25% silent regression after item 3,000, 10% audit), the monitor alarmed after about 124–250 audits and had no false alarms before the shift. Sexism accuracy after the shift went from 0.755 to 0.875 with the monitor on. See [Results](../results.md).

!!! note
    A label-free monitor is only as good as its reference. On hallucination, Gemini disagrees with the stack far more than gold does, so its tolerance (0.43) is useless. Hallucination needs a human audit slice.
