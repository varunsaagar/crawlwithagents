# Human review queue

Certificates and the monitor compare Jev with the fallback LLM. Neither can see the errors that Jev and the fallback make together, and neither finds failure modes that the rubric never names. The review queue closes that loop. It sends a small, targeted share of graded items to people, and turns their verdicts into gold labels for the next calibration.

```mermaid
flowchart LR
    G["grade (mode=serve)"] -->|offer| Q[("review_queue.jsonl")]
    Q -->|pending| H[reviewer]
    H -->|label| Q
    Q -->|export_labels| L["labels CSV<br/>session_id, metric, label"]
    L --> P["Project.add_labels /<br/>parity_gold certificates"]
```

## What gets enqueued

After every `grade()` in `serve` mode, the grader offers the report to the queue. For each rubric's verdict criterion, an item is enqueued with one or more reasons:

| Reason | Condition | Config |
|---|---|---|
| `high_stakes` | the criterion has `high_stakes: true` and the rubric fired (in the voice presets: `output_pii`) | `high_stakes: true` |
| `both_unsure` | System Two answered with confidence `q < unsure_margin` | `unsure_margin: 0.7` |
| `both_unsure` | System One and System Two disagree, and System One's `q` was at least `θ − near_threshold`. This covers escalations just below θ and audited, accepted verdicts that the fallback contradicts | `near_threshold: 0.05` |
| `audit` | a deterministic random slice (hash of subject and criterion), whatever the confidence | `audit_rate: 0.01` |

`pending()` returns `high_stakes` items first, then `both_unsure`, then `audit`.

`report.meta["review_enqueued"]` holds the number of items the report added. The queue never breaks grading: if `offer` fails, the report is returned without that key. Nothing is enqueued in `calibrate` or `collect` mode.

## Configure

In the judge YAML (`JudgeConfig.review`):

```yaml
review:
  path: review/review_queue.jsonl     # append-only JSONL, one file per queue (relative to the working directory)
  audit_rate: 0.01                    # 0..1
  unsure_margin: 0.7
  near_threshold: 0.05
  high_stakes: true
```

Or in code: `CriterionGrader(..., review=ReviewConfig(...))`. You can also pass a path string, which uses the defaults for everything else, or a `ReviewQueue` instance.

!!! note
    Like `registry` and `monitor.state_path`, a relative `review.path` resolves against the YAML file's directory (so do `ingest.profile`, `sinks.cmcs` and `drift.state_path`).

## Review and export

The example runs offline. The fallback mock is deliberately unsure, so most metrics land in the queue.

```python
import asyncio
from jevjudge import CriterionGrader, EscalationConfig, Session, preset
from jevjudge.backends.mock import MockBackend, keyword_rule
from jevjudge.review import ReviewConfig, ReviewQueue

queue = ReviewQueue(ReviewConfig(path="/tmp/jevjudge-review/queue.jsonl", audit_rate=0.05))
jev = MockBackend("jev", rules=[keyword_rule("output_pii__pii_exposed", ["4111"], 0.99, 0.02)])
llm = MockBackend("llm", kind="llm", sharpness=0.6)                 # an unsure fallback
grader = CriterionGrader([jev], EscalationConfig(judges=[], threshold=0.9), judges=[llm], review=queue)

session = Session.from_turns("s1", [{"speaker": "user", "text": "what card is on file?"},
                                    {"speaker": "agent", "text": "The card on file is 4111 1111 1111 1111."}])
report = asyncio.run(grader.grade(session, preset("voice")))
print(report.meta["review_enqueued"])                               # 5

for item in queue.pending(limit=10):                                # high_stakes first
    print(item["metric"], item["reasons"], item["verdict"], item["final_source"])
# output_pii ['high_stakes'] fired system_one
# ...

item = queue.pending(limit=1, reason="high_stakes")[0]
queue.label(item["item_id"], fired=True, reviewer="carol@example.com", note="full card number read aloud")
print(queue.stats())
# {'total': 5, 'pending': 4, 'labelled': 1, 'judge_human_agreement': 1.0, 'new_failure_modes': []}
queue.export_labels("/tmp/jevjudge-review/labels.csv")              # session_id,metric,label (1 = fired)
```

Each queue item carries what a reviewer needs: `subject_id`, `metric`, `criterion`, `question` (the verdict question text), `jev` (the last System One answer), `fallback` (the System Two answer with its rationale, if any), `final_label`, `final_source`, `verdict`, `trace_ref` (the subject's trace id) and `created`.

| `ReviewQueue` method | Description |
|---|---|
| `offer(report, rubrics, trace_ref=None) -> int` | enqueue what the report warrants (the grader calls this) |
| `reasons(report, rubric, criterion_result) -> list[str]` | the reasons that would apply, without enqueueing |
| `pending(limit=50, reason=None) -> list[dict]` | unlabelled items, by priority; filter by one reason |
| `label(item_id, fired, reviewer, note="", new_failure_mode=None) -> dict` | record a human verdict. `fired=True` means the metric triggered (a violation, or the action was *not* completed) |
| `stats() -> dict` | `total`, `pending`, `labelled`, `judge_human_agreement` (share of labelled items where the served verdict matched the human), `new_failure_modes` |
| `export_labels(path) -> int` | write labelled items as CSV `session_id,metric,label` |

Labels are appended to the same JSONL file. The last record for an `item_id` wins, so relabelling an item is just another `label()` call.

!!! tip "Name new failure modes"
    Set `new_failure_mode="tool-echoed account id"` (any short tag) when an item shows a failure the rubric does not describe. `stats()["new_failure_modes"]` collects them. They are candidates for a new detail criterion or a rubric revision.

## Feed labels back into calibration

The CSV is in the calibration label format. Load it with `Project.add_labels(path)` in the Studio, or join it to your board rows as `labels[rubric_id]`. With at least `min_n` gold labels per metric, the calibration engine certifies in `parity_gold` mode, which measures the guarantee against people rather than the fallback LLM. Every new certificate still needs approval (see [Governance](governance.md#certificate-lifecycle)).

!!! warning "Audit items are the unbiased sample"
    `high_stakes` and `both_unsure` items are chosen *because* they are hard, so their agreement rate is pessimistic. Use only `audit` items (filter with `pending(reason="audit")` or on `reasons`) to estimate live accuracy.

## In the Calibration Studio

Each Studio project has its own queue at `<project>/review_queue.jsonl` with `audit_rate: 0.02`. The exported `judge.yaml` points `review.path` at it, so `/v1/judge` traffic for the project fills it.

```bash
curl -s "localhost:8000/v1/projects/$PID/review?reason=high_stakes&limit=20" | jq '.stats, .items[0]'
curl -s -X POST localhost:8000/v1/projects/$PID/review/$ITEM -H 'Content-Type: application/json' \
     -d '{"fired": true, "reviewer": "carol@example.com", "note": "PAN read aloud"}'
curl -s -X POST localhost:8000/v1/projects/$PID/review/import          # -> {"imported": n}
```

`review/import` (`Project.import_review_labels()`) exports every labelled item to `<project>/review_labels.csv` and adds them to the project's labels. Re-run calibrate afterwards.
