# Index

| File | Purpose |
|------|---------|
| [README.md](README.md) | Pack overview, audience, winning architecture summary |
| [PLAN.md](PLAN.md) | One-pager printable plan with links into deeper docs |
| [01-architecture.md](01-architecture.md) | Mermaid diagram, components, session data model, sampling, drift split |
| [02-build-plan.md](02-build-plan.md) | Day 0 / Week 1 / Month 1 checklists, owners, gates, risks |
| [03-implementation-guide.md](03-implementation-guide.md) | Langfuse outline, workers, judge prompts, κ/Se/Sp, alerts, CI |
| [04-versioning-and-ops.md](04-versioning-and-ops.md) | Version scheme, promotion, rollback, runbooks |
| [05-metrics-and-drift.md](05-metrics-and-drift.md) | Sparse-GT metrics, three drift signals, dashboards, anti-patterns |
| [06-references.md](06-references.md) | Curated bibliography with URLs, why-it-matters, red herrings |
| [07-templates.md](07-templates.md) | Gold CSV, judge JSON schema, sampling SQL, alerts, HITL checklist |
| [INDEX.md](INDEX.md) | This file list |
