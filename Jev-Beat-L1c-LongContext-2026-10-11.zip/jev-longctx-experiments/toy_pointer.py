"""Toy Jev long-context proxy (NOT E4B). A small causal transformer with a Kairos/strands-style
POINTER HEAD is trained from scratch on synthetic 'states' (fact records + distractor records + filler),
answering typed questions: noul (YES/NO), choice (pick plan among listed options), score (1..5).
Trained at length 128, evaluated at 128..1024 (8x, mirrors 8K->64K). CPU, minutes."""
import argparse, json, math, random, time
import numpy as np, torch, torch.nn as nn, torch.nn.functional as F

NE, NP, NF = 200, 32, 64                                  # entities, plans, filler tokens
PAD, Q_CH, Q_NO, Q_SC, OPT, ANS, SEP, YES, NO = range(9)
S0 = 9; E0 = S0 + 5; P0 = E0 + NE; F0 = P0 + NP; V = F0 + NF   # score toks, entity, plan, filler

def make(rng, L, k, qtype, n_opt=8, sandwich=False):
    """State = shuffled records [SEP e p s] (1 evidence + k distractors) and filler; query at end."""
    ents = rng.sample(range(NE), k + 1); recs = []
    for e in ents: recs.append([(SEP, E0 + e, P0 + rng.randrange(NP), S0 + rng.randrange(5))])
    ev = recs[0][0]
    if qtype == "choice":
        others = rng.sample([p for p in range(P0, P0 + NP) if p != ev[2]], n_opt - 1)
        # hard negatives: distractor plans included among options when possible
        opts = others + [ev[2]]; rng.shuffle(opts); gold = opts.index(ev[2]); q = [Q_CH, ev[1]]
    elif qtype == "noul":
        yes = rng.random() < .5; asked = ev[2] if yes else rng.choice([p for p in range(P0, P0 + NP) if p != ev[2]])
        q = [Q_NO, ev[1], asked]; opts = [YES, NO]; gold = 0 if yes else 1
    else:
        q = [Q_SC, ev[1]]; opts = list(range(S0, S0 + 5)); gold = ev[3] - S0
    tail = q + [OPT] + opts + [ANS]
    head = (q + [ANS]) if sandwich else []
    body_len = L - len(tail) - len(head)
    nfill = body_len - len(recs)
    assert nfill >= 0, (L, k)
    units = [r for r in recs] + [[F0 + rng.randrange(NF)] for _ in range(nfill)]
    rng.shuffle(units)
    def tup(t):   # shared entity/plan/score embedding channels so query & options match records
        if isinstance(t, tuple): return t
        if E0 <= t < P0: return (OPT, t, 0, 0)
        if P0 <= t < F0: return (OPT, 0, t, 0)
        if S0 <= t < E0: return (OPT, 0, 0, t)
        return (t, 0, 0, 0)
    seq = [tup(t) for t in head] + [tup(t) for u in units for t in u] + [tup(t) for t in tail]
    opt_pos = [len(seq) - 1 - len(opts) + i for i in range(len(opts))]
    return seq, opt_pos, gold

def rope(x, pos):
    d = x.shape[-1]; inv = 1.0 / (10000 ** (torch.arange(0, d, 2).float() / d))
    ang = pos[:, None].float() * inv[None]; c, s = ang.cos(), ang.sin()
    x1, x2 = x[..., ::2], x[..., 1::2]
    return torch.stack([x1 * c - x2 * s, x1 * s + x2 * c], -1).flatten(-2)

class Block(nn.Module):
    def __init__(s, d, h):
        super().__init__(); s.h = h; s.qkv = nn.Linear(d, 3 * d); s.o = nn.Linear(d, d)
        s.n1, s.n2 = nn.LayerNorm(d), nn.LayerNorm(d); s.ff = nn.Sequential(nn.Linear(d, 4 * d), nn.GELU(), nn.Linear(4 * d, d))
        s.ssmax_s = nn.Parameter(torch.ones(h))           # used only if trained-SSMax
    def forward(s, x, cfg):
        B, T, D = x.shape; hd = D // s.h
        q, k, v = s.qkv(s.n1(x)).view(B, T, 3, s.h, hd).permute(2, 0, 3, 1, 4)
        pos = torch.arange(T); q, k = rope(q, pos), rope(k, pos)
        att = (q @ k.transpose(-1, -2)) / math.sqrt(hd)
        if cfg.get("ssmax_train"):                         # SSMax: logits * s*log(n), n = #visible keys
            n = torch.arange(1, T + 1).float()
            att = att * (s.ssmax_s.view(1, -1, 1, 1) * torch.log(n).view(1, 1, T, 1) / math.log(cfg["L0"]))
        if cfg.get("tau"):                                 # training-free logit temperature at inference
            n = torch.arange(1, T + 1).float()
            att = att * torch.clamp(torch.log(n) / math.log(cfg["L0"]), min=1.0).view(1, 1, T, 1) ** cfg["tau"]
        att = att.masked_fill(torch.triu(torch.ones(T, T, dtype=torch.bool), 1), float("-inf"))
        y = (att.softmax(-1) @ v).transpose(1, 2).reshape(B, T, D)
        x = x + s.o(y); return x + s.ff(s.n2(x))

class Toy(nn.Module):
    def __init__(s, d=96, h=4, nl=4):
        super().__init__(); s.emb = nn.Embedding(V, d); s.emb_e = nn.Embedding(V, d); s.emb_p = nn.Embedding(V, d); s.emb_s = nn.Embedding(V, d); s.blocks = nn.ModuleList([Block(d, h) for _ in range(nl)])
        s.nf = nn.LayerNorm(d); s.pq, s.pk = nn.Linear(d, d), nn.Linear(d, d)   # pointer head
    def forward(s, seqs, opt_pos, cfg):
        x = s.emb(seqs[..., 0]) + s.emb_e(seqs[..., 1]) + s.emb_p(seqs[..., 2]) + s.emb_s(seqs[..., 3])
        for b in s.blocks: x = b(x, cfg)
        x = s.nf(x); qa = s.pq(x[:, -1]); ks = s.pk(torch.stack([x[i, p] for i, p in enumerate(opt_pos)]))
        return (ks @ qa.unsqueeze(-1)).squeeze(-1) / math.sqrt(x.shape[-1])

def batch(rng, B, L, kfn, qtypes, n_opt, sandwich):
    S, P, G = [], [], []
    qt = rng.choice(qtypes)                                # one type per batch (same #options)
    for _ in range(B):
        s, p, g = make(rng, L, kfn(rng), qt, n_opt, sandwich); S.append(s); P.append(p); G.append(g)
    return torch.tensor(S), P, torch.tensor(G)

def train(cfg, seed):
    torch.manual_seed(seed); rng = random.Random(seed); m = Toy(); opt = torch.optim.AdamW(m.parameters(), 2e-3, weight_decay=0.01)
    L = cfg["L0"]; kmin, kmax = cfg["k_train"]
    for step in range(cfg["steps"]):
        lr = 1e-3 * min(1, step / 100) * (1.0 if step < 0.7 * cfg["steps"] else 0.3)
        for g in opt.param_groups: g["lr"] = lr
        Lb = rng.choice(cfg.get("L_mix", [L]))
        S, P, G = batch(rng, 64, Lb, lambda r: r.randint(kmin, min(kmax, Lb - 20)), ["choice", "noul", "score"], 8, cfg.get("sandwich", False))
        loss = F.cross_entropy(m(S, P, cfg), G); opt.zero_grad(); loss.backward(); opt.step()
    return m

@torch.no_grad()
def evaluate(m, cfg, L, k, qtype, n=300, seed=999, n_opt=8, mode="single", chunk=None):
    rng = random.Random(seed * 7 + L + k); hits = []
    for i0 in range(0, n, 50):
        items = [make(rng, L, k, qtype, n_opt, cfg.get("sandwich", False)) for _ in range(min(50, n - i0))]
        if mode == "single":
            lg = m(torch.tensor([s for s, _, _ in items]), [p for _, p, _ in items], cfg)
            hits += (lg.argmax(-1) == torch.tensor([g for _, _, g in items])).int().tolist()
        else:   # chunked map-reduce: re-split records/filler into chunks of `chunk` tokens, re-append query
            for s, p, g in items:
                ntail = len(p) + 2 + (3 if qtype == "noul" else 2)
                tail = s[-ntail:]; nhead = (ntail - len(p) - 1) if cfg.get("sandwich") else 0
                head = s[:nhead]; body = s[nhead:len(s) - ntail]
                cap = chunk - len(tail) - len(head)
                chunks = [body[i:i + cap] for i in range(0, len(body), cap)]
                # pad each chunk with filler to exactly `chunk` (model trained at fixed L0)
                seqs = [head + c + [(F0 + rng.randrange(NF), 0, 0, 0) for _ in range(cap - len(c))] + tail for c in chunks]
                op = [[len(sq) - 1 - len(p) + j for j in range(len(p))] for sq in seqs]
                pr = m(torch.tensor(seqs), op, cfg).softmax(-1)
                if mode == "chunk_max": pred = pr[pr.max(-1).values.argmax()].argmax().item()
                else: pred = pr.log().sum(0).argmax().item()
                hits.append(int(pred == g))
    a = float(np.mean(hits)); se = math.sqrt(a * (1 - a) / len(hits))
    return dict(acc=round(a, 4), ci95=[round(max(0, a - 1.96 * se), 3), round(min(1, a + 1.96 * se), 3)], n=len(hits))
