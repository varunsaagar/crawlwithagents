# 02 — Build plan

Cross-links: [Architecture](01-architecture.md) · [Implementation](03-implementation-guide.md) · [Versioning](04-versioning-and-ops.md) · [PLAN](PLAN.md)

Decisive rule: **ship an instrumented MVP in hours, not a perfect platform in months.** Version gates from day one so you do not paint yourself into unversioned prompts.

---

## Owners (suggested RACI)

| Workstream | Accountable | Responsible | Consulted |
|------------|-------------|-------------|-----------|
| Ingest + Langfuse | Platform eng | Backend eng | Security |
| Judges + rubrics | ML eng | ML eng + QA lead | Legal/compliance (safety) |
| Gold / HITL | QA lead | Annotators | Product |
| CI (Promptfoo/DeepEval) | ML eng | Backend eng | — |
| Drift dashboards | Platform eng | ML eng | On-call |
| Promotion / rollback | Eng manager | On-call + ML | Product |

Adjust names to your org; keep one **accountable** human per stream.

---

## Day 0 — 2–4 hour MVP

**Goal:** One session type end-to-end: ingest → Langfuse trace → one binary judge → visible score. No fancy sampling yet.

### Checklist

- [ ] Stand up Langfuse (docker compose on a non-prod box) — [outline](03-implementation-guide.md#langfuse-self-host-outline)
- [ ] Define `session_trace.v1` JSON; reject payloads missing `session_id`, `prompt_version`, `model_id`
- [ ] Ingest worker: consume a queue (or HTTP) → create Langfuse trace + spans for ASR / search / LLM
- [ ] Hard-code one judge: **faithfulness** (answer grounded in `retrieved_docs`) — [prompt](03-implementation-guide.md#example-binary-judge-prompts)
- [ ] Store score with `judge_version=faithfulness@0.1.0`, `rubric_version=faithfulness-rubric@0.1.0`
- [ ] Manual: push 20 fixture sessions; confirm scores appear in UI
- [ ] Create empty git repos/tags for: prompts, judges, rubrics, gold sets (even if gold is empty)

### Exit criteria

| Criterion | Pass |
|-----------|------|
| Fixture sessions scored | ≥20 with non-null judge JSON |
| Versions attached | Every score has judge + rubric version |
| Call path untouched | Ingest is async / offline replay OK for Day 0 |
| Time box | ≤4 hours elapsed |

### Risks (Day 0)

| Risk | Mitigation |
|------|------------|
| Langfuse auth/OIDC rabbit hole | Local user + password for MVP; OIDC in Week 1 |
| PII in fixtures | Use synthetic transcripts only |
| Judge model unavailable | Fall back to a smaller hosted model; record `model_id` |

---

## Week 1 — Online sampling + five judges + CI stub

**Goal:** Production-shaped loop on a canary traffic slice (or shadow of historical sessions).

### Checklist

- [ ] Five binary judges live: safety, search relevance, faithfulness, task unresolved, policy miss
- [ ] Sampler: 100% high-risk + 5% random (config-flagged)
- [ ] Idempotency key: `(session_id, judge_version)`
- [ ] Gold set v0: ≥100 labelled sessions (CSV per [07-templates](07-templates.md)); `gold_set_version=gold@0.1.0`
- [ ] Compute first κ / sensitivity / specificity on gold — [methods](03-implementation-guide.md#judgehuman-agreement--bias-adjusted-prevalence)
- [ ] Promptfoo or DeepEval job in CI on `search` + reply prompts; fails PR if faithfulness on gold drops beyond threshold **you** set after measuring baseline
- [ ] Alert stub: page if safety-fail rate > X on high-risk **and** sample n ≥ N (do not alert on n=3)
- [ ] Document promotion: shadow only this week — no full traffic prompt swaps without CI green

### Exit criteria

| Criterion | Pass |
|-----------|------|
| Online coverage | High-risk 100%; random ≥5% for ≥3 consecutive days |
| Judges | All five emit valid JSON schema |
| Calibration snapshot | κ reported (even if low — honesty over vanity) |
| CI | PR check exists and can fail |
| Versions | Changelog entries for judge@0.1.x and prompt canaries |

### Risks (Week 1)

| Risk | Mitigation |
|------|------------|
| Cost blow-up | Cap daily judge calls; kill-switch config |
| Annotator disagreement | Dual-label 20% of gold; adjudicate |
| Alert noise | Minimum sample size + hysteresis |
| Treating κ=0.4 as “done” | Publish κ with CI; plan Week 2–4 judge iteration |

---

## Month 1 — Production discipline

**Goal:** Calibrated monitoring, drift separation, promotion/rollback you would trust on-call.

### Checklist

- [ ] Gold set ≥300–500 stratified; weekly HITL cadence with checklist ([07](07-templates.md#weekly-hitl-checklist))
- [ ] Bias-adjusted prevalence (Rogan–Gladen style) for safety and policy metrics on dashboards
- [ ] Phoenix + Evidently: input embedding drift, retrieval score drift, judge score-rate drift — **separate** panels
- [ ] Full versioning scheme live ([04](04-versioning-and-ops.md)): immutable artifacts in object store + git tags
- [ ] Promotion path: shadow → canary → full with human approve on **rubric** changes
- [ ] Runbooks rehearsed: judge drift, system drift, cost spike, false safety flood
- [ ] Retention + PII review signed off
- [ ] Cost dashboard: £ or $ per 1k sessions (ingest + judges + storage)

### Exit criteria

| Criterion | Pass |
|-----------|------|
| On-call ready | Runbooks linked from alert pages |
| Drift | At least one true-positive drill (inject bad prompt in shadow) detected |
| Rollback | Documented + tested: revert `prompt_version` within 15 minutes |
| Reporting | No dashboard tile labelled “precision” that is only judge-pass rate |
| Governance | Rubric change requires human approval before live scoring |

### Risks (Month 1)

| Risk | Mitigation |
|------|------------|
| Judge gaming / Goodhart | Rotate gold items; keep hold-outs secret from prompt authors |
| System vs judge confusion | Dual dashboards; post-incident taxonomy required |
| Vendor lock-in fear | Export traces weekly; schema is yours |
| Over-automating labels | HITL stays weekly; automation assists, does not replace |

---

## Versioned system plan (explicit)

Everything that affects scores or behaviour gets a version. No silent edits.

| Artifact | Version field | Storage | Promotion gate |
|----------|---------------|---------|----------------|
| Reply / search prompts | `prompt_version` | git + Langfuse prompt mgmt | CI gold eval + canary |
| Judge prompts | `judge_version` | git | κ vs gold ≥ floor *or* explicit waiver |
| Rubrics | `rubric_version` | git | **Human approve** before live |
| Gold sets | `gold_set_version` | object store + manifest | Dual-review sample |
| Generator / judge models | `model_id` / `judge_model_id` | registry | Shadow then canary |

### Promotion / rollback gates (summary)

1. **Shadow:** new artifact scores sessions; alerts muted; compare to control.
2. **Canary:** 5–20% traffic or 25–50% of canary cohort judged; alerts on canary namespace.
3. **Full:** only after κ/regression gates + human sign-off for rubrics.
4. **Rollback:** pin previous `prompt_version` / `judge_version` in config; do not “hotfix” by editing the live string.

Detail: [04-versioning-and-ops.md](04-versioning-and-ops.md).

---

## Timeline sketch

```text
Day 0     | Langfuse + ingest + 1 judge + version tags
Week 1    | 5 judges + sampling + gold@0.1 + CI stub + alert stub
Weeks 2–3 | κ iteration, HITL process, cost caps, canary prompts
Week 4    | Drift panels, runbooks, promotion to “on-call trusted”
```

Slip the calendar if κ is unusable; do **not** slip versioning or HITL process.

---

## Done means

You can answer, with evidence: *Is the system worse, or did the judge move?* — and roll back either side within minutes. That is the Month 1 bar.
