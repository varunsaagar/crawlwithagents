"""Kairos Jev restart utilities (CPU-testable, no transformers dependency).

Portions adapted from perplexity-ai/pplx-decider-v1.1-27b source/src/autojev (Apache-2.0):
  - answer-code selection and readout init: model.py:215-250
  - option shuffle with soft-target permutation: train.py:367-379
  - NearDuplicates / family choose / conflicting-label drop: data.py:333-388, 663-670
Modified for Kairos Jev (Gemma-4): generic encode() callable, fp32 readout, Noul balancing.
See NOTICE-pplx-decider and LICENSE-pplx-decider-Apache-2.0.
"""
from __future__ import annotations

import hashlib
import itertools
import random
import re
import string
from collections import defaultdict
from collections.abc import Callable, Iterator, Sequence

import torch

MAX_OPTIONS = 255


# ---------- 1. LM-prior head ----------
def select_answer_codes(encode: Callable[[str], list[int]], chat_prefix: str, max_options: int = MAX_OPTIONS
                        ) -> tuple[list[str], list[int]]:
    """A..Z then AA..ZZ, keep codes that are ONE token alone AND appended to the chat prefix."""
    candidates = list(string.ascii_uppercase) + ["".join(p) for p in itertools.product(string.ascii_uppercase, repeat=2)]
    prefix_ids = encode(chat_prefix)
    codes, ids = [], []
    for code in candidates:
        alone = encode(code)
        if len(alone) != 1:
            continue
        if encode(chat_prefix + code) != prefix_ids + alone:
            continue  # merges with the prefix -> not readable at the last position
        codes.append(code)
        ids.append(alone[0])
        if len(codes) == max_options:
            break
    if len(set(ids)) != len(ids):
        raise ValueError("answer codes must map to distinct token ids")
    if len(codes) < max_options:
        raise ValueError(f"tokenizer gives only {len(codes)} single-token codes (< {max_options})")
    return codes, ids


class CodeReadoutHead(torch.nn.Module):
    """fp32 readout initialised from the LM unembedding rows of the answer codes; last-token pooling."""

    def __init__(self, lm_head_weight: torch.Tensor, token_ids: Sequence[int], softcap: float | None = None):
        super().__init__()
        w = lm_head_weight.detach()[list(token_ids)].to(torch.float32).clone()
        self.weight = torch.nn.Parameter(w)
        self.softcap = softcap  # Gemma final_logit_softcapping, if the base applies one; set from config

    def forward(self, last_hidden: torch.Tensor, n_options: torch.Tensor) -> torch.Tensor:
        logits = last_hidden.to(torch.float32) @ self.weight.T
        if self.softcap:
            logits = torch.tanh(logits / self.softcap) * self.softcap
        mask = torch.arange(logits.shape[-1], device=logits.device)[None] >= n_options[:, None]
        return logits.masked_fill(mask, float("-inf"))


def render_options(descriptions: Sequence[str], codes: Sequence[str]) -> str:
    return "\n".join(f"{c}: {d}" for c, d in zip(codes, descriptions))


# ---------- 2. option shuffle per epoch ----------
def shuffle_options(row: dict, rng: random.Random) -> dict:
    """Return a copy with Choice criteria shuffled; list (soft) targets permuted in lockstep."""
    q = row["question"]
    if q["type"] != "choice":
        return row
    items = list(q["criteria"].items())
    target = row.get("target")
    weights = dict(zip(q["criteria"], target)) if isinstance(target, list) else None
    rng.shuffle(items)
    out = {**row, "question": {**q, "criteria": dict(items)}}
    if weights is not None:
        out["target"] = [weights[k] for k, _ in items]
    return out


def epoch_iter(rows: Sequence[dict], epoch: int, seed: int) -> Iterator[dict]:
    rng = random.Random(seed + epoch)
    order = list(range(len(rows)))
    rng.shuffle(order)
    for i in order:
        yield shuffle_options(rows[i], rng)


# ---------- 3. Noul balance ----------
def noul_label(row: dict) -> bool | None:
    if row["question"]["type"] != "noul":
        return None
    t = row.get("target", row.get("label"))
    return bool(t >= 0.5) if isinstance(t, float) else bool(t)


class NoulBalancedSampler:
    """Per source: Noul true/false drawn 50/50 (upsample minority); other types pass through once."""

    def __init__(self, rows: Sequence[dict], seed: int, source_key: str = "source_name"):
        self.rows, self.seed, self.key = rows, seed, source_key

    def indices(self, epoch: int) -> list[int]:
        rng = random.Random(self.seed * 1000003 + epoch)
        groups: dict[tuple, list[int]] = defaultdict(list)
        out: list[int] = []
        for i, r in enumerate(self.rows):
            lab = noul_label(r)
            if lab is None:
                out.append(i)
            else:
                groups[(r.get(self.key, ""), lab)].append(i)
        for src in {s for s, _ in groups}:
            pos, neg = groups.get((src, True), []), groups.get((src, False), [])
            if not pos or not neg:
                out.extend(pos or neg)  # cannot balance a one-class source; flag it upstream
                continue
            n = max(len(pos), len(neg))
            for g in (pos, neg):
                out.extend(g + [rng.choice(g) for _ in range(n - len(g))])
        rng.shuffle(out)
        return out


# ---------- 4. splits / near-dup / conflicts (pplx data.py) ----------
def normalized(v: str) -> str:
    return " ".join(v.casefold().split())


def digest(v: str) -> str:
    return hashlib.sha256(v.encode()).hexdigest()


class NearDuplicates:
    """5-word shingle Jaccard >= threshold, candidates via 8 min-sha anchors (pplx data.py:359-388)."""

    def __init__(self, threshold: float = 0.85):
        self.t, self.parts, self.index = threshold, [], defaultdict(list)

    @staticmethod
    def shingles(text: str) -> set[str]:
        w = re.findall(r"\w+", normalized(text))
        return {" ".join(w[i:i + 5]) for i in range(len(w) - 4)} if len(w) >= 20 else set()

    def add(self, text: str) -> None:
        s = self.shingles(text)
        if s:
            self.parts.append(s)
            for a in sorted(s, key=digest)[:8]:
                self.index[a].append(len(self.parts) - 1)

    def matches(self, text: str) -> bool:
        s = self.shingles(text)
        if not s:
            return False
        cands = {i for a in sorted(s, key=digest)[:8] for i in self.index.get(a, [])}
        return any(len(s & self.parts[i]) / len(s | self.parts[i]) >= self.t for i in cands)


def family_split(rows: Sequence[dict], fractions: dict[str, float], seed: int, family_key: str = "family"
                 ) -> dict[str, list[dict]]:
    """Whole families go to one fold, ordered by seeded hash."""
    fams: dict[str, list[dict]] = defaultdict(list)
    for r in rows:
        fams[r[family_key]].append(r)
    order = sorted(fams, key=lambda f: digest(f"{seed}:{f}"))
    out = {k: [] for k in fractions}
    total, cursor, names = len(rows), 0, list(fractions)
    bounds = list(itertools.accumulate(fractions[n] * total for n in names))
    for f in order:
        while cursor < len(names) - 1 and sum(len(v) for v in out.values()) >= bounds[cursor]:
            cursor += 1
        out[names[cursor]].extend(fams[f])
    return out


def drop_conflicts(rows: Sequence[dict], state_of: Callable[[dict], str]) -> tuple[list[dict], int]:
    """Same normalized state+question with different labels -> drop all copies (pplx data.py:663-670)."""
    seen: dict[str, dict] = {}
    bad: set[str] = set()
    for r in rows:
        k = digest(normalized(state_of(r)))
        if k in seen and seen[k]["label"] != r["label"]:
            bad.add(k)
        seen.setdefault(k, r)
    return [r for k, r in seen.items() if k not in bad], len(bad)


def decontaminate(train: Sequence[dict], protected: Sequence[dict], text_of: Callable[[dict], str]) -> tuple[list[dict], int]:
    nd, exact = NearDuplicates(), set()
    for r in protected:
        nd.add(text_of(r))
        exact.add(digest(normalized(text_of(r))))
    keep = [r for r in train if digest(normalized(text_of(r))) not in exact and not nd.matches(text_of(r))]
    return keep, len(train) - len(keep)
