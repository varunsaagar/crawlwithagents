# strands-decider → Jev on Gemma-4-26B-A4B: repo review and approach (2026-10-10)

Repo: https://github.com/strands-labs/strands-decider (cloned to /workspace/refs/strands-decider, last commit 2026-10-09 16:33 -0700 = 2026-10-10 05:03 IST). License Apache-2.0. Everything in §1 is read from the repo; §2.3 memory beyond the repo's own measurements is **estimated**.

## 1. What the repo is
- **Purpose:** "decision model / system one" for agentic workflows (Strands Agents SDK). Typed Noul / Choice / Score with calibrated confidence, served at `/v1/systemone` (README.md). Same API shape as Jev.
- **Architecture (README "Model Architecture", src/strands_decider/modeling.py `PointerHead`):** pretrained decoder torso, **LM head discarded**, replaced by a ~1M-param *pointer head* (query = `<answer>` position, key = last token of each option line, LayerNorm + dot product). Option count unbounded. ⇒ This is **not** letter-logit readout from the LM head like our jev-lite; output is 1 token "usage" but no decoding.
- **Base models:** reference recipe v19 = `Qwen/Qwen3.5-2B-Base`, teacher `Qwen/Qwen3.5-4B`. **Gemma 4 support is on `main`** (not yet on PyPI): torsos `google/gemma-4-{E2B,E4B,12B,26B-A4B}-it`.
- **Already-released Gemma checkpoints** (README "Gemma 4 models", evaluation/results.md#gemma-4-v1): `StrandsAgents/strands-decider-26B-A4B-gemma4-v1-2610` (also `amazon/…`): JevBench 207/231, Brier 0.162, ECE 0.051, held-out short 0.708, code 0.859, HotpotQA 0.897, ~51 GB bf16, median 245 ms/JevBench question on 1 H100. E4B: 187/231, Brier 0.243, 139 ms. 12B: 200, 0.173, 136 ms.
- **Training recipe** (training/recipe.sh, training/steps.md, configs/train.yaml, train-parent.yaml, configs/experiments/v11–v21b): build corpus → fetch (ContractNLI, MuSiQue, HelpSteer2) → multistep → generated docs → adequacy → **teacher** (frozen LLM option distributions, src/strands_decider/data/teacher.py) → **parent** → **replay** (self-distillation) → **train** → **calibrate** → eval. No RL stage. Distillation = KL(teacher‖student) on option distributions (`teacher_file`, `teacher_weight`) + KL anchor to frozen readout or a reference checkpoint (`kl_frozen_weight`, `kl_frozen_reference`). Soups: mean of 3 seeds' LoRA updates (`soup` command) then recalibrate.
- **Loss:** CE over options + ordinal label smoothing 0.1 for Score + optional forward/reverse KL terms; option shuffling at collate (`shuffle_options: true` "the whole point"); `reverse_score_prob 0.5`.
- **Data schema** (src/strands_decider/data/format.py `Example`): `{kind: noul|choice|score, state, instructions, options:[[name,desc]], label (canonical index; noul 0=false 1=true), task, weight, paraphrases…}`.
- **Gemma 4 v1 training mix:** hobson-v21 data 123,339 rows + 12,263 code rows (25 public HF datasets; data/sources.md). **Teacher = Qwen3.5-4B** where it agrees with gold, plus a KL anchor (0.3) to the released **v19 (a Qwen3.5-based model)**. → see §4 compliance risk.
- **Calibration:** temperature scaling (global and per kind) fitted on a `calib` half disjoint from `eval --split test` (src/strands_decider/evaluate.py). No conformal/LTT — that remains our layer.
- **Eval:** JevBench public 231 tasks (evaluation/jevbench/jevbench.sh), held-out short tasks, multi-step (MuSiQue/HotpotQA), adequacy; preregistrations in research/preregistrations/.
- **Serving:** own server `strands-decider serve` (PyTorch/transformers, MPS, CPU, MLX), prefix KV reuse across questions ("asking many questions is nearly free"). **No vLLM integration.** Gemma at 32,768 window: `--max-batch 4 --max-batch-tokens 34000` → 26B-A4B peaked 57 GiB on one H100 (docs/inference.md). Trained and served at 4,096 by default.
- **Activity:** active (CHANGELOG, commit the day before this review, preregistered v9–v20 runs). Training docs measured on 8× H100 and RTX 3090; AWS runner in training/aws/.

## 2. Portability to Gemma-4-26B-A4B
**Verdict: already ported upstream.** No new port needed; we reuse their trainer and change data, teacher, window, and calibration.

| item | status in repo |
|---|---|
| chat template / BOS | `force_bos: true` required (-it tokenizer adds no BOS; frozen E2B reads JevBench at chance without it) |
| label tokens | N/A for training: the pointer head scores option hidden states, not letter tokens. The frozen option-number readout (KL anchor) applies Gemma's final logit soft-cap |
| LoRA targets | `q,k,v,o,gate,up,down_proj` (attention + dense MLP) |
| MoE experts / router | **Not adapted**: experts are 3-D params, not Linear; LoRA attaches by name, so 128 experts (top 8) and router keep base weights |
| PLE | N/A for 26B (only E2B/E4B; `host_embeddings`) |
| attention | default SDPA; `attn_implementation` config key exists. E2B forced to eager because of a CUDA bug; 26B keeps default |
| QLoRA / 4-bit | **Not supported**: no bitsandbytes / quantization code in src/ |
| sequence packing / Liger | **Not in repo**: uses `group_by_length` bucketing, padding to batch max |
| Unsloth / TRL | Not used; custom trainer. Unsloth/TRL Gemma-4-MoE expert-LoRA status is **unverified** and irrelevant if we stay on this trainer |

### 2.3 One-GPU memory (H100 80 GB, bf16 LoRA r16, grad checkpointing)
| window | micro-batch | peak | source |
|---|---|---|---|
| 4K | 8 | **52.9 GiB** | measured by repo (training/README.md) |
| 8K | 4 | ~55–58 GiB | estimate |
| 32K | 1–2 | ~60–66 GiB | estimate |
| 64K | 1 | ~68–78 GiB, tight | estimate; may need micro-batch 1 and SDPA mem-efficient/flash |
| serve 32K | max-batch 4 | 57 GiB | measured by repo |

The pointer head avoids the 262k-vocab logits tensor, which is the biggest long-sequence saver. A QLoRA route would need code changes, and the experts (most of the 26B) would likely stay bf16 anyway because they aren't Linear. So it isn't recommended. If 64K OOMs, fall back to: freeze_torso on the longest rows, an 80→141 GB H200, or 2 GPUs via torchrun (supported).

## 3. Approach (files in gemma26b-jev-recipe/)
0. **Baseline first:** evaluate `strands-decider-26B-A4B-gemma4-v1-2610` as-is on Jev groups at 4K/8K/32K. It may already meet the MVP. Licence/compliance check first (§4).
1. **Data:** convert Jev Noul/Choice/Score rows with `to_strands_jsonl.py` (adds `ctx_tokens`). Build long rows per length bucket and put evidence at the start, middle and end.
2. **Teacher = Gemma-4-31B-it**, through `python -m strands_decider.data.teacher --model google/gemma-4-31B-it`, so there's no Qwen in the chain. Keep the upstream rule: use teacher targets only where the teacher agrees with gold. Optionally add E4B jev-lite as a KL reference (`kl_frozen_reference`); the tokenizers may differ, which upstream allows.
3. **Stage 1 at 8K** (`stage1-8k.yaml`), **Stage 2 at 32K** (`stage2-32k.yaml`, 25% short mix), **Stage 3 at 64K** (`stage3-64k.yaml`, lr 5e-5). Note that `init_from` keeps the LoRA but re-initialises the head each stage (upstream semantics). Alternative: one run with all buckets mixed at max_length 65536.
4. Run 3 seeds, then `soup`, then `calibrate` (per-kind temperature, kept only if held-out NLL improves).
5. **Our layer:** `ltt_length_buckets.py` certifies thresholds per (group × ≤8k / 8–32k / 32–64k / 64–128k) with ε, δ. Uncertified buckets escalate to the LLM.
6. **Gates:** JevBench ≥ 207 (no regression vs v1 soup); ECE ≤ 0.03 in every bucket; needle-position accuracy drop ≤ 3 pts start/middle/end; short-context accuracy ≥ stage-1 − 1 pt; p50 latency at 32K measured.
7. **Serving:** `strands-decider serve … --max-batch 4 --max-batch-tokens 68000`. vLLM can't serve the pointer head natively. Options: (a) keep their server behind our `/v1/systemone` gateway; (b) a vLLM hidden-state/pooling-runner port (unverified effort). The prefix caching / packing levers from the throughput plan map to their state-once KV broadcast.

Commands: `run.sh setup validate smoke teacher s1 s2 s3 calibrate eval buckets serve`.

## 4. Risks / verify
- **Qwen ban:** the published Gemma deciders are Gemma weights but were distilled from Qwen3.5-4B targets and anchored to a Qwen-based v19. Legal/compliance must decide whether that counts as "Qwen-derived". Our retrain removes both (31B teacher, frozen-Gemma anchor). Upstream training data still includes Qwen-labelled rows in data/synthetic (teacher_v5_qwen35-4b.jsonl) and Qwen-generated sets (gen_pilot_qwen). Exclude them.
- Experts and router aren't fine-tuned. The domain shift is carried only by attention and the dense MLP. The repo's own results still show 26B is the best of the four.
- 64K memory and speed are unmeasured: run `run.sh smoke` first. Their trainer pads instead of packing.
- Labelling with the 31B teacher at 64K on one GPU needs FP8 or a separate host. The teacher labeller's FP8 support is unverified.
- No vLLM path. Their server's throughput at 40–60 RPS is unknown.
- Pointer head vs our E4B letter-logit head: the confidence semantics differ, so recalibrate and recertify; don't reuse E4B thresholds.
- Gemma 4 support exists only on `main`, so pin a commit.
