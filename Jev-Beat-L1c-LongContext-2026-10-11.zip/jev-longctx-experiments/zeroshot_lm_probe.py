"""Toy Jev-like long-context proxy (NOT E4B). Typed Noul/Choice/Score questions over a
'state' document = 1 evidence fact + k distractor facts + neutral filler, at a target token length.
Zero-shot letter-logit scoring with a small open model on CPU."""
import argparse, json, math, random, time, sys
import numpy as np, torch
from transformers import AutoTokenizer, AutoModelForCausalLM

NAMES = [f"{a} {b}" for a in "Ana Bo Cy Di Ed Fay Gus Hal Ida Jo Kai Lu Mo Ned Oz Pia Quin Rex Sol Tia Uma Vic Wes Xan Yuri Zed".split()
         for b in "Lin Park Roy Sato Diaz Kerr Moss Vale Hart Cole Ng Reis".split()]
PLANS = "Gold Silver Bronze Platinum Copper Iron Jade Ruby Opal Pearl Onyx Topaz Amber Coral Ivory Slate".split()
FILL = ["The harbor report noted mild winds and a calm tide this morning.", "Shipping schedules were posted on the main board near the gate.",
        "A maintenance window was planned for the regional data center.", "The quarterly newsletter discussed recycling and office supplies.",
        "Several teams met to review the onboarding checklist for interns.", "Traffic on the northern bridge was lighter than usual today.",
        "The cafeteria menu rotated to include a new vegetable soup.", "Printer drivers were updated across the second floor machines."]
LET = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"

def fact(name, plan, score): return f"Record: customer {name} is on the {plan} plan and rated support {score} out of 5."

def build(rng, tok, L, k, n_opt, qtype, sandwich):
    names = rng.sample(NAMES, k + 1); tgt = names[0]
    plans = [rng.choice(PLANS[:max(n_opt,2)]) for _ in names]; scores = [rng.randint(1, 5) for _ in names]
    facts = [fact(n, p, s) for n, p, s in zip(names, plans, scores)]
    if qtype == "choice":
        opts = rng.sample(PLANS[:n_opt], n_opt) if plans[0] in PLANS[:n_opt] else None
        q = f"Which plan is customer {tgt} on?"; gold = opts.index(plans[0])
    elif qtype == "noul":
        yes = rng.random() < 0.5; asked = plans[0] if yes else rng.choice([p for p in PLANS[:8] if p != plans[0]])
        q = f"Is customer {tgt} on the {asked} plan?"; opts = ["Yes", "No"]; gold = 0 if yes else 1
    else:
        q = f"What support rating did customer {tgt} give?"; opts = ["1", "2", "3", "4", "5"]; gold = scores[0] - 1
    optblock = "\n".join(f"{LET[i]}. {o}" for i, o in enumerate(opts))
    head = (f"Question: {q}\n\n" if sandwich else "")
    tail = f"\n\nQuestion: {q}\nOptions:\n{optblock}\nAnswer with the option text only.\nAnswer:"
    # body: facts + filler up to L tokens; evidence at uniform random depth
    budget = L - len(tok(head + tail).input_ids) - 10
    sents = facts[1:]; ftoks = sum(len(tok(" " + s).input_ids) for s in facts)
    filler = []; used = ftoks
    while True:
        s = rng.choice(FILL); t = len(tok(" " + s).input_ids)
        if used + t > budget: break
        filler.append(s); used += t
    body = sents + filler; rng.shuffle(body)
    body.insert(rng.randint(0, len(body)), facts[0])
    return dict(sents=body, head=head, tail=tail, gold=gold, n=len(opts), opts=opts, evidence=facts[0])

class Scorer:
    def __init__(s, mid):
        s.tok = AutoTokenizer.from_pretrained(mid); s.m = AutoModelForCausalLM.from_pretrained(mid, torch_dtype=torch.float32).eval()
        s.lid = [s.tok(" " + c, add_special_tokens=False).input_ids[-1] for c in LET]
        s.tau = 1.0
        for mod in s.m.model.layers: mod.self_attn.q_proj.register_forward_hook(lambda m, i, o: o * s.tau)
    @torch.no_grad()
    def probs(s, text, opts):
        ids = s.tok(text, return_tensors="pt").input_ids
        oid = [s.tok(" " + o, add_special_tokens=False).input_ids[0] for o in opts]
        assert len(set(oid)) == len(oid), opts
        lg = s.m(ids, logits_to_keep=1).logits[0, -1, oid]
        return torch.softmax(lg.float(), -1).numpy(), ids.shape[1]

def run_item(sc, it, mode, chunk_tokens=512, ssmax_L0=None, chunk_P=None):
    full = it["head"] + "Document:\n" + " ".join(it["sents"]) + it["tail"]
    if mode == "single":
        if ssmax_L0:
            n = len(sc.tok(full).input_ids); sc.tau = max(1.0, math.log(n) / math.log(ssmax_L0))
        p, n = sc.probs(full, it["opts"]); sc.tau = 1.0
        return int(p.argmax()), float(p.max()), n
    # chunked: split sentences into ~chunk_tokens chunks, score each, aggregate
    chunks, cur, ct = [], [], 0
    for snt in it["sents"]:
        t = len(sc.tok(" " + snt).input_ids)
        if ct + t > chunk_tokens and cur: chunks.append(cur); cur, ct = [], 0
        cur.append(snt); ct += t
    chunks.append(cur)
    if chunk_P is not None and "P" in chunk_P: P = chunk_P["P"]
    else:
        P = np.stack([sc.probs(it["head"] + "Document:\n" + " ".join(c) + it["tail"], it["opts"])[0] for c in chunks])
        if chunk_P is not None: chunk_P["P"] = P
    if mode == "chunk_max":   # answer from most confident chunk (≈ their floor rule)
        i = P.max(1).argmax(); return int(P[i].argmax()), float(P[i].max()), len(chunks)
    if mode == "chunk_mean":
        m = P.mean(0); return int(m.argmax()), float(m.max()), len(chunks)
    if mode == "chunk_logsum":  # product of experts / sum log-probs
        m = np.log(P + 1e-9).sum(0); return int(m.argmax()), float(np.exp(m - m.max()).max()), len(chunks)

if __name__ == "__main__":
    ap = argparse.ArgumentParser(); ap.add_argument("--model", default="HuggingFaceTB/SmolLM2-360M-Instruct")
    ap.add_argument("--exp", required=True); ap.add_argument("--n", type=int, default=40); ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--out", required=True); a = ap.parse_args()
    sc = Scorer(a.model); torch.set_num_threads(8); res = []
    # experiment grids: list of (cell_name, L, k, n_opt, qtype, sandwich, mode, ssmax)
    G = []
    QT = ["choice", "noul", "score"]
    if a.exp == "length":       # (a)+(c): single vs chunked vs ssmax, k grows with length (realistic)
        for L in [512, 2048, 4096]:
            for qt in QT:
                G.append((f"L{L}", L, max(4, L // 64), 8, qt, False, "ALL", 512))
    if a.exp == "sandwich":     # (b)
        for L in [2048]:
            for qt in QT:
                for sw in [False, True]: G.append((f"L{L}", L, max(4, L // 64), 8, qt, sw, "single", None))
    if a.exp == "distract":     # (d) distractors vs length
        for k in [2, 16, 64]: 
            for qt in QT: G.append((f"fixL2048_k{k}", 2048, k, 8, qt, False, "single", None))
        for L in [512, 2048, 4096]:
            for qt in QT: G.append((f"fixk8_L{L}", L, 8, 8, qt, False, "single", None))
    if a.exp == "options":      # (e)
        for no in [2, 4, 8, 16]: G.append((f"opt{no}", 1024, 16, no, "choice", False, "single", None))
    t0 = time.time()
    for cell, L, k, no, qt, sw, mode, ss in G:
        rng = random.Random(hash((a.seed, cell, qt, sw)) % 2**31)
        modes = [("single", None), ("single_ssmax", ss), ("chunk_max", None), ("chunk_mean", None), ("chunk_logsum", None)] if mode == "ALL" else [(mode, None)]
        H = {m_: [] for m_, _ in modes}
        if mode == "ALL" and L <= 512: modes = [m_ for m_ in modes if m_[0] != "single_ssmax"]; H.pop("single_ssmax")
        for j in range(a.n):
            it = build(rng, sc.tok, L, k, no, qt, sw); cache = {}
            for m_, s_ in modes:
                if m_.startswith("chunk"):
                    pred, conf, _ = run_item(sc, it, m_, chunk_P=cache)
                else:
                    pred, conf, _ = run_item(sc, it, "single", ssmax_L0=s_)
                H[m_].append(int(pred == it["gold"]))
        for m_, hits in H.items():
            acc = float(np.mean(hits)); se = math.sqrt(acc * (1 - acc) / len(hits))
            r = dict(cell=cell, L=L, k=k, n_opt=no, qtype=qt, sandwich=sw, mode=m_, n=len(hits), acc=acc,
                     ci95=[round(max(0, acc - 1.96 * se),3), round(min(1, acc + 1.96 * se),3)], hits=hits, seed=a.seed)
            res.append(r); print(json.dumps({k_: v for k_, v in r.items() if k_ != "hits"}), f"t={time.time()-t0:.0f}s", flush=True)
        json.dump(res, open(a.out, "w"), indent=1)
