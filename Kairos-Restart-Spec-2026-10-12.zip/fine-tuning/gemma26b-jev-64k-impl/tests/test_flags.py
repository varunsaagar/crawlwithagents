import sys, os, types, torch, torch.nn.functional as F
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from kairos_loss import kairos_loss
torch.manual_seed(0); B, K = 32, 9
logits = torch.randn(B, K, requires_grad=True); mask = torch.rand(B, K) > 0.3; mask[:, 0] = True
lg = logits.masked_fill(~mask, float("-inf")); y = torch.stack([mask[b].nonzero().flatten()[-1] for b in range(B)])
task = torch.randint(0, 3, (B,)); ref = torch.randn(B, K).masked_fill(~mask, float("-inf"))
off = types.SimpleNamespace(label_smoothing=0, brier_w=0, kl_w=0, ordinal_eps=0)
a = kairos_loss(lg, y, task, off); b = F.cross_entropy(lg, y)
assert torch.equal(a, b); ga = torch.autograd.grad(a, logits, retain_graph=True)[0]; gb = torch.autograd.grad(b, logits, retain_graph=True)[0]
assert torch.equal(ga, gb); print(f"[PASS] flags=0 loss bit-identical to F.cross_entropy ({a.item():.8f}) and grads identical")
on = types.SimpleNamespace(label_smoothing=0.05, brier_w=0.5, kl_w=0.02, ordinal_eps=0.1)
l1 = kairos_loss(lg, y, task, on, ref)
perm = torch.randperm(K); inv = perm.argsort()
# ordinal targets depend on level order, so Score options are never permuted in practice; test invariance on choice/noul rows
cn = task != 2
l_c = kairos_loss(lg[cn], y[cn], task[cn], on, ref[cn]); l_p = kairos_loss(lg[cn][:, perm], inv[y[cn]], task[cn], on, ref[cn][:, perm])
assert torch.allclose(l_c, l_p, atol=1e-6); print(f"[PASS] flags on: loss invariant to option permutation (choice/noul) |diff|={abs(l_c-l_p).item():.1e}")
g = torch.autograd.grad(l1, logits)[0]; assert torch.isfinite(g).all() and (g[~mask] == 0).all()
print("[PASS] flags on: finite grads, zero grad on masked options")
print("ALL FLAG TESTS PASSED")
