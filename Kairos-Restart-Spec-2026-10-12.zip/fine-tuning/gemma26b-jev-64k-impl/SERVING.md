# Serving native Jev 26B-A4B at 64K on 1 GPU (estimates unless marked)
- Weights bf16 ~50.7 GB (measured in run log) + LoRA merged or applied + fp32 head (~MBs). FP8 copy 27 GB exists in-cluster (inference only).
- Single prefill of <=65,536 tokens, no decode, no KV cache retained -> activations only. flex_attention with the packed block mask (SDPA dense mask at 64K ~90 GiB: do not use).
- H100 80GB: bf16 fits 1 request at 64K (est.); H200 141GB: 2-4 concurrent 64K or many short. Latency est. 3-6 s per 64K decision (H100, bf16), ~1-2 s at 16K.
- Endpoint /v1/systemone: {state, questions{choice|noul|score}} -> {answer, probabilities, confidence, certified: bool}.
- Router (fail closed): answer iff slice (type x length bucket) has a certified theta AND conf >= theta; else escalate to LLM. Missing calibration, over-length (>65,536 after pack), unknown type, non-finite logits -> escalate.
- Above 16K until native 64K beats it on the eval: chunked map-reduce (jev-64k-recipe/chunk_aggregate.py, 8K chunks, 0.80 floor), report which path answered.
- Telemetry: OTel gen_ai.evaluation.result per decision; drift alarm freezes a slice (routes to LLM).
