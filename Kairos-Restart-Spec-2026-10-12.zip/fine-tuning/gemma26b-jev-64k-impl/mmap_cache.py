"""Pre-tokenise ONCE to a shared memory-mapped cache (lifts the pod-RAM wall: 3 ranks x full corpus copy
= 103/104 GiB). Every rank np.memmap's the same files; the OS page cache shares pages across ranks.
Layout: tokens.u32 (all ids concatenated), index.npy [N,3] = (offset, length, row_id), meta.jsonl (labels/spans)."""
import json, os, numpy as np

def build_cache(rows, tokenize, out):
    os.makedirs(out, exist_ok=True); off = 0; idx = []
    with open(f"{out}/tokens.u32", "wb") as f, open(f"{out}/meta.jsonl", "w") as m:
        for i, r in enumerate(rows):
            ids = np.asarray(tokenize(r), dtype=np.uint32); f.write(ids.tobytes())
            idx.append((off, len(ids), i)); off += len(ids)
            m.write(json.dumps({k: v for k, v in r.items() if k != "state"}) + "\n")
    np.save(f"{out}/index.npy", np.asarray(idx, dtype=np.int64)); return off

class MmapRows:
    def __init__(s, d):
        s.tok = np.memmap(f"{d}/tokens.u32", dtype=np.uint32, mode="r"); s.idx = np.load(f"{d}/index.npy", mmap_mode="r")
        s.meta_path = f"{d}/meta.jsonl"
    def __len__(s): return len(s.idx)
    def ids(s, i):
        o, n, _ = s.idx[i]; return np.asarray(s.tok[o:o + n])
    def shard(s, rank, world):           # disjoint rows per rank
        return range(rank, len(s), world)
