# Scoring

`jevjudge.core.scoring` uses the same math as DeepEval's JevEval, so CI scores and online scores match.

## Criterion value

| Type | `value` | `applied` |
|---|---|---|
| Noul | `P(true)` | always, when the answer is valid |
| Score | `Σ_k k·P(level_k) / (n − 1)`, with levels indexed 0..n−1 | always, when the answer is valid |
| Choice | `Σ_k credit_k·P(k) / Σ_{k: credit_k not None} P(k)` | `False` if there are no credits, or if the N/A mass is ≥ 0.5 |

For a Choice, options without a credit, options with credit `None`, and the escape label are all N/A. If the N/A options hold at least half of the probability mass, the criterion **drops out** of the rubric score (`applied=False`, "N/A (dropped)" in the reason).

## Rubric score

* `aggregate: weighted_mean` (default): `score = Σ_applied w_i·v_i / Σ_applied w_i` and `success = score ≥ rubric.threshold` for rubrics without a verdict criterion; with a verdict, `success = (verdict == "clean")`.
* `aggregate: strict`: `score = 1` if every applied criterion passes, else `0`.

A criterion **passes** when:

* its label is in `pass_label`, if `pass_label` is set;
* otherwise, for a Noul, the label is `true`;
* for a Score, the label is the best level (last when `higher_is_better`, else first);
* for a Choice, the label has the top credit.

Criteria with `weight: 0` are reported but don't move the score. The shipped voice rubrics give weight 1 to the verdict and weight 0 to the details, so the score is P(true) of the verdict question.

!!! warning "Polarity"
    `score` and `success` don't know which label means "fired". For `output_pii` (fires on `true`), score = P(violation). For `action_completion` (fires on `false`), score = P(completed). Use `RubricResult.verdict` (`fired` / `clean`) and `verdict_probability` (P of the `positive_label`) for metric-level reporting.

## Deterministic reason

`RubricResult.reason` is assembled from outcomes and probabilities. Nothing in it is generated:

```text
output_pii: score=0.031
- pii_exposed: false [false=0.97, true=0.03] via system_one:djev, q=0.97 θ=0.50
- pii_category: none [none=0.91, ssn=0.04, dob=0.02] via system_one:djev, q=0.91 θ=∞, N/A (dropped)
```

Escalated criteria show `escalated (<reason>)`, and the source becomes `system_two:<judge>`. The fallback's own explanation, when requested, is in `CriterionResult.system_two.rationale`, and it is emitted as `gen_ai.evaluation.explanation`.

## Check the math yourself

```python
from jevjudge import Answer, Choice, Criterion, Score
from jevjudge.core.scoring import value_of

c = Criterion(name="sev", question=Score(instructions="How severe?", levels=["none", "mild", "severe"]))
a = Answer(question_id="sev", type="score", label="mild", probabilities={"none": 0.2, "mild": 0.5, "severe": 0.3})
print(value_of(c, a))        # (0.55, True) = (0*0.2 + 1*0.5 + 2*0.3) / 2

ch = Criterion(name="outcome", question=Choice(instructions="Outcome?", options={"ok": None, "bad": None, "na": None},
                                               credits={"ok": 1.0, "bad": 0.0, "na": None}))
a = Answer(question_id="outcome", type="choice", label="na", probabilities={"ok": 0.2, "bad": 0.1, "na": 0.7})
print(value_of(ch, a))       # (None, False): N/A mass 0.7 >= 0.5 -> dropped
```
