// Rasterise every .svg in this directory to a 2x PNG.
//
//   node export_png.js [name.svg ...]
//
// Chromium renders the SVG directly, so the PNG is exactly what the SVG says —
// no separate rendering path to drift from.
const path = require('path');
const fs = require('fs');
const puppeteer = require(process.env.PUPPETEER_PATH ||
  path.join(process.env.HOME, '.npm/_npx/ab5cd9f6d13a2312/node_modules/puppeteer'));

const DIR = __dirname;
const SCALE = 2;

const files = process.argv.length > 2
  ? process.argv.slice(2)
  : fs.readdirSync(DIR).filter(f => f.endsWith('.svg')).sort();

const dims = (svg) => {
  const src = fs.readFileSync(path.join(DIR, svg), 'utf8');
  const w = /\swidth="(\d+(?:\.\d+)?)"/.exec(src);
  const h = /\sheight="(\d+(?:\.\d+)?)"/.exec(src);
  if (!w || !h) throw new Error(svg + ': no width/height on the root <svg>');
  return { w: Math.round(+w[1]), h: Math.round(+h[1]) };
};

(async () => {
  const browser = await puppeteer.launch({ headless: 'new', args: ['--allow-file-access-from-files'] });
  for (const svg of files) {
    const { w, h } = dims(svg);
    const page = await browser.newPage();
    await page.setViewport({ width: w, height: h, deviceScaleFactor: SCALE });
    await page.goto('file://' + path.join(DIR, svg), { waitUntil: 'networkidle0' });
    await page.evaluateHandle('document.fonts.ready');
    const out = path.join(DIR, svg.replace(/\.svg$/, '.png'));
    await page.screenshot({ path: out, omitBackground: false });
    await page.close();
    console.log(`${svg}  ->  ${path.basename(out)}   ${w * SCALE}x${h * SCALE}  ` +
                `${(fs.statSync(out).size / 1024).toFixed(0)} KB`);
  }
  await browser.close();
})();
