# OpenTelemetry in and out

## Ingest: OTLP → Session

`jevjudge.otel.ingest.session_from_otlp(payload, session_id=None, profile=None)` turns these inputs into a `Session`:

* OTLP `resourceSpans` (an envelope, a list of envelopes, or BigQuery rows with `spans_json` / `all_spans_data`);
* Sierra (`conversation_turn` + `execute_tool`), Decagon (`agent_turn` + `mcp_*`) and CES (`turn N workflow`) traces;
* traces that follow the OTel GenAI semantic conventions.

The grader calls it automatically when you pass a dict with `resourceSpans`, `spans_json` or `all_spans_data`.

```python
import json
from jevjudge.otel.ingest import session_from_otlp
from jevjudge.adapters.cmcs import session_from_prod_transcript    # CMCS `prod_transcript` text

# rows = json.load(open("prod_cmcs_session_spans.json"))           # BigQuery-shaped rows
# s = session_from_otlp(rows[0], session_id=rows[0]["conv_id"])
# print(s.source, len(s.turns), len(s.tool_calls), s.trace_id)
```

Tool spans are attached to the agent turn whose time window contains them. If there is none, they go to the next agent turn, or else to the last one. Tool errors are detected structurally: the span status is ERROR, or the result JSON has a truthy error key, a false success key, or a status ≥ 400. A leading echo of tool-call syntax in the agent text (`Fn({...}) Thanks …`) is stripped before judging.

### Trace profiles

A **trace profile** maps spans to turns and tool calls. Add a profile for a new platform instead of changing code. The packaged default is `resources/profiles/default.yaml`:

```yaml
conversation_id_keys: [gen_ai.conversation.id, session.id, session_id, conversation_id]
resource_conversation_id_keys: [verizon.call.id, session.id]
turn_spans:
  names: [agent_turn, conversation_turn]          # exact span names
  name_prefixes: ["turn "]                        # CES "turn N workflow"
  operations: [invoke_agent, workflow]            # gen_ai.operation.name (requires gen_ai.input.messages)
tool_spans:
  operations: [execute_tool]
  span_types: [execute_tool, tool, toolcall, tool_call, mcp, function]
  name_prefixes: ["execute_tool"]
attributes:
  input_messages: gen_ai.input.messages
  output_messages: gen_ai.output.messages
  system_instructions: gen_ai.system.instructions
  tool_name: [gen_ai.tool.name, tool.name]
  tool_arguments: gen_ai.tool.call.arguments
  tool_result: gen_ai.tool.call.result
  project: [vz.project_slug.use_case, gen_ai.agent.name, service.name]
  channel: [gen_ai.agent.channel]
user_roles: [user, human, customer]
ignore_output_roles: [user, tool, system]
error_detection:
  json_keys_truthy: [error, errors, isError, is_error, exception, fault]
  json_keys_false: [success, ok]
  json_status_keys: [status, statusCode, httpStatusCode, status_code]
  status_error_min: 400
agent_text_normalize:
  strip_leading_call_syntax: true
max_tool_result_chars: 20000
```

Use your own profile file:

```python
from jevjudge.otel.ingest import TraceProfile, session_from_otlp
prof = TraceProfile.load()                       # packaged default; TraceProfile.load("my_profile.yaml") for yours
# session = session_from_otlp(payload, profile="my_profile.yaml")
```

!!! note
    `JudgeConfig` has an `ingest: {profile: path}` key, but `CriterionGrader.from_config` and `jevjudge grade` don't read it yet. To use a custom profile, convert the traces with `session_from_otlp(..., profile=...)` first and pass the `Session` objects to the grader.

## Emit: `gen_ai.evaluation.result` events

`report.to_events()` (or `jevjudge.otel.emit.events(report)`) returns one event per criterion plus one aggregate event per rubric:

| Attribute | Criterion event | Rubric event |
|---|---|---|
| `gen_ai.evaluation.name` | `<rubric_id>.<criterion>` | `<rubric_id>` |
| `gen_ai.evaluation.score.value` | criterion value | rubric score |
| `gen_ai.evaluation.score.label` | final label | `fired` / `clean` |
| `gen_ai.evaluation.explanation` | System Two rationale (if any) | deterministic reason |
| `gen_ai.evaluation.subject.id` / `.trace_id` / `.span_id` | subject ids | subject id |
| `gen_ai.request.model`, `jev.backend` | backend that produced the final answer | |
| `jev.question.type`, `jev.decision`, `jev.escalated`, `jev.escalation.reason` | gate outcome | |
| `jev.final.source` | `system_one` / `system_two` / `code` / `none` | |
| `jev.probabilities` (JSON), `jev.confidence.q`, `jev.confidence.native`, `jev.threshold` | routing signal | |
| `jev.rubric.id`, `jev.rubric.revision`, `jev.calibration.version`, `jev.weight`, `jev.applied`, `jev.latency_ms` | provenance | `jev.rubric.revision`, `jev.aggregate` |
| `jev.policy.source`, `jev.shadow_threshold`, `jev.stratum` | threshold governance (see [Governance](governance.md#migration-phases)); only set when present | |

Sinks:

```python
from jevjudge.otel.emit import JsonlSink, OtelSink, metrics_blob

jsonl = JsonlSink("out/events.jsonl")          # one line per subject: {subject_id, events, calls, latency_ms}

from opentelemetry.sdk.trace import TracerProvider
otel = OtelSink(TracerProvider())              # an INTERNAL `evaluation` span per subject, linked to the subject trace

# await grader.grade_many(items, rubrics, on_result=lambda rep: (jsonl(rep), otel(rep)))
```

`OtelSink` needs the `otel` extra. Configure the `TracerProvider` with an OTLP exporter to send the spans to a collector, and from there to Langfuse, Phoenix or Galileo. `examples/otel_pipeline.py` shows the whole flow end to end.

To write native Langfuse scores or Phoenix span annotations directly, without a collector, use `LangfuseSink` and `PhoenixSink` (see [Monitoring → Sinks](monitoring.md#sinks)). With `jevjudge grade`, select sinks with `emit:` in the judge YAML.

## Metrics blob

`report.to_blob(mapping=None)` (or `metrics_blob(report, mapping)`) maps rubric results to a downstream blob. The default mapping, `resources/sinks/cmcs.yaml`, produces the CMCS `metrics` STRING that Insights Manager reads, so a Jev run can be compared column by column with the incumbent:

```yaml
metrics:
  output_pii:        {key: "pii@category_count", kind: categories, category_criterion: pii_category, none_label: none}
  output_toxicity:   {key: toxicity_gpt_multijudge_average, kind: risk, severity_criterion: toxicity_severity}
  output_sexism:     {key: sexist_gpt_multijudge_average, kind: risk, severity_criterion: sexism_severity}
  hallucination:     {key: "VZ Hallucination", kind: risk, severity_criterion: hallucination_severity}
  action_completion: {key: Action_Completion_Voice_Agent, kind: bool_pass,
                      metadata_criteria: {reason_category: reason_category, containment_quality: containment_quality}}
```

| `kind` | Value |
|---|---|
| `categories` | `{<category label>: 1}` when the verdict fired (`unspecified` if the category is missing or equals `none_label`), else `{}` |
| `risk` | exactly `0.0` when clean; otherwise the severity value (at least 0.1), or the verdict probability if there is no severity |
| `bool_pass` | `True` when clean, `False` when fired, `None` if unknown |
| `probability` | `verdict_probability` (P of the positive label) |

Every key also gets `<key>_rationale` (the deterministic reason) and `<key>_status` (`success`, or `error` when there is no verdict). With `metadata_criteria`, it also gets `<key>_metadata`. A `_judge` entry records the engine, tiers, judges and call counts.

```python
custom = {"metrics": {"output_pii": {"key": "pii_p", "kind": "probability"}}}
# blob = report.to_blob(custom)                 # or a path to a YAML file with the same shape
```

The CLI writes CMCS blobs with `jevjudge grade --cmcs blobs.jsonl`. Each line is `{"session_id": ..., "metrics": {...}}`.
