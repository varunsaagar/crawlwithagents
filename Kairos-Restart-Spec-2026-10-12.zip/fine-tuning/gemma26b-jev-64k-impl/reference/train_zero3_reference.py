"""Minimal distributed trainer with the CORRECT ZeRO-3 control flow (CPU / gloo).

ZeRO-3 is emulated by ShardedLinear: each rank holds 1/world of every frozen base weight
and all-gathers it inside forward(), so EVERY forward pass is a collective -- exactly the
property that turned Kairos' `if rank == 0: evaluate()` into a deadlock.
Trainable params (LoRA + fp32 head) are replicated, grads all-reduced; save() runs a
collective gather on all ranks and only rank 0 writes (mirrors GatheredParameters).

--bug rank0_eval            : original Failure #8 structure (rank-0-only eval, others barrier)
--bug post_destroy_barrier  : the train.py:406 crash (barrier after destroy_process_group)
"""
import argparse, json, os, random, sys, time, datetime
import torch, torch.nn as nn, torch.nn.functional as F, torch.distributed as dist
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from jev_native_head import TinyBackbone, JevNet, freeze_for_lora, pack

ZERO_STAGE = 3
VOCAB, H = 128, 64
TOK = {"ANS": 1, "Q": 2}

def dist_ready(): return dist.is_available() and dist.is_initialized()
def rank(): return dist.get_rank() if dist_ready() else 0
def world(): return dist.get_world_size() if dist_ready() else 1
def safe_barrier():
    if dist_ready(): dist.barrier()
def safe_teardown():
    """Called exactly once, by every rank, as the LAST distributed action."""
    if dist_ready():
        dist.barrier(); dist.destroy_process_group()

class ShardedLinear(nn.Module):
    """Frozen weight stored as a 1/world shard; gathered (collective) on every forward."""
    def __init__(s, i, o):
        super().__init__(); s.in_features, s.out_features = i, o
        full = nn.Linear(i, o)  # same seed on all ranks -> identical full init
        W = torch.cat([full.weight.data.flatten(), full.bias.data])
        s.numel = W.numel(); w = world(); per = -(-s.numel // w); W = F.pad(W, (0, per * w - s.numel))
        s.register_buffer("shard", W[rank()*per:(rank()+1)*per].clone()); s.per = per
    def full(s):
        if not dist_ready(): return s.shard[:s.numel]
        parts = [torch.empty_like(s.shard) for _ in range(world())]
        dist.all_gather(parts, s.shard)          # <-- collective in EVERY forward
        return torch.cat(parts)[:s.numel]
    def forward(s, x):
        W = s.full(); n = s.in_features * s.out_features
        return F.linear(x, W[:n].view(s.out_features, s.in_features), W[n:])

# ---------------- synthetic Jev data ----------------
def make_example(rng, n_opts=6, state_len=40):
    """State contains one evidence token; choice gold = option equal to it; noul = 'is X present';
    score = count bucket. Token ids >= 10."""
    gold_tok = rng.randrange(10, VOCAB); state = [rng.randrange(10, VOCAB) for _ in range(state_len)]
    state[rng.randrange(state_len)] = gold_tok
    opts = rng.sample([t for t in range(10, VOCAB) if t not in state], n_opts - 1) + [gold_tok]; rng.shuffle(opts)
    probe = rng.choice([gold_tok, opts[0] if opts[0] != gold_tok else opts[1]])
    qs = [dict(type="choice", q_ids=[TOK["Q"], 3], options=[[o] for o in opts]),
          dict(type="noul", q_ids=[TOK["Q"], 4, probe], options=[[5], [6]]),
          dict(type="score", q_ids=[TOK["Q"], 7], options=[[8, 0], [8, 1], [8, 2]])]
    cnt = sum(t < 50 for t in state); lvl = 0 if cnt < 12 else (1 if cnt < 16 else 2)
    labels = [opts.index(gold_tok), int(probe in state), lvl]
    return pack(state, qs, TOK, max_len=args_max_len), torch.tensor(labels)

args_max_len = 65536
def dataset(seed, n):
    rng = random.Random(seed); return [make_example(rng) for _ in range(n)]

def build(sharded=True, seed=0):
    torch.manual_seed(seed)
    bb = TinyBackbone(VOCAB, H, linear_cls=ShardedLinear if sharded else nn.Linear)
    freeze_for_lora(bb)
    net = JevNet(bb, H)
    return net

def evaluate(net, data):
    """Under ZeRO-3 this is a COLLECTIVE (ShardedLinear all-gathers). Must run on ALL ranks."""
    net.eval(); correct = n = 0
    with torch.no_grad():
        for packed, y in data:
            logits, _ = net(packed); correct += (logits.argmax(-1) == y).sum().item(); n += len(y)
    net.train(); return correct / n

def trainable_state(net):
    """Collective: every rank must call it (mirrors deepspeed.zero.GatheredParameters)."""
    out = {}
    for k, p in net.named_parameters():
        if p.requires_grad or k.startswith("head."):
            t = p.detach().clone()
            if dist_ready():
                parts = [torch.empty_like(t) for _ in range(world())]; dist.all_gather(parts, t)
                assert all(torch.equal(parts[0], q) for q in parts), f"replica divergence in {k}"
                t = parts[0]
            out[k] = t
    return out

def save(net, path, meta):
    assert ZERO_STAGE == 3, "save() assumes ZeRO-3 semantics: gather is collective on all ranks"
    sd = trainable_state(net)                  # ALL ranks
    if rank() == 0:                            # I/O on rank 0 only
        os.makedirs(path, exist_ok=True); tmp = os.path.join(path, "weights.pt.tmp")
        torch.save(sd, tmp); os.replace(tmp, os.path.join(path, "weights.pt"))
        json.dump(meta, open(os.path.join(path, "meta.json"), "w"))
        with open(os.path.join(path, "writes.log"), "a") as f: f.write(f"rank{rank()} {time.time()}\n")
    safe_barrier()                             # nobody races ahead of the write

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", required=True); ap.add_argument("--steps", type=int, default=60)
    ap.add_argument("--eval_every", type=int, default=20); ap.add_argument("--bug", default="none")
    ap.add_argument("--timeout_s", type=int, default=60); ap.add_argument("--skip_post_eval", type=int, default=1)
    a = ap.parse_args()
    torch.set_num_threads(1)
    dist.init_process_group("gloo", timeout=datetime.timedelta(seconds=a.timeout_s))
    assert ZERO_STAGE == 3
    R, W = rank(), world()
    net = build(sharded=True); net.train(); net.backbone.gc = True
    params = [p for p in net.parameters() if p.requires_grad]
    assert all(p.dtype == torch.float32 for p in params), "ZeRO-3 single-dtype trainables (defect 7)"
    opt = torch.optim.AdamW(params, lr=3e-3)
    train, dev = dataset(1, 240), dataset(2, 30)
    os.makedirs(a.out, exist_ok=True)
    log = open(os.path.join(a.out, f"log.rank{R}.jsonl"), "w"); best = -1.0; dev_score = None
    for step in range(1, a.steps + 1):
        packed, y = train[(step * W + R) % len(train)]
        logits, T = net(packed)
        loss = F.cross_entropy(logits, y)
        opt.zero_grad(); loss.backward()
        for p in params:
            dist.all_reduce(p.grad); p.grad /= W
        opt.step()
        if step % a.eval_every == 0:
            if a.bug == "rank0_eval":
                if R == 0: dev_score = evaluate(net, dev)     # collective on one rank -> DEADLOCK
                dist.barrier()
            else:
                dev_score = evaluate(net, dev)                # ALL ranks, deterministic -> same value
            log.write(json.dumps(dict(event="dev", step=step, score=dev_score, loss=loss.item())) + "\n"); log.flush()
            if dev_score > best:                              # identical decision on all ranks
                best = dev_score; save(net, os.path.join(a.out, "best"), dict(step=step, score=dev_score))
    final = evaluate(net, dev)
    save(net, os.path.join(a.out, "last"), dict(step=a.steps, score=final))   # BEFORE teardown
    log.write(json.dumps(dict(event="final", score=final)) + "\n"); log.close()
    if a.bug == "post_destroy_barrier":
        if dist_ready(): dist.destroy_process_group()
        if R != 0: dist.barrier()                             # == train.py:406 -> ValueError
        return
    if not a.skip_post_eval:
        raise SystemExit("post-eval inside a ZeRO-3 run is unsupported; use score_single.py")
    safe_teardown()                                           # exactly once, all ranks, last

if __name__ == "__main__":
    main()
