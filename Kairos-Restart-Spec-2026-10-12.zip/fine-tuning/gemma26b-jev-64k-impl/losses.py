"""Calibration losses for the Kairos Jev pointer head (fp32, masked logits over options).
logits: [B,K] with -inf on invalid options; labels: [B] gold index; mask: [B,K] bool."""
import torch, torch.nn.functional as F

def _f32(logits): return logits.float()

def smoothed_ce(logits, labels, mask, eps=0.05):
    """Label smoothing spread only over VALID options (never onto masked ones)."""
    lp = F.log_softmax(_f32(logits), -1).masked_fill(~mask, 0.0)
    k = mask.sum(-1).clamp_min(1).float()
    tgt = (mask.float() * (eps / k)[:, None])
    tgt.scatter_add_(1, labels[:, None], (1 - eps) * torch.ones_like(labels[:, None], dtype=tgt.dtype))
    return -(tgt * lp).sum(-1)

def brier(logits, labels, mask):
    """Multiclass Brier ||p - e_y||^2 over valid options (in [0,2])."""
    p = F.softmax(_f32(logits), -1).masked_fill(~mask, 0.0)
    y = F.one_hot(labels, p.shape[-1]).float()
    return ((p - y) ** 2).sum(-1)

def ordinal_soft_target(labels, mask, eps=0.1):
    """Score questions: put eps on adjacent levels (Clef 'partial credit for adjacent ordinal choices')."""
    B, K = mask.shape; t = torch.zeros(B, K)
    for b in range(B):
        y = int(labels[b]); nb = [j for j in (y-1, y+1) if 0 <= j < K and mask[b, j]]
        t[b, y] = 1 - (eps if nb else 0)
        for j in nb: t[b, j] = eps / len(nb)
    return t

def kl_to_ref(logits, ref_logits, mask):
    # zero masked entries BEFORE subtracting (-inf - -inf = nan would poison grads)
    lp = F.log_softmax(_f32(logits), -1).masked_fill(~mask, 0.0)
    lq = F.log_softmax(_f32(ref_logits), -1).masked_fill(~mask, 0.0)
    p = F.softmax(_f32(logits), -1)
    return (p * (lp - lq)).sum(-1)

def stage1_loss(logits, labels, mask, ref_logits=None, eps=0.05, lam_brier=0.5, beta_kl=0.02, weights=None):
    l = smoothed_ce(logits, labels, mask, eps) + lam_brier * brier(logits, labels, mask)
    if ref_logits is not None: l = l + beta_kl * kl_to_ref(logits, ref_logits, mask)
    return (l * weights).sum() / weights.sum() if weights is not None else l.mean()

def stage2_selective_reinforce(logits, labels, mask, theta=0.8, c_wrong=4.0, c_esc=0.3, M=4, ref_logits=None, beta_kl=0.04):
    """Optional RLCD-style stage 2 for a NON-differentiable reward: action = (pick argmax-sample, answer or escalate).
    Sample answer a~p M times; answer if p[a]>=theta: reward +1 correct / -c_wrong wrong; else -c_esc.
    REINFORCE with leave-one-out baseline (as in OpenJev-RLCD / RLOO), plus pathwise Brier anchor."""
    lp = F.log_softmax(_f32(logits), -1)
    p = lp.exp()
    lp = lp.masked_fill(~mask, 0.0)
    a = torch.multinomial(p.detach().masked_fill(~mask, 0) + 1e-12, M, replacement=True)  # [B,M]
    conf = p.detach().gather(1, a); correct = (a == labels[:, None]).float()
    R = torch.where(conf >= theta, correct - c_wrong * (1 - correct), torch.full_like(conf, -c_esc))
    base = (R.sum(1, keepdim=True) - R) / (M - 1)
    pg = -((R - base) * lp.gather(1, a)).mean()
    l = pg + brier(logits, labels, mask).mean()
    if ref_logits is not None: l = l + beta_kl * kl_to_ref(logits, ref_logits, mask).mean()
    return l, R.mean().item()

@torch.no_grad()
def calib_metrics(probs, labels, n_bins=15, eps_risk=0.05):
    conf, pred = probs.max(-1); corr = (pred == labels).float()
    ece = torch.zeros(()); edges = torch.linspace(0, 1, n_bins + 1)
    for lo, hi in zip(edges[:-1], edges[1:]):
        m = (conf > lo) & (conf <= hi)
        if m.any(): ece += m.float().mean() * (conf[m].mean() - corr[m].mean()).abs()
    br = ((probs - F.one_hot(labels, probs.shape[-1]).float()) ** 2).sum(-1).mean()
    order = conf.argsort(descending=True); c = corr[order]
    risk = 1 - c.cumsum(0) / torch.arange(1, len(c) + 1)
    aurc = risk.mean(); ok = (risk <= eps_risk).nonzero()
    cov = (ok.max().item() + 1) / len(c) if len(ok) else 0.0
    # AUROC of confidence for correct vs wrong
    pos, neg = conf[corr == 1], conf[corr == 0]
    auroc = (pos[:, None] > neg[None]).float().mean().item() if len(pos) and len(neg) else float("nan")
    return dict(acc=corr.mean().item(), ece=ece.item(), brier=br.item(), aurc=aurc.item(), cov_at_eps=cov, auroc=auroc)
