"""Jev long-context data builder (8K->64K). Input: short Jev rows (JSONL: text, question, kind, options, answer, source).
Output: long rows padded with same-domain distractor documents, evidence placed at start/middle/end, catalog options
expanded to 2..300 with hard negatives, length-bucket balanced, deduped and contamination-checked vs JevBench.
Token counts use a ~4 chars/token proxy unless --tokenizer is given. Teacher labelling is a separate step (31B)."""
import argparse, hashlib, json, random, re, sys

BUCKETS = [(0, 8192), (8192, 32768), (32768, 65536)]
POS = ("start", "middle", "end")

def ntok(s, tok=None):
    return len(tok.encode(s)) if tok else len(s) // 4

def shingles(s, k=13):
    w = re.findall(r"\w+", s.lower()); return {" ".join(w[i:i + k]) for i in range(0, max(1, len(w) - k + 1), 7)}

def build_row(row, pool, target, pos, rng, tok, max_opts):
    ev = f"[DOC evidence]\n{row['text']}"
    docs, cur = [], ntok(ev, tok)
    cand = [d for d in pool if d["source"] == row.get("source")] or pool
    while cur < target and cand:
        d = rng.choice(cand)
        if d["text"] == row["text"]: continue
        docs.append(f"[DOC {len(docs)}]\n{d['text']}"); cur += ntok(docs[-1], tok)
        if len(docs) > 5000: break
    i = {"start": 0, "middle": len(docs) // 2, "end": len(docs)}[pos]
    docs.insert(i, ev)
    opts = list(row["options"])
    if row.get("kind") == "choice" and len(opts) < max_opts:  # catalog expansion with hard negatives from same source
        extra = [o for d in cand for o in d.get("options", []) if o not in opts]
        rng.shuffle(extra); opts += extra[: rng.randint(0, max_opts - len(opts))]
    rng.shuffle(opts)
    return dict(row, text="\n\n".join(docs), options=opts, evidence_pos=pos, approx_tokens=cur, target_len=target)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--short", required=True); ap.add_argument("--out", required=True)
    ap.add_argument("--max_len", type=int, default=65536); ap.add_argument("--per_bucket", type=int, default=20000)
    ap.add_argument("--jevbench", help="JSONL of JevBench items for contamination check")
    ap.add_argument("--max_opts", type=int, default=300); ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--tokenizer"); a = ap.parse_args()
    rng = random.Random(a.seed)
    tok = None
    if a.tokenizer:
        from transformers import AutoTokenizer; tok = AutoTokenizer.from_pretrained(a.tokenizer)
    rows = [json.loads(l) for l in open(a.short)]
    rows = [r for r in rows if "qwen" not in json.dumps(r.get("provenance", "")).lower()]  # Qwen ban
    bench = set()
    if a.jevbench:
        for l in open(a.jevbench): bench |= shingles(json.loads(l).get("text", ""))
    seen, n_out, drop = set(), 0, 0
    with open(a.out, "w") as f:
        for lo, hi in BUCKETS:
            if lo >= a.max_len: break
            for k in range(a.per_bucket):
                r = rng.choice(rows); pos = POS[k % 3]
                tgt = rng.randint(max(lo, 1024), min(hi, a.max_len)) - 512
                out = build_row(r, rows, tgt, pos, rng, tok, a.max_opts)
                h = hashlib.sha1((r["text"] + r["question"] + pos + str(tgt // 4096)).encode()).hexdigest()
                if h in seen or (bench and len(shingles(r["text"]) & bench) > 2): drop += 1; continue
                seen.add(h); out["bucket"] = f"{lo}-{hi}"; f.write(json.dumps(out) + "\n"); n_out += 1
    print(f"wrote {n_out} rows, dropped {drop} (dup/contamination)", file=sys.stderr)

if __name__ == "__main__": main()
