"""Teacher labelling sketch for long rows. Providers: gemini (token logprobs over option letters where the model/API exposes
them), opus (Anthropic API gives no logprobs: n samples -> vote distribution, or ask for a JSON distribution; treat as soft
label only after gold-filtering), gemma31b (vLLM logprobs). Keeps teacher dist only where argmax == gold, else one-hot gold.
Cost ~= rows * (avg_input_tokens * price_in + out_tokens * price_out) * samples; long rows are input-dominated, so use
provider prompt caching for shared documents. Fill prices from the provider's current price page; none are assumed here."""
import argparse, json, os, string, collections

LET = string.ascii_uppercase

def prompt(r):
    opts = "\n".join(f"{LET[i]}. {o}" for i, o in enumerate(r["options"][:26]))
    return f"Question: {r['question']}\n\n{r['text']}\n\nQuestion (repeated): {r['question']}\nOptions:\n{opts}\nAnswer with one letter."

def gemini(r, n):
    from google import genai  # pip install google-genai ; GEMINI_API_KEY in env
    c = genai.Client(); resp = c.models.generate_content(model=os.environ.get("GEMINI_MODEL", "gemini-pro-latest"),
        contents=prompt(r), config={"response_logprobs": True, "logprobs": 20, "max_output_tokens": 1, "temperature": 0})
    import math; d = collections.Counter()
    for cand in resp.candidates[0].logprobs_result.top_candidates[0].candidates:
        t = cand.token.strip()
        if t in LET[: len(r["options"])]: d[t] += math.exp(cand.log_probability)
    return d

def opus(r, n):
    import anthropic  # ANTHROPIC_API_KEY in env
    c = anthropic.Anthropic(); d = collections.Counter()
    for _ in range(n):
        m = c.messages.create(model=os.environ.get("OPUS_MODEL", "claude-opus-latest"), max_tokens=2, temperature=1.0,
                              messages=[{"role": "user", "content": prompt(r)}])
        t = m.content[0].text.strip()[:1]
        if t in LET: d[t] += 1
    return d

def main():
    ap = argparse.ArgumentParser(); ap.add_argument("--inp"); ap.add_argument("--out"); ap.add_argument("--provider", choices=["gemini", "opus"])
    ap.add_argument("--samples", type=int, default=8); a = ap.parse_args(); fn = {"gemini": gemini, "opus": opus}[a.provider]
    kept = 0
    with open(a.out, "w") as f:
        for l in open(a.inp):
            r = json.loads(l); d = fn(r, a.samples); z = sum(d.values()) or 1
            dist = {r["options"][LET.index(k)]: v / z for k, v in d.items()}
            gold_ok = bool(dist) and max(dist, key=dist.get) == r["answer"]
            r["teacher"] = dist if gold_ok else {r["answer"]: 1.0}; r["provenance"] = {"teacher": a.provider, "gold_ok": gold_ok}
            kept += gold_ok; f.write(json.dumps(r) + "\n")
    print("teacher agreed with gold on", kept, "rows")

if __name__ == "__main__": main()
