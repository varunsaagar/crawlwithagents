# Jev long-context toy experiments (CPU proxy, NOT E4B)

What this is: a small sanity check on CPU (8 cores, no GPU) that tests the *direction* of five long-context hypotheses before spending GPU hours on E4B. These numbers say nothing about the *size* of any effect on E4B.

## Files
- `toy_pointer.py`: synthetic Jev-like task plus a 4-layer causal transformer (d=96, RoPE) with a Kairos/strands-style **pointer head** (answer-position query · option-position keys). States are fact records (the evidence plus k distractor records about other entities) and filler. Questions are Noul (YES/NO about the entity's plan), Choice (pick the plan among n listed options) and Score (1–5). Trained from scratch at length 64, evaluated at 64/128/256/512 (8×, the same ratio as 8K→64K).
  - Modes: `single`; `tau` = training-free attention-logit scaling × (log n / log 64)^τ on every layer (SSMax-style); `chunk_max` = map-reduce over 64-token chunks taking the most confident chunk (≈ your floor rule); `chunk_logsum` = sum of log-probs over chunks.
  - Training variants: `base` (k = 2–6 distractors at 64), `hard_distract` (k = 6–30 at the same length 64), `length_mix` (lengths 64/128/256, few distractors), `ssmax_trained` (learned s·log n per head), `sandwich` (question before and after the state).
- `run_toy.py` (phase 1: base seed 0, all modes, distractor, length and option sweeps; stopped after seed 0 to keep within the time box), `run_toy2.py` (phase 2: one seed per variant plus base seed 1).
- `results_toy.json`, `results_toy2.json` (each cell has per-item hits, n, 95% Wald CI, seed), `RESULTS.md` (tables, from `summarize.py`).
- `zeroshot_lm_probe.py`: a first attempt with zero-shot letter or option logits on SmolLM2-360M/1.7B-Instruct. **Dropped**: both scored at or below chance on Choice even at 512 tokens (360M choice 0.05–0.25, 1.7B 0.10), so they could not show length effects. It's kept for the record.

## Run
```bash
uv venv .venv && . .venv/bin/activate && uv pip install torch --index-url https://download.pytorch.org/whl/cpu && uv pip install numpy
python run_toy.py 3000; python run_toy2.py; python summarize.py
```
Runtime is about 15 min for phase 1 seed 0 and about 25 min for phase 2, on 8 CPU threads.

## Caveats
- Undertrained (3,000 steps): Score is weak even at length 64 (~0.36). Read Noul and Choice; treat Score as noise.
- Most cells are 1 seed. CIs are within-seed binomial and don't cover seed variance. Base seed 0 vs seed 1 gives a rough idea of seed spread.
- Records are one fused token (entity+plan+score embeddings), so "reading" is a single content match. Real states need multi-token evidence and reasoning.
