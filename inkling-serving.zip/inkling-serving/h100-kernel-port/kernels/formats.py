"""Weight formats used by Inkling 2 Mini routed experts, plus exact reference dequantisers.

NVFP4 (layers 0-19, ModelOpt-style; layout assumed, verify against the checkpoint):
  - packed  : uint8 [E, N, K//2], two e2m1 codes per byte, low nibble = even k
  - scale   : uint8 [E, N, K//16], FP8 E4M3 (fn) bit patterns, one per 16 weights along K
  - gscale  : fp32  [E], per-expert global scale
  w[e, n, k] = e2m1(code) * e4m3(scale[e, n, k//16]) * gscale[e]

MXFP8 (layers 20-23, OCP MX):
  - packed  : uint8 [E, N, K], FP8 E4M3 bit patterns
  - scale   : uint8 [E, N, K//32], UE8M0 exponents (value 2**(s-127))
  - gscale  : fp32  [E], all ones (kept so both formats share one kernel signature)

All decoding here is done with integer/bit arithmetic so it is exact and runs on CPU.
"""
import torch

E2M1_LUT = torch.tensor([0.0, 0.5, 1.0, 1.5, 2.0, 3.0, 4.0, 6.0,
                         -0.0, -0.5, -1.0, -1.5, -2.0, -3.0, -4.0, -6.0], dtype=torch.float32)


def e4m3fn_decode(u8: torch.Tensor) -> torch.Tensor:
    """Decode FP8 E4M3 (fn variant, bias 7, no inf) bit patterns to fp32, exactly."""
    u = u8.to(torch.int32)
    s = (u >> 7) & 1
    e = (u >> 3) & 0xF
    m = (u & 0x7).to(torch.float32)
    normal = (1.0 + m / 8.0) * torch.pow(2.0, (e - 7).to(torch.float32))
    sub = (m / 8.0) * (2.0 ** -6)
    v = torch.where(e == 0, sub, normal)
    v = torch.where((e == 0xF) & ((u & 0x7) == 0x7), torch.full_like(v, float("nan")), v)
    return torch.where(s == 1, -v, v)


def e4m3fn_encode_nearest(x: torch.Tensor) -> torch.Tensor:
    """Round fp32 to nearest FP8 E4M3fn bit pattern (test-data helper only; uses torch dtype)."""
    return x.clamp(-448, 448).to(torch.float8_e4m3fn).view(torch.uint8)


def ue8m0_decode(u8: torch.Tensor) -> torch.Tensor:
    return torch.pow(2.0, u8.to(torch.float32) - 127.0)


def dequant_nvfp4(packed, scale, gscale):
    """-> fp32 [E, N, K]. Exact (e2m1*e4m3 fits in fp32; global scale applied in fp32)."""
    E, N, Kh = packed.shape
    lo = (packed & 0xF).long()
    hi = (packed >> 4).long()
    codes = torch.stack([lo, hi], dim=-1).reshape(E, N, Kh * 2)
    vals = E2M1_LUT[codes]
    s = e4m3fn_decode(scale).repeat_interleave(16, dim=-1)
    return vals * s * gscale.view(E, 1, 1)


def dequant_mxfp8(packed, scale, gscale):
    E, N, K = packed.shape
    vals = e4m3fn_decode(packed)
    s = ue8m0_decode(scale).repeat_interleave(32, dim=-1)
    return vals * s * gscale.view(E, 1, 1)


def random_nvfp4(E, N, K, gen=None):
    """Random but realistic NVFP4 expert weights (codes uniform, scales in a sane range)."""
    assert K % 16 == 0
    packed = torch.randint(0, 256, (E, N, K // 2), dtype=torch.uint8, generator=gen)
    scale_f = torch.rand((E, N, K // 16), generator=gen) * 0.05 + 0.01
    scale = e4m3fn_encode_nearest(scale_f)
    gscale = torch.rand((E,), generator=gen) * 0.5 + 0.75
    return packed, scale, gscale


def random_mxfp8(E, N, K, gen=None):
    assert K % 32 == 0
    w = torch.randn((E, N, K), generator=gen) * 2.0
    packed = e4m3fn_encode_nearest(w)
    scale = torch.randint(118, 124, (E, N, K // 32), dtype=torch.uint8, generator=gen)
    gscale = torch.ones((E,))
    return packed, scale, gscale
