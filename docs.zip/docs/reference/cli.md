# CLI

The `jevjudge` console script is installed with the package. `python -m jevjudge.cli` works too.

```text
jevjudge {smoke,grade,calibrate,convert,serve} ...
```

## `jevjudge smoke`

Builds each backend and asks it one Noul question ("The caller uses abusive or insulting language.") about a fixed abusive line. Use it to check credentials, the proxy and TLS.

```bash
jevjudge smoke                                   # default: kairos-jev kev-gemma laya djev gemma-26b gemini-2.5-flash
jevjudge smoke --models djev gw/djev gemini-3.8-flash
```

Each line prints `ok`, `label`, `p_true` and the latency, or the error.

## `jevjudge grade`

```bash
jevjudge grade --config configs/judge.yaml --input traces.json --out events.jsonl [--cmcs blobs.jsonl] [--limit N]
```

| Option | Meaning |
|---|---|
| `--config` | judge YAML (required) |
| `--input` | `.jsonl`: one item per line (a `{"session": {...}}` wrapper is unwrapped). `.json`: a list of BigQuery OTLP rows, a list of items, or a single item. Each item can be any input the grader accepts |
| `--out` | JSONL of events per subject (`JsonlSink`), appended |
| `--cmcs` | also append `{"session_id", "metrics": <CMCS blob>}` lines |
| `--limit` | only grade the first N items |

The command prints one progress line per subject: `subject_id {rubric: (verdict, p, final_source)} calls`. At the end, it prints `DRIFT ALARMS: {...}` if any unit raised a [drift alarm](../guides/monitoring.md#drift-statistics).

`emit:` in the judge YAML selects the sinks: `jsonl` (writes `--out`, default `events.jsonl`), `otel` (global TracerProvider), `langfuse`, `phoenix` (see [Sinks](../guides/monitoring.md#sinks)) and `cmcs` (blobs to `--cmcs`, or `<out>.blob.jsonl` when `--cmcs` is not given). `--cmcs` writes blobs whatever `emit` says.

## `jevjudge calibrate`

```bash
jevjudge calibrate --board runs/board.jsonl [more.jsonl ...] --tiers jev-stack --reference gemini-2.5-flash \
    --eps 0.03 --delta 0.05 --registry experiments/registry/certificates.json --promote [--report report.json]
```

| Option | Default | Meaning |
|---|---|---|
| `--board` | required | retained-probability boards (JSONL rows `{item_id, labels, answers}`; produced by `experiments/run_board.py` or a Studio project's `board.jsonl`); loaded with `jevjudge.calibration.boards.load_boards` |
| `--rubrics` | `configs/rubrics/voice` | rubric directory (revisions go into the certificates) |
| `--tiers` | `kairos-jev` | tier names in cascade order (`jev-ens` is derived from the board) |
| `--reference` | `gemini-2.5-flash` | reference judge name |
| `--eps`, `--delta` | `0.02`, `0.05` | tolerance and risk |
| `--min-n` | `100` | minimum items, else θ = ∞ |
| `--label-free` | off | ignore gold and certify in `parity_ref` mode |
| `--registry` | `experiments/registry/certificates.json` | registry file |
| `--promote` | off | activate (`CertificateRegistry.promote`) and save the certificates. This skips the approval step: no approver is recorded (see [Governance](../guides/governance.md#certificate-lifecycle)) |
| `--report` | none | write the analysis and certificates JSON |


## `jevjudge convert`

```bash
jevjudge convert --prompt judge_prompt.txt --out configs/rubrics/new \
    [--cases labelled.jsonl] [--llm gemma-26b] [--decider kairos-jev] [--target-acc 0.9] [--max-refine 2]
```

This command writes `<out>/<rubric_id>.yaml` and prints the agent log. The decider is used only when `--cases` is given. See [Convert an LLM judge](../guides/convert-llm-judge.md).

## `jevjudge serve`

```bash
jevjudge serve [--host 127.0.0.1] [--port 8000]
```

This starts the Calibration Studio and the HTTP API. It needs the `studio` extra. See [HTTP API](http-api.md).

## Make targets

| Target | Command |
|---|---|
| `make install` | `uv pip install -e ".[all,dev,docs]"` |
| `make test` | `pytest -q` |
| `make lint` | `ruff check src tests` |
| `make docs` | `mkdocs build` |
| `make serve` | `jevjudge serve --port 8000` |
| `make build` | build the wheel and sdist |
| `make notebooks`, `make figures` | execute the notebooks, regenerate the `reports/` figures |
