# HTTP API

`jevjudge serve [--host 127.0.0.1] [--port 8000]` (or `uvicorn jevjudge.server.app:app`) starts a FastAPI app. It serves the Calibration Studio UI at `/` and the JSON API under `/v1`. Projects persist under `$JEVJUDGE_HOME` (default `~/.jevjudge/projects`). Interactive OpenAPI docs are at `/docs`.

CORS is open (`*`) and there is **no authentication**. Bind to localhost or put the server behind an authenticating proxy.

## Service

| Method | Path | Body | Response |
|---|---|---|---|
| GET | `/v1/health` | | `{"status": "ok", "version": "0.2.0", "home": "<projects dir>"}` |
| GET | `/v1/models` | | `{"models": {alias: spec}}`; keys containing "key" are removed |
| GET | `/v1/presets` | | `{"presets": {"voice": ["action_completion", ...], "voice_decomposed": [...], "voice_v2": [...]}}` |

## Projects

| Method | Path | Body | Response |
|---|---|---|---|
| GET | `/v1/projects` | | list of `project.json` objects |
| POST | `/v1/projects` | `{"name": str, "description": str = ""}` | project meta (`id`, `name`, `status`, …) |
| GET | `/v1/projects/{id}` | | meta plus `n_sessions`, `n_labels`, `rubrics[]` (`id`, `revision`, `verdict`, `question`, `criteria`), `n_board`, `report`, `jobs[]` |
| DELETE | `/v1/projects/{id}` | | `{"deleted": id}` |
| POST | `/v1/projects/{id}/traces` | multipart `file` (OTLP JSON, BigQuery rows, JSONL, CSV, CMCS rows) | `{"parsed": n, "added": n, "duplicates": n, "total": n}`; 400 if unparseable |
| GET | `/v1/projects/{id}/sessions?limit=20&offset=0` | | `{"total": n, "sessions": [Session]}`: a page of the project's parsed sessions |
| POST | `/v1/projects/{id}/labels` | multipart `file` (CSV or JSONL: `session_id, metric, label`) | `{"added": n}` |
| POST | `/v1/projects/{id}/preset` | `{"name": "voice"}` | `{"rubrics": [ids]}` |
| POST | `/v1/projects/{id}/convert` | `{"prompt": str, "llm": "gemini-3.8-flash", "decider": null, "max_refine": 1}` | job |
| GET | `/v1/projects/{id}/rubrics/{rid}` | | rubric YAML (`text/plain`) |
| PUT | `/v1/projects/{id}/rubrics/{rid}` | JSON `{"yaml": "<rubric yaml>"}` | `{"id", "revision"}`; 400 if invalid. If the YAML's `id` differs from `rid`, the old file is removed (rename) |
| POST | `/v1/projects/{id}/run` | `{"tiers": ["kairos-jev", "djev"], "reference": "gemini-3.8-flash", "limit": null, "concurrency": 8}` | job |
| POST | `/v1/projects/{id}/calibrate` | `{"eps": 0.03, "delta": 0.05, "stack": true, "min_n": 50}` | report: `{eps, delta, tiers, reference, metrics: {rubric_id: {certificate, analysis, curves}}, stacked_metrics}`; 400 if `run` has not been called with a reference. Certificates are proposed and auto-approved as `studio:auto` (send `"approve_as": null` to only propose them); the project's cached grader is dropped and `judge.yaml` re-exported |
| GET | `/v1/projects/{id}/export?base_url=http://localhost:8000` | | `{"python", "python_sync", "langgraph", "curl", "judge_yaml"}`; also writes `judge.yaml` |
| GET | `/v1/jobs/{job_id}` | | `{"id", "kind", "status": "running" \| "done" \| "error", "done", "total", "message", "started"}` |

Unknown projects return 404. Long operations (`convert`, `run`) return a job right away. Poll `/v1/jobs/{id}` until the status is no longer `running`.

```bash
PID=$(curl -s -X POST localhost:8000/v1/projects -H 'Content-Type: application/json' -d '{"name":"demo"}' | jq -r .id)
curl -s -F file=@sessions.jsonl localhost:8000/v1/projects/$PID/traces
curl -s -X POST localhost:8000/v1/projects/$PID/preset -H 'Content-Type: application/json' -d '{"name":"voice"}'
YAML=$(curl -s localhost:8000/v1/projects/$PID/rubrics/output_toxicity)
curl -s -X PUT localhost:8000/v1/projects/$PID/rubrics/output_toxicity -H 'Content-Type: application/json' \
     -d "$(jq -n --arg y "$YAML" '{yaml: $y}')"
JOB=$(curl -s -X POST localhost:8000/v1/projects/$PID/run -H 'Content-Type: application/json' \
      -d '{"tiers":["djev"],"reference":"gemini-3.8-flash"}' | jq -r .id)
curl -s localhost:8000/v1/jobs/$JOB
```

## Governance

Certificate lifecycle, human review and drift for a project. See [Threshold governance](../guides/governance.md), [Human review queue](../guides/review-queue.md) and [Monitoring](../guides/monitoring.md).

| Method | Path | Body | Response |
|---|---|---|---|
| GET | `/v1/projects/{id}/certificates` | | `[{"unit_id", "certificates": [{"certificate_id", "state", "stratum", "thetas", "approver", "approved_at", "issued_at", "expires_at", "expired", "tier_models", "reference_model", "supersedes", "eps", "delta", "n_cal", "mode", "history": [{"event", "by", "at", "note"}]}]}]` (`CertificateRegistry.history` per unit) |
| POST | `/v1/projects/{id}/certificates/{cert_id}/approve` | `{"approver": str, "note": str = ""}` | `{"certificate_id", "state": "ACTIVE", "approver"}`; 400 if the id is unknown, the certificate expired, or its state is not PROPOSED / SUPERSEDED / ROLLED_BACK |
| POST | `/v1/projects/{id}/certificates/rollback` | `{"unit_id": str, "stratum": "all", "by": null, "note": ""}` | `{"unit_id", "active": <re-activated certificate id> \| null}`; `null` means the unit is now uncertified (everything escalates) |
| GET | `/v1/projects/{id}/review?reason=&limit=50` | | `{"items": [queue item], "stats": {"total", "pending", "labelled", "judge_human_agreement", "new_failure_modes"}}`. `reason` filters on `high_stakes`, `both_unsure` or `audit` |
| POST | `/v1/projects/{id}/review/{item_id}` | `{"fired": bool, "reviewer": str, "note": "", "new_failure_mode": null}` | the label record (`item_id`, `status: "labelled"`, `human_fired`, `reviewer`, `note`, `new_failure_mode`, `labelled_at`) |
| POST | `/v1/projects/{id}/review/import` | | `{"imported": n}`: labelled items exported to `review_labels.csv` and added to the project's labels |
| GET | `/v1/projects/{id}/drift` | | `{"units": {unit: {"baseline_n", "window_n", "psi_q", "escalation_rate", "valid_rate", "alarms"}}, "note"}` for the project's `/v1/judge` traffic; `note` explains an empty result |

Approve and rollback drop the project's cached `/v1/judge` grader, so the next call serves the new certificate. They do not reset a monitor freeze (there is no endpoint for that; see [Monitoring](../guides/monitoring.md#configure-and-operate)). Drift statistics live in that cached grader, so they restart after approve, rollback, calibrate or a server restart.

```bash
curl -s localhost:8000/v1/projects/$PID/certificates | jq '.[0]'
curl -s -X POST localhost:8000/v1/projects/$PID/certificates/$CERT/approve -H 'Content-Type: application/json' \
     -d '{"approver": "alice@example.com", "note": "holdout reviewed"}'
curl -s -X POST localhost:8000/v1/projects/$PID/certificates/rollback -H 'Content-Type: application/json' \
     -d '{"unit_id": "output_pii/pii_exposed@noul", "by": "alice@example.com"}'
curl -s "localhost:8000/v1/projects/$PID/review?reason=high_stakes" | jq '.stats'
curl -s -X POST localhost:8000/v1/projects/$PID/review/$ITEM -H 'Content-Type: application/json' \
     -d '{"fired": false, "reviewer": "carol@example.com"}'
curl -s -X POST localhost:8000/v1/projects/$PID/review/import
curl -s localhost:8000/v1/projects/$PID/drift | jq '.units'
```

## Online judging

| Method | Path | Body | Response |
|---|---|---|---|
| POST | `/v1/judge` | `{"trace": <any supported input>, "project": null, "preset": "voice", "tiers": ["djev"], "fallback": ["gemini-3.8-flash"], "threshold": 0.9, "rationale": "on_escalation"}` | `{"report": GradeReport, "blob": CMCS blob, "events": [gen_ai.evaluation.result]}` |

* **With `project`:** the project's `judge.yaml` is used, with certified thresholds, registry, monitor and the project's review queue. If no export exists yet, one is written first. This traffic feeds the project's `review` and `drift` endpoints.
* **Without `project`:** a grader is built from `preset`, `tiers` (default `["djev"]`), `fallback`, `threshold` and `rationale`. It has no registry, monitor or review queue.

`report.meta` includes `timings_ms` (per-stage latency) and, with a review queue, `review_enqueued`.

Graders are cached per project, or per (preset, tiers, fallback, threshold), for the server's lifetime. `calibrate`, certificate approve and rollback drop a project's cached grader. Restart the server to pick up rubric edits or anything changed outside the API.

```bash
curl -s -X POST localhost:8000/v1/judge -H 'Content-Type: application/json' -d '{
  "tiers": ["djev"], "fallback": ["gemini-3.8-flash"], "threshold": 0.9,
  "trace": {"session_id": "s1", "turns": [
    {"speaker": "user", "text": "Can you waive the late fee?"},
    {"speaker": "agent", "text": "I have waived the $10 late fee; you will see it on your next bill."}]}}' | jq '.report.rubrics[] | {rubric_id, verdict}'
```
