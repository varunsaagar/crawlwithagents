#!/usr/bin/env python3
"""Build `jevjudge-explained.html` — how jevjudge judges a conversation, stage by stage.

    python3 build_walkthrough.py

Same shell as the Kairos walkthroughs (`docshell.py` + `shell.css`, copied here unchanged so the
build is self-contained). Standard library only. Every figure is animated SVG (SMIL) with a
replay control and starts when it scrolls into view, as in `kairos/docs/build_laya8k.py`.

Numbers come from FACTS.md only. Anything drawn for shape is marked "illustrative".
"""
from __future__ import annotations

import html
import math as _m
import random
from pathlib import Path

from docshell import (AMBER, AMBER_T, BLUE, BLUE_T, DIM, GREEN, GREEN_T, INK, LINE, MUT, RED,
                      RED_T, STONE, STONE2, page, section, table)

HERE = Path(__file__).parent
W = 1160

TXT = "'Verizon NHG TX',Helvetica,Arial,sans-serif"
DS = "'Verizon NHG DS','Verizon NHG TX',Helvetica,sans-serif"
MONO = "ui-monospace,Menlo,monospace"
GREY = "#9AA0A6"
LGREY = "#D8D8DC"
TAUPE = "#6E6152"


# ── lenses: the three explanations, plus the trap ──────────────────────────
def _lens(kind: str, tag: str, *parts: str) -> str:
    """Like docshell.lens, but block-level parts (equations, code) are not wrapped in <p>."""
    body = "".join(p if p.lstrip().startswith(("<div", "<pre", "<table", "<ul")) else f"<p>{p}</p>"
                   for p in parts)
    return f'<div class="lens {kind}"><span class="tag">{html.escape(tag)}</span>{body}</div>'


def eli5(*p): return _lens("eli5", "in plain English", *p)
def maths(*p): return _lens("math", "the maths", *p)
def tech(*p): return _lens("tech", "under the hood", *p)
def warn(*p): return _lens("warn", "the trap", *p)


def eq(*lines: str) -> str:
    return '<div class="eq">' + "<br>".join(lines) + "</div>"


def figure(svg_: str, title: str, caption: str) -> str:
    return (f'<figure><div class="bar"><span class="t">{html.escape(title)}</span></div>'
            f'{svg_}<figcaption>{caption}</figcaption></figure>')


# ── SVG helpers (same look as build_laya8k.py) ─────────────────────────────
def svg(h, body):
    return (f'<svg class="anim" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {W} {h}" '
            f'role="img"><rect width="{W}" height="{h}" fill="#fff"/>{body}</svg>')


def t(x, y, s, *, size=14, w="400", fill=INK, fam=TXT, anchor="start", op=None):
    a = (f'<text x="{x}" y="{y}" font-size="{size}" font-weight="{w}" fill="{fill}" '
         f'font-family="{fam}"')
    if fam == MONO:
        a += ' xml:space="preserve"'
    if anchor != "start":
        a += f' text-anchor="{anchor}"'
    if op is not None:
        a += f' opacity="{op}"'
    return a + f">{html.escape(str(s), quote=False)}</text>"


def box(x, y, w_, h_, fill, stroke=None, rx=8, op=None, sw=1.5, dash=None):
    a = f'<rect x="{x}" y="{y}" width="{w_}" height="{h_}" rx="{rx}" fill="{fill}"'
    if stroke:
        a += f' stroke="{stroke}" stroke-width="{sw}"'
    if dash:
        a += f' stroke-dasharray="{dash}"'
    if op is not None:
        a += f' opacity="{op}"'
    return a + "/>"


def fade(begin, dur=0.5, frm=0, to=1, attr="opacity"):
    return (f'<animate attributeName="{attr}" from="{frm}" to="{to}" dur="{dur}s" '
            f'begin="{begin}s" fill="freeze"/>')


def grow(begin, frm, to, dur=0.9, attr="width"):
    return (f'<animate attributeName="{attr}" from="{frm}" to="{to}" dur="{dur}s" '
            f'begin="{begin}s" fill="freeze" calcMode="spline" '
            f'keySplines="0.3 0 0.2 1" keyTimes="0;1"/>')


def show(begin, *inner, dur=0.5):
    """A group that fades in at `begin`."""
    return f'<g opacity="0">{fade(begin, dur)}{"".join(inner)}</g>'


def hide(begin, *inner, dur=0.4):
    """A group that is visible, then fades out at `begin`."""
    return f'<g>{fade(begin, dur, 1, 0)}{"".join(inner)}</g>'


def slide(begin, dx, dy, *inner, dur=0.8, appear=True):
    """A group drawn at its final place that travels there from (dx, dy) at `begin`."""
    op = f'<animate attributeName="opacity" from="0" to="1" dur="0.25s" begin="{begin}s" fill="freeze"/>' \
        if appear else ""
    return (f'<g transform="translate({dx} {dy})" opacity="{0 if appear else 1}">{op}'
            f'<animateTransform attributeName="transform" type="translate" from="{dx} {dy}" to="0 0" '
            f'dur="{dur}s" begin="{begin}s" fill="freeze" calcMode="spline" keySplines="0.3 0 0.2 1" '
            f'keyTimes="0;1"/>{"".join(inner)}</g>')


def hbar(x, y, w_, h_, frac, fill, begin, dur=0.9, track="#EDEDED"):
    out = box(x, y, w_, h_, track, rx=h_ / 2) if track else ""
    return out + (f'<rect x="{x}" y="{y}" width="0" height="{h_}" rx="{h_ / 2}" fill="{fill}">'
                  f'{grow(begin, 0, round(w_ * frac, 1), dur)}</rect>')


def vbar(x, base, w_, h_, fill, begin, dur=0.8):
    return (f'<rect x="{x}" y="{base}" width="{w_}" height="0" rx="3" fill="{fill}">'
            f'{grow(begin, 0, round(h_, 1), dur, "height")}'
            f'{grow(begin, base, round(base - h_, 1), dur, "y")}</rect>')


def packet(path, dur, begin, r=6, fill=RED, repeat=True):
    rc = 'repeatCount="indefinite"' if repeat else 'fill="freeze"'
    return (f'<circle r="{r}" fill="{fill}" opacity="0">'
            f'<animate attributeName="opacity" values="0;1;1;0" keyTimes="0;0.08;0.88;1" '
            f'dur="{dur}s" begin="{begin}s" {rc}/>'
            f'<animateMotion path="{path}" dur="{dur}s" begin="{begin}s" {rc}/></circle>')


def drawn(d, begin, dur, stroke, sw=2.5, extra=""):
    """A path that draws itself from start to end."""
    return (f'<path d="{d}" fill="none" stroke="{stroke}" stroke-width="{sw}" pathLength="1" '
            f'stroke-dasharray="1" stroke-dashoffset="1" stroke-linejoin="round" {extra}>'
            f'<animate attributeName="stroke-dashoffset" from="1" to="0" dur="{dur}s" '
            f'begin="{begin}s" fill="freeze"/></path>')


def arrow(x1, y1, x2, y2, col=RED, sw=2, mk="ar", dash=None):
    d = f' stroke-dasharray="{dash}"' if dash else ""
    return (f'<line x1="{x1}" y1="{y1}" x2="{x2}" y2="{y2}" stroke="{col}" stroke-width="{sw}"'
            f'{d} marker-end="url(#{mk})"/>')


def band(y, h, msg, fill=STONE, col=TAUPE, begin=None, size=13.5, sub=None):
    inner = box(30, y, 1100, h, fill, rx=8) + t(52, y + (h / 2 + 5 if not sub else 23), msg,
                                                size=size, w="700", fill=col)
    if sub:
        inner += t(52, y + 44, sub, size=13, fill=col)
    return show(begin, inner) if begin is not None else inner


def title(s, sub=None):
    out = t(30, 36, s, size=17, w="700", fam=DS)
    if sub:
        out += t(30, 58, sub, size=13, fill=MUT)
    return out


def note(y, s, x=1130, anchor="end"):
    return t(x, y, s, size=11.5, fill=DIM, anchor=anchor)


def lines_doc(x, y, w_, rows, rnd, col=GREY, h_=8, gap=14):
    """Grey bars that read as text."""
    out = []
    for i in range(rows):
        ww = w_ * rnd.uniform(0.55, 1.0)
        out.append(f'<rect x="{x}" y="{y + i * gap}" width="{ww:.0f}" height="{h_}" rx="4" fill="{col}"/>')
    return "".join(out)


# ═══════════════════════════════════════════════════════════════════════════
# 1 · the opener — System Two writes, System One fills in boxes
# ═══════════════════════════════════════════════════════════════════════════
def fig_two_systems():
    H = 420
    rnd = random.Random(4)
    b = [title("Same transcript. Two ways to judge it.")]
    # left: System Two
    b.append(box(30, 62, 540, 290, "#FFFBF5", AMBER_T, rx=12))
    b.append(show(2.6, t(50, 90, "System Two · an LLM judge", size=15, w="700", fill=AMBER),
                  t(50, 110, "it writes, one token at a time", size=12.5, fill=MUT)))
    b.append(box(50, 128, 140, 120, STONE2, LINE, rx=8) + lines_doc(64, 144, 110, 7, rnd))
    b.append(arrow(196, 188, 232, 188, AMBER, mk="aam"))
    b.append(box(238, 160, 100, 56, AMBER_T, AMBER, rx=9))
    b.append(t(288, 194, "LLM", size=16, w="700", fill=AMBER, anchor="middle"))
    b.append(arrow(342, 188, 370, 188, AMBER, mk="aam"))
    b.append(box(376, 128, 176, 150, "#fff", LINE, rx=8))
    toks = ["The agent checked", "the account, then", "offered a credit…", "so the verdict", "is: “YES”"]
    for i, s in enumerate(toks):
        b.append(show(0.4 + i * 0.45, t(390, 152 + i * 24, s, size=13, fill=INK if i < 4 else AMBER,
                                        w="400" if i < 4 else "700", fam=MONO if i == 4 else TXT)))
    b.append(f'<g opacity="0">{fade(0.4, 0.3)}'
             f'<rect x="390" y="262" width="8" height="2" fill="{AMBER}">'
             f'<animate attributeName="x" values="390;530;390" dur="2.25s" begin="0.4s" '
             f'repeatCount="indefinite"/></rect></g>')
    b.append(show(2.6, box(376, 290, 176, 46, AMBER_T, AMBER, rx=8),
                  t(390, 309, "parse the text", size=12.5, w="700", fill=AMBER),
                  t(390, 327, "it can fail, or ramble", size=11.5, fill=MUT)))
    b.append(show(2.6, t(50, 280, "a decode loop:", size=12.5, w="700", fill=AMBER),
                  t(50, 298, "many passes, then parsing", size=12.5, fill=MUT)))
    # right: System One
    b.append(box(590, 62, 540, 290, "#F6FBF8", GREEN_T, rx=12))
    b.append(show(2.6, t(610, 90, "System One · a decision model", size=15, w="700", fill=GREEN),
                  t(610, 110, "it fills in boxes, in one pass", size=12.5, fill=MUT)))
    b.append(box(610, 128, 140, 120, STONE2, LINE, rx=8) + lines_doc(624, 144, 110, 7, rnd))
    qs = [("noul", "PII exposed?"), ("choice", "task done?"), ("score", "how toxic?")]
    for i, (ty, q) in enumerate(qs):
        b.append(show(0.3 + i * 0.15, box(610, 258 + i * 30, 140, 24, BLUE_T, rx=5),
                      t(618, 275 + i * 30, ty, size=11, w="700", fill=BLUE, fam=MONO),
                      t(672, 275 + i * 30, q, size=11, fill=BLUE)))
    b.append(arrow(756, 210, 790, 210, GREEN, mk="agr"))
    b.append(box(796, 178, 110, 64, GREEN_T, GREEN, rx=9))
    b.append(t(851, 205, "one", size=14, w="700", fill=GREEN, anchor="middle"))
    b.append(t(851, 224, "forward pass", size=12, fill=GREEN, anchor="middle"))
    b.append(arrow(910, 210, 936, 210, GREEN, mk="agr"))
    outs = [("PII", 0.03, ["true", "false"]), ("task", 0.88, ["yes", "no"]), ("toxic", 0.06, ["0", "1+"])]
    for i, (lbl, p, _) in enumerate(outs):
        y = 150 + i * 46
        b.append(box(942, y, 172, 38, "#fff", LINE, rx=7))
        b.append(t(954, y + 24, lbl, size=12.5, w="700"))
        b.append(hbar(1000, y + 14, 70, 10, p, GREEN, 0.9 + i * 0.2))
        b.append(show(1.5 + i * 0.2, t(1076, y + 24, f"{p:.2f}", size=12, w="700", fill=GREEN, fam=MONO)))
    b.append(show(2.0, t(942, 300, "real probabilities", size=12.5, w="700", fill=GREEN),
                  t(942, 318, "nothing to parse", size=12.5, fill=MUT)))
    b.append(band(366, 40, "System One answers first. System Two is asked only when System One is not "
                           "confident.", begin=3.0))
    b.append(note(414, "probabilities are illustrative"))
    return svg(H, "".join(b))


# ═══════════════════════════════════════════════════════════════════════════
# 2 · onboard — otel-check and otel-validate
# ═══════════════════════════════════════════════════════════════════════════
def fig_onboard():
    H = 420
    b = [title("Will your traces work? Two commands answer that first.",
               "27 production projects, checked on 2026-10-09.")]
    # 27 project squares
    order = list(range(27))
    for i in order:
        c, r = i % 9, i // 9
        x, y = 40 + c * 28, 96 + r * 28
        col = GREEN if i < 25 else (RED if i == 25 else AMBER)
        b.append(box(x, y, 22, 22, LGREY, rx=4))
        b.append(f'<rect x="{x}" y="{y}" width="22" height="22" rx="4" fill="{col}" opacity="0">'
                 f'{fade(0.3 + i * 0.05, 0.25)}</rect>')
    b.append(t(40, 200, "one square = one project", size=11.5, fill=DIM))
    b.append(arrow(300, 136, 340, 136, RED))
    b.append(box(346, 104, 170, 64, STONE2, INK, rx=9))
    b.append(t(431, 132, "otel-check", size=15, w="700", fam=MONO, anchor="middle"))
    b.append(t(431, 152, "ready / partial / unsupported", size=10.5, fill=MUT, anchor="middle"))
    b.append(arrow(520, 136, 556, 136, RED))
    cards = [(GREEN_T, GREEN, "ready", "25 of 27 projects", 1.7),
             (RED_T, RED, "blocked", "otel-unknown-agent: LangSmith exports {} on 97% of spans", 1.9),
             (AMBER_T, AMBER, "not chat", "GNT_KP_AI_WIRELESS", 2.1)]
    for i, (fill, col, k, v, d) in enumerate(cards):
        y = 80 + i * 40
        b.append(show(d, box(562, y, 568, 34, fill, rx=7),
                      t(578, y + 22, k, size=13, w="700", fill=col),
                      t(668, y + 22, v, size=13, fill=INK)))
    # validate
    b.append(show(2.4, f'<line x1="30" y1="226" x2="1130" y2="226" stroke="{LINE}" stroke-width="1"/>',
                  t(40, 256, "otel-validate · the jev.trace/v1 contract", size=14.5, w="700"),
                  t(40, 276, "share of conversations that conform", size=12.5, fill=MUT)))
    b.append(show(2.6, t(40, 312, "raw traces", size=13, w="700")))
    b.append(show(2.6, box(250, 300, 700, 16, "#EDEDED", rx=8)))
    b.append(show(3.0, t(962, 313, "0 conformant", size=13, w="700", fill=RED)))
    b.append(show(3.2, t(40, 352, "after otel-normalize", size=13, w="700")))
    b.append(show(3.2, hbar(250, 340, 700, 16, 0.986, GREEN, 3.4, dur=1.2)))
    b.append(show(4.4, t(962, 353, "1,499 / 1,520 = 98.6%", size=13, w="700", fill=GREEN)))
    b.append(show(4.6, t(40, 398, "fidelity 1,520 / 1,520 exact  ·  0 wrong merges  ·  281 refused "
                                  "(no content)  ·  1,806 conversations in all", size=12.5, fill=MUT)))
    return svg(H, "".join(b))


# ═══════════════════════════════════════════════════════════════════════════
# 3 · collect — three ways in
# ═══════════════════════════════════════════════════════════════════════════
def fig_collect():
    H = 400
    b = [title("Three ways for spans to reach the judge")]
    b.append(box(40, 160, 150, 80, STONE2, INK, rx=10))
    b.append(t(115, 196, "your agent", size=14, w="700", anchor="middle"))
    b.append(t(115, 216, "emits OTel spans", size=11.5, fill=MUT, anchor="middle"))
    b.append(box(970, 160, 160, 80, RED_T, RED, rx=10))
    b.append(t(1050, 196, "the judge", size=14, w="700", fill=RED, anchor="middle"))
    b.append(t(1050, 216, "jevjudge", size=11.5, fill=MUT, anchor="middle", fam=MONO))
    lanes = {
        "a": "M190,200 C250,200 250,104 300,104 L770,104 C830,104 900,200 970,200",
        "b": "M190,200 L970,200",
        "c": "M190,200 C250,200 250,296 300,296 L770,296 C830,296 900,200 970,200",
    }
    for d in lanes.values():
        b.append(f'<path d="{d}" fill="none" stroke="{LINE}" stroke-width="3"/>')
    # packets: red = GenAI span, grey = other span (dropped by the collector)
    for k in range(3):
        b.append(packet(lanes["a"], 3.0, 0.2 + k * 1.0))
        b.append(packet(lanes["b"], 2.4, 0.5 + k * 0.8, fill=INK))
        b.append(packet(lanes["c"], 3.0, 0.8 + k * 1.0, fill=GREEN))
    drop = "M190,200 C250,200 250,104 300,104 L420,104"
    for k in range(2):
        b.append(packet(drop, 1.4, 0.7 + k * 1.5, fill=GREY))
    # lane A: collector
    b.append(box(300, 64, 470, 78, "#fff", BLUE, rx=10))
    b.append(show(1.2, t(316, 86, "OTel Collector", size=13.5, w="700", fill=BLUE),
                  t(436, 86, "deploy/otel-collector/jev-collector.yaml", size=11, fill=MUT, fam=MONO)))
    chips = ["stamp use case", "map conversation id", "scrub identifiers", "keep GenAI spans"]
    for i, c in enumerate(chips):
        b.append(show(1.4 + i * 0.15, box(312 + i * 113, 100, 107, 30, BLUE_T, rx=5),
                      t(365 + i * 113, 119, c, size=10.5, w="700", fill=BLUE, anchor="middle")))
    # lane B
    b.append(box(470, 182, 220, 36, "#fff", INK, rx=8))
    b.append(show(1.6, t(580, 205, "POST /v1/traces", size=13, w="700", fam=MONO, anchor="middle")))
    # lane C
    b.append(box(400, 276, 370, 40, "#fff", GREEN, rx=8))
    b.append(show(1.8, t(585, 301, "ContractRecorder  ·  jevjudge otel-normalize", size=12.5, w="700",
                         fill=GREEN, anchor="middle")))
    b.append(show(2.2, t(300, 160, "grey spans are not GenAI: the collector drops them", size=11.5,
                         fill=DIM)))
    b.append(band(342, 40, "All three paths deliver OTLP spans. The judge reads them the same way.",
                  begin=2.6))
    return svg(H, "".join(b))


# ═══════════════════════════════════════════════════════════════════════════
# 4 · ingest — spans snap into turns
# ═══════════════════════════════════════════════════════════════════════════
def fig_ingest():
    H = 460
    b = [title("Spans from many envelopes become one Session")]
    b.append(t(40, 66, "1 · spans arrive, scattered", size=13, w="700", fill=MUT))
    b.append(show(1.0, t(400, 66, "2 · union-find joins envelopes", size=13, w="700", fill=RED)))
    b.append(show(2.0, t(780, 66, "3 · spans snap into turns", size=13, w="700", fill=GREEN)))
    b.append(box(640, 84, 490, 300, STONE2, LINE, rx=12))
    b.append(show(2.0, t(660, 108, "Session", size=14, w="700", fam=DS)))
    for i in range(3):
        b.append(show(2.2, t(660, 146 + i * 84, f"turn {i + 1}", size=12, w="700", fill=DIM)))
    # (label, envelope colour, start x,y, final x,y, kind)
    E1, E2, E3 = BLUE, AMBER, GREEN
    spans = [
        ("invoke_agent", E1, 60, 110, 720, 128, "turn"),
        ("execute_tool", E1, 230, 150, 880, 152, "tool"),
        ("invoke_agent", E2, 90, 210, 720, 212, "turn"),
        ("invoke_agent", E3, 300, 250, 720, 296, "turn"),
        ("execute_tool", E3, 120, 300, 880, 320, "tool"),
        ("execute_tool", E2, 330, 330, 880, 236, "err"),
    ]
    for (_l, col, sx, sy, _fx, _fy, _k) in spans:
        b.append(box(sx, sy, 140, 28, "none", col, rx=6, sw=1.2, dash="4 3", op=0.35))
    for i, (lbl, col, sx, sy, fx, fy, kind) in enumerate(spans):
        fill = RED_T if kind == "err" else "#fff"
        inner = (box(fx, fy, 140, 28, fill, col, rx=6, sw=2)
                 + t(fx + 70, fy + 19, lbl, size=12, w="700", fill=INK, fam=MONO, anchor="middle"))
        b.append(slide(2.2 + i * 0.12, sx - fx, sy - fy, inner, dur=0.9, appear=False))
    b.append(show(3.3, t(1026, 255, "tool error", size=11, w="700", fill=RED)))
    for fy in (152, 320, 236):
        b.append(show(3.2, f'<path d="M790,{fy - 10} L790,{fy + 14} L876,{fy + 14}" fill="none" '
                           f'stroke="{DIM}" stroke-width="1.4"/>'))
    # a decoy span from another conversation stays out
    b.append(hide(2.0, box(420, 380, 160, 28, "#fff", GREY, rx=6, sw=2),
                  t(500, 399, "conv B · other", size=12, fill=GREY, anchor="middle", fam=MONO)))
    # union-find links: same conversation id, same traceId
    links = [((130, 124), (160, 224)), ((300, 164), (370, 264)), ((370, 264), (190, 314)),
             ((160, 224), (400, 344))]
    for i, ((x1, y1), (x2, y2)) in enumerate(links):
        b.append(f'<line x1="{x1}" y1="{y1}" x2="{x2}" y2="{y2}" stroke="{RED}" stroke-width="2" '
                 f'stroke-dasharray="5 4" opacity="0">'
                 f'<animate attributeName="opacity" values="0;1;1;0.3" keyTimes="0;0.2;0.8;1" dur="1.4s" '
                 f'begin="{1.0 + i * 0.12}s" fill="freeze"/></line>')
    b.append(show(1.1, t(40, 380, "dashed = the two envelopes share a", size=12, fill=RED),
                  t(40, 397, "conversation id or a traceId", size=12, fill=RED)))
    b.append(band(404, 44, "Output: a Session of turns, tool calls and tool errors.",
                  begin=3.4, fill=GREEN_T, col=GREEN))
    return svg(H, "".join(b))


# ═══════════════════════════════════════════════════════════════════════════
# 5 · pack and chunk — one transcript, three budgets
# ═══════════════════════════════════════════════════════════════════════════
def fig_chunks():
    H = 500
    rnd = random.Random(11)
    X0, BW = 250, 640
    segs, x = [], 0.0
    while x < BW:
        kind = rnd.choice(["u", "a", "a", "t"])
        w_ = rnd.uniform(10, 26) if kind != "t" else rnd.uniform(30, 70)
        w_ = min(w_, BW - x)
        segs.append((x, w_, kind))
        x += w_
    cols = {"u": "#7FA7BF", "a": "#B9B0A0", "t": "#E3D9C6"}

    def strip(y):
        return "".join(f'<rect x="{X0 + sx + 0.5:.1f}" y="{y}" width="{max(1, sw - 1):.1f}" height="30" '
                       f'fill="{cols[k]}"/>' for sx, sw, k in segs)

    b = [title("One long session. Each model cuts it to fit its own budget.")]
    b.append(t(40, 98, "the session", size=13.5, w="700"))
    b.append(t(40, 116, "user · agent · tool JSON", size=11.5, fill=MUT))
    b.append(strip(86))
    for i, (k, lbl) in enumerate([("u", "user"), ("a", "agent"), ("t", "tool JSON")]):
        b.append(box(X0 + i * 100, 126, 12, 12, cols[k], rx=2) + t(X0 + 18 + i * 100, 137, lbl,
                                                                   size=11.5, fill=MUT))
    rows = [("kairos-jev", "~30k tokens · HF tokenizer", 1, [0.84], 0.4),
            ("djev", "~19k chars · counts chars", 2, [0.21, 0.86], 1.2),
            ("kev-gemma", "~6.5k tokens · tiktoken", 4, [0.07, 0.12, 0.88, 0.19], 2.0)]
    for r, (name, bud, n, ps, d) in enumerate(rows):
        y = 186 + r * 90
        cut = [BW * j / n for j in range(1, n)]
        inner = [t(40, y + 14, name, size=14, w="700", fam=MONO),
                 t(40, y + 34, bud, size=11.5, fill=MUT), strip(y)]
        b.append(slide(d, 0, 86 - y, *inner, dur=0.7))
        for j, cx in enumerate(cut):
            b.append(show(d + 0.8 + j * 0.15, f'<rect x="{X0 + cx - 3:.1f}" y="{y - 6}" width="6" height="42" '
                                              f'fill="#fff"/>',
                          f'<line x1="{X0 + cx:.1f}" y1="{y - 8}" x2="{X0 + cx:.1f}" y2="{y + 38}" '
                          f'stroke="{RED}" stroke-width="2" stroke-dasharray="4 3"/>'))
        for j, p in enumerate(ps):
            cx = X0 + BW * (j + 0.5) / n
            hi = p == max(ps)
            b.append(show(d + 1.3 + j * 0.1, t(cx, y + 54, f"p = {p:.2f}", size=11.5, w="700" if hi else "400",
                                               fill=RED if hi else MUT, fam=MONO, anchor="middle")))
        b.append(show(d + 1.7, box(920, y - 4, 210, 40, RED_T if n > 1 else STONE2, rx=7),
                      t(934, y + 21, f"{n} chunk{'s' if n > 1 else ''}" + (f"  ·  max = {max(ps):.2f}" if n > 1
                                                                           else f"  ·  p = {ps[0]:.2f}"),
                        size=13, w="700", fill=RED if n > 1 else INK)))
    b.append(band(450, 34, "The answer is joined per criterion: max, noisy_or, mean, last or first.",
                  begin=4.2, size=13))
    b.append(note(496, "budgets are from models.yaml; chunk counts and p values are illustrative"))
    return svg(H, "".join(b))


# ═══════════════════════════════════════════════════════════════════════════
# 6 · ask — rubric YAML, typed questions, decomposition
# ═══════════════════════════════════════════════════════════════════════════
def fig_ask():
    H = 430
    b = [title("A rubric is YAML. Each criterion becomes one typed question.")]
    b.append(box(30, 64, 420, 262, "#1A1A1A", rx=10))
    yaml = [("# output_pii@1.0.0#35238815becb", "#7E7E7E"), ("id: output_pii", "#E8E8E8"),
            ("criteria:", "#E8E8E8"), ("- name: pii_exposed", "#FFC46B"), ("  question:", "#E8E8E8"),
            ("    type: noul", "#FF8AA0"), ("    instructions: An AGENT line…", "#8FD6FF"),
            ("  view: dialogue", "#E8E8E8"), ("  verdict: true", "#E8E8E8"),
            ("  high_stakes: true", "#E8E8E8")]
    for i, (ln, col) in enumerate(yaml):
        b.append(show(0.1 + i * 0.12, t(48, 92 + i * 23, ln, size=12.5, fill=col, fam=MONO)))
    b.append(show(1.4, arrow(456, 112, 496, 112)))
    types = [("noul", "true or false", "PII exposed?"), ("choice", "one of N options", "which outcome?"),
             ("score", "a level on a scale", "how severe?")]
    for i, (ty, what, eg) in enumerate(types):
        x = 502 + i * 212
        b.append(show(1.5 + i * 0.2, box(x, 68, 200, 88, BLUE_T, BLUE, rx=9),
                      t(x + 14, 94, ty, size=15, w="700", fill=BLUE, fam=MONO),
                      t(x + 14, 116, what, size=12.5, fill=INK),
                      t(x + 14, 138, eg, size=12, fill=MUT)))
    # decomposition
    b.append(show(2.3, t(502, 192, "Decomposition: one hard question becomes many easy ones",
                         size=13.5, w="700")))
    b.append(show(2.5, hide(3.3, box(700, 210, 230, 44, RED_T, RED, rx=8),
                            t(815, 238, "did the agent finish the task?", size=12.5, w="700", fill=RED,
                              anchor="middle"))))
    for k in range(12):
        c, r = k % 6, k // 6
        x, y = 502 + c * 106, 214 + r * 42
        last = k == 11
        lbl = "verdict" if last else f"sub {k + 1}"
        inner = (box(x, y, 100, 34, RED_T if last else "#fff", RED if last else BLUE, rx=6)
                 + t(x + 50, y + 22, lbl, size=12, w="700", fill=RED if last else BLUE, anchor="middle"))
        b.append(slide(3.4 + k * 0.05, 815 - (x + 50), 232 - (y + 17), inner, dur=0.7))
    b.append(show(4.2, t(502, 318, "action completion: 12 criteria (about 11 read-offs + a verdict)",
                         size=12.5, fill=MUT),
                  t(502, 338, "toxicity: 9 criteria", size=12.5, fill=MUT)))
    b.append(band(362, 44, "Many questions go in one request. The revision is hash-pinned, and a "
                           "certificate pins one revision.", begin=4.5, size=13))
    return svg(H, "".join(b))


# ═══════════════════════════════════════════════════════════════════════════
# 7 · decide — one model vs the 3-model stack
# ═══════════════════════════════════════════════════════════════════════════
def fig_decide():
    H = 440
    b = [title("One model, or three that vote through a fitted combiner")]
    # left: one model
    b.append(box(30, 64, 420, 320, STONE2, LINE, rx=12))
    b.append(t(50, 94, "one model", size=15, w="700", fam=DS))
    b.append(t(50, 114, "one tier · temperature calibrates p", size=12.5, fill=MUT))
    b.append(t(50, 170, "raw p", size=13, w="700"))
    b.append(hbar(150, 160, 230, 14, 0.97, GREY, 0.3))
    b.append(show(1.1, t(388, 172, "0.97", size=12.5, w="700", fam=MONO, fill=MUT)))
    b.append(show(1.3, t(50, 214, "after T", size=13, w="700")))
    b.append(show(1.3, hbar(150, 204, 230, 14, 0.88, INK, 1.4)))
    b.append(show(2.2, t(388, 216, "0.88", size=12.5, w="700", fam=MONO)))
    b.append(show(2.4, box(50, 252, 380, 46, "#fff", LINE, rx=7),
                  t(240, 281, "p = σ(z / T)", size=16, w="700", fam=MONO, anchor="middle")))
    b.append(show(2.6, t(50, 330, "T ships only if held-out NLL improves.", size=12.5, fill=MUT),
                  t(50, 352, "An over-sure model gets T > 1.", size=12.5, fill=MUT)))
    # right: the stack
    b.append(box(470, 64, 660, 320, "#FFF8F8", RED_T, rx=12))
    b.append(t(490, 94, "jev-stack", size=15, w="700", fam=DS, fill=RED))
    b.append(t(490, 114, "three members answer in parallel, each with its own budget", size=12.5, fill=MUT))
    mem = [("kairos-jev", 0.82), ("kev-gemma", 0.64), ("djev", 0.91)]
    for i, (nm, p) in enumerate(mem):
        y = 146 + i * 40
        b.append(t(490, y + 12, nm, size=13, w="700", fam=MONO))
        b.append(hbar(600, y + 2, 170, 12, p, BLUE, 0.3 + i * 0.15))
        b.append(show(1.1 + i * 0.15, t(778, y + 13, f"{p:.2f}", size=12, w="700", fam=MONO, fill=BLUE)))
        b.append(show(1.6, f'<path d="M812,{y + 8} C850,{y + 8} 850,185 884,185" fill="none" '
                           f'stroke="{RED}" stroke-width="1.8"/>'))
        b.append(packet(f"M812,{y + 8} C850,{y + 8} 850,185 884,185", 0.9, 1.6 + i * 0.1, r=4))
    b.append(show(1.8, box(890, 150, 224, 70, "#fff", RED, rx=9, sw=2),
                  t(1002, 176, "combiner", size=14, w="700", fill=RED, anchor="middle"),
                  t(1002, 202, "σ(Σ wₖ·logit pₖ + b)", size=12.5, fam=MONO, anchor="middle")))
    b.append(show(2.4, t(890, 248, "combined p", size=12.5, w="700")))
    b.append(show(2.4, hbar(890, 256, 160, 14, 0.93, RED, 2.5)))
    b.append(show(3.3, t(1058, 268, "0.93", size=12.5, w="700", fam=MONO, fill=RED)))
    # verdict model heatmap
    b.append(show(3.4, t(490, 298, "decomposed AC: the verdict model", size=13, w="700")))
    rnd = random.Random(5)
    for r in range(3):
        for c in range(11):
            v = rnd.random()
            col = RED if v > 0.66 else (AMBER if v > 0.33 else BLUE)
            b.append(f'<rect x="{490 + c * 19}" y="{310 + r * 15}" width="16" height="12" rx="2" '
                     f'fill="{col}" opacity="0">{fade(3.5 + c * 0.04 + r * 0.05, 0.3, 0, 0.25 + 0.6 * v)}</rect>')
    b.append(show(3.9, arrow(706, 332, 744, 332),
                  box(750, 312, 150, 40, "#fff", RED, rx=7),
                  t(825, 337, "verdict_model", size=12.5, w="700", fam=MONO, fill=RED, anchor="middle"),
                  t(912, 328, "logistic over", size=11.5, fill=MUT),
                  t(912, 344, "member × sub-question logits", size=11.5, fill=MUT)))
    b.append(t(490, 372, "3 members × 11 sub-questions", size=11, fill=DIM))
    b.append(note(410, "probabilities are illustrative; laya is excluded from the v2 stack (pod down)"))
    return svg(H, "".join(b))


def fig_lever():
    H = 250
    b = [title("Decomposition was the lever", "Action-completion agreement with the reference.")]
    rows = [("one verdict question", 0.837, GREY), ("decomposed + verdict model", 0.868, RED),
            ("…on consensus labels", 0.96, GREEN)]
    for i, (lbl, v, col) in enumerate(rows):
        y = 92 + i * 46
        b.append(t(40, y + 15, lbl, size=13.5, w="700"))
        b.append(hbar(300, y + 2, 700, 18, v, col, 0.3 + i * 0.4, dur=1.0))
        b.append(show(1.2 + i * 0.4, t(1012, y + 17, f"{v:.3f}".rstrip("0") if v == 0.96 else f"{v:.3f}",
                                       size=14, w="700", fill=col, fam=MONO)))
    b.append(note(242, "bars start at zero"))
    return svg(H, "".join(b))


# ═══════════════════════════════════════════════════════════════════════════
# 8 · gate and escalate — a needle against θ
# ═══════════════════════════════════════════════════════════════════════════
def fig_gate():
    H = 420
    cx, cy, r = 280, 300, 190
    th = 0.90

    def pt(q, rr=r):
        phi = (q - 0.5) / 0.5 * _m.pi
        return cx - rr * _m.cos(phi), cy - rr * _m.sin(phi)

    def arc(q0, q1, col, sw=26):
        x0, y0 = pt(q0)
        x1, y1 = pt(q1)
        return (f'<path d="M{x0:.1f},{y0:.1f} A{r},{r} 0 0 1 {x1:.1f},{y1:.1f}" fill="none" stroke="{col}" '
                f'stroke-width="{sw}"/>')

    b = [title("The confidence gate: answer, or ask for help")]
    b.append(arc(0.5, th, AMBER_T) + arc(th, 1.0, GREEN_T))
    for q in (0.5, 0.6, 0.7, 0.8, 0.9, 1.0):
        x1, y1 = pt(q, r + 16)
        x2, y2 = pt(q, r + 30)
        b.append(f'<line x1="{x1:.1f}" y1="{y1:.1f}" x2="{x2:.1f}" y2="{y2:.1f}" stroke="{DIM}" stroke-width="1.4"/>')
        lx, ly = pt(q, r + 46)
        b.append(t(round(lx, 1), round(ly + 4, 1), f"{q:.1f}", size=11.5, fill=MUT, fam=MONO, anchor="middle"))
    x1, y1 = pt(th, r - 22)
    x2, y2 = pt(th, r + 22)
    b.append(f'<line x1="{x1:.1f}" y1="{y1:.1f}" x2="{x2:.1f}" y2="{y2:.1f}" stroke="{RED}" stroke-width="4"/>')
    lx, ly = pt(th, r - 44)
    b.append(show(0.2, t(round(lx, 1), round(ly + 6, 1), "θ", size=20, w="700", fill=RED, anchor="middle")))
    b.append(show(0.2, t(cx - 120, cy - 62, "escalate", size=13, w="700", fill=AMBER, anchor="middle"),
                  t(cx + r - 72, cy - 62, "answer", size=13, w="700", fill=GREEN, anchor="middle")))
    a1 = (0.96 - 0.5) / 0.5 * 180
    a2 = (0.72 - 0.5) / 0.5 * 180
    b.append(f'<g><line x1="{cx}" y1="{cy}" x2="{cx - r + 30}" y2="{cy}" stroke="{INK}" stroke-width="4" '
             f'stroke-linecap="round"/><circle cx="{cx}" cy="{cy}" r="10" fill="{INK}"/>'
             f'<animateTransform attributeName="transform" type="rotate" '
             f'values="0 {cx} {cy};{a1:.1f} {cx} {cy};{a1:.1f} {cx} {cy};{a2:.1f} {cx} {cy}" '
             f'keyTimes="0;0.3;0.6;1" dur="3.4s" begin="0.4s" fill="freeze" calcMode="spline" '
             f'keySplines="0.3 0 0.2 1;0 0 1 1;0.3 0 0.2 1"/></g>')
    b.append(t(cx, cy + 34, "q = max(p, 1 − p)", size=13, w="700", fam=MONO, anchor="middle"))
    b.append(show(1.4, t(cx, cy + 56, "item 1: q = 0.96", size=12, fill=GREEN, fam=MONO, anchor="middle")))
    b.append(show(3.6, t(cx, cy + 76, "item 2: q = 0.72", size=12, fill=AMBER, fam=MONO, anchor="middle")))
    # outcome cards
    b.append(show(1.6, box(560, 72, 570, 84, GREEN_T, GREEN, rx=9),
                  t(580, 100, "q ≥ θ  ·  System One answers", size=14.5, w="700", fill=GREEN),
                  t(580, 124, "The verdict and its probability are final.", size=12.5),
                  t(580, 144, "No rationale is written. jev.final.source = system_one", size=12.5, fill=MUT)))
    b.append(packet("M470,160 C520,160 520,114 556,114", 0.8, 1.6, repeat=False, fill=GREEN))
    b.append(show(3.8, box(560, 172, 570, 104, AMBER_T, AMBER, rx=9),
                  t(580, 200, "q < θ  ·  ask System Two", size=14.5, w="700", fill=AMBER),
                  t(580, 224, "gemini-3.8-flash on the Kairos gateway, then gemma-26b.", size=12.5),
                  t(580, 246, "A rationale is written only here.", size=12.5),
                  t(580, 266, "jev.escalation.reason = low_conf", size=12, fill=MUT, fam=MONO)))
    b.append(packet("M470,240 L556,224", 0.6, 3.8, repeat=False, fill=AMBER))
    b.append(show(4.3, box(560, 292, 570, 64, RED_T, rx=9),
                  t(580, 318, "Invalid answer: q = −∞, so it always escalates.", size=12.5, w="700",
                    fill="#A8071A"),
                  t(580, 340, "Frozen unit (drift alarm): every item escalates.", size=12.5, w="700",
                    fill="#A8071A")))
    b.append(note(412, "θ = 0.9 is illustrative; the real θ comes from a certificate"))
    return svg(H, "".join(b))


# ═══════════════════════════════════════════════════════════════════════════
# 9 · emit — the evaluation event
# ═══════════════════════════════════════════════════════════════════════════
def fig_emit():
    H = 432
    b = [title("Every verdict leaves as a standard OTel event")]
    b.append(box(40, 170, 170, 70, STONE2, INK, rx=10))
    b.append(t(125, 202, "GradeReport", size=14, w="700", anchor="middle"))
    b.append(t(125, 222, "one per session", size=11.5, fill=MUT, anchor="middle"))
    b.append(arrow(214, 205, 266, 205))
    b.append(box(272, 62, 500, 300, "#fff", RED, rx=10, sw=2))
    b.append(show(0.2, t(292, 90, "gen_ai.evaluation.result", size=14.5, w="700", fill=RED, fam=MONO)))
    attrs = [("gen_ai.evaluation.name", "output_pii.pii_exposed"),
             ("gen_ai.evaluation.score.label", "false"),
             ("gen_ai.evaluation.score.value", "0.03"),
             ("jev.question.type", "noul"),
             ("jev.decision", "accept"),
             ("jev.escalated", "false"),
             ("jev.final.source", "system_one"),
             ("jev.confidence.q", "0.97"),
             ("jev.threshold", "θ from the certificate"),
             ("jev.calibration.version", "certificate id")]
    for i, (k, v) in enumerate(attrs):
        y = 118 + i * 23
        col = INK if k.startswith("gen_ai") else BLUE
        b.append(show(0.4 + i * 0.14, t(292, y, k, size=11.5, fill=col, fam=MONO),
                      t(540, y, v, size=11.5, w="700", fill=col, fam=MONO)))
    b.append(show(1.9, t(292, 350, "black = OTel GenAI standard · blue = jev.* extras", size=11.5,
                         fill=DIM)))
    sinks = [("OTel pipeline", "events + jev.* attributes", 90), ("JSONL", "one line per verdict", 190),
             ("CMCS sink", "the metrics blob", 290)]
    for i, (nm, sub, y) in enumerate(sinks):
        b.append(show(2.1 + i * 0.15, box(880, y - 30, 250, 60, STONE2, INK, rx=9),
                      t(900, y - 4, nm, size=14, w="700"), t(900, y + 16, sub, size=11.5, fill=MUT)))
        d = f"M776,212 C830,212 830,{y} 876,{y}"
        b.append(show(2.1, f'<path d="{d}" fill="none" stroke="{LINE}" stroke-width="2.5"/>'))
        b.append(packet(d, 1.2, 2.4 + i * 0.3))
    b.append(band(374, 38, "Dashboards that read OTel GenAI evaluations read jevjudge with no change.",
                  begin=2.8))
    b.append(note(428, "values are illustrative"))
    return svg(H, "".join(b))


# ═══════════════════════════════════════════════════════════════════════════
# 10 · calibrate — betting wealth and fixed-sequence search
# ═══════════════════════════════════════════════════════════════════════════
def _wealth_curves():
    """Run the WSR betting update of `calibration/bounds.py` on synthetic paired losses.

    The data are synthetic (illustrative); the update is the real one."""
    eps, delta, n = 0.02, 0.05, 240
    tgt = (1 + eps) / 2

    def run(p_worse, p_better, seed):
        rnd = random.Random(seed)
        xs = []
        for _ in range(n):
            u = rnd.random()
            d = 1 if u < p_worse else (-1 if u < p_worse + p_better else 0)
            xs.append((d + 1) / 2)
        logk, mu, sig2, out, ssum, sq = 0.0, 0.5, 0.25, [0.0], 0.0, 0.0
        for i, x in enumerate(xs, start=1):
            lam = min(_m.sqrt(2 * _m.log(1 / delta) / (n * sig2)), 0.75 / (1 - tgt))
            logk += _m.log1p(lam * (tgt - x))
            out.append(logk)
            ssum += x
            sq += (x - mu) ** 2
            mu = (0.5 + ssum) / (i + 1)
            sig2 = (0.25 + sq) / (i + 1)
        return out
    return run(0.03, 0.09, 9), run(0.07, 0.05, 52), delta


def fig_wealth():
    H = 440
    safe, unsafe, delta = _wealth_curves()
    X0, X1, Y0, Y1 = 110, 1080, 90, 350
    lo, hi = _m.log(0.25), _m.log(400)

    def py(lk):
        lk = max(lo, min(hi, lk))
        return Y1 - (lk - lo) / (hi - lo) * (Y1 - Y0)

    def px(i, n):
        return X0 + (X1 - X0) * i / (n - 1)

    b = [title("Learn-then-Test: bet against “this θ is unsafe”",
               "Start with wealth 1. Each calibration item is one bet. Wealth K is drawn on a log scale.")]
    b.append(box(X0, Y0, X1 - X0, Y1 - Y0, STONE2, rx=6))
    for v in (1, 20, 100):
        y = py(_m.log(v))
        if v != 20:
            b.append(f'<line x1="{X0}" y1="{y:.1f}" x2="{X1}" y2="{y:.1f}" stroke="{LINE}" stroke-width="1"/>')
        b.append(t(X0 - 10, round(y + 4, 1), f"{v}", size=11.5, fill=MUT, fam=MONO, anchor="end"))
    yb = py(_m.log(1 / delta))
    b.append(f'<line x1="{X0}" y1="{yb:.1f}" x2="{X1}" y2="{yb:.1f}" stroke="{RED}" stroke-width="2" '
             f'stroke-dasharray="7 5"/>')
    b.append(t(X1 - 8, round(yb - 8, 1), "1/δ = 20", size=13, w="700", fill=RED, anchor="end", fam=MONO))
    b.append(t(X0 - 10, Y1 + 22, "item 0", size=11.5, fill=MUT, fam=MONO))
    b.append(t(X1, Y1 + 22, f"item {len(safe) - 1}", size=11.5, fill=MUT, fam=MONO, anchor="end"))
    d_safe = "M" + " L".join(f"{px(i, len(safe)):.1f},{py(v):.1f}" for i, v in enumerate(safe))
    d_uns = "M" + " L".join(f"{px(i, len(unsafe)):.1f},{py(v):.1f}" for i, v in enumerate(unsafe))
    b.append(drawn(d_uns, 0.3, 3.0, GREY, 2))
    b.append(drawn(d_safe, 0.3, 3.0, GREEN, 3))
    cross = next(i for i, v in enumerate(safe) if v >= _m.log(1 / delta))
    cxp, cyp = px(cross, len(safe)), py(safe[cross])
    b.append(show(0.3 + 3.0 * cross / (len(safe) - 1),
                  f'<circle cx="{cxp:.1f}" cy="{cyp:.1f}" r="8" fill="none" stroke="{RED}" stroke-width="3"/>',
                  t(round(cxp - 14, 1), round(cyp - 40, 1), "wealth ≥ 1/δ", size=13, w="700", fill=RED,
                    anchor="end"),
                  t(round(cxp - 14, 1), round(cyp - 22, 1), "reject H0: θ is certified", size=13, w="700",
                    fill=RED, anchor="end")))
    b.append(show(3.4, t(X1 - 8, round(py(0) - 10, 1), "grey, a looser θ: wealth never gets there",
                         size=12.5, w="700", fill=GREY, anchor="end")))
    b.append(band(378, 46, "A big win against “unsafe” is strong evidence that it is safe.",
                  begin=3.6, sub="Ville: under H0 the wealth reaches 1/δ with probability at most δ.",
                  fill=GREEN_T, col=GREEN, size=13.5))
    b.append(note(436, "synthetic items (illustrative); the bet is the real WSR update, ε = 0.02, δ = 0.05"))
    return svg(H, "".join(b))


def fig_fst():
    H = 300
    grid = ["∞", "0.99", "0.97", "0.95", "0.93", "0.90", "0.85", "0.80", "0.70", "0.60", "0.50"]
    passes = 6           # ∞ .. 0.90 pass, 0.85 fails, stop (illustrative)
    b = [title("Fixed-sequence search: test thresholds from strict to loose, stop at the first fail")]
    b.append(t(40, 76, "stricter θ: fewer items answered, safer", size=12.5, fill=MUT))
    b.append(t(1120, 76, "looser θ: more items answered", size=12.5, fill=MUT, anchor="end"))
    for i, g in enumerate(grid):
        x = 40 + i * 98
        b.append(box(x, 96, 88, 50, STONE2, LINE, rx=8))
        b.append(t(x + 44, 127, g, size=15, w="700", fam=MONO, anchor="middle"))
        if i <= passes:
            ok = i < passes
            d = 0.4 + i * 0.32
            b.append(show(d, box(x, 96, 88, 50, GREEN_T if ok else RED_T, GREEN if ok else RED, rx=8, sw=2),
                          t(x + 44, 127, g, size=15, w="700", fam=MONO, anchor="middle",
                            fill=GREEN if ok else RED),
                          t(x + 44, 168, "p ≤ δ" if ok else "p > δ", size=12.5, w="700",
                            fill=GREEN if ok else RED, fam=MONO, anchor="middle")))
        else:
            b.append(show(0.4 + (passes + 1) * 0.32, t(x + 44, 168, "not tested", size=11.5, fill=DIM,
                                                       anchor="middle")))
    b.append(f'<path d="M84,90 l-7,-10 h14 z" fill="{RED}">'
             f'<animateMotion path="M0,0 L{passes * 98},0" dur="{passes * 0.32:.2f}s" begin="0.4s" '
             f'fill="freeze"/></path>')
    stop = 0.4 + (passes + 1) * 0.32
    xc = 40 + (passes - 1) * 98
    b.append(show(stop, f'<rect x="{xc - 4}" y="92" width="96" height="58" rx="10" fill="none" '
                        f'stroke="{RED}" stroke-width="3"/>',
                  t(xc + 44, 202, "certified θ", size=13, w="700", fill=RED, anchor="middle")))
    b.append(band(226, 54, "Testing in a fixed order spends the full δ on each test and still controls "
                           "the family-wise error.", begin=stop + 0.4,
                  sub="∞ means “escalate everything”. It is always safe, so the search can always fall "
                      "back to it.", size=13))
    b.append(note(296, "pass/fail pattern is illustrative; the grid is DEFAULT_GRID in solver.py"))
    return svg(H, "".join(b))


# ═══════════════════════════════════════════════════════════════════════════
# 11 · monitor and drift — CUSUM e-detector, ACI, PSI
# ═══════════════════════════════════════════════════════════════════════════
def _cusum():
    """Run the AccuracyMonitor CUSUM e-detector (eps 0.05, alpha 0.01, the code's λ grid) on a
    synthetic audit stream whose disagreement rate jumps. The stream is illustrative."""
    eps, alpha = 0.05, 0.01
    lams = [l for l in (0.5, 1.0, 2.0, 4.0, 8.0) if l < 1 / eps]
    rnd = random.Random(21)
    n, shift = 200, 120
    xs = [1 if rnd.random() < (0.03 if i < shift else 0.30) else 0 for i in range(n)]
    logk = [0.0] * len(lams)
    es, fired = [], None
    for i, x in enumerate(xs):
        logk = [max(v, 0.0) for v in logk]
        logk = [v + _m.log1p(l * (x - eps)) for v, l in zip(logk, lams)]
        e = sum(_m.exp(v) for v in logk) / len(lams)
        es.append(e)
        if fired is None and e >= 1 / alpha:
            fired = i
            break
    return xs[:len(es)], es, shift, fired, n, alpha


def fig_cusum():
    H = 450
    xs, es, shift, fired, n, alpha = _cusum()
    X0, X1, Y0, Y1 = 110, 1080, 88, 320
    lo, hi = _m.log10(0.3), _m.log10(400)

    def py(e):
        v = max(lo, min(hi, _m.log10(max(e, 1e-9))))
        return Y1 - (v - lo) / (hi - lo) * (Y1 - Y0)

    def px(i):
        return X0 + (X1 - X0) * i / (n - 1)

    b = [title("Watching accepted verdicts: a CUSUM e-detector on audit disagreements",
               "Each tick is one audited item. Red = System One disagreed with the fallback judge.")]
    b.append(box(X0, Y0, X1 - X0, Y1 - Y0, STONE2, rx=6))
    for v in (1, 10):
        y = py(v)
        b.append(f'<line x1="{X0}" y1="{y:.1f}" x2="{X1}" y2="{y:.1f}" stroke="{LINE}" stroke-width="1"/>')
        b.append(t(X0 - 10, round(y + 4, 1), f"{v}", size=11.5, fill=MUT, fam=MONO, anchor="end"))
    ya = py(1 / alpha)
    b.append(f'<line x1="{X0}" y1="{ya:.1f}" x2="{X1}" y2="{ya:.1f}" stroke="{RED}" stroke-width="2" '
             f'stroke-dasharray="7 5"/>')
    b.append(t(X0 - 10, round(ya + 4, 1), "100", size=11.5, fill=RED, fam=MONO, anchor="end"))
    b.append(t(X1 - 8, round(ya - 8, 1), "alarm line 1/α = 100", size=13, w="700", fill=RED, anchor="end",
               fam=MONO))
    xsft = px(shift)
    T = 3.2                                   # draw time for the full width
    tshift = 0.3 + T * shift / (n - 1)
    b.append(show(tshift, f'<line x1="{xsft:.1f}" y1="{Y0}" x2="{xsft:.1f}" y2="{Y1 + 40}" stroke="{AMBER}" '
                          f'stroke-width="1.6" stroke-dasharray="4 4"/>',
                  t(round(xsft - 8, 1), Y0 + 20, "the data shift here", size=12.5, w="700", fill=AMBER,
                    anchor="end")))
    d = "M" + " L".join(f"{px(i):.1f},{py(e):.1f}" for i, e in enumerate(es))
    b.append(drawn(d, 0.3, T * (len(es) - 1) / (n - 1), INK, 2.4))
    for i, x in enumerate(xs):
        col = RED if x else LGREY
        h_ = 16 if x else 9
        b.append(f'<rect x="{px(i) - 1.5:.1f}" y="{Y1 + 30 - h_}" width="3" height="{h_}" fill="{col}" '
                 f'opacity="0">{fade(0.3 + T * i / (n - 1), 0.1)}</rect>')
    b.append(t(X0 - 10, Y1 + 28, "audits", size=11.5, fill=MUT, anchor="end"))
    tf = 0.3 + T * fired / (n - 1)
    fx, fy = px(fired), py(es[fired])
    b.append(show(tf, f'<circle cx="{fx:.1f}" cy="{fy:.1f}" r="8" fill="none" stroke="{RED}" stroke-width="3"/>',
                  f'<rect x="{fx + 14:.1f}" y="{Y0}" width="{X1 - fx - 14:.1f}" height="{Y1 - Y0}" fill="{RED}" '
                  f'opacity="0.08"/>',
                  t(round(fx + 24, 1), Y0 + 70, "ALARM", size=15, w="700", fill=RED),
                  t(round(fx + 24, 1), Y0 + 90, "unit frozen:", size=12.5, w="700", fill=RED),
                  t(round(fx + 24, 1), Y0 + 108, "every item", size=12.5, fill=RED),
                  t(round(fx + 24, 1), Y0 + 126, "escalates", size=12.5, fill=RED)))
    b.append(show(1.0, t(X0 + 16, Y1 - 14, "healthy: the wealth restarts at 1 after each loss",
                         size=12.5, fill=MUT)))
    b.append(band(380, 46, "W ← max(W, 1) · (1 + λ(x − ε)). The detection delay does not grow with "
                           "healthy history.", begin=tf + 0.4,
                  sub="Alarm when the mean over λ reaches 1/α. A fresh certificate resets the unit.",
                  size=13))
    b.append(note(446, "synthetic audit stream (illustrative); detector is AccuracyMonitor, eps 0.05, alpha 0.01"))
    return svg(H, "".join(b))


def fig_drift():
    H = 330
    b = [title("Between certificates: θ can only tighten, and the inputs are watched")]
    # ACI panel
    b.append(box(30, 60, 540, 230, STONE2, LINE, rx=10))
    b.append(t(50, 88, "ACI: θ ← θ + γ(x − target)", size=13.5, w="700", fam=MONO))
    b.append(t(50, 108, "aci_gamma 0.02 · floor = the certified θ", size=12, fill=MUT))
    X0, X1, Y0, Y1 = 60, 540, 130, 260
    th, floor_, g, tgt = 0.90, 0.90, 0.02, 0.05
    rnd = random.Random(2)
    pts = [th]
    for i in range(60):
        x = 1 if rnd.random() < (0.05 if i < 30 else 0.4) else 0
        th = min(0.999, max(floor_, th + g * (x - tgt)))
        pts.append(th)

    def py(v):
        return Y1 - (v - 0.88) / (1.0 - 0.88) * (Y1 - Y0)

    yf = py(floor_)
    b.append(f'<line x1="{X0}" y1="{yf:.1f}" x2="{X1}" y2="{yf:.1f}" stroke="{RED}" stroke-width="1.6" '
             f'stroke-dasharray="6 4"/>')
    b.append(t(X1, round(yf + 18, 1), "certified θ: never below", size=11.5, w="700", fill=RED, anchor="end"))
    d = "M" + " L".join(f"{X0 + (X1 - X0) * i / 60:.1f},{py(v):.1f}" for i, v in enumerate(pts))
    b.append(drawn(d, 0.3, 2.4, GREEN, 2.6))
    b.append(show(2.0, t(X0 + 270, round(py(pts[-1]) - 12, 1), "disagreements push θ up", size=11.5,
                         w="700", fill=GREEN)))
    # PSI panel
    b.append(box(590, 60, 540, 230, STONE2, LINE, rx=10))
    b.append(t(610, 88, "PSI of the confidence q", size=13.5, w="700"))
    b.append(t(610, 108, "baseline (grey) vs current window (red), q in [0.5, 1]", size=12, fill=MUT))
    base = [2, 3, 4, 5, 6, 8, 10, 14, 20, 28]
    cur = [5, 7, 8, 9, 9, 10, 10, 11, 12, 19]
    sb, sc = sum(base), sum(cur)
    for i, (a, c) in enumerate(zip(base, cur)):
        x = 620 + i * 48
        b.append(vbar(x, 260, 18, a / sb * 260, GREY, 0.3 + i * 0.05))
        b.append(vbar(x + 20, 260, 18, c / sc * 260, RED, 1.0 + i * 0.05))
    b.append(f'<line x1="610" y1="260" x2="1110" y2="260" stroke="{DIM}" stroke-width="1"/>')
    b.append(show(1.8, t(1110, 138, "PSI = Σ (c − b) ln(c / b)", size=12.5, w="700", fam=MONO, anchor="end"),
                  t(1110, 158, "alarm above 0.2", size=12, w="700", fill=RED, anchor="end")))
    b.append(t(620, 278, "0.5", size=11, fill=MUT, fam=MONO))
    b.append(t(1100, 278, "1.0", size=11, fill=MUT, fam=MONO, anchor="end"))
    b.append(band(298, 26, "DriftStats also tracks the escalation rate (|Δ| > 30%) and the valid-answer "
                           "rate (< 99.9%).", begin=2.4, size=12.5))
    return svg(H, "".join(b))


# ═══════════════════════════════════════════════════════════════════════════
# 12 · govern — certificate lifecycle, migration phases, review queue
# ═══════════════════════════════════════════════════════════════════════════
def fig_cert():
    H = 420
    b = [title("A certificate's life: every change is a new state, and the history stays")]
    nodes = {"PROPOSED": (60, 160, BLUE_T, BLUE), "ACTIVE": (380, 160, GREEN_T, GREEN),
             "SUPERSEDED": (720, 70, STONE2, MUT), "ROLLED_BACK": (720, 170, AMBER_T, AMBER),
             "REVOKED": (380, 290, RED_T, RED)}
    NW, NH = 190, 56
    for k, (x, y, fill, col) in nodes.items():
        b.append(box(x, y, NW, NH, fill, col, rx=28, sw=2))
        b.append(t(x + NW / 2, y + 34, k, size=14, w="700", fill=col, fam=MONO, anchor="middle"))
    edges = [("M250,188 L376,188", "approve", 313, 178),
             ("M570,178 C640,140 650,98 716,98", "new cert approved", 620, 116),
             ("M570,194 L716,198", "rollback", 643, 188),
             ("M475,218 L475,284", "revoke", 508, 258)]
    for d, lbl, lx, ly in edges:
        b.append(f'<path d="{d}" fill="none" stroke="{DIM}" stroke-width="1.8" marker-end="url(#ag)"/>')
        b.append(t(lx, ly, lbl, size=11.5, fill=MUT, anchor="middle"))
    b.append(f'<path d="M780,226 C720,280 610,280 556,222" fill="none" stroke="{AMBER}" stroke-width="1.6" '
             f'stroke-dasharray="5 4" marker-end="url(#aam)"/>')
    b.append(t(612, 296, "rollback reactivates the previous certificate", size=11.5, fill=AMBER))
    b.append(t(155, 248, "propose()", size=12, fam=MONO, fill=BLUE, anchor="middle"))
    b.append(t(155, 266, "shadow only, not served", size=11.5, fill=MUT, anchor="middle"))
    # the travelling token
    path = "M155,160 L155,160 C200,130 420,130 475,160 C560,130 640,170 815,170"
    b.append(f'<circle r="9" fill="{RED}" opacity="0"><animate attributeName="opacity" from="0" to="1" '
             f'dur="0.2s" begin="0.3s" fill="freeze"/>'
             f'<animateMotion path="{path}" dur="2.6s" begin="0.4s" fill="freeze" keyPoints="0;0.45;0.45;1" '
             f'keyTimes="0;0.4;0.6;1" calcMode="linear"/></circle>')
    # history log
    b.append(box(950, 70, 180, 276, "#fff", LINE, rx=8))
    b.append(t(964, 94, "history", size=13, w="700"))
    log = [("proposed", BLUE, 0.4), ("approved · J. Doe", GREEN, 1.5), ("superseded old", MUT, 1.6),
           ("rolled_back", AMBER, 3.0), ("reactivated prev", GREEN, 3.2)]
    for i, (s, col, d) in enumerate(log):
        b.append(show(d, t(964, 122 + i * 26, s, size=12, fill=col, fam=MONO)))
    b.append(band(362, 44, "A certificate pins the rubric revision, tier models and reference (a "
                           "fingerprint). Change any of them: new unit.", begin=3.4, size=13))
    return svg(H, "".join(b))


def fig_phases():
    H = 260
    b = [title("Migration: from static thresholds to certified ones, in four phases")]
    ph = [("legacy_shadow", "serve the static θ", "certified θ is shadow only"),
          ("tighter_of", "max(static, certified)", "missing certificate → static"),
          ("certified_preferred", "serve the certified θ", "missing → static"),
          ("enforce", "serve the certified θ", "missing → all escalate")]
    b.append(f'<line x1="140" y1="100" x2="1020" y2="100" stroke="{LINE}" stroke-width="6" '
             f'stroke-linecap="round"/>')
    b.append(f'<line x1="140" y1="100" x2="140" y2="100" stroke="{RED}" stroke-width="6" '
             f'stroke-linecap="round">{grow(0.3, 140, 1020, 3.0, "x2")}</line>')
    for i, (nm, a, c) in enumerate(ph):
        x = 140 + i * 293.3
        b.append(f'<circle cx="{x:.1f}" cy="100" r="12" fill="#fff" stroke="{RED}" stroke-width="3"/>')
        b.append(f'<circle cx="{x:.1f}" cy="100" r="6" fill="{RED}" opacity="0">{fade(0.3 + i * 1.0, 0.3)}'
                 f'</circle>')
        b.append(show(0.3 + i * 1.0, t(round(x, 1), 76, nm, size=13.5, w="700", fam=MONO, anchor="middle",
                                       fill=RED if i == 3 else INK),
                      t(round(x, 1), 140, a, size=12.5, w="700", anchor="middle"),
                      t(round(x, 1), 160, c, size=12, fill=MUT, anchor="middle")))
    b.append(band(194, 50, "enforce is the target state and the default.", begin=3.4,
                  sub="Mondrian strata give each project or channel its own certificate.", size=13))
    return svg(H, "".join(b))


def fig_review():
    H = 290
    b = [title("The human review queue turns doubt into gold labels")]
    srcs = [("both_unsure", "System Two unsure, or S1 and S2 disagree near θ", 90),
            ("high_stakes", "a high_stakes criterion fired (for example PII)", 150),
            ("audit", "a random slice, whatever the confidence", 210)]
    for i, (nm, sub, y) in enumerate(srcs):
        b.append(box(30, y - 24, 390, 48, STONE2, LINE, rx=8))
        b.append(t(46, y - 4, nm, size=13.5, w="700", fam=MONO))
        b.append(t(46, y + 15, sub, size=11.5, fill=MUT))
        d = f"M424,{y} C470,{y} 470,150 512,150"
        b.append(f'<path d="{d}" fill="none" stroke="{LINE}" stroke-width="2.5"/>')
        b.append(packet(d, 1.1, 0.3 + i * 0.35))
    b.append(box(518, 110, 200, 80, "#fff", INK, rx=10, sw=2))
    b.append(t(618, 145, "review queue", size=14.5, w="700", anchor="middle"))
    b.append(t(618, 167, "append-only JSONL", size=11.5, fill=MUT, anchor="middle"))
    b.append(show(1.4, arrow(722, 150, 772, 150), box(778, 116, 160, 68, GREEN_T, GREEN, rx=10),
                  t(858, 146, "gold labels", size=14, w="700", fill=GREEN, anchor="middle"),
                  t(858, 166, "session, metric, label", size=11.5, fill=MUT, anchor="middle")))
    b.append(show(2.0, arrow(942, 150, 980, 150), box(986, 116, 144, 68, RED_T, RED, rx=10),
                  t(1058, 146, "parity_gold", size=13.5, w="700", fill=RED, anchor="middle", fam=MONO),
                  t(1058, 166, "certificate refit", size=11.5, fill=MUT, anchor="middle")))
    b.append(band(246, 34, "The audit slice catches failure modes the rubric never names.", begin=2.4,
                  size=13))
    return svg(H, "".join(b))


# ═══════════════════════════════════════════════════════════════════════════
# 13 · prove it on prod
# ═══════════════════════════════════════════════════════════════════════════
def fig_prod_agree():
    H = 330
    b = [title("Production validation run 1: agreement with the production judge",
               "2026-09-29 · 16,511 sessions · 82,555 verdicts · 0 errors")]
    rows = [("action completion", 0.731, "9.9% escalated"), ("PII", 0.980, "0.6% escalated"),
            ("hallucination", 0.958, ""), ("toxicity / sexism", 1.000, "")]
    for i, (lbl, v, esc) in enumerate(rows):
        y = 92 + i * 48
        b.append(t(40, y + 16, lbl, size=13.5, w="700"))
        b.append(hbar(240, y + 3, 640, 18, v, INK if i else AMBER, 0.3 + i * 0.25, dur=1.0))
        b.append(show(1.2 + i * 0.25, t(892, y + 18, f"{v:.3f}", size=14, w="700", fam=MONO,
                                        fill=AMBER if i == 0 else INK),
                      t(970, y + 18, esc, size=12.5, fill=MUT)))
    b.append(show(2.4, t(40, 300, "AC population-weighted: 0.762. Agreement is not accuracy: when the two "
                                  "disagree, who is right?", size=13, w="700", fill=AMBER)))
    b.append(note(324, "bars start at zero"))
    return svg(H, "".join(b))


def fig_prod_adj():
    H = 470
    b = [title("Blind adjudication: gemini-3.8-flash reads each disagreement and picks a side")]
    adj = [("AC", 104, 150), ("PII", 116, 149), ("hallucination", 60, 149)]
    for i, (lbl, k, n) in enumerate(adj):
        y = 70 + i * 40
        f = k / n
        b.append(t(40, y + 17, lbl, size=13, w="700"))
        b.append(box(200, y + 2, 600, 22, LGREY, rx=4))
        b.append(f'<rect x="200" y="{y + 2}" width="0" height="22" rx="4" fill="{RED}">'
                 f'{grow(0.3 + i * 0.25, 0, round(600 * f, 1), 1.0)}</rect>')
        b.append(show(1.2 + i * 0.25, t(812, y + 18, f"sides with JEV {round(100 * f)}% ({k} / {n})", size=12.5,
                                        w="700", fill=RED)))
    b.append(show(1.0, t(200, 64, "red = sides with JEV  ·  grey = sides with production", size=11.5,
                         fill=DIM)))
    # estimated accuracy, grouped columns
    b.append(show(2.0, t(40, 216, "Estimated accuracy with the adjudicator as truth", size=14.5, w="700"),
                  t(40, 236, "JEV (red) vs production (grey)", size=12.5, fill=MUT)))
    base, Hh = 420, 160
    est = [("AC", 0.92, 0.81), ("PII", 0.996, 0.984), ("hallucination", 0.975, 0.983)]
    for i, (lbl, j, p) in enumerate(est):
        x = 420 + i * 240
        b.append(vbar(x, base, 64, j * Hh, RED, 2.2 + i * 0.3))
        b.append(vbar(x + 72, base, 64, p * Hh, GREY, 2.3 + i * 0.3))
        b.append(show(3.0 + i * 0.3, t(x + 32, round(base - j * Hh - 8, 1), f"{j:g}", size=13, w="700",
                                       fill=RED, anchor="middle", fam=MONO),
                      t(x + 104, round(base - p * Hh - 8, 1), f"{p:g}", size=13, w="700", fill=MUT,
                        anchor="middle", fam=MONO)))
        b.append(t(x + 68, base + 22, lbl, size=13, w="700", anchor="middle"))
    b.append(f'<line x1="400" y1="{base}" x2="1110" y2="{base}" stroke="{DIM}" stroke-width="1"/>')
    b.append(show(3.9, t(40, 300, "AC: the biggest gain.", size=13, w="700", fill=RED),
                  t(40, 320, "PII: JEV is ahead.", size=13, fill=INK),
                  t(40, 340, "hallucination: production", size=13, fill=INK),
                  t(40, 358, "is slightly ahead.", size=13, fill=INK)))
    b.append(note(464, "columns start at zero"))
    return svg(H, "".join(b))


def fig_v3():
    H = 200
    b = [title("Calibration v3 (System One only): in progress, results pending")]
    days = [("09-27", "holdout day", AMBER_T, AMBER), ("09-28", "calibration day", BLUE_T, BLUE),
            ("09-29", "calibration day", BLUE_T, BLUE)]
    for i, (d, what, fill, col) in enumerate(days):
        x = 40 + i * 230
        b.append(show(0.3 + i * 0.3, box(x, 66, 210, 64, fill, col, rx=9),
                      t(x + 16, 92, d, size=15, w="700", fam=MONO, fill=col),
                      t(x + 16, 114, what, size=12.5)))
    b.append(show(1.3, box(740, 66, 390, 64, "#fff", LINE, rx=9, dash="6 4"),
                  t(790, 92, "reference: Gemini labels on", size=12.5),
                  t(790, 112, "every holdout session", size=12.5)))
    b.append(f'<circle cx="764" cy="98" r="7" fill="{RED}"><animate attributeName="opacity" '
             f'values="1;0.2;1" dur="1.4s" repeatCount="indefinite"/></circle>')
    b.append(band(146, 38, "No v3 numbers are shown here, because there are none yet.", begin=1.6,
                  size=13))
    return svg(H, "".join(b))


# ═══════════════════════════════════════════════════════════════════════════
# 14 · use it
# ═══════════════════════════════════════════════════════════════════════════
def fig_use():
    H = 370
    b = [title("Three ways to use it: a library call, a graph node, a UI")]
    b.append(box(30, 62, 470, 160, "#1A1A1A", rx=10))
    code_ = [("from jevjudge import CriterionGrader", "#E8E8E8"),
             ("g, rubrics = CriterionGrader.from_config(", "#E8E8E8"),
             ('    "configs/judge_v2.yaml")', "#8FD6FF"),
             ("report = await g.grade(trace, rubrics)", "#9EE493")]
    for i, (ln, col) in enumerate(code_):
        b.append(show(0.2 + i * 0.3, t(48, 96 + i * 28, ln, size=12.5, fill=col, fam=MONO)))
    b.append(show(1.4, t(48, 206, "# one GradeReport per conversation", size=12, fill="#7E7E7E", fam=MONO)))
    # langgraph
    b.append(box(530, 62, 600, 160, STONE2, LINE, rx=10))
    b.append(t(548, 86, "LangGraph: jev_judge_node + jev_route", size=13, w="700"))
    b.append(packet("M583,130 L797,130 C860,130 880,172 980,172", 2.0, 0.6, fill=GREEN))
    b.append(packet("M583,130 L797,130 C860,130 880,112 980,112", 2.0, 1.6))
    nodes = [("START", 548, 130, 70), ("agent", 640, 130, 80), ("jev_judge", 742, 130, 110)]
    for nm, x, y, w_ in nodes:
        b.append(box(x, y - 18, w_, 36, "#fff", INK if nm != "jev_judge" else RED, rx=18, sw=1.8))
        b.append(t(x + w_ / 2, y + 5, nm, size=12, w="700", fam=MONO, anchor="middle",
                   fill=RED if nm == "jev_judge" else INK))
    b.append(arrow(618, 130, 636, 130, DIM, mk="ag") + arrow(720, 130, 738, 130, DIM, mk="ag"))
    b.append(box(920, 96, 120, 32, RED_T, RED, rx=16) + t(980, 117, "redact", size=12, w="700", fam=MONO,
                                                          fill=RED, anchor="middle"))
    b.append(box(920, 156, 120, 32, GREEN_T, GREEN, rx=16) + t(980, 177, "send", size=12, w="700", fam=MONO,
                                                               fill=GREEN, anchor="middle"))
    b.append(f'<path d="M852,130 C885,130 885,112 916,112" fill="none" stroke="{RED}" stroke-width="1.8"/>')
    b.append(f'<path d="M852,130 C885,130 885,172 916,172" fill="none" stroke="{GREEN}" stroke-width="1.8"/>')
    b.append(t(1048, 117, "fired", size=11.5, fill=RED))
    b.append(t(1048, 177, "clean", size=11.5, fill=GREEN))
    b.append(t(548, 208, "the judge itself is a LangGraph graph you can embed", size=11.5, fill=MUT))
    # studio + other
    outs = [("jevjudge serve", "Calibration Studio UI + HTTP API", 1.8),
            ("DeepEval adapter", "a metric in your CI tests", 2.0),
            ("POST /v1/traces", "send OTLP spans, get verdicts", 2.2)]
    for i, (nm, sub, d) in enumerate(outs):
        x = 30 + i * 372
        b.append(show(d, box(x, 240, 356, 66, "#fff", INK, rx=10),
                      t(x + 18, 268, nm, size=14, w="700", fam=MONO),
                      t(x + 18, 290, sub, size=12.5, fill=MUT)))
    b.append(band(320, 38, "Same rubrics, same certificates, same events, whichever door you use.",
                  begin=2.6))
    return svg(H, "".join(b))


# ═══════════════════════════════════════════════════════════════════════════
DEFS = (f'<svg width="0" height="0" style="position:absolute" aria-hidden="true"><defs>'
        + "".join(f'<marker id="{i}" markerWidth="9" markerHeight="9" refX="7" refY="3.2" orient="auto">'
                  f'<path d="M0,0 L7,3.2 L0,6.4 z" fill="{c}"/></marker>'
                  for i, c in (("ar", RED), ("ag", DIM), ("agr", GREEN), ("aam", AMBER)))
        + "</defs></svg>")

REPLAY_CSS = """
figure .bar{display:flex;align-items:center;gap:12px}
figure .bar .t{flex:1}
figure .bar button.replay{font-family:var(--tx);font-weight:700;font-size:11.5px;
 background:#fff;color:var(--ink);border:1.5px solid var(--ink);border-radius:20px;
 padding:4px 14px;cursor:pointer}
figure .bar button.replay:hover{background:var(--red);border-color:var(--red);color:#fff}
svg.anim{display:block;width:100%}
.lens .eq{background:#fff}
"""

REPLAY_JS = """
<script>
document.querySelectorAll('figure').forEach(f=>{
  const s=f.querySelector('svg.anim'); if(!s) return;
  const b=document.createElement('button');
  b.className='replay'; b.textContent='replay';
  b.onclick=()=>{ s.setCurrentTime(0); };
  f.querySelector('.bar').appendChild(b);
  // only start once it is actually on screen, so the reader sees it move
  new IntersectionObserver((e,o)=>{e.forEach(x=>{if(x.isIntersecting){
    s.setCurrentTime(0); o.unobserve(x.target);}})},{threshold:.35}).observe(s);
});
</script>"""


def py_code(src: str) -> str:
    """Escape a short Python snippet and colour keywords, strings and comments."""
    out = []
    for ln in src.strip("\n").split("\n"):
        e = html.escape(ln, quote=False)
        if "#" in e:
            i = e.index("#")
            e, c = e[:i], f'<span class="c">{e[i:]}</span>'
        else:
            c = ""
        parts = e.split('"')
        for k in range(1, len(parts), 2):
            parts[k] = f'<span class="s">"{parts[k]}"</span>'
        e = "".join(parts)
        for kw in ("from ", "import ", "await ", "def ", "return "):
            e = e.replace(kw, f'<span class="k">{kw.strip()}</span> ')
        out.append(e + c)
    return "<pre>" + "\n".join(out) + "</pre>"


# ═══════════════════════════════════════════════════════════════════════════
NAV = [("s1", "1 · two systems"), ("s2", "2 · onboard"), ("s3", "3 · collect"), ("s4", "4 · ingest"),
       ("s5", "5 · pack"), ("s6", "6 · ask"), ("s7", "7 · decide"), ("s8", "8 · gate"),
       ("s9", "9 · emit"), ("s10", "10 · calibrate"), ("s11", "11 · monitor"), ("s12", "12 · govern"),
       ("s13", "13 · on prod"), ("s14", "14 · use it")]

S = []

S.append(section(1, "s1", "An LLM judge writes. A decision model fills in boxes.",
    "Two kinds of judge read the same conversation. jevjudge uses the fast one first.",
    figure(fig_two_systems(), "System Two writes; System One fills in boxes",
           "Left: the LLM writes a verdict word by word, then code parses it. Right: one forward pass "
           "gives a probability per answer. This is <b>System One</b>.")
    + eli5("An LLM judge writes an essay, then someone reads the last line. "
           "A decision model ticks one box per question. It also says how sure it is.",
           "jevjudge asks the box-ticker first. It asks the essay-writer only when the box-ticker is not sure.")
    + maths("Each question has a fixed set of options. The model gives one score per option, in one pass.",
            eq("p(option<sub>k</sub> | transcript, question) = softmax(s<sub>1</sub> … s<sub>K</sub>)<sub>k</sub>",
               '<span class="c"># no decode loop: 1 forward pass, K scores, nothing to parse</span>'),
            "Because p is a real probability, a threshold on p can be certified. Section 10 shows how.")
    + tech("Three Kairos decision models serve System One. The wire format is one POST per member: "
           "<code>{base}/v1/systemone</code> with <code>{\"model\", \"state\", \"questions\": {id: {type, "
           "instructions, criteria}}}</code>. Many questions go in one request.",
           table(["model", "backbone", "budget", "measured on the prod gateway"], [
               ["kairos-jev", "Granite 311M (ModernBERT family)", "~30k tokens", "p50 0.5 s / p95 2.8 s"],
               ["kev-gemma", "Gemma 4 (gran-c)", "~6.5k tokens", "p50 4.9 s / p95 5.8 s"],
               ["djev", "Diffusion Gemma 26B", "~19k chars", "p50 0.7 s / p95 1.5 s"],
               ["laya", "ModernBERT-large", "7.5k tokens", "pod down, not in v2"]]),
           "Kairos server time is 20–70 ms. The rest is the gateway hop and queueing. System Two is "
           "gemini-3.8-flash on the Kairos gateway, then gemma-26b.")))

S.append(section(2, "s2", "Onboard: check the traces before you trust them",
    "Two commands tell a team if jevjudge can read its traces, and what to fix.",
    figure(fig_onboard(), "otel-check, then otel-validate",
           "25 of 27 projects were ready. No raw trace met the contract. After "
           "<code>otel-normalize</code>, 98.6% did.")
    + eli5("Before a judge reads a conversation, it must find the conversation. "
           "The first command says: we can read this, partly, or not at all. "
           "The second command says: your traces follow the house format, or here is what is missing.")
    + maths("Conformance is a plain ratio over conversations with content.",
            eq("conformance = 1,499 / 1,520 = 98.6%",
               "fidelity &nbsp;&nbsp;&nbsp;= 1,520 / 1,520 exact &nbsp;&nbsp;<span class='c'># no turn lost "
               "or changed</span>",
               "wrong merges = 0 &nbsp;&nbsp;&nbsp;&nbsp;refused = 281 <span class='c'># no content to "
               "judge</span>"))
    + tech("<code>jevjudge otel-check</code> gives a verdict (ready / partial / unsupported) and a derived "
           "profile. <code>jevjudge otel-validate</code> checks the <b>jev.trace/v1</b> contract. Fixes come "
           "from its BLOCKER hints.",
           "The contract: resource attributes <code>service.name</code> and "
           "<code>vz.project_slug.use_case</code>. Every span carries <code>gen_ai.conversation.id</code>. "
           "One turn is one <code>invoke_agent</code> span (<code>jev.turn.index</code>; input = the new user "
           "message, output = the reply). One tool call is one <code>execute_tool</code> span under its turn.")
    + warn("A trace can look complete and still be empty. LangSmith exported <code>{}</code> for 97% of "
           "the spans of one project. Run <code>otel-check</code> before you calibrate anything.")))

S.append(section(3, "s3", "Collect: three ways in, one format out",
    "Spans reach the judge through a collector, an HTTP endpoint, or a recorder in your code.",
    figure(fig_collect(), "packets flowing into the judge",
           "Red: GenAI spans through the collector. Black: direct POST. Green: recorded or normalized "
           "spans. Grey spans are dropped at the collector.")
    + eli5("Think of three doors into the same room. "
           "The collector door also cleans the mail: it labels it, removes private ids and throws away junk.")
    + maths("The collector is a filter and a map on each span s.",
            eq("keep(s) &nbsp;= s is a GenAI span",
               "s.use_case ← the configured use case",
               "s.gen_ai.conversation.id ← map(the platform's conversation key)",
               "s.identifiers ← scrubbed"))
    + tech("Door 1: the OTel Collector config <code>deploy/otel-collector/jev-collector.yaml</code>. Door 2: "
           "the judge's own <code>POST /v1/traces</code>. Door 3: <code>ContractRecorder</code> in the agent, "
           "or <code>jevjudge otel-normalize</code> on exported files. All three give OTLP spans.")))

S.append(section(4, "s4", "Ingest: spans snap into turns",
    "Many envelopes and many OTel dialects become one Session per conversation.",
    figure(fig_ingest(), "spans snapping into turns",
           "Colours are envelopes. Union-find joins envelopes that share an id. Then each "
           "<code>invoke_agent</code> span becomes a turn and each <code>execute_tool</code> span a tool call.")
    + eli5("One phone call can arrive as many separate letters. "
           "We put letters together when they carry the same call number. Then we sort them into turns.")
    + maths("Each envelope is a node. Two nodes join if they share a conversation id or a traceId.",
            eq("union(i, j) &nbsp;if ids(i) ∩ ids(j) ≠ ∅ &nbsp;or traces(i) ∩ traces(j) ≠ ∅",
               "conversation = one connected component &nbsp;<span class='c'># find() with path "
               "compression</span>",
               "skip id x &nbsp;if share(x) &gt; max_share · n &nbsp;&nbsp;<span class='c'># max_share = 0.5, "
               "when n ≥ 20</span>"))
    + tech("A convention layer reads several OTel dialects: genai_semconv, genai_events, langsmith, "
           "openllmetry, openinference, vertex_adk, plus Sierra, Decagon and CES. "
           "<code>otel/grouping.py</code> does the union-find. The output is a <code>Session</code>: turns, "
           "tool calls and tool errors.")
    + warn("Placeholder ids such as <code>default</code> would join every conversation into one. "
           "So an id carried by more than half of the envelopes is ignored for joining.")))

S.append(section(5, "s5", "Pack and chunk: each model gets what fits",
    "A view selects what a criterion needs. Then each model cuts it to its own token budget.",
    figure(fig_chunks(), "one transcript sliced per model budget",
           "The large budget takes the session whole. The small budget cuts it into four chunks. The "
           "chunk answers are joined per criterion.")
    + eli5("Each reader has a different page limit. "
           "We cut the story into pieces that fit. Each piece gets its own answer. Then we join the answers.")
    + maths("Text is counted in the model's own tokenizer. Chunk answers are joined on P(positive label).",
            eq("max &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;: p = max<sub>i</sub> p<sub>i</sub>",
               "noisy_or : p = 1 − Π<sub>i</sub> (1 − p<sub>i</sub>)",
               "mean &nbsp;&nbsp;&nbsp;&nbsp;: p = (1/n) Σ<sub>i</sub> p<sub>i</sub> &nbsp;&nbsp;&nbsp;"
               "<span class='c'># also: last, first</span>"),
            "For “did the agent ever expose PII?”, max is right: one bad chunk is enough.")
    + tech("Tokenizers: HF tokenizers for kairos-jev, <code>tiktoken:cl100k_base</code> for kev-gemma, "
           "<code>chars:1</code> for djev (<code>max_state_tokens</code> 30000 / 6500 / 19000 in "
           "<code>models.yaml</code>). Each member of the stack packs and chunks with its own budget.",
           "<code>ChunkSpec</code> in the rubric YAML: <code>strategy</code> none / window / units, "
           "<code>aggregate</code>, <code>max_chunks</code> 16, <code>overlap_turns</code>, <code>carry</code>. "
           "With <code>none</code>, an over-budget state first shrinks tool results, then elides the middle.")
    + warn("kev-gemma has the smallest budget, so it chunks the most. One session becomes many requests "
           "on its queue. That is why it is the latency bottleneck (p50 4.9 s / p95 5.8 s per member call).")))

S.append(section(6, "s6", "Ask: a rubric is a list of typed questions",
    "Rubrics are YAML. Each criterion is one question with a type and fixed options.",
    figure(fig_ask(), "from YAML to typed questions, and one question split into twelve",
           "A real rubric header (<code>output_pii@1.0.0#35238815becb</code>). Below: the action-completion "
           "verdict split into read-off sub-questions plus a verdict.")
    + eli5("A vague question gets a vague answer. "
           "So we split “did the agent finish the job?” into small questions that a reader can check. "
           "Then one last box joins them.")
    + maths("Each type turns probabilities into a value in [0, 1].",
            eq("noul &nbsp;&nbsp;: v = P(true)",
               "score &nbsp;: v = Σ<sub>k</sub> k · P(level<sub>k</sub>) / (n − 1)",
               "choice : v = Σ<sub>k</sub> credit<sub>k</sub> · P(k) / Σ<sub>scored</sub> P(k) &nbsp;&nbsp;"
               "<span class='c'># drops out if N/A mass ≥ 0.5</span>",
               "rubric : Σ w<sub>i</sub> v<sub>i</sub> / Σ w<sub>i</sub> &nbsp;&nbsp;"
               "<span class='c'># or strict: 1 only if every criterion passes</span>"))
    + tech("Rubrics live in <code>metrics/voice_v2/*.yaml</code>: action_completion, hallucination, "
           "output_pii, output_sexism, output_toxicity. Revisions are hash-pinned. A certificate pins one "
           "revision, so an edited rubric needs a new certificate.",
           "Action completion has 12 criteria (about 11 read-off sub-questions plus a verdict). Toxicity has 9.")))

S.append(section(7, "s7", "Decide: one model, or a stack of three",
    "The stack asks three different models and joins their answers with a fitted combiner.",
    figure(fig_decide(), "one model vs the 3-model stack, side by side",
           "Left: one tier, calibrated by temperature. Right: three members in parallel, joined in logit "
           "space. For decomposed action completion, a verdict model reads every member’s sub-answers.")
    + figure(fig_lever(), "the lever",
             "Agreement for action completion before and after decomposition.")
    + eli5("Three experts with different blind spots vote. "
           "We learned from past cases how much to trust each one. Their votes become one number.")
    + maths("The combiner is a logistic regression on member logits, one per question.",
            eq("P(fired) = σ( Σ<sub>k</sub> w<sub>k</sub> · logit(p<sub>k</sub>) + b )",
               "fit: L2-regularized Newton on retained, labelled probabilities",
               "verdict_model: the same form, over member × sub-question logits"))
    + tech("<code>calibration/combiner.py</code>: <code>fit_logistic(X, y, l2=1.0)</code>. The combined "
           "score is a new signal. Its version goes into the certificate fingerprint, so a member change "
           "forces a refit and a new certificate.",
           "The v2 stack is kairos-jev, kev-gemma and djev. laya was excluded because its pod was down.")))

S.append(section(8, "s8", "Gate and escalate: answer, or ask for help",
    "If the stack is confident enough, its answer stands. If not, System Two answers.",
    figure(fig_gate(), "a gate needle against θ",
           "The needle is the confidence q. Item 1 is past θ, so System One answers. Item 2 is not, so it "
           "goes to System Two.")
    + eli5("A junior answers the easy cases. A senior gets only the hard ones. "
           "The line between easy and hard is not a guess. It is certified (section 10).")
    + maths(eq("q = max(p, 1 − p)",
               "accept &nbsp;&nbsp;if q ≥ θ<sub>certified</sub>",
               "escalate otherwise; invalid output → q = −∞ → escalate"),
            "On the v2 holdout, JEV decided 96% of action-completion items itself.")
    + tech("<code>judge/graph.py</code> is a LangGraph graph: pack → route → decide ⇄ gate → escalate → "
           "audit → aggregate. Escalation reasons: <code>low_conf</code>, <code>abstain</code>, "
           "<code>invalid</code>, <code>uncertified</code>, <code>drift_freeze</code>, "
           "<code>backend_error</code> and more.",
           "<code>escalation.rationale: on_escalation</code> writes a rationale only when System Two answers. "
           "<code>audit_rate: 0.05</code> sends a slice of accepted items to System Two in shadow, for the monitor.")))

S.append(section(9, "s9", "Emit: one standard event per verdict",
    "Results leave as OTel GenAI evaluation events, with jev.* attributes for the details.",
    figure(fig_emit(), "the evaluation event, attribute by attribute",
           "Standard <code>gen_ai.evaluation.*</code> fields plus <code>jev.*</code> extras, sent to the OTel "
           "pipeline, JSONL and the CMCS sink.")
    + eli5("The judge writes its verdict on a standard form. "
           "Any tool that reads the form can show it. Extra boxes on the form say how sure it was and who answered.")
    + maths("The emitted score is the criterion value from section 6. The confidence is q from section 8.",
            eq("gen_ai.evaluation.score.value = v &nbsp;&nbsp;&nbsp;<span class='c'># e.g. P(true) for noul</span>",
               "jev.confidence.q = max(p, 1 − p)",
               "jev.aggregate = weighted_mean | strict &nbsp;&nbsp;<span class='c'># the rubric-level "
               "event</span>"))
    + tech("<code>otel/emit.py</code> turns a <code>GradeReport</code> into one "
           "<code>gen_ai.evaluation.result</code> event per criterion, plus one per rubric. The extras include "
           "<code>jev.probabilities</code>, <code>jev.backend</code>, <code>jev.latency_ms</code>, "
           "<code>jev.policy.source</code> and <code>jev.stratum</code>. A rationale goes into "
           "<code>gen_ai.evaluation.explanation</code> only on escalation.")))

S.append(section(10, "s10", "Calibrate: certify θ with Learn-then-Test",
    "θ is not tuned by eye. It is the loosest threshold that passes a valid statistical test.",
    figure(fig_wealth(), "a betting-wealth curve crossing 1/δ",
           "Green: a safe θ. The bettor gets rich, so “unsafe” is rejected. Grey: a looser θ. The wealth "
           "never reaches 1/δ, so it is not certified.")
    + figure(fig_fst(), "fixed-sequence threshold search",
             "Candidates are tested in a fixed order, strict to loose. The last pass before the first fail "
             "is certified.")
    + eli5("We bet against the claim “this threshold is unsafe”. "
           "If that claim were true, we could not win big. So a big win proves the threshold is safe, "
           "with a known error rate.")
    + maths("Hypothesis H0: the policy is not safe. The cascade error exceeds the reference error by more "
            "than ε.",
            eq("d<sub>i</sub> = 1[cascade wrong] − 1[reference wrong] ∈ {−1, 0, 1}",
               "H0: E[d] &gt; ε &nbsp;&nbsp;→ &nbsp;x<sub>i</sub> = (d<sub>i</sub> + 1)/2, &nbsp;target = "
               "(1 + ε)/2",
               "K<sub>t</sub> = Π<sub>i≤t</sub> (1 + λ<sub>i</sub> (target − x<sub>i</sub>)) &nbsp;&nbsp;"
               "<span class='c'># λ<sub>i</sub> predictable, ≥ 0</span>",
               '<span class="h">p = 1 / max<sub>t</sub> K<sub>t</sub> &nbsp;&nbsp;reject H0 if p ≤ δ</span>',
               "<span class='c'># defaults: ε = 0.02, δ = 0.05, min_n = 100</span>"),
            "Under H0, K is a non-negative supermartingale. Ville’s inequality gives P(max K ≥ 1/δ) ≤ δ.")
    + tech("<code>calibration/bounds.py</code>: <code>wsr_pvalue</code> (Waudby-Smith–Ramdas betting), "
           "with <code>hoeffding_bentkus_pvalue</code> and Clopper–Pearson available. "
           "<code>calibration/engine.py</code>: <code>CalibrationEngine(eps=0.02, delta=0.05, min_n=100)</code>.",
           "Modes: <code>parity_gold</code> when gold labels exist, otherwise <code>parity_ref</code>. "
           "parity_ref uses l<sub>i</sub> = 1[JEV answered and disagreed with the reference]. That bounds the "
           "gold loss for any labelling, so it needs no human labels. Method <code>auto</code> uses split "
           "fixed-sequence below n = 600, else Holm.")
    + warn("If nothing certifies, θ = ∞ for every tier: everything escalates. Below "
           "<code>min_n</code> = 100 items, the engine does not certify at all. This is safe, but slow and "
           "costly. It is not a bug.")))

S.append(section(11, "s11", "Monitor and drift: freeze first, ask later",
    "A certificate holds for the data it saw. The monitor checks, item by item, that it still holds.",
    figure(fig_cusum(), "the CUSUM statistic rising to the alarm line",
           "While healthy, the statistic stays near 1. After the shift it climbs. At 1/α it fires and the "
           "unit freezes.")
    + figure(fig_drift(), "ACI tightening and PSI",
             "Left: θ moves up on disagreements and never goes below the certified θ. Right: the "
             "confidence distribution moves away from its baseline.")
    + eli5("A smoke alarm does not wait for a report. "
           "When disagreements pile up, the unit stops answering on its own. A senior judge takes every item "
           "until a new certificate is approved.")
    + maths(eq("x<sub>t</sub> = 1[System One disagreed with the fallback] &nbsp;&nbsp;"
               "<span class='c'># on the audit slice</span>",
               "W<sub>λ</sub> ← max(W<sub>λ</sub>, 1) · (1 + λ (x<sub>t</sub> − ε)), &nbsp;λ ∈ {0.5, 1, 2, 4, 8}",
               '<span class="h">alarm if mean<sub>λ</sub> W<sub>λ</sub> ≥ 1/α</span> &nbsp;&nbsp;'
               "<span class='c'># eps 0.05, alpha 0.01</span>",
               "ACI: θ ← min(0.999, max(θ<sub>cert</sub>, θ + γ (x<sub>t</sub> − target))), &nbsp;γ = 0.02",
               "PSI = Σ<sub>bins</sub> (c − b) · ln(c / b) &nbsp;&nbsp;<span class='c'># alarm &gt; 0.2</span>"))
    + tech("<code>AccuracyMonitor(eps=0.05, alpha=0.01, aci_gamma=0.02, detector=\"cusum\")</code> in "
           "<code>calibration/monitor.py</code>. State persists to JSON, so a batch job and a service share "
           "freeze decisions. <code>reset(unit)</code> runs when a fresh certificate is promoted.",
           "<code>DriftStats</code> in <code>drift_stats.py</code> compares a window of 500 with a baseline "
           "of 500: PSI of q, the escalation rate and the valid-answer rate.")
    + warn("A plain cumulative test reacts slowly after a long healthy period: old good data hides new bad "
           "data. The CUSUM restart (wealth never below 1 before a bet) removes that delay. ACI is not a "
           "certificate, so it may only tighten θ.")))

S.append(section(12, "s12", "Govern: who changed θ, when, and why",
    "Certificates have a lifecycle, rollouts have phases, and doubtful items go to people.",
    figure(fig_cert(), "certificate state machine",
           "The token moves PROPOSED → ACTIVE → ROLLED_BACK. A rollback reactivates the previous "
           "certificate. The history keeps every step.")
    + figure(fig_phases(), "migration phases", "Teams move from static thresholds to certified ones "
             "one phase at a time.")
    + figure(fig_review(), "the review queue", "Three reasons send an item to a person. Their labels "
             "come back as gold for the next certificate.")
    + eli5("A threshold is like a building permit. Someone proposes it. Someone approves it. "
           "It can be replaced, rolled back or cancelled. Nothing is erased.")
    + maths(eq("tighter_of: θ = max(θ<sub>static</sub>, θ<sub>certified</sub>)",
               "fingerprint = sha256(revision, tier models, reference)[:16]",
               "unit = rubric revision × criterion × output type × tier backends × reference"))
    + tech("<code>calibration/registry.py</code>: <code>propose</code> (state PROPOSED, not served), "
           "<code>approve</code> (ACTIVE; the old ACTIVE in that stratum becomes SUPERSEDED), "
           "<code>rollback</code>, <code>revoke</code>, <code>history</code>. Certificates expire after "
           "<code>ttl_days</code> (30).",
           "<code>review.py</code>: reasons <code>both_unsure</code>, <code>high_stakes</code>, "
           "<code>audit</code> (default <code>audit_rate</code> 0.01). Exported labels "
           "(<code>session_id, metric, label</code>) feed <code>parity_gold</code>.")))

S.append(section(13, "s13", "Prove it on prod",
    "Production validation run 1: five metrics on 16,511 real sessions.",
    figure(fig_prod_agree(), "prod results bars growing",
           "Agreement with the production judge, per metric, with the share that JEV escalated.")
    + figure(fig_prod_adj(), "the adjudication bar chart",
             "Top: who the blind adjudicator sided with. Bottom: estimated accuracy with the adjudicator "
             "as truth.")
    + eli5("Agreeing with the old judge is not the goal. The old judge makes mistakes too. "
           "So a third judge read the cases where they disagreed, without knowing who said what.")
    + maths("If both are right where they agree, and the adjudicator is right where they disagree:",
            eq("acc<sub>JEV</sub> ≈ a + (1 − a) · s &nbsp;&nbsp;&nbsp;&nbsp;acc<sub>prod</sub> ≈ a + (1 − a) · "
               "(1 − s)",
               "<span class='c'># a = agreement, s = share of disagreements won by JEV</span>",
               "AC: &nbsp;0.731 + 0.269 · 0.69 ≈ 0.92 &nbsp;&nbsp;&nbsp;0.731 + 0.269 · 0.31 ≈ 0.81"),
            "The same rule gives PII ≈ 0.996 vs 0.984 and hallucination ≈ 0.975 vs 0.983.")
    + tech("Scope: <code>prod_eval_hub_sessions</code> on 2026-09-29: Sierra, Decagon, CES voice and "
           "nonbilling, and both chat projects. 82,555 verdicts, 0 errors.",
           "Latency under batch load: p50 8.9 s / p95 30.8 s per session (5 metrics). This is mostly "
           "kev-gemma queueing: 16 slots shared by about 24 sessions.",
           table(["v2 holdout · agreement with reference", "cascade", "gemini-3.8-flash"], [
               ["action completion (JEV decides 96%)", "0.881", "0.851"],
               ["toxicity", "0.967", "0.958"], ["PII", "0.916", "0.894"],
               ["sexism", "0.981", "0.963"], ["hallucination", "0.948", "0.571"]], numeric={1, 2}))
    + warn("Hallucination is the honest exception. The adjudicator sided with JEV on only 40% of "
           "disagreements, so production is slightly ahead there (0.983 vs 0.975).")
    + figure(fig_v3(), "calibration v3: in progress",
             "v3 calibrates System One alone. It is running now. Results are pending, so none are shown.")))

S.append(section(14, "s14", "Use it",
    "One config file. Call it from Python, drop it into a LangGraph graph, or run the Studio.",
    figure(fig_use(), "a library call, a graph node, a UI",
           "The same <code>configs/judge_v2.yaml</code> drives every path.")
    + py_code('''
from jevjudge import CriterionGrader
g, rubrics = CriterionGrader.from_config("configs/judge_v2.yaml")
report = await g.grade(trace, rubrics)
''')
    + py_code('''
from jevjudge.integrations.langgraph import jev_judge_node, jev_route
graph.add_node("judge", jev_judge_node("configs/judge_v2.yaml"))
graph.add_node("redact", redact); graph.add_node("send", send); graph.add_node("hold", human_review)
graph.add_conditional_edges("judge", jev_route("output_pii", "redact", "send", on_unknown="hold"))
''')
    + '<pre>jevjudge serve --port 8000   <span class="c"># Calibration Studio + HTTP API</span></pre>'
    + eli5("Point it at a config. Give it a conversation. Get a verdict per metric, with how sure it is "
           "and who answered.")
    + maths("The node writes a compact result per rubric.",
            eq("{rubric_id: {verdict, p_fired, score, source}}",
               "jev_route: fired → on_fired, clean → on_clean, else → on_unknown"))
    + tech("<code>jev_judge_node</code> reads <code>state[\"trace\"]</code> and writes "
           "<code>state[\"evaluation\"]</code>. <code>judge_subgraph</code> embeds the judge graph itself. "
           "The DeepEval adapter uses the same scoring maths, so CI scores match online scores.")
    + warn("Without <code>on_unknown</code>, a missing verdict (every backend failed) routes as clean. "
           "For a guardrail, always set it.")))

HTML = page(
    title="How jevjudge judges a conversation — a whiteboard walkthrough",
    kicker="jevjudge · engineering walkthrough",
    h1="How jevjudge judges a conversation",
    lede="jevjudge replaces an LLM-as-judge for voice and chat agents. Decision models answer typed "
         "questions in one forward pass. A certified gate decides when to ask an LLM instead. "
         "This page follows one conversation from trace to verdict, one stage at a time.",
    facts=[("3", "decision models"), ("5", "metrics"), ("98.6%", "contract conformance"),
           ("0.92 vs 0.81", "AC accuracy (adjudicated)"), ("0", "decode loops")],
    nav=NAV, sections=S)

HTML = (HTML.replace("</style>", REPLAY_CSS + "</style>")
            .replace("<body>", "<body>" + DEFS)
            .replace("</div>\n</body>", "</div>" + REPLAY_JS + "\n</body>"))

if __name__ == "__main__":
    out = HERE / "jevjudge-explained.html"
    out.write_text(HTML, encoding="utf-8")
    n_anim = HTML.count('svg class="anim"')
    print(f"wrote {out.name}  ({out.stat().st_size / 1024:.0f} KB, {len(S)} sections, "
          f"{n_anim} animated figures)")
