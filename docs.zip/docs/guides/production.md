# Production

## Certified mode

In production, serve with `threshold: certified`, an approved certificate registry, the monitor and, ideally, the review queue. This is `configs/judge_v2.yaml` plus the optional review block:

```yaml
tiers:
  - {model: jev-stack, members: [kairos-jev, kev-gemma, djev], combiner: registry/v2/combiner.json}
escalation:
  judges: [{model: gemini-3.8-flash}, {model: gemma-26b, timeout: 60}]   # judges[0] is the certified reference
  threshold: certified
  rationale: on_escalation
  audit_rate: 0.05
  use_fallback_rubric: false        # the v2 certificates were measured with question-only escalation
registry: registry/v2/certificates.json
monitor: {enabled: true, eps: 0.05, alpha: 0.01, detector: cusum, state_path: registry/v2/monitor_state.json}
review: {path: /data/jevjudge/review_queue.jsonl, audit_rate: 0.01}
rubrics: [rubrics/voice_v2]
```

Coming from hand-set thresholds? Don't switch in one step. Use the [migration phases](governance.md#migration-phases) (`legacy_shadow` → `tighter_of` → `certified_preferred` → `enforce`).

What fails closed (θ = ∞, so every item of that unit goes to System Two). The full table, including what each migration phase relaxes, is in [Governance → Fail-closed rules](governance.md#fail-closed-rules):

| Situation | `escalation_reason` / policy source |
|---|---|
| no ACTIVE certificate for the unit (only PROPOSED, revoked, rolled back) | `uncertified` |
| certificate past `expires_at` (TTL 30 days by default) | `uncertified` (policy `expired`) |
| rubric revision, tier list or reference changed | `uncertified` (policy `fingerprint_mismatch`) |
| Mondrian stratum without its own certificate | `uncertified` |
| monitor alarm | `drift_freeze` |
| ensemble member or `verdict_model` feature missing, backend error | `invalid` (per item) |

`threshold="certified"` without a registry raises `ConfigError` (a `ValueError`) at construction.

## Registry, approval and rollback

* **Certify.** Run `CalibrationEngine(...).certify_unit(...)` (see [Escalation and calibration](../concepts/escalation-and-calibration.md#calibration-engine)), `jevjudge calibrate`, or Studio step 5.
* **Propose, then approve.** `registry.propose(cert)` stores a certificate without serving it. A named person approves it with `registry.approve(cert_id, approver, note)` or `POST /v1/projects/{id}/certificates/{cert_id}/approve`. Approval supersedes the unit's previous ACTIVE certificate. See [Certificate lifecycle](governance.md#certificate-lifecycle).
* **Roll back.** `registry.rollback(unit_id, stratum)` re-activates the certificate that the current one superseded.
* **Unreviewed shortcuts.** `jevjudge calibrate --promote` and `registry.promote(cert)` activate a certificate directly, without an approver or event log. Studio calibration auto-approves as `studio:auto` unless you pass `approve_as: null` to `POST /v1/projects/{id}/calibrate` (propose only; approve in the Certificates view). Use the shortcuts for experiments only.
* **Review.** Keep the registry file under review, like code. A certificate records the unit, stratum, fingerprint, mode, method, ε, δ, n, θ per tier, temperatures, `monitor_eps`, `issued_at`, `expires_at`, a summary (share answered by Jev, gap), and the approval history.
* **Fallback-specific registries.** Ship one registry per reference: `certificates.json` (Gemini first) and `certificates_gemma.json` (Gemma first). Switching the chain order means switching the registry.
* **Reload.** Graders read the registry at construction. Rebuild them, or call `grader.registry.load()`, after approving or rolling back from another process.

## Monitor, drift and review

* **Audit slice.** `audit_rate` is the share of *accepted* verdicts that System Two shadow-judges. Sampling is deterministic per subject and criterion. In batch, this runs inline. In a latency-sensitive service, keep `audit_rate` small, or run audits off the hot path.
* **Freeze.** When the e-process alarm fires, the unit is frozen. All its items escalate until a new certificate is approved and you call `AccuracyMonitor.reset(unit)`. The default `detector: cusum` keeps the detection delay short even after months of healthy traffic. See [Monitoring](monitoring.md#accuracy-monitor).
* **Share state.** Point `monitor.state_path` at shared storage so batch jobs and services agree on freezes.
* **Drift statistics.** `grader.drift` tracks the confidence PSI, the escalation rate and the valid rate per unit. Alarms show up in `jevjudge grade` output and at `GET /v1/projects/{id}/drift`. See [Drift statistics](monitoring.md#drift-statistics).
* **Human review.** The [review queue](review-queue.md) collects high-stakes, both-unsure and random-audit items for people. Their labels feed `parity_gold` re-certification.
* **Label-free limits.** The label-free monitor can't detect errors that the reference also makes. Hallucination needs the human `audit` slice.

## Shadow rollout

The recommended rollout:

1. **Shadow for 7 days.** Run `jevjudge grade --config judge.yaml --input <traces> --out events.jsonl --cmcs blobs.jsonl` on 100% of traffic beside the incumbent, and write the CMCS blob to a side table. If the incumbent already uses hand-set thresholds, serve them with `phase: legacy_shadow` so each event also records the certified θ (`jev.shadow_threshold`).
2. **Compare** column by column (`pii@category_count`, `toxicity_gpt_multijudge_average`, …) and review the disagreements in the [review queue](review-queue.md).
3. **Label** 200–400 disagreement-stratified sessions per metric, re-certify in `parity_gold` mode, and approve the certificates.
4. **Switch** downstream readers to the Jev blob, step the phase up to `enforce`, and keep `audit_rate > 0`.

## Versioning

Every event carries enough to reproduce the decision:

* `jev.rubric.revision`, the rubric content hash (see [Rubrics](../concepts/rubrics.md#revision-hash));
* `jev.calibration.version`, the certificate id, or `fixed:<θ>`;
* `jev.policy.source`, `jev.shadow_threshold` and `jev.stratum`: which governance branch produced θ (see [Governance](governance.md#migration-phases));
* `report.meta["timings_ms"]`: per-stage latency (see [Per-stage timings](monitoring.md#per-stage-timings));
* backend fingerprints in `report.meta["tiers"]` and `report.meta["judges"]` (`name@version`). For an ensemble, the fingerprint covers member fingerprints plus the combiner hash.

Rules:

* **Rubric edits.** Bump `version` for humans. The hash changes anyway, and certificates stop applying.
* **Model changes.** A new member version requires refitting the combiner and re-certifying.
* **Reference changes.** These are a new calibration unit.

## Cost and latency

Measured on the k5lv pods, Vertex and the Kairos gateway (REPORT §7 and the v2 latency section). Use `report.meta["timings_ms"]` to see where the time goes for your own traffic.

| Component | Latency | Notes |
|---|---|---|
| Kairos decision models | 20–70 ms server-side | one request answers every question in a view |
| kev-gemma | about 1.3 s idle, 10–20 s under batch load | throughput bottleneck of `jev-stack` |
| `jev-stack` | slowest member | drop kev-gemma or add a replica for inline modes |
| Gemma-26B (System Two) | about 0.7 s | shared endpoint, unreliable under other teams' batches |
| Gemini-2.5-flash (System Two) | about 2.1 s (p50 1.3–1.6 s question only) | reliable through Vertex ADC |
| gemini-3.8-flash via the test gateway (System Two) | about 9 s per call | the v2 reference; with certified thresholds most verdicts never reach it |

Cost levers:

* **Requests per subject.** Count one per (view × chunk) per System One tier, plus one per escalated question per System Two judge. LLMs answer one question per request, and `two_order` doubles that. `report.calls` gives the counts per backend.
* **Dollar cost.** `report.cost_usd = Σ calls × cost_per_call_usd`. Set `cost_per_call_usd` per model in `models.yaml` or inline. All packaged entries default to 0.
* **Measured cost.** With the v2 certified stack, every metric costs 1.7–5.6% of a gemini-3.8-flash call: Jev answers 100% of the safety verdicts and 96% of the action-completion verdicts. (In v1, action completion cost about 58%, because about half its items escalated.)
* **Throughput knobs.** `concurrency` (subjects in flight), per-backend `max_concurrency`, `timeout` and `retries`, and `max_escalations_per_subject`.

## Gateway vs pods

| | Direct pods | Kairos inference gateway |
|---|---|---|
| Aliases | `kairos-jev`, `kev-gemma`, `laya`, `djev`, `clm-gemma`, `jev-stack` | `gw/kairos-jev`, `gw/kev-gemma`, `gw/laya`, `gw/djev`; Gemini via `gemini-3.8-flash` (test), `gemini-3.8-flash-prod` |
| URL | `https://{route}-k5lv-prod-vllm.apps.tdcpdocpgp1j14v.verizon.com` | `${KAIROS_GATEWAY_URL_TEST}/{route}`, `${KAIROS_GATEWAY_URL_PROD}` |
| Key | `JEV_API_KEY` | `KAIROS_JWT_NP` (test) / `KAIROS_JWT_PR` (prod) |
| Use when | batch jobs and experiments inside the network; lowest latency | services that must go through the governed gateway; prod Gemini |

You can switch between them in YAML without code changes, either by changing the alias or by overriding `base_url` and `api_key_env` inline:

```yaml
tiers:
  - {model: gw/djev}
  - {model: kairos-jev, base_url: "kairos_gateway_prod/kairos-jev", api_key_env: KAIROS_JWT_PR}
```

`base_url` can name an endpoint from `models.yaml`, optionally followed by a path. `{route}` is substituted for pods.

Certificates pin backend **names**, not URLs. Switching from `djev` to the `gw/djev` alias changes the tier name, so the router fails closed until you re-certify. Overriding `base_url` inline on `djev` keeps the name, and the certificate still applies. Re-certify anyway if the gateway serves a different model version.

## Operational checklist

- [ ] `.env` with keys is git-ignored; Vertex ADC is set up on the runner
- [ ] `jevjudge smoke` passes for every configured model
- [ ] Registry certified against `judges[0]`, every serving certificate approved by a named person, none expired
- [ ] `phase: enforce` (or a documented migration plan) and no stale `static_thresholds`
- [ ] `monitor.state_path` on shared storage; `audit_rate > 0`
- [ ] Review queue path on shared storage, and an owner who labels it weekly
- [ ] Alerting on `jev.escalation.reason = drift_freeze | uncertified` rates, on frozen units and on drift alarms
- [ ] Re-certification scheduled before the 30-day TTL
