# Agent brief: optimise the Inkling 2 Mini MoE expert GEMM on H100 (sm_90)

You may edit exactly one file: `candidates/current.py`. Everything else is frozen and hashed.

Contract (do not change): the file must expose
`fused_moe_wq(x, topk_ids, topk_w, w13, w2, fmt13, fmt2, softcap=None) -> bf16 [T, H]`
and the real work must happen in kernels you write (`@triton.jit`, or CUDA via
`torch.utils.cpp_extension.load_inline`). Calling torch matmul/bmm/linear, cuBLAS, vLLM ops,
Humming, Marlin or the reference implementation is rejected by a static check.

Numerics: NVFP4 (e2m1 + E4M3 block-16 + fp32 global) and MXFP8 (e4m3 + UE8M0 block-32)
weights, BF16 activations, fp32 accumulation. Hopper has no FP4 tensor cores.

Hard requirements, checked on every candidate:
1. Matches the fp32 reference within tolerance on visible and hidden shapes and formats.
2. Bitwise deterministic run to run.
3. Batch invariant: a token's output bits are identical alone or in a batch of N.
   So: no split-K or stream-K with atomics, no batch-size-dependent tile choice, and
   fixed reduction order.
4. Outputs must change when inputs change (no caching), must not alias inputs.
5. Speed is measured only by the harness (CUDA events, L2 flushed, median). A result above
   the calibrated HBM roofline is treated as a bug, not a win.

Ideas worth trying (Shape notes: H=2304, I=1152, E=128, top-8; decode is weight-bandwidth bound):
wgmma-friendly pre-shuffled weight layout; TMA loads; larger BLOCK_N at small M; fusing
SwiGLU into the w13 epilogue; fusing the top-k combine with a fixed j order; persistent
grid over (expert, n-tile) work items; num_warps / num_stages; FP8 activations for
large-M prefill only (separate path, must still pass the numerics gate).
