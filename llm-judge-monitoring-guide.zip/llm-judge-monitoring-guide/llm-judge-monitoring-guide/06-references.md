# 06 — References

Curated bibliography. URLs verified as of the pack’s authorship window (2026). Prefer primary sources over secondary summaries.

Cross-links: [Architecture](01-architecture.md) · [Metrics](05-metrics-and-drift.md) · [PLAN](PLAN.md)

---

## Core lifecycle & production monitoring

### Netflix Tech Blog — Lifecycle of LLM-as-a-Judge (Medium)

- **URL:** https://netflixtechblog.medium.com/the-lifecycle-of-llm-as-a-judge-building-aligning-and-monitoring-at-scale-c95bd8283508
- **Why it matters:** Practical four-phase lifecycle (birth → training → deployment → HITL monitoring). Explicit principle: judges must stay anchored to humans; **humans approve changes before rollout**. Direct template for our Week 1 / Month 1 ops stance.

### arXiv 2608.18300 — Lifecycle of LLM-as-a-Judge for Large-Scale Recommendation Explanations

- **URL:** https://arxiv.org/abs/2608.18300
- **Why it matters:** Peer-reviewed companion to the Netflix lifecycle post. Details RART (rubric tuning), dual role of judge (gate + critic), and continuous HITL drift monitoring at large weekly explanation volume. Steal the *process*, not the recommendation-domain metrics.

### Who Drifted: the System or the Judge? — arXiv 2606.15474

- **URL:** https://arxiv.org/abs/2606.15474
- **Code:** https://github.com/yitao416/driftjudge
- **Why it matters:** Formalises the ambiguity every on-call feels: score drop ≠ product regression if the judge moved. Anchor-set re-scoring + attribution verdict `{none, system, judge}`. Underpins our dual dashboards and runbooks in [04](04-versioning-and-ops.md) / [05](05-metrics-and-drift.md).

### Artefact — Millions of calls, one judge (Medium)

- **URL:** https://medium.com/artefact-engineering-and-data-science/millions-of-calls-one-judge-how-we-evaluated-our-voicebot-in-production-8c00f6ea6654
- **Why it matters:** Voicebot-at-scale lessons: **binary atomic judges**, golden dataset calibration, offline lab + online safety net, and the hard truth that **ASR/STT quality** often dominates “judge” failures. Closest industry narrative to 50–70k voice sessions/day.

---

## Evaluation methodology

### MT-Bench / Chatbot Arena — Zheng et al.

- **URL:** https://arxiv.org/abs/2306.05685 (*Judging LLM-as-a-Judge with MT-Bench and Chatbot Arena*)
- **Why it matters:** Foundational evidence that strong LLMs can approximate human preference rankings — and where they fail (bias, position, verbosity). Read before trusting pairwise or Likert judges; we prefer **binary rubrics** partly to dodge some of these failure modes.

### G-Eval — Liu et al.

- **URL:** https://arxiv.org/abs/2303.16634
- **Why it matters:** Chain-of-thought scoring against explicit criteria. Our judge prompts in [03](03-implementation-guide.md) follow the G-Eval spirit (rubric → reasoning → score) constrained to binary JSON.

### RAGAS — arXiv 2309.15217

- **URL:** https://arxiv.org/abs/2309.15217
- **Why it matters:** Reference-free / retrieval-aware metrics (faithfulness, answer relevance, context precision). Useful inspiration for search+generation judges; still calibrate against humans before alerting.

### How to Correctly Report LLM-as-a-Judge Evaluations — UW-Madison / collaborators — arXiv 2511.21140

- **URL:** https://arxiv.org/abs/2511.21140
- **Code:** https://github.com/UW-Madison-Lee-Lab/LLM-judge-reporting
- **Why it matters:** Makes Rogan–Gladen-style bias adjustment + proper intervals operational. Primary citation for “do not publish raw judge pass as accuracy/precision.” See [05](05-metrics-and-drift.md).

---

## Tooling docs

### Langfuse — evaluation / LLM-as-judge

- **URL:** https://langfuse.com/docs/scores/overview (scores) · https://langfuse.com/docs/scores/model-based-evals (model-based)
- **Self-host:** https://langfuse.com/self-hosting
- **Why it matters:** Trace + score store for this pack’s architecture. Prefer current docs over outdated compose gists; pin versions.

### DeepEval

- **URL:** https://docs.confident-ai.com/ (DeepEval docs hub)
- **Why it matters:** CI-friendly metrics (faithfulness et al.) for prompt regression gates.

### Promptfoo

- **URL:** https://www.promptfoo.dev/docs/intro/
- **Why it matters:** Declarative prompt test suites in CI; good fit for Llama/custom search prompt PRs.

### Arize Phoenix

- **URL:** https://docs.arize.com/phoenix
- **Why it matters:** Tracing + embedding drift workflows; use for **system** input/output drift panels.

### Evidently

- **URL:** https://docs.evidentlyai.com/
- **Why it matters:** Tabular / distribution drift reports (ASR confidence, retrieval scores, judge rates as features). Pair with Phoenix; do not collapse into one vague “AI quality” widget.

---

## Supporting classics (short)

| Work | URL | Use |
|------|-----|-----|
| Rogan & Gladen (1978) prevalence adjustment | https://doi.org/10.1093/oxfordjournals.aje.a112560 | Statistical ancestor of judge-rate correction |
| Cohen’s κ | any stats text / scikit-learn `cohen_kappa_score` | Calibration headline |

---

## Red herrings

Do **not** confuse these with the continuous LLM-judge monitoring problem:

| Red herring | Why it misleads |
|-------------|-----------------|
| **Netflix classic A/B experimentation platform** posts (allocation, metrics store for product A/B) | Essential for product experiments; **orthogonal** to judge lifecycle, κ, and rubric versioning. Do not “implement A/B platform” when you need eval observability. |
| **GenRec / generic recommender monitoring** as a drop-in for voice+RAG judges | Ranking offline metrics (NDCG etc.) do not replace faithfulness/safety rubrics or HITL anchors. |
| **Invented Netflix product names** (e.g. fictional “elements” platforms) | Not used in this pack; stick to published lifecycle + arXiv. |
| **Chatbot Arena Elo as your only prod monitor** | Great for model selection research; too slow/sparse for 50–70k sessions/day ops. |
| **Single “LLM quality” vendor score without versions** | Un-debuggable; fails the system-vs-judge fork. |
| **Treating RAGAS/DeepEval defaults as calibrated GT** | They are metrics libraries — still need gold + κ. |

---

## Reading order for a busy lead

1. Artefact voicebot post (domain feel)  
2. Netflix lifecycle Medium + skimming 2608.18300  
3. Who Drifted (2606.15474)  
4. Reporting paper (2511.21140)  
5. G-Eval + RAGAS as prompt/metric design references  
6. Langfuse + Promptfoo/DeepEval + Phoenix/Evidently docs as implementation manuals  

---

## Citation hygiene

When you publish internal RFCs, cite arXiv IDs and doc URLs with access dates. Do not attribute metrics from Netflix/Artefact posts to *your* system — those are their measurements, not yours.
