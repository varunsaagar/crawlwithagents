# Jev long-context: beating L1c and the road toward 90% (2026-10-11)

Scope: Gemma-4 E4B + Kairos typed-decision heads (pointer head), Noul / Choice / Score. **Qwen-based models are now allowed (org change).** Qwen deciders are included as candidate controls (see `Qwen-Decider-64K-128K-Options-2026-10-11.md`). Teachers: Gemini (gemini-3.7-flash reachable) or Opus. Everything marked **MEASURED** comes from your case study (kairos-report-2026-10-11) or from the toy runs here; **ESTIMATE** / **HYPOTHESIS** is mine.

---

## 1. Direct answer

**Do now (no training):**
1. **Promote `kairos-e4b-L1c-best` over `open275k-e4b`**, served with `attn: flex_attention` (its shipped `sdpa` needs ~90 GiB at 64K). Let both evals finish first; the 64K gap (0.283 → 0.348, noul 0.318 → 0.645) is wide enough that the order should hold.
2. **Route states >16K through chunked map-reduce with floor 0.80** (MEASURED 1.000 vs 0.115 single-pass on the 64K subset). Keep single-pass + relative-distance position compression for ≤16K (MEASURED +10 pp at 8K, +11 pp at 16K).
3. **Write an unconditional `last/` checkpoint, point dev at a long-context slice, and tear down NCCL before calibrate** (defects 7 and 8). Without these, nothing below can be measured.

**Is 90% reachable?** Not as one pooled number on the current eval, and not mainly through long-context work. The headline 8K accuracy is only **0.41**: 64K costs 4–7 points on top of a ~59-point gap that already exists at 8K. So the 90% problem is an **8K problem first**. Realistic targets, if the diagnosis in §2 holds:

| type | today (L1c / step15, 64K) | 4–6 week target, 8K | 4–6 week target, 64K (with chunking) | 90%? |
|---|---|---|---|---|
| Noul | 0.645 / 0.708 | 0.85–0.90 | 0.82–0.88 | **Plausible** for in-domain sources. Strands-decider reaches 0.96 noul on in-mix tasks but ~0.6 on unseen ones (their results.md) |
| Choice (≤26 options) | not split out | 0.75–0.85 | 0.70–0.80 | Only per-source, on narrow-label tasks |
| Choice (27–254 options) | not split out | 0.5–0.7 | same | **No**, unless a retrieve-then-rerank stage is added (§3) |
| Score | not split out | measure first: use ±1 accuracy / MAE | same | Exact-match 90% is unlikely on 5+ levels with noisy labels; ±1 accuracy 90% is plausible |

These are targets, not results. Report them per type and per source, never pooled.

**Where the 8K ceiling probably comes from** (to check in §2 before any training): (a) wide Choice questions (up to 254 options) dragging the pooled mean down, (b) label noise in the new long-data sources (churn, voice), (c) hard tasks, (d) mis-calibrated Noul (strands-decider measured noul ECE 0.162 while choice was 0.040). Your report also has an 8K figure of **0.765** in the α-sweep control against the **0.400** headline. Find out which subset that was. It tells you how much of the gap is the eval's composition rather than the model.

---

## 2. Diagnosis

### 2.1 Why 64K drops (what your data already shows)
- **Attention-mass dilution, not position.** The base passes 64K needle 1000/1000, position remap does nothing, and at 64K p_gold is exactly 1/8. E4B's long-range path is 4 KV-owning global layers that are 75% NoPE with a 188-token longest wavelength, so nothing separates "8,000 away" from "64,000 away". Softmax over 8× more keys spreads the same evidence mass 8× thinner. This is the mechanism SSMax (arXiv 2501.19399) and the log-n scaling in YaRN (arXiv 2309.00071) target.
- **The training data never contained many plausible distractors.** Kev-27B loses only 2.4 pp from 7.5K training to 64K, so training *length* buys little. What changes with length in your data is the **number and quality of distractors** that compete for the 4 global layers' attention.
- **The Noul sign-flip** (0.318 at 64K, flat across depth) is a calibration and bias failure, not decay. Strands-decider saw the same failure ("all 6 lost yes/no tasks flipped yes to no", research/history.md). Noul needs its own head bias and temperature per length bucket.

### 2.2 Why 8K is only ~0.41: hypotheses and the breakdown that tests each

| # | hypothesis | breakdown to run on the existing 1,552-state eval (no training) | what would confirm it |
|---|---|---|---|
| H1 | Wide Choice drags the mean | accuracy by option count bucket: 2 / 3–8 / 9–26 / 27–64 / 65–254, against chance (1/n) | ≥26-option buckets far below the others; pooled 0.41 is mostly them |
| H2 | Score is scored as exact match | Score: exact, ±1, MAE, Spearman, per level count | ±1 accuracy ≫ exact |
| H3 | Some sources are noisy or near impossible | accuracy by source (voice / OTel-Safety / churn / open_clinc…) × type; 50-item hand audit or Gemini relabel of the worst source | source-level accuracy ≤ chance, or a Gemini/gold disagreement rate >20% |
| H4 | Noul is biased, not blind | Noul recall-yes vs recall-no, mean P(yes), ECE, by length | big recall asymmetry; balanced accuracy with a re-fitted bias jumps |
| H5 | Calibration, not ranking | top-2 / top-5 accuracy and AUROC per type | top-5 ≫ top-1 means a reranker or 2nd stage helps |
| H6 | Head capacity / multi-question interference | accuracy by questions per state (1 / 2–8 / 9+) and by the question's position in the request | later or crowded questions worse |
| H7 | Evidence depth | accuracy by evidence depth band at 8K | middle worse means "lost in the middle" (arXiv 2307.03172), fixable by IN2-style data |
| H8 | Teacher ceiling | gemini-3.7-flash on 200 sampled 8K states, same options | if Gemini is also ~0.5, the ceiling is the labels or the task, not E4B |

H8 is the single most informative control. If a frontier teacher can't reach 0.9 on your 8K states, the student won't either, and the work is data cleaning, not modelling.

---

## 3. Techniques from research

Gains are from the cited papers' own settings unless noted. Expected gains for Jev are my estimate (**ESTIMATE**).

| technique | evidence | expected Jev gain | cost | applies to | source |
|---|---|---|---|---|---|
| **Chunked map-reduce + confidence floor** (route >16K) | MEASURED by you: 1.000 vs 0.115; Chain-of-Agents shows chunked workers beat full-context and RAG on long tasks | the biggest 64K win available now; needs a null-chunk-aware head (toy: §4) | inference ×(chunks); no training | all; Score needs mean/MAE aggregation, not max | [arXiv 2406.02818](https://arxiv.org/abs/2406.02818) |
| **Hard-distractor / evidence-anywhere training** (IN2, FILM-7B) | IN2: info-intensive synthetic training fixes lost-in-the-middle; FILM-7B is much flatter across positions | +5–15 pp at 32–64K (ESTIMATE), plus some at 8K | Gemini-labelled data; 1–2 training runs | all | [arXiv 2404.16811](https://arxiv.org/abs/2404.16811) |
| **Hard negatives in long inputs** | more retrieved passages *hurt* because of hard negatives; fixed by retrieval reordering and RAG-specific fine-tuning on noisy contexts | the "distractor quality" lever, same as IN2 | data | all | [arXiv 2410.05983](https://arxiv.org/abs/2410.05983) |
| **SSMax / log-n attention scaling** on global layers | SSMax: logits × s·log n, keeps attention focused as n grows; better length generalisation and key retrieval. YaRN uses 0.1·ln(s)+1 for the same reason | training-free try first (cheap); trained-in s on the 4 KV-owning layers if it moves anything | tiny | all | [arXiv 2501.19399](https://arxiv.org/abs/2501.19399), [arXiv 2309.00071](https://arxiv.org/abs/2309.00071) |
| **Positional-bias calibration** ("Found in the Middle") | calibrating out the U-shaped attention bias gives up to +15 pp on RAG | depth-band fix; your 8K depth breakdown decides | inference patch | all | [arXiv 2406.16008](https://arxiv.org/abs/2406.16008), Ms-PoE [arXiv 2403.04797](https://arxiv.org/abs/2403.04797) |
| **Query sandwich / re-reading** | putting the question before the document lets a causal model encode the document *conditioned on* the question; re-reading improves reasoning | small; must be trained in (toy §4) | prompt + retrain | all | [arXiv 2309.06275](https://arxiv.org/abs/2309.06275), [Anthropic long-context tips](https://docs.anthropic.com/en/docs/build-with-claude/prompt-engineering/long-context-tips) |
| **Query-aware compression** before the model | LongLLMLingua: question-aware coarse-to-fine compression, +21.4% on NaturalQuestions at ~4× fewer tokens | turns 64K into 8–16K; the same idea as your INDEX shortlisting | small model in front | all | [arXiv 2310.06839](https://arxiv.org/abs/2310.06839), InfiniPot [arXiv 2410.01518](https://arxiv.org/abs/2410.01518) |
| **Long-context data mix** (ProLong, Data-Engineering-128K) | ProLong: code + books as long sources mixed with high-quality short data; train *longer* than eval length; SFT on short data only is fine. Fu et al.: 1–5B tokens of length-upsampled, domain-balanced data is enough | keeps 8K from slipping while extending | 1 run | all | [arXiv 2410.02660](https://arxiv.org/abs/2410.02660), [arXiv 2402.10171](https://arxiv.org/abs/2402.10171) |
| **PoSE / LongAlign packing + loss weighting** | PoSE: simulate long positions inside short windows; LongAlign: packing with loss weighting, sorted batching | lower training cost for 64K (positions aren't your lever, so mainly cost) | low | all | [arXiv 2309.10400](https://arxiv.org/abs/2309.10400), [arXiv 2401.18058](https://arxiv.org/abs/2401.18058) |
| **Retrieval heads** | a small set of heads (<5%) does long-context retrieval; masking them kills NIAH | diagnostic: find E4B's retrieval heads, apply SSMax / temperature only there | analysis | all | [arXiv 2404.15574](https://arxiv.org/abs/2404.15574) |
| **Attention sinks** | the first tokens soak up attention mass; streaming keeps them | check the BOS sink share at 8K vs 64K; dilution may be sink-dominated | analysis | all | [arXiv 2309.17453](https://arxiv.org/abs/2309.17453) |
| **Sparse / block top-k attention** (NSA, MoBA) | trainable top-k block attention matches full attention at long length and is faster | in principle the clean fix for dilution; too invasive for E4B now (Phase 3) | high | all | [arXiv 2502.11089](https://arxiv.org/abs/2502.11089), [arXiv 2502.13189](https://arxiv.org/abs/2502.13189) |
| **Listwise reranking / tournament for many options** | RankGPT sliding-window listwise reranking | wide Choice: shortlist top-k options, then the pointer head over ≤26 | ×2 passes | Choice | [arXiv 2304.09542](https://arxiv.org/abs/2304.09542) |
| **Cross-encoder decider with tree mask** | tasksource-decider-nano: 150M ModernBERT-style cross-encoder, every option scored against the full state, state encoded once via a tree mask; Decision Index 30.90 | a cheap first-stage option ranker, or an option-isolation mask for the pointer head (strands notes ~0.016 order sensitivity) | small | Choice | [HF card](https://huggingface.co/tasksource/tasksource-decider-nano), ModernBERT [arXiv 2412.13663](https://arxiv.org/abs/2412.13663) |
| **Calibration per type × length bucket** | temperature scaling ([arXiv 1706.04599](https://arxiv.org/abs/1706.04599)); strands fits temperature per type (noul ECE 0.162 vs choice 0.040) | fixes the Noul sign-flip and makes the floor-0.80 router honest | trivial | Noul especially | [strands-decider results.md](https://github.com/strands-labs/strands-decider) |
| **KL anchor + seed soup** | strands-decider v1: KL to previous release (0.3), 3-seed soup ≥ seed mean on most measures, Brier 0.294 → 0.280 | +0.5–2 pp, better calibration | 3× training | all | [strands-decider](https://github.com/strands-labs/strands-decider), Model soups [arXiv 2203.05482](https://arxiv.org/abs/2203.05482) |
| **Teacher distribution targets, gold-filtered** | strands v1 trains on gemma-4-31B distributions only where the teacher agrees with gold | label-noise fix for H3 | teacher calls | all | strands-decider results.md |
| **Self-distil chunked → single-pass** | (my proposal) chunked map-reduce scores 1.000 where single-pass scores 0.115; use its outputs as soft targets at 32–64K | brings native 64K toward chunked accuracy without the inference cost | 1 run | all | — |

**Top five for you, in order (updated with the toy results):** (1) per-type/per-source/option-count breakdown and a Gemini teacher-ceiling check; (2) Noul bias plus temperature per type × length bucket; (3) chunk-trained head (null chunks) + trained query sandwich, then distilled into single-pass; (4) a curriculum of hard distractors with Gemini-labelled hard negatives at 8–16K, ramped from easy; (5) retrieve-then-pointer for Choice >26 options. SSMax / attention temperature drops to a cheap disqualifier (null in the toy).

---

## 4. Toy experiments (CPU proxy, NOT E4B)

Setup (details in `jev-longctx-experiments/README.md`, tables in `RESULTS.md`): a 4-layer causal transformer with a **pointer head**, trained from scratch on synthetic states with evidence records, distractor records and filler. Trained at length 64, tested at 64→512 (8×, the same ratio as 8K→64K), with distractors growing with length (k = L/16). n = 200–300 items per cell, 95% CIs, seed 0 for every variant and seed 1 for base. **These are toy proxies, not E4B results. Trust the direction, not the size.** A first attempt with zero-shot SmolLM2-360M/1.7B was at or below chance on Choice even at 512 tokens, so it was dropped (`zeroshot_lm_probe.py`).

| finding | numbers (Noul / Choice / Score) | implication for Jev |
|---|---|---|
| **The toy reproduces your length decay** | base s0: L64 0.96 / 0.61 / 0.36 → L512 0.65 / 0.24 / 0.18; s1: 0.95 / 0.68 / 0.44 → 0.60 / 0.27 / 0.25 | the proxy behaves like E4B at 8K→64K |
| **(d) Distractors and length both hurt; distractors hurt Choice more** | fixed L=64, k 2→30: Choice 0.80 → 0.27, Noul 0.95 → 0.65. Fixed k=4, L 64→512: Choice 0.61 → 0.48, Noul 0.96 → 0.71 | supports your "distractor number is the lever" for Choice; for Noul, dilution from length alone also matters |
| **(c) Training-free log-n temperature: no effect** | L512: τ=1 0.64 / 0.26 / 0.23 vs single 0.65 / 0.24 / 0.18 (within CI) | E2 is a cheap disqualifier and is likely to come back null; run it only because it costs ~3 GPU-h |
| **(c) Trained SSMax scalar: no gain** | L512 0.59 / 0.24 / 0.22 vs base 0.60–0.65 / 0.24–0.27 / 0.18–0.25 | move E8 down; don't expect SSMax alone to fix dilution |
| **(a) Naive chunked map-reduce *hurts* without null-chunk training** | L512 chunk_max 0.45 / 0.23 / 0.23; Noul collapses to ~0.5 at every length >64 | chunks with no evidence give confident garbage. Your 1.000 result relies on the 0.80 floor, which was calibrated per pod. **E6 (train with evidence-absent chunks) is required** before map-reduce is safe to use widely; keep the floor and monitor abstentions |
| **(b) Query sandwich: large gain at training length, faster decay** | L64 0.93 / **0.88** / **0.68** vs 0.96 / 0.61 / 0.36; L512 0.47 / 0.19 / 0.23 | sandwich must be **trained in**, and combined with chunking (each chunk ≤ training length) it gives the best of both. This makes sandwich + chunk-trained a top candidate |
| **(e) Option count is steep** | Choice at L64: 2→0.96, 4→0.82, 8→0.61, 16→0.42, 31→0.18 | wide Choice (up to 254) will dominate pooled error, so a shortlist or tournament is needed (E4) |
| **Hard-distractor or length training from scratch didn't train** | hard_distract (k 6–30) and length_mix stayed at chance (Noul ~0.5, Choice ~0.12) after 3,000 steps | a toy optimisation failure, not evidence against IN2. The lesson is to **curriculum the distractors** (start easy, ramp k) and to start from L1c, not from scratch |


---

## 5. Pre-registered experiment ladder on your stack (start: E4B L1c)

Sample-size rule from the 1,552-state eval: a paired McNemar test on n items detects a Δ of about 2.8·sqrt(p_disc/n). With ~30% discordant pairs: n=1,552 → ~4 pp; n=460 (paired 4-rung subset) → ~7 pp. So **any claim under 4 pp at 64K needs the full eval plus a second seed.** Every rung reports per type × source × option-count × length, never pooled.

| # | experiment | hypothesis | change | eval / n | decision rule | GPU-h |
|---|---|---|---|---|---|---|
| E0 | **Breakdown + teacher ceiling** (disqualifying control) | the 8K gap is mostly wide Choice, Score scoring, and noisy sources (H1–H3, H8) | none: re-slice saved predictions; Gemini-3.7-flash on 200 8K states | existing predictions; 200 for Gemini | if Gemini <0.7 on a source → relabel or drop that source before any training; if wide-Choice ≥ half the error → E4 before E5 | ~0 (+ API) |
| E1 | **Noul bias + temperature per (type × length bucket)** | Noul at 64K is biased, not blind | fit bias b and temperature T on a 30% calibration split, per bucket | 70% held-out Noul | ship if balanced accuracy +≥5 pp at 64K and ECE ≤0.05 per bucket with no 8K loss | ~0.5 |
| E2 | **Training-free attention-temperature (SSMax-style) sweep** | dilution is fixable at inference on the 4 KV-owning global layers | logits × (log n / log 8192)^τ, τ ∈ {0.25, 0.5, 1}, global layers only | 460 paired, then 1,552 | carry on only if +≥4 pp at 64K and ≤1 pp loss at 8K; otherwise drop (cheap disqualifier) | ~3 |
| E3 | **Query sandwich at inference** | the pointer query reads evidence better when the question comes first | duplicate the question block before `<state>` | 460 paired | the toy says a trained sandwich gives big gains at training length (Choice +27 pp) but decays faster; untrained sandwich is expected ≈0 → fold the trained version into E6 (sandwich in every chunk) | ~2 |
| E4 | **Retrieve-then-pointer for Choice >26** | wide Choice is ranking, not reading | stage 1: score options with the E4B pointer head in windows of 26 (tournament, top-2 advance) or tasksource-style cross-encoder; stage 2: pointer over ≤26 | Choice ≥27 options only | ship if +≥10 pp on that bucket | ~4 |
| E5 | **Hard-distractor curriculum at 8–16K (IN2/FILM style)** | the lever is distractor number and quality, not max_len | 30–50K rows: real states with **Gemini-generated hard negatives** (same entity, near-miss values, contradicting older records), evidence depth uniform; 25% short replay; KL 0.3 to L1c | full 1,552 + length sweep | ship if 64K +≥4 pp **and** 8K ≥ L1c−1 pp, 2 seeds agree | ~40 |
| E6 | **Chunk-trained head + trained sandwich** | chunked inference fails on null chunks unless trained on them (toy: Noul collapses to 0.5) | question before and after each 8–16K chunk; add evidence-absent chunks with target "abstain/low confidence" (Noul: calibrated 0.5; Choice: uniform) | 64K subset through map-reduce | ship if map-reduce accuracy on 64K ≥ floor-0.80 result with fewer abstentions | ~20 |
| E7 | **Self-distil map-reduce into single-pass** | single-pass at 64K can learn what chunked computes | soft targets from chunked inference on 10–20K long states; KL loss at 32–64K | full eval, single-pass | ship if single-pass 64K closes ≥50% of the gap to map-reduce | ~40 |
| E8 | **Trained SSMax scalar on global layers** | a learned s·log n focuses attention at length | add 1 scalar per head on 4 KV-owning layers, train with E5 data | full eval | keep only if it beats E5 alone by ≥3 pp at 64K | ~40 |
| E9 | **Seed soup (3 seeds) + KL anchor** | soups improve calibration and robustness | 3 seeds of the best recipe, average LoRA deltas, refit temperature | full eval | ship if soup ≥ best single seed on 64K and Brier | ~80 |
| E9b | **Qwen-decider controls (now allowed)** | a stronger or longer-trained decider base beats E4B at 8K and 64K | score `perplexity-ai/pplx-decider-v1.1-27b` zero-shot, plus small Qwen deciders (strands-decider-2B-qwen3.5, Mapika/decider-4b, APUS-OpenJev-v1-4B) on the 1,552-state eval at 8K–64K, same harness | full eval | if pplx-27B ≥ L1c+8 pp at 8K → use it as teacher or as the 64K tier (recipe in Qwen-Decider-64K-128K-Options doc); a small Qwen ≥ L1c → candidate E4B replacement | ~10–20 |
| E10 | **26B-A4B control** | capacity limits 8K accuracy | same data as E5 on gemma-4-26B-A4B | full eval | only worth it if 8K jumps ≥8 pp over E4B at matched data | ~120 |

Order: E0 → E1 → E9b (Qwen controls, eval only) → E2/E3 (cheap disqualifiers, run together) → E4 → E6 (chunk-trained + sandwich) → E5 → E7 → E8/E9 → E10. Total ≈ 350 GPU-hours if every rung runs; E0–E4 cost under 10.

Operational rules from your case study: an unconditional `last/`; dev = a 64K slice of held-out data, not open_clinc; never report pooled loss on bimodal batches (split by regime); reconcile rows × questions × steps before reading a dashboard.

---

## 6. Landscape

**Leaderboard (Hard-Decisions, ProofWriter, 1,800 items per task; [hard-decisions.anth.us/models](https://hard-decisions.anth.us/models), scored 2026-10-09):** Jev 1.13 (TypeSafe, hosted) open-world 83.8% / closed-world 89.3%; GLiDE (Fastino, "thinking" decision model) 82.9/71.8 on Oct 2 and 76.4/68.8 on the Oct 3 rerun; GPT-6 Luna as classifier 64.1/65.0; Kev-9B 58.6/63.8; Kev-4B 53.6/58.8; GLiNER2.5-Decide 32.8/50.3; Laya 42.4/55.6. Kev-27B (full fine-tune on Qwen3.8-27B) was not run. These are short-state reasoning results: **no public leaderboard measures typed decisions at 64K.** Jev's lead is largest at proof depth 5, i.e. on multi-step reasoning, not context length.

**Open recipes:** strands-decider (pointer head, LoRA, KL to previous release, 3-seed soup, gemma-4-31B distributions filtered on gold, per-type temperature; trained at 4K); Kev (pointer head + rank-16 LoRA on frozen Qwen3.5; reference only); pplx-decider-v1-27b (Qwen, now allowed); tasksource-decider-nano (cross-encoder with tree mask, 8K context).

**Hugging Face decision-model releases, last 60 days (API search 2026-10-11):**

| model | base | updated | context / notes |
|---|---|---|---|
| [StrandsAgents/strands-decider-{E2B,E4B,12B,26B-A4B}-gemma4-v1-2610](https://huggingface.co/StrandsAgents/strands-decider-26B-A4B-gemma4-v1-2610) (mirrored under `amazon/`) | google/gemma-4-*-it, Apache-2.0 | 2026-10-09 | trained at 4K; 26B: 207/231 JevBench (prior doc) |
| [StrandsAgents/strands-decider-2B-qwen3.5-v1-2610](https://huggingface.co/StrandsAgents/strands-decider-2B-qwen3.5-v1-2610) | Qwen3.5 (now allowed) | 2026-10-09 | JevBench 180/231, Brier 0.280 |
| [tasksource/tasksource-decider-nano](https://huggingface.co/tasksource/tasksource-decider-nano) | ettin-reranker-150m (ModernBERT-style) | 2026-10-11 | 8,192 ctx; Decision Index 30.90; median 52 ms on A10 |
| [BricksDisplay/jevling-e2b-v1](https://huggingface.co/BricksDisplay/jevling-e2b-v1) (+ 0.8B, GGUF) | gemma-4-E2B-it | 2026-10-11 | letter-logit readout, up to 52 options |
| [systemonedev/kenning-large-v0.6](https://huggingface.co/systemonedev/kenning-large-v0.6) | ModernBERT-large-nli | 2026-10-09 | zero-shot classifier |
| [mondk/Gemma-1B-Jev-Decision-Classification-SystemOne](https://huggingface.co/mondk/Gemma-1B-Jev-Decision-Classification-SystemOne) | gemma-3-1b-pt | 2026-10-11 | small hobby release |
| [att/OTel-2.0-Decision-26B-A4B-4bit](https://huggingface.co/att/OTel-2.0-Decision-26B-A4B-4bit) | gemma-4-26B-A4B-it | 2026-10-11 | 4-bit decision model |
| StartLux-Decision-v1 2B/4B/27B/35B-A3B (GGUF via mradermacher) | Qwen-derived (per your case study), cc-by-nc-4.0 on 4B | 2026-10-11 | "262K context" is an inherited config value, not evaluated (your report) |
| [perplexity-ai/pplx-decider-v1.1-27b](https://huggingface.co/perplexity-ai/pplx-decider-v1.1-27b) | Qwen (now allowed) | 2026-10-09 | control candidate; see Qwen-Decider doc |
| [Mapika/decider-4b](https://huggingface.co/Mapika/decider-4b), [apus-ailab/APUS-OpenJev-v1-4B](https://huggingface.co/apus-ailab/APUS-OpenJev-v1-4B) | Qwen3.5 | recent | small Qwen deciders, evals unverified |
| [flymy-ai/decision-4b-v1.6](https://huggingface.co/flymy-ai/decision-4b-v1.6) | Qwen3.5-4B | 2026-10-11 | — |
| [jaredpalmer/kev-27b](https://huggingface.co/jaredpalmer/kev-27b) | Qwen3.8-27B (now allowed) | 2026-10-01 | full fine-tune |
| Decision Index leaderboard space | — | — | [multimodalart/jev-decision-index](https://huggingface.co/spaces/multimodalart/jev-decision-index) |

None of these publishes a typed-decision evaluation at 32–64K. Your length-sweep harness is ahead of the public state of the art on measurement.

---

## 7. Sources
All arXiv titles were verified against arxiv.org on 2026-10-11.
- SSMax: Scalable-Softmax Is Superior for Attention, https://arxiv.org/abs/2501.19399
- YaRN, https://arxiv.org/abs/2309.00071
- Lost in the Middle, https://arxiv.org/abs/2307.03172
- Found in the Middle (Ms-PoE), https://arxiv.org/abs/2403.04797
- Found in the Middle: Calibrating Positional Attention Bias, https://arxiv.org/abs/2406.16008
- Make Your LLM Fully Utilize the Context (IN2 / FILM-7B), https://arxiv.org/abs/2404.16811
- PoSE, https://arxiv.org/abs/2309.10400
- LongAlign, https://arxiv.org/abs/2401.18058
- How to Train Long-Context Language Models (Effectively) (ProLong), https://arxiv.org/abs/2410.02660
- Data Engineering for Scaling Language Models to 128K Context, https://arxiv.org/abs/2402.10171
- LongLLMLingua, https://arxiv.org/abs/2310.06839
- InfiniPot, https://arxiv.org/abs/2410.01518
- Native Sparse Attention, https://arxiv.org/abs/2502.11089
- MoBA, https://arxiv.org/abs/2502.13189
- Attention Sinks (StreamingLLM), https://arxiv.org/abs/2309.17453
- Retrieval Head, https://arxiv.org/abs/2404.15574
- RankGPT, https://arxiv.org/abs/2304.09542
- ModernBERT, https://arxiv.org/abs/2412.13663
- Re-Reading, https://arxiv.org/abs/2309.06275
- Long-Context LLMs Meet RAG (hard negatives), https://arxiv.org/abs/2410.05983
- On Calibration of Modern Neural Networks, https://arxiv.org/abs/1706.04599
- Chain of Agents, https://arxiv.org/abs/2406.02818
- Model soups, https://arxiv.org/abs/2203.05482
- Hard-Decisions leaderboard, https://hard-decisions.anth.us/models
- strands-decider, https://github.com/strands-labs/strands-decider (local clone: evaluation/results.md, research/history.md, docs/architecture.md)
- Hugging Face model pages listed in §6
- Your case study: kairos-report-2026-10-11.pdf
- Qwen-Decider-64K-128K-Options-2026-10-11.md (Qwen candidates and the pplx-27B 64K recipe)

## Uncertain
- The 0.765 vs 0.400 8K discrepancy in the case study: which subset or metric is it?
- Whether pooled 0.41 includes Score exact-match and wide Choice. E0 answers this.
- The toy model is a 4-layer transformer trained from scratch. Its direction of effect can transfer, but its size of effect cannot.
- No public typed-decision benchmark at 64K exists, so every 64K target here is an extrapolation.
