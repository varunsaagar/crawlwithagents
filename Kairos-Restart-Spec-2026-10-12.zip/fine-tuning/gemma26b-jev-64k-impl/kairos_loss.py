"""Additive, config-flagged loss swap for the EXISTING Kairos trainer.
Forward pass and choice-invariant head are untouched: this only consumes the head's masked logits.
All flags default to 0 -> returns exactly F.cross_entropy(logits, labels) (bit-for-bit, same op).

cfg.loss.label_smoothing  (float, 0)   smoothing over VALID options only
cfg.loss.brier_w          (float, 0)   + w * multiclass Brier
cfg.loss.kl_w             (float, 0)   + w * KL(p || p_ref); p_ref from LoRA-disabled forward, same packed input
cfg.loss.ordinal_eps      (float, 0)   Score questions: eps mass on adjacent levels
"""
import torch, torch.nn.functional as F
from contextlib import nullcontext
from losses import smoothed_ce, brier, kl_to_ref, ordinal_soft_target

def kairos_loss(logits, labels, task, cfg, ref_logits=None, SCORE=2):
    ls = float(getattr(cfg, "label_smoothing", 0) or 0); bw = float(getattr(cfg, "brier_w", 0) or 0)
    kw = float(getattr(cfg, "kl_w", 0) or 0); oe = float(getattr(cfg, "ordinal_eps", 0) or 0)
    if ls == 0 and bw == 0 and kw == 0 and oe == 0:
        return F.cross_entropy(logits, labels)                       # == today's run, unchanged op
    mask = torch.isfinite(logits)
    lp = F.log_softmax(logits.float(), -1).masked_fill(~mask, 0.0)
    K = logits.shape[-1]; k = mask.sum(-1).clamp_min(1).float()
    tgt = F.one_hot(labels, K).float()
    if oe > 0 and (task == SCORE).any():
        sc = task == SCORE; tgt[sc] = ordinal_soft_target(labels[sc].cpu(), mask[sc].cpu(), oe).to(tgt.device)
    if ls > 0: tgt = (1 - ls) * tgt + ls * mask.float() / k[:, None]
    loss = -(tgt * lp).sum(-1)
    if bw > 0: loss = loss + bw * brier(logits, labels, mask)
    if kw > 0:
        assert ref_logits is not None, "loss.kl_w>0 needs ref_logits"
        loss = loss + kw * kl_to_ref(logits, ref_logits.detach(), mask)
    return loss.mean()

def ref_logits_lora_disabled(net, packed):
    """Frozen-base reference on the SAME packed input. Under ZeRO-3 this is a collective forward:
    call it on ALL ranks, every step where kl_w>0. Head is shared (no grad); only LoRA is switched off."""
    ctx = net.backbone.disable_adapter() if hasattr(net.backbone, "disable_adapter") else nullcontext()
    with torch.no_grad(), ctx:
        logits, _ = net(packed)
    return logits
