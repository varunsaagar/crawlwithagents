# Calibration Studio

The Calibration Studio packages the whole workflow in a browser UI and an HTTP API. It takes uploaded traces, picks or converts rubrics, runs every tier and the reference, certifies thresholds, and exports copy-paste code. The same workflow is available as a library (`jevjudge.studio.Project`).

```bash
uv pip install -p .venv/bin/python -e ".[studio,vertex]"
set -a; . ./.env; set +a
jevjudge serve --port 8000          # or: uvicorn jevjudge.server.app:app
# open http://127.0.0.1:8000/
```

Projects are stored under `$JEVJUDGE_HOME` (default `~/.jevjudge/projects/<project-id>/`).

## The six steps

The UI is a stepper. Each step corresponds to one or two API calls (full reference in [HTTP API](../reference/http-api.md)).

### 1. Project

A project holds one set of traces, one judge definition and its certificates. Open an existing project or create a new one.

![Project step](../img/studio-1-project.png)

```bash
curl -s -X POST localhost:8000/v1/projects -H 'Content-Type: application/json' -d '{"name": "voice-qa"}'
# -> {"id": "voice-qa-1a2b3c", "name": "voice-qa", "status": "created", ...}
```

### 2. Traces (and optional labels)

Upload the conversations to calibrate on. The format is detected from the file, and uploading several files appends them. Supported formats:

* OTLP JSON (an envelope or a list of envelopes);
* BigQuery rows with `spans_json` / `all_spans_data`;
* JSONL of `Session` objects or `{session: {...}}`;
* JSON(L) with `{session_id, transcript|turns|messages: [...]}`;
* CMCS rows with `prod_transcript`;
* CSV with `session_id,speaker,text[,turn]`.

**Human labels** are optional: a CSV or JSONL with `session_id,metric,label`, where `label` is `1/0`, `true/false`, `violation/clean`, `fired` or `fail`. With at least 50 labelled sessions per metric (the Studio's `min_n`), the certificate is checked against your labels (`parity_gold`). Otherwise it is checked against agreement with the reference judge (`parity_ref`).

![Traces step](../img/studio-2-traces.png)

```bash
curl -s -F file=@sessions.jsonl localhost:8000/v1/projects/$PID/traces     # -> {"added": 120, "total": 120}
curl -s -F file=@labels.csv     localhost:8000/v1/projects/$PID/labels     # -> {"added": 240}
```

### 3. Judge definition

Each metric becomes a rubric. You can **convert** your current LLM-judge prompt (see [Convert an LLM judge](convert-llm-judge.md)) or **start from a preset** (`voice`, `voice_decomposed`). Applying a preset overwrites rubrics with the same id. Rubrics can be edited as YAML in the browser; they are validated on save, and the new revision is shown.

![Judge definition step](../img/studio-3-judge.png)

Invalid YAML is rejected on save, with the validation error shown inline:

![Rubric YAML validation](../img/studio-3-yaml-validation.png)

```bash
curl -s -X POST localhost:8000/v1/projects/$PID/preset -H 'Content-Type: application/json' -d '{"name": "voice"}'
curl -s -X POST localhost:8000/v1/projects/$PID/convert -H 'Content-Type: application/json' \
     -d "{\"prompt\": $(jq -Rs . < judge_prompt.txt), \"llm\": \"gemini-3.8-flash\"}"          # -> job
curl -s localhost:8000/v1/projects/$PID/rubrics/output_pii                                  # YAML
```

### 4. Run

Every selected System One tier and the reference judge answer every verdict question on every session (`mode="calibrate"`). Every probability is kept in `board.jsonl`, so calibration can be re-run at any ε without new model calls. Re-running skips sessions that are already on the board.

![Run step](../img/studio-4-run.png)

```bash
curl -s -X POST localhost:8000/v1/projects/$PID/run -H 'Content-Type: application/json' \
     -d '{"tiers": ["kairos-jev", "djev"], "reference": "gemini-3.8-flash", "limit": 200}'   # -> {"id": JOB, ...}
curl -s localhost:8000/v1/jobs/$JOB                                                       # {"status", "done", "total"}
```

### 5. Calibrate

Pick the tolerance **ε** (maximum accuracy loss vs the reference, in percentage points) and the risk **δ** (the chance that the guarantee fails on new traffic). With **Stack tiers** on and two or more tiers, the Studio first fits a per-metric logistic combiner (`combiner.json`) and certifies the combined `jev-stack` signal. The result per metric is a certificate (θ, the share answered by Jev, the mode) plus risk–coverage curves for the chart. Each certificate is proposed into the project's `certificates.json` and approved automatically as `studio:auto`. To require a named approver, calibrate from Python with `Project.calibrate(..., approve_as=None)` and approve over HTTP (see [Governance](governance.md#over-http-calibration-studio)). The minimum is 50 sessions per metric with a reference verdict.

![Calibrate step](../img/studio-5-calibrate.png)

Each metric gets a card with the certified θ, the cascade accuracy, the gap to the reference, the cost per 1k sessions, the split of who answers, and a risk–coverage chart per tier. With too few sessions (as in this 6-session demo), the card says "Escalate all: too few sessions", and every verdict goes to the fallback:

![Calibration certificate cards](../img/studio-5-calibrate-cards.png)

```bash
curl -s -X POST localhost:8000/v1/projects/$PID/calibrate -H 'Content-Type: application/json' \
     -d '{"eps": 0.03, "delta": 0.05, "stack": true}'
```

### 6. Export

The export step writes `judge.yaml` into the project, with `threshold: certified`, the project's registry and monitor state, `audit_rate: 0.05`, and a review queue (`review_queue.jsonl`, `audit_rate: 0.02`). It returns copy-paste snippets: `python` (async), `python_sync`, `langgraph`, `curl` and `judge_yaml`. **Try it** posts a trace to `/v1/judge` with this project.

![Export step](../img/studio-6-export.png)

```bash
curl -s "localhost:8000/v1/projects/$PID/export?base_url=http://localhost:8000" | jq -r .python
curl -s -X POST localhost:8000/v1/judge -H 'Content-Type: application/json' \
     -d '{"project": "'$PID'", "trace": {"session_id": "s1", "turns": [{"speaker": "user", "text": "cancel my add-on"},
          {"speaker": "agent", "text": "Done, the add-on is removed."}]}}'
```

!!! note "Reloading certificates"
    The server caches one grader per project for `/v1/judge`. `POST /v1/projects/{id}/calibrate` drops that cache and re-exports `judge.yaml`, and certificate approve and rollback drop it too, so the next `/v1/judge` call serves the new certificates. Other processes that loaded the old `judge.yaml` need to reload it.

## After export: review and drift

`/v1/judge` traffic for a project fills the project's [review queue](review-queue.md#in-the-calibration-studio) and its [drift statistics](monitoring.md#drift-statistics) (`GET /v1/projects/{id}/drift`). Label review items, import them as gold labels with `POST /v1/projects/{id}/review/import`, and re-calibrate.

## The same workflow in Python

```python
import asyncio
from jevjudge.studio import Project

p = Project.create("voice-qa", root="/tmp/jevjudge-projects")
p.add_traces("sessions.jsonl")                       # any supported format; returns the number added
p.add_labels("labels.csv")                           # optional gold
p.use_preset("voice")                                # or: await p.convert_prompt(open("judge_prompt.txt").read())
asyncio.run(p.run(tiers=["kairos-jev", "djev"], reference="gemini-3.8-flash"))
report = p.calibrate(eps=0.03, delta=0.05, min_n=50, stack=True)
for metric, m in report["metrics"].items():
    print(metric, m["certificate"]["mode"], m["certificate"]["thetas"])
bundle = p.export()                                  # {"python", "python_sync", "langgraph", "curl", "judge_yaml"}
```

Files in a project directory:

| File | Written by |
|---|---|
| `project.json` | create / run / calibrate (`tiers`, `reference`, `status`) |
| `sessions.jsonl` | `add_traces` (deduplicated by `session_id` on read) |
| `labels.json` | `add_labels` |
| `rubrics/*.yaml`, `judge_prompt.txt`, `convert_log.txt` | `use_preset`, `save_rubric`, `convert_prompt` |
| `board.jsonl` | `run` (retained probabilities per session, tier and metric) |
| `combiner.json`, `certificates.json`, `report.json` | `calibrate` (`certificates.json` also by approve / rollback) |
| `judge.yaml`, `export.json` | `export` |
| `monitor_state.json` | the exported judge in production |
| `review_queue.jsonl` | the exported judge (enqueued items) and review labels |
| `review_labels.csv` | `import_review_labels` |

!!! note "Studio calibration vs serving"
    During `run`, the reference judge answers exactly as it will in production: as System Two, with each criterion's `fallback_instructions`, verdict only. The certificate therefore describes the cascade you deploy.
