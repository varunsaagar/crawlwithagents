# Inkling 2 Mini on H100: porting the Blackwell FP4 MoE path to Hopper

Status: design plus a starter kernel. **Nothing here has been run on a GPU.** Every number below is
either quoted from a named source or derived by arithmetic and labelled as such. No benchmark
numbers are invented.

## 0. TL;DR

- Hopper (sm_90) has **no FP4 tensor cores**, so a B200 NVFP4 kernel cannot be "ported" as is. What
  ports is the *storage format*, the *routing/permute/combine logic* and the *determinism
  discipline*; the MMA has to change.
- Recommended: **keep NVFP4 weights in HBM, dequantise exactly in registers to BF16, and run BF16
  WGMMA (W4A16)**. This is what vLLM's own Inkling Hopper path already does via Humming, so step one
  is to measure that, and only write a kernel for the gaps it leaves.
- The gaps worth a custom kernel: a **fused, persistent decode MoE block** (route → align → w13 →
  softcapped SwiGLU → w2 → combine) to cut launch and glue cost over **48 expert visits per token**;
  **bitwise batch invariance** without paying for it in stream-K being switched off; small-M tile
  shapes for the 1152-wide experts.
- Effort (judgement, not measured): **3–4 engineer-weeks** to a measured go/no-go; **9–12
  engineer-weeks** to a production CUTLASS/WGMMA kernel integrated in vLLM with CI.
- An **autokernel-style search loop** (section 9, `autokernel/`) automates the variant search
  with hard anti-reward-hacking guardrails.

## 1. What ports from Blackwell and what doesn't

| Piece | B200 (sm_100) | H100 (sm_90) | Ports? |
|---|---|---|---|
| NVFP4 weights (e2m1 + E4M3 block-16 scale + fp32 global) | native FP4 MMA (tcgen05) | no FP4 MMA | Storage yes, compute no |
| MXFP8 weights (layers 20–23; e4m3 + UE8M0 block-32) | native block-scaled MMA | FP8 WGMMA, but **no block-scale hardware** | Partly: scales applied in software |
| Block-scaled MMA instructions | yes | no | No |
| TMA, warp specialisation, clusters | yes | yes (introduced on Hopper) | Yes |
| TMEM, 2-CTA MMA | yes | no | No; accumulators live in registers |
| Routing, top-8, align/permute, combine | software | software | Yes, unchanged |
| Batch-invariant fixed-order reductions (RightNow AI) | discipline | discipline | Yes, fully |

Numerics note (own reasoning, check before relying on it): an e2m1 value times an E4M3 scale has at
most 2 + 3 significant bits, so it is **exactly representable in BF16**. Dequant-to-BF16 is therefore
lossless; the fp32 global scale belongs in the fp32 epilogue. This is why W4A16 is the faithful
Hopper equivalent.

## 2. The three options

| | (a) W4A16: NVFP4 → BF16 in registers, BF16 WGMMA | (b) Offline NVFP4 → FP8 E4M3 requant, FP8 WGMMA (DeepGEMM-style) | (c) Keep NVFP4 in HBM, dequant to FP8 on load, FP8 WGMMA |
|---|---|---|---|
| Accuracy | Exact weights; BF16 activations as the model was served elsewhere | **Lossy**: e2m1×E4M3 needs more mantissa than e4m3 has; block-16 scales must be re-blocked to DeepGEMM's 128-channel scaling | Lossy in-flight; same scale-granularity mismatch; activations also need FP8 quantisation |
| HBM bytes (derived) | 0.5625 B/param | ~1.03 B/param (≈ **1.8×**) | 0.5625 B/param |
| Expert memory, layers 0–19 (derived) | ≈ 11.5 GB | ≈ 21.0 GB | ≈ 11.5 GB |
| Decode (bandwidth-bound) | best: fewest bytes | worst: ~1.8× bytes | as (a) |
| Prefill (compute-bound) | BF16 WGMMA peak | FP8 WGMMA peak, about 2× BF16 on spec sheets | FP8 peak, minus dequant cost |
| Fit with block-16 scales | scale applied per 16-wide k chunk before the MMA, simple | needs re-blocking | block-16 vs FP8 wgmma k=32 step: scale must be applied before the MMA, so no saving over (a) |
| Existing kernels | Humming (vLLM Inkling path), Marlin MoE, CUTLASS ex. 69 (row-wise scales only) | DeepGEMM SM90 grouped (contiguous/masked) | none found |

Derived arithmetic (not measured): per expert, w13 + w2 = 3 × 2304 × 1152 ≈ 7.96 M params, i.e. ≈
4.48 MB in NVFP4, ≈ 8.21 MB in MXFP8. A batch-1 decode step touches 8 experts per visit; with 44
NVFP4 visits and 4 MXFP8 visits that is ≈ **1.84 GB of expert weights per token**, a floor of ≈
**0.55 ms** at the 3.35 TB/s H100 SXM spec-sheet bandwidth, single GPU, before attention and dense
weights. Under TP/EP this divides across GPUs.

**Verdict:** (a) for decode, always. (b)/(c) only as an *optional prefill path* behind the accuracy
gate in section 10, and only if profiling shows prefill expert GEMMs dominate.

## 3. Recommended path

Use option (a), **Humming-first**. Step one is to profile vLLM's existing Inkling Hopper path (Humming
indexed W4A16, PR #68761) at Mini shapes on H100, with and without `VLLM_BATCH_INVARIANT`. Write custom
code only where that profile shows a gap. The likely gaps are a fused, persistent decode MoE
block; deterministic, batch-invariant reductions that don't cost what disabling stream-K costs; and
small-M tiles for 1152-wide experts. If Humming already sits near the derived bandwidth floor at
decode, stop: the effort is better spent on the scheduler, attention, or speculative decoding.

What PR #68761 reports (quoted, H200 rather than H100, Inkling **Small** rather than Mini, TP4):
1.48× end-to-end at concurrency 1 and 2.71× at concurrency 64 over the previous Triton path, and
1.4–2.6× per GEMM at 1–32 tokens. Stream-K is disabled for determinism, which the PR puts at about
15 µs per layer at tiny M. These are not H100 or Mini numbers.

## 4. Kernel design (starter in `kernels/moe_wq_gemm_triton.py`)

Dataflow (see `kernel_dataflow.png`):

```
router logits ─► softmax ─► top-8 ─► renorm ×8 ─► align (stable sort by expert, pad to BLOCK_M)
x [T,2304] bf16 ─► gather rows (row // top_k, fused in the A load)
w13 NVFP4 ─► TMA/ld ─► unpack nibbles ─► e2m1 LUT × E4M3 block-16 scale ─► BF16 (exact) ─► WGMMA (fp32 acc)
          ─► epilogue: × fp32 global scale ─► BF16 h ─► softcapped SwiGLU (gate/up interleaved) ─► BF16 act
w2  NVFP4 ─► same mainloop ─► epilogue: × global scale × routing weight ─► scatter to [T,8,2304]
combine: fixed j = 0..7 order, fp32 accumulate ─► BF16 out
```

Starter-kernel facts:
- Triton, one kernel per GEMM, grid = (aligned row blocks, N tiles). Gather fused into the A load,
  routing weight and scatter fused into the w2 epilogue.
- Exact decoders via exponent-bit construction (no `ex2.approx`).
- Constant tile config (BLOCK_M=16, BLOCK_N=64, BLOCK_K=64): **no per-batch autotuning**, which would
  break batch invariance.
- No split-K, no atomics. Combine uses a fixed order in fp32.
- SwiGLU is still in torch: the next step is to fuse it into the w13 epilogue.
- The Triton version is for correctness and search. The production target is CUTLASS 3.x / CuTe
  with TMA, warp-specialised producer/consumer and `wgmma.mma_async`, because Triton's control over
  the register-dequant pipeline on sm_90 is limited.

Layout assumptions (**verify against the real checkpoint**): packed uint8 `[E, N, K/2]` with the low
nibble as the even k; scales uint8 `[E, N, K/16]`; global scale fp32 `[E]`; gate rows before up
rows after de-interleave; softcap value is a parameter.

## 5. Batch invariance (RightNow AI discipline)

Following RightNow AI's "bit-identical FP4 MoE kernels on Blackwell" post:
- **Fixed reduction shapes.** Tile config is a constant, never chosen from M. No split-K or
  stream-K with atomics. A persistent scheduler may reorder *which CTA* computes a tile but never
  how the K-reduction of that tile is split.
- **Rank-ordered FP32.** The top-8 combine sums in slot order j = 0..7, and the expert reduction is
  fixed by tile order. No `atomicAdd`.
- **Compiler flags.** Use `-fmad=false` (or explicit `fma`) on the CUDA path so contraction can't
  differ between instantiations. Triton: avoid relying on `tl.dot` input precision modes that
  vary.
- **Tests with deliberately broken twins.** `tests/test_batch_invariance.py` includes a negative
  control that changes reduction order and must change the bits.
- **Sample size matters (found while building this).** BF16 output rounding hides most fp32
  reduction-order changes. In a torch simulation at 1024×2304, BK=32 vs BK=64 flipped 532 of 2.36 M
  BF16 values. At the small CPU test shapes, a batch-dependent cheat passed. GPU-mode checks
  therefore use Inkling shapes and a 512-token batch.

## 6. Loop-aware considerations (layers 6–17, three passes each)

- **Passes are sequential**: pass p+1 needs pass p's output, so you cannot batch the three visits of
  a token. Each visit is a separate MoE call, giving 48 expert visits per token instead of 24.
- **Weights are re-read every visit.** L2 (about 50 MB on H100 per spec) cannot hold a layer's 128
  experts (≈ 573 MB, derived), so there is no cross-pass reuse at realistic batch sizes. At batch 1
  the 8 active experts (≈ 36 MB) might partly survive in L2 between passes of the *same* layer
  only if nothing else evicts them, which attention and the other loop layers will. Treat this as
  unverified; measure L2 hit rate in Nsight Compute.
- **Launch count triples** in the looped block. This argues for CUDA graphs (already standard in
  vLLM decode) and a **persistent MoE kernel** that does route-to-combine in one or two launches.
- **Routing differs per pass**, so expert-load histograms must be profiled per pass and not per
  layer.
- **Errors compound over passes**, which argues again for exact W4A16 over lossy FP8 requant.

## 7. vLLM integration

Inkling experts are **not** vLLM `FusedMoE`: the model owns routing and EP, and the Hopper path calls
the `vllm.utils.humming` facade from `vllm/models/inkling2/nvidia/ops/moe_sm90.py` (`HummingExperts`).
Options, best first:
1. **General plugin** (`vllm.general_plugins` entry point) that wraps that Hopper experts call,
   keeping Humming as the fallback. Sketch in `vllm_plugin/` (unverified, off by default).
2. **Fork/patch** `moe_sm90.py` directly. Simplest for an internal build, but you own rebasing.
3. **torch.library custom op** for the kernel, so it is opaque to torch.compile and can be captured
   in CUDA graphs. Combine this with 1 or 2.
4. For *other* models that use `FusedMoE`, add a quant method / modular-kernel backend selectable
   with `--moe-backend`. **Verify the class names on current main.**

Existing selection knobs (quoted): `--moe-backend humming`, `VLLM_HUMMING_MOE_GEMM_TYPE=indexed`,
`VLLM_BATCH_INVARIANT`.

## 8. Reuse before writing

| Kernel | What it gives on Hopper | Gap for Inkling 2 Mini |
|---|---|---|
| Humming (vLLM Inkling path, PR #68761) | indexed W4A16/W8A16 MoE, exact dequant; README claims about 2× Marlin MoE on H200 (third-party claim) | stream-K off for determinism; separate SwiGLU/combine launches; not tuned for Mini on H100 (unverified) |
| Marlin MoE (generic vLLM Hopper NVFP4 MoE fallback) | W4A16 grouped MoE | open bugs #49070 (swigluoai params, padding), #48895 (topk-weight epilogue index), #41947 (TP padding); #60315 keeps Humming behind Marlin for compressed-tensors |
| CUTLASS 3.x example 69 (Hopper mixed-dtype grouped GEMM) | TMA + WGMMA int4×bf16 grouped | row-wise scales only, no block-16 FP8 scales; needs a custom converter |
| vLLM PR #29691 (W4A8 grouped on Hopper) | LUT INT4→FP8 | INT4 not e2m1; activations to FP8 |
| DeepGEMM SM90 | FP8 grouped contiguous/masked | 128-channel FP32 scaling only; masked mode needs max_m ≥ 64; option (b) only |
| Machete (vLLM) | Hopper mixed-input dense GEMM (general knowledge) | not grouped MoE |
| FlashInfer | attention, sampling, some MoE (general knowledge) | check current Hopper NVFP4 MoE support |
| Triton | fast iteration, used by the starter and autokernel | weaker sm_90 WGMMA/TMA pipelining control |

**The real gap** is the fused, deterministic, small-M decode MoE block for these exact shapes,
plus the loop. It is not "an FP4 GEMM on Hopper", which already exists.

## 9. Autokernel: automated kernel search (`autokernel/`)

An agentic loop in the style of RightNow AI's AutoKernel: an LLM proposes kernel variants →
compile → correctness (visible + hidden shapes) → determinism and batch invariance → H100
microbenchmark → keep if faster and passes holdout → human review → register via the vLLM plugin.
Details, research links and usage: `autokernel/README.md`.

Guardrails map to documented reward hacks:

| Guardrail | Catches | Source of the hack |
|---|---|---|
| G1 AST static check (no torch matmul/cuBLAS/vLLM/Humming/reference; must contain a kernel) | "kernel" that just calls PyTorch/cuBLAS | KernelBench v0.1 blog |
| G2/G3 numerics on visible **and held-out** shapes, edge modes (zeros, one expert, large values), finiteness | no-op kernels, shape-overfitting | KernelBench; Sakana AI CUDA Engineer post-mortem / robust-kbench |
| G4 bitwise run-to-run | race conditions and garbage reads that pass a tolerance | Wafer "fake 104×" (shared-memory overflow) |
| G5 batch invariance at scale | batch-size-dependent tiles or split-K | RightNow AI |
| G6 input sensitivity, no aliasing | cached outputs, memory reuse | KernelBench |
| G7 harness-owned timing (CUDA events, L2 flush, median, fresh process) | stream and timing tricks | KernelBench; robust-kbench |
| G8 roofline rejection (faster than calibrated HBM copy = bug) | anything physically impossible | KernelBench recommendation |
| G9 frozen-file hashes | agent editing the harness or reference | AutoKernel's single-file contract |

`autokernel/test_guardrails.py` runs four cheats through the harness. On CPU, three are rejected
(torch matmul, no-op, cached output). The batch-dependent cheat is a **known CPU-scale gap** (see
section 5) that GPU mode should close. That is unverified until it runs on an H100.

## 10. Plan, effort, gates, risks

Effort is a judgement for one experienced GPU engineer, not measured.

| Phase | Work | Effort | Go/no-go gate |
|---|---|---|---|
| 0 Baseline | Serve Mini on H100 with vLLM's Humming path; Nsight Systems/Compute per-pass profile; `bench/bench_moe.py` with the Humming baseline added | 1 wk | Expert GEMMs + MoE glue are a material share of decode step time. If not, stop |
| 1 Starter on GPU | Run the tests and bench; fuse SwiGLU; verify checkpoint layout | 1 wk | Correct vs reference; bitwise batch-invariant at Inkling shapes |
| 2 Autokernel search | Run the loop on H100 (Triton), 1–2 targets (w13, w2, fused block) | 1–2 wk | Beats Humming at decode token counts (1–32) by an agreed margin under batch-invariant mode |
| Decision | | **3–4 wk total** | All of the above, plus GSM8K / own evals within tolerance |
| 3 Production | CUTLASS/CuTe WGMMA + TMA warp-specialised kernel, persistent fused block, torch custom op, plugin, CUDA graphs | 5–6 wk | Matches the Triton winner's numerics bit for bit vs reference policy |
| 4 Integration | TP/EP shapes, MXFP8 layers 20–23, CI tests (deterministic + perf regression), rollout flag | 2–3 wk | `vllm bench serve` end-to-end improvement at target concurrency; no eval regression |
| Optional | FP8 prefill path (option b/c) | 2–3 wk | Only if prefill expert GEMMs dominate **and** evals pass |

**Total to production: about 9–12 engineer-weeks.**

Risks:
- Humming may already be near the bandwidth floor at decode, leaving little to win (phase 0 decides).
- Checkpoint layout, gate/up interleave and softcap value are assumed here.
- Triton sm_90 codegen for in-register dequant may not pipeline well, so the CUTLASS rewrite is
  real work.
- vLLM's Inkling code is new and moving; plugin hooks may break on upgrade.
- Batch invariance costs throughput; measure both modes.
- Autokernel winners can overfit benchmark shapes; holdout + human review are mandatory.

## 11. Files and status

| Path | What | Status |
|---|---|---|
| `kernels/formats.py` | exact NVFP4/MXFP8 decoders, random weight generators | CPU-tested |
| `kernels/reference.py` | routing, softcapped SwiGLU, fp64/fp32 reference MoE | CPU-tested |
| `kernels/moe_wq_gemm_triton.py` | starter fused-gather W4A16 grouped GEMM + MoE wrapper | **14 tests pass under `TRITON_INTERPRET=1` (CPU); never run on a GPU** |
| `tests/` | correctness, batch-invariance (with negative control) | as above |
| `bench/bench_moe.py` | GPU microbenchmark vs dequant+bmm baseline | compiles; never run; Humming baseline TODO |
| `autokernel/` | search loop, frozen harness, config, results DB, cheats | dry run works on CPU; no timing measured |
| `vllm_plugin/` | general-plugin registration sketch | unverified, off by default |
| `kernel_dataflow.png` | dataflow + integration + search loop diagram | |

CPU interpreter caveat: Triton 3.9's CPU interpreter miscomputes an in-kernel fp32→bf16 cast, so
under the interpreter the kernel uses an fp32 dot (identical products, since dequantised values
are exact) and rounds in torch. On GPU it uses the bf16 `tl.dot` path, which is untested.

## Sources

- vLLM Inkling Hopper path: https://github.com/vllm-project/vllm/pull/68761
- Marlin MoE issues: https://github.com/vllm-project/vllm/issues/49070, /48895, /41947; PR /60315; W4A8 Hopper grouped PR /29691
- RightNow AI, bit-identical FP4 MoE kernels: https://www.rightnowai.co/blog/bit-identical-fp4-moe-kernels-on-blackwell
- nnsight/NDIF on Inkling 2 Mini: https://nnsight.net/blog/2026/11/20/opening-the-box-of-inkling-2-mini-using-nnsight-ndif/
- CUTLASS example 69: https://github.com/NVIDIA/cutlass/tree/main/examples/69_hopper_mixed_dtype_grouped_gemm
- DeepGEMM: https://github.com/deepseek-ai/DeepGEMM
- Autokernel-related sources: see `autokernel/README.md`.
