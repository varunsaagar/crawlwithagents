# Qwen-based Jev deciders for 64K–128K — options (2026-10-11)

Context: Verizon now allows Qwen-based models (this replaces the earlier ban). The question is whether we can train on top of `perplexity-ai/pplx-decider-v1.1-27b` and reach 64–128K, and what smaller and larger Qwen options exist.
Labels: **[V]** = verified from the HF API, config.json, README, LICENSE or the released source on 2026-10-11. **[E]** = estimate (formula, not measured). **[U]** = unverified.

## 1. pplx-decider-v1.1-27b — verified facts
| Item | Finding |
|---|---|
| Link | https://huggingface.co/perplexity-ai/pplx-decider-v1.1-27b (not gated, sha 6195aa5, updated 2026-10-09) [V] |
| Base | `Qwen/Qwen3.8-27B` @ rev 1d4bf0f2 (the NOTICE says the backbone, vision and readout were all updated by **full SFT**) [V] |
| License | **Apache-2.0** for both the decider (LICENSE + NOTICE) and the Qwen3.8-27B base. Commercial fine-tuning and derivatives are allowed. Keep the NOTICE and attribution. The tasksource training data has per-dataset licences, which matter only if we redistribute data [V/U] |
| Head | **Not an LM head.** `readout.safetensors` is a BF16 `[255, 5120]` decision head, pooled on the **last token**, with up to 255 options (codes A…). Temperature is 1.0087 [V] |
| Attention | Hybrid: 64 layers, `full_attention_interval: 4`, so **48 gated-DeltaNet linear-attention layers + 16 full-attention layers** (GQA 24 q / 4 kv heads, head_dim 256, partial RoPE 0.25). The full layers run **noncausal** (bidirectional), which is the main change in v1.1. This needs `attn_implementation=sdpa`, and there is **no KV cache** (one forward pass) [V] |
| Native context | `max_position_embeddings 262144`, rope_theta 1e7, rope_type default. **64K and 128K are inside the native window, so no YaRN is needed.** Qwen's README says YaRN is only for going past 262K, and that static YaRN "may impact performance on shorter texts", so don't enable it [V] |
| Trained / evaluated at | **8,192 tokens.** training/config.json has `max_length 8192` and `token_budget 8192`, and `prepare()` **rejects** inputs over 8,192 instead of truncating them. Training used 626,033 rows, 1 epoch, lr 2e-6, effective batch 256 on 8 GPUs, full FT with gradient checkpointing [V] |
| Evals | Decision Index 61.56, up from 56.4 for v1. The "Jev" column is 57.9. Knowledge 48.2, Language 69.5, Retrieval 61.3, Tools 78.9, Arts 44.7. **No long-context eval is published** [V] |
| Size | 11 shards, about 52 GB in BF16. The README says "roughly 49 GiB of weights plus working memory" [V] |
| Code | **Training and inference code is public in the repo**: `source/src/autojev/{train,model,data,loss,evaluate,server}.py`, `training/train.sbatch`, a pinned `requirements.txt` (torch 2.14, transformers 5.17, flash-linear-attention 0.5.2) and `uv.lock`. The training data paths are internal and not released [V] |
| Serving | Uses its own `DecisionModel` and a FastAPI `server.py`. **No stock vLLM path:** vLLM would need an LM-head export (readout row i → vocab token_ids[i]) *and* noncausal attention, and stock vLLM is causal-only. Community quants exist (GGUF, MLX 4-bit, bnb-nf4), but they're unverified for noncausal behaviour [V/U] |

**What this means for 64K:** position encoding isn't the problem. The model has **never seen a sequence longer than 8K**, and its noncausal full attention plus last-token pooling at 64K is untested. That is the same attention-dilution risk the Kairos report measured on E4B, where the output went uniform at 64K. Expect a drop without length training until the sweep in section 5 shows otherwise [E].

## 2. Feasibility verdict
**Feasible and licence-clean (Apache-2.0).** The context window is native, so no YaRN is needed. The work is *length training* plus engineering:
1. Lift the 8,192 cap in `prepare()`/`train.py` (`--max-length`, `--token-budget`).
2. Confirm SDPA uses the memory-efficient kernel with the boolean noncausal mask at 64K. If it falls back to the math kernel, it materialises L² scores: about 24 heads × 65,536² × 2 B ≈ 206 GB per layer, which is an instant OOM [E]. The other option is a FlexAttention port of `enable_noncausal_full_attention`, the same fix Kairos needed for L1c.
3. Training at 64K on one H100 is **not** realistic at full precision (see the memory table). Use LoRA plus context parallelism on 8×H100, or H200.

## 3. Memory and throughput (1 GPU) — all [E]
Basis: 27B params; 16 full-attention layers × 4 KV heads × 256 dim. Linear layers keep a fixed-size state. Noncausal inference uses no KV cache.

| | 64K | 128K |
|---|---|---|
| Serve, BF16 weights | ~52 GB + ~8–15 GB activations. **Fits on 1×H100 80 GB at batch 1** if the efficient attention kernel is used | ~52 + ~16–30 GB, which is tight on H100. **Use H200 141 GB** or FP8 weights (~27 GB) |
| Serve, FP8 weights | ~27 GB + activations, so 2–4 requests in flight on an H100 | 1–2 on an H100 |
| Prefill compute | ≈2·27e9·65,536 ≈ 3.5 PFLOP + full-attention ≈1.7 PFLOP ≈ **5.2 PFLOP** | ≈7.1 + 6.8 ≈ **13.9 PFLOP** |
| Latency per decision (H100, ~50% MFU) | **~10 s BF16, ~5–6 s FP8**, so about 0.1–0.2 decisions/s per GPU | **~25–30 s BF16, ~13–15 s FP8** |
| LoRA training (BF16 base, grad checkpointing) | weights 52 + checkpointed activations ~40–45 + LoRA/optimizer ~2 ≈ **95–100 GB**. Doesn't fit 1×H100. **Fits on 1×H200**, or 8×H100 with context parallelism | ≈150 GB+, so H200 with CP=2 or 8×H100 with CP |
| QLoRA (4-bit base) on 1×H100 at 64K | ~15 + ~45 ≈ 60–65 GB, which fits. **Not recommended:** the Kairos lesson was that 4-bit training shifted calibration. Use it only for smoke tests | no |

So **27B is the accuracy tier, not the throughput tier.** At 64K it is roughly 50× slower per decision than E4B at 8K. Keep chunked map-reduce (8K chunks, the length it was trained at) as the default for anything over 16K, and run single-pass 64K only when chunking loses.

## 4. Recipe (a): extend pplx-decider-v1.1-27b to 64K → 128K
Start from **v1.1 weights and keep its readout** (255 codes, last-token pooling, noncausal). Do not re-initialise anything.
0. **Zero-shot sweep first** (section 5). If 64K retention is already ≥0.90, skip training and only calibrate.
1. **Code patch:** add `--max-length` up to 131,072. Port the noncausal hook to FlexAttention, or verify the SDPA mem-efficient backend. Set `token_budget` = max_length with batch 1 per rank and gradient accumulation.
2. **LoRA r=16–32, α=2r** on the full-attention q/k/v/o, the DeltaNet in/out projections (`in_proj_*`, `out_proj`) and the MLP gate/up/down. **Train the readout fully** (2.6 MB). Freeze vision and embeddings. lr 1e-5 for LoRA (their full FT used 2e-6) [E].
3. **Length curriculum:** 16K (~30% of steps) → 32K (~30%) → 64K (~30%) → 128K (~10%, only if 128K is required). **Replay 25–30% at ≤8K** in every stage to protect Decision Index and short-context calibration.
4. **Data:** use the Kairos long rows plus synthetic long states, with the evidence placed at the start, middle and end. Add hard distractors (same-domain, near-duplicate, conflicting passages). Use up to 255 options with hard-negative options. Use teacher labels (Gemini, Opus or Qwen3.8-27B thinking) only where they match gold. Balance Noul so the true/false prior is about 50/50 per bucket (this targets the noul anti-correlation Kairos found).
5. **Checkpoint selection** on a *long* dev set covering every bucket. Don't use saturated short dev data (Kairos defect #7).
6. **Calibrate:** temperature per question type × length bucket (≤8K, 8–32K, 32–64K, 64–128K). Certify Learn-then-Test thresholds per group × bucket. Uncertified buckets escalate to the LLM.
7. **Gates:** Decision Index no more than 1 point below 61.56; on the Kairos eval, beat L1c in every bucket; retention 64K/8K ≥0.90; ECE ≤0.03 per bucket; Noul@64K > 0.70.
8. **Fallback:** chunked map-reduce over 8K chunks with the pplx head, aggregated by max or noisy-OR for Noul and evidence-weighted for Choice/Score. Kairos measured a 0.80 floor for this on E4B.
- Compute [E]: about 2–5k steps × 64K tokens on 8×H100 with CP. Roughly 150–400 GPU-h to reach 64K, plus about 150–300 to reach 128K.
- No YaRN unless you go past 262K.

## 5. First experiment — score what exists (no training)
Score pplx-decider-v1.1-27b zero-shot on the Kairos 1,552-state held-out eval (manifest c23d9d39…) at 8K/16K/32K/64K. Compare it with baseline open275k-e4b, L1c and L1c+15 steps (8K ≈0.41; 64K 0.283/0.348/0.374; Noul@64K 0.318/0.645/0.708).
- Script: `qwen-decider-64k/eval_pplx_length_sweep.py` (syntax-checked, dry-run tested on a toy row; **not run on a GPU**). It uses the released `DecisionModel` and raises the cap via `prepare(max_length=…)`. It applies the saved temperature once, maps choice/score/noul (verified order: noul = ["false","true"], score = criteria index), and logs per-row p_gold/conf/tokens/latency. Over-cap rows and OOMs are recorded, not truncated. Adjust `FIELD_MAP` to the real eval field names.
- Also run **chunked 8K map-reduce** with the same model on the 32K/64K rows.
- Hardware: 1×H200, or an H100 with FP8 weights for 64K. About 1,552 rows × ~1–10 s each ≈ 1–3 GPU-h [E].
- Decision rule: if pplx single-pass beats L1c at 8K by a clear margin with non-overlapping CIs, adopt it as the accuracy tier and run section 4. If it beats L1c only via chunking, ship chunked pplx and skip long training.

## 6. Qwen-based candidates (small → large)
| Model | Base | Native ctx | License | Notes |
|---|---|---|---|---|
| [StrandsAgents/strands-decider-2B-qwen3.5-v1-2610](https://huggingface.co/StrandsAgents/strands-decider-2B-qwen3.5-v1-2610) | Qwen3.5-2B-Base (adapter) | 262K (inherited) | Apache-2.0 [V] | Same Jev schema as strands-decider. Trained at 4K |
| [Mapika/decider-0.8b](https://huggingface.co/Mapika/decider-0.8b) / [decider-4b](https://huggingface.co/Mapika/decider-4b) | Qwen3.5-0.8B / 4B-Base | 262K | Apache-2.0 [V] | Community. Evals unverified |
| [apus-ailab/APUS-OpenJev-v1-4B](https://huggingface.co/apus-ailab/APUS-OpenJev-v1-4B) (also 9B, 35B-A3B GGUF) | Qwen3.5-4B | 262K | Apache-2.0 [V] | |
| [openjev/openjev](https://huggingface.co/openjev/openjev) | qwen3_5 64-layer (27B-class) | 262K | **CC-BY-NC-4.0 → not usable commercially** [V] | |
| [jaredpalmer/kev-27b](https://huggingface.co/jaredpalmer/kev-27b) | **Qwen3.8-27B** | 262K | Apache-2.0 [V] | Kairos report: rank-16 LoRA, max_state 7,552 |
| [denis-pplx/autojev-27b](https://huggingface.co/denis-pplx/autojev-27b), [pplx-decider-v1-27b](https://huggingface.co/perplexity-ai/pplx-decider-v1-27b) | Qwen3.8-27B | 262K | Apache-2.0 [V] | Predecessors of v1.1 (DI 56.4) |
| StartLux-Decision-v1 0.8B/2B/4B/9B/27B, 35B-A3B (GGUF, e.g. [27B](https://huggingface.co/startlux-models/StartLux-Decision-v1-27B-BF16-GGUF)) | Qwen3.5 family | 262K **inherited config, not validated** (per their case study) | [U] | GGUF only, so hard to fine-tune |
| [Mapika/decider-35b-a3b](https://huggingface.co/Mapika/decider-35b-a3b) | Qwen3.5-35B-A3B-Base (MoE, ~3B active) | 262K | Apache-2.0 [V] | Fast MoE option |
| Bases: [Qwen3.5-4B-Base](https://huggingface.co/Qwen/Qwen3.5-4B-Base), [9B-Base](https://huggingface.co/Qwen/Qwen3.5-9B-Base), [35B-A3B-Base](https://huggingface.co/Qwen/Qwen3.5-35B-A3B-Base), [122B-A10B](https://huggingface.co/Qwen/Qwen3.5-122B-A10B), [397B-A17B](https://huggingface.co/Qwen/Qwen3.5-397B-A17B), [Qwen3.8-27B](https://huggingface.co/Qwen/Qwen3.8-27B) | — | all 262K, same hybrid 3:1 DeltaNet/full design | Apache-2.0 [V] | Qwen3.8-27B README: 262K native, up to 1M with YaRN |
| [Qwen/Qwen3.8-Flash-Next](https://huggingface.co/Qwen/Qwen3.8-Flash-Next) | qwen4_exp | 262K | **license: other**, needs review [V] | |
| [Qwen3-Reranker-0.6B/4B/8B](https://huggingface.co/Qwen/Qwen3-Reranker-8B) | Qwen3 (dense, causal) | **40,960**, so 64K needs YaRN | Apache-2.0 [V] | Use as an INDEX shortlister, not as Jev |

Not verified here: RULER or other long-context scores for the Qwen3.5/3.8 bases (not found in the model cards I fetched), the evals behind the community deciders, and Qwen2.5/Qwen3 dense 0.6–32B / 30B-A3B / 235B-A22B (older generation, 32K native + YaRN; superseded by the 3.5 family).

## 7. Recommended picks
| Tier | Pick | Why | Serving at 64K [E] |
|---|---|---|---|
| **Small / fast** | **Qwen3.5-4B-Base** with the pplx `autojev` recipe (noncausal + 255 readout), distilled from the long-trained 27B. Mapika/decider-4b or APUS-OpenJev-4B are warm starts, after scoring them | Same hybrid architecture, so the 64K state cost is small. About 7× fewer FLOPs than 27B | ~1–1.5 s per 64K decision on H100. ≤8K: tens of ms |
| **Mid (recommended)** | **pplx-decider-v1.1-27b** + section 4 recipe | Highest public Decision Index (61.56), Apache-2.0, code public | ~5–10 s per 64K decision; chunked 8K is the default |
| **MoE speed alternative** | Qwen3.5-35B-A3B-Base (or Mapika/decider-35b-a3b) | ~3B active, so 27B-class capacity at near-4B prefill cost. Needs the head and recipe ported | ~1–2 s per 64K decision; ~70 GB BF16, so FP8 on H100 |
| **Large / teacher** | Qwen3.5-122B-A10B (or 397B-A17B) as an offline teacher/judge for long labels | Not for 1-GPU serving | multi-GPU |

## 8. Open / uncertain items
- Whether SDPA's noncausal boolean mask runs on the efficient kernel at 64K in transformers 5.17 (OOM risk). Test first.
- How pplx's last-token pooling behaves when the question sits far from the evidence. The prompt already puts Question/Options *after* State, which helps [V], but this is untested past 8K.
- No published long-context accuracy for any Qwen decider. All the 64K figures above are formula estimates.
- Community quants (GGUF/MLX/nf4) may run causal attention, which differs from the evaluated setup.
- Distributing tasksource-derived data needs a per-dataset licence check. Using the weights is Apache-2.0.
- The Gemini/Opus teacher terms still need legal review (carried over).
