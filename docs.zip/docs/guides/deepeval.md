# DeepEval

`jevjudge.integrations.deepeval.JevRubricMetric` runs a Jev rubric as a DeepEval metric. The scoring math matches DeepEval's JevEval (see [Scoring](../concepts/scoring.md)), so CI scores and online scores agree.

```bash
uv pip install -p .venv/bin/python -e ".[deepeval]"
```

```python
from deepeval import assert_test
from deepeval.test_case import LLMTestCase
from jevjudge import Judge
from jevjudge.integrations.deepeval import JevRubricMetric

judge = Judge.from_preset("voice", tiers=["djev"], fallback="gemini-2.5-flash", threshold=0.9)

toxicity = JevRubricMetric(judge, "output_toxicity", threshold=0.5)                          # pass when score <= 0.5
completed = JevRubricMetric(judge, "action_completion", threshold=0.5, higher_is_better=True)  # pass when score >= 0.5

def test_agent_reply():
    case = LLMTestCase(input="Can you remove the add-on?", actual_output="Done, it's removed from your next bill.")
    assert_test(case, [toxicity, completed])
```

`JevRubricMetric(judge, rubric_id, threshold=0.5, higher_is_better=False)`:

* `judge` must be a sync `Judge`. `measure()` calls `judge.grade(...)` and `a_measure()` calls `judge.agrade(...)`, with only the named rubric.
* The test case is passed as a DeepEval-style dict (`input`, `actual_output`, `expected_output`, `context`, `retrieval_context`) and packed as labelled text sections.
* `score` is the rubric score, and `reason` is the deterministic reason.
* `success` is "the rubric passed" (`verdict == "clean"`) for rubrics with a verdict; set `higher_is_better=True/False` to compare `score` with `threshold` instead.

!!! warning "Set `higher_is_better` per metric"
    The rubric score is P(true) of the verdict question. For the safety rubrics (`output_pii`, `output_toxicity`, `output_sexism`, `hallucination`), lower is better, which is the default. For `action_completion`, the verdict asks whether the action *was* completed, so pass `higher_is_better=True`.

!!! note "Text-only test cases"
    DeepEval test cases have no turn structure, so they are judged as a single raw state rather than through the `agent_only` / `dialogue` / `grounded` views. To keep turn and tool structure, pass a `{"session_id", "turns": [...]}` dict or a `Session` to `judge.grade()` directly.

Without DeepEval installed, `JevRubricMetric` still imports, with `object` as its base class, so you can call `measure()` in plain pytest.
