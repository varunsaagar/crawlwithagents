# Installation

jevjudge needs Python 3.10 or newer. The project is developed on 3.12 with `uv`.

## Install

=== "uv (recommended)"

    ```bash
    cd jevjudge
    uv venv -p 3.12 .venv
    uv pip install -p .venv/bin/python -e ".[all,dev]"
    ```

=== "pip"

    ```bash
    cd jevjudge
    python -m venv .venv && . .venv/bin/activate
    pip install -e ".[all,dev]"
    ```

### Extras

| Extra | Installs | Needed for |
|---|---|---|
| `studio` | `fastapi`, `uvicorn`, `python-multipart` | `jevjudge serve` (Calibration Studio and HTTP API) |
| `vertex` | `google-genai` | Gemini through Vertex AI (`gemini-2.5-flash`, `gemini-3.5-flash`, any `vertex/<model>`) |
| `otel` | `opentelemetry-api`, `opentelemetry-sdk` | `OtelSink` (emit evaluation spans through the OTel SDK) |
| `bigquery` | `google-cloud-bigquery`, `db-dtypes` | reading traces from BigQuery in your own scripts |
| `deepeval` | `deepeval` | `jevjudge.integrations.deepeval.JevRubricMetric` |
| `notebooks` | `jupyter`, `nbclient`, `matplotlib` | the notebooks under `notebooks/` |
| `docs` | `mkdocs`, `mkdocs-material` | building this site (`make docs`) |
| `dev` | `pytest`, `pytest-asyncio`, `ruff`, `fastapi`, `build`, … | tests, lint, packaging |
| `all` | `studio,vertex,otel,bigquery,notebooks` | everything except `deepeval`, `docs` and `dev` |

The core dependencies already include the text and chunking libraries: `tokenizers`, `tiktoken`, `pysbd`, `bm25s` and `langchain-text-splitters`. If a tokenizer can't be loaded, for example a gated Hugging Face repo when you are offline, jevjudge falls back to `tiktoken:cl100k_base` or `chars:3.2` and logs a warning.

`make install` runs `uv pip install -e ".[all,dev,docs]"`.

Check the install:

```bash
.venv/bin/python -m pytest -q        # offline tests, no network
.venv/bin/jevjudge smoke             # one live decision per backend (needs credentials)
```

## Credentials

Credentials come from environment variables. Put them in a **git-ignored** `.env` file at the repo root (`.env` is already listed in `.gitignore`) and load it into your shell:

```bash
# .env  (never commit this file)
JEV_API_KEY=...            # Kairos decision-model pods: kairos-jev, kev-gemma, laya, djev, clm-gemma
KAIROS_JWT_NP=...          # Kairos inference gateway, non-prod: gw/* models and gemini-3.8-flash / gemini-3.5-flash-lite
KAIROS_JWT_PR=...          # Kairos inference gateway, prod: gemini-3.8-flash-prod
# optional endpoint overrides used by models.yaml
KAIROS_GATEWAY_URL_TEST=https://kairos-gateway-test.ebiz.verizon.com
KAIROS_GATEWAY_URL_PROD=https://kairos-gateway.verizon.com
```

```bash
set -a; . ./.env; set +a
```

Each model entry in `models.yaml` names the variable it reads (`api_key_env`), so the key used depends on the model alias:

| Alias | Path | Key variable |
|---|---|---|
| `kairos-jev`, `kev-gemma`, `kev-gemma-granc`, `laya`, `djev`, `clm-gemma`, `jev-stack` | direct Kairos pods | `JEV_API_KEY` |
| `gw/kairos-jev`, `gw/kev-gemma`, `gw/laya`, `gw/djev` | Kairos gateway (test) | `KAIROS_JWT_NP` |
| `gemini-3.8-flash`, `gemini-3.5-flash-lite` | Kairos gateway (test), OpenAI-compatible | `KAIROS_JWT_NP` |
| `gemini-3.8-flash-prod` | Kairos gateway (prod) | `KAIROS_JWT_PR` |
| `gemma-26b`, `kairos-per-hub` | vLLM endpoints | none |
| `gemini-2.5-flash`, `gemini-3.5-flash`, `vertex/<model>` | Vertex AI | Application Default Credentials |

### Vertex AI (Gemini)

The Vertex backend uses Application Default Credentials:

```bash
gcloud auth application-default login
export VERTEX_PROJECT=<gcp-project>        # default: vz-it-np-ienv-test-vegsdo-0 (ANTHROPIC_VERTEX_PROJECT_ID also works)
export VERTEX_LOCATION=global              # default: global
```

`gemini-3.x` models on Vertex do not return logprobs. jevjudge can use them as parsed-answer fallbacks, but not as gated tiers (see [Decision models](concepts/decision-models.md)).

### Other environment variables

| Variable | Effect |
|---|---|
| `JEVJUDGE_MODELS` | path to a `models.yaml` that is deep-merged over the packaged registry |
| `OPENAI_BASE_URL` | default `base_url` for `openai/<model>` entries that don't set one |
| `JEVJUDGE_HOME` | Studio project directory (default `~/.jevjudge/projects`) |
| `JEVJUDGE_CA_BUNDLE` / `JEV_CA_BUNDLE` | explicit CA bundle for TLS |

## Proxy and TLS

The corporate proxy re-signs TLS with an internal root that only the OS trust store has. jevjudge builds its TLS context in this order:

1. `JEVJUDGE_CA_BUNDLE` or `JEV_CA_BUNDLE`, if set.
2. The OS trust store through `truststore`, a core dependency.
3. The default `httpx` verification.

`*.verizon.com` hosts are expected to bypass the HTTP proxy through `NO_PROXY`. The Kairos client honours `HTTP(S)_PROXY` and `NO_PROXY` (`trust_env=True`).

!!! warning "A 404 can mean the host never answered"
    From a laptop, an unresolvable host (for example any in-cluster `*.svc` URL) comes back from the proxy as **HTTP 404 with an HTML body**, as if the service had answered. jevjudge turns this into an invalid answer, which is escalated. Check the `error` field on the `Answer` before you debug the model.
