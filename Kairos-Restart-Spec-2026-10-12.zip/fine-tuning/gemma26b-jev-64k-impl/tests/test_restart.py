import random, sys, pathlib
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1]))
import torch
from restart_utils import *

def ok(m): print("[PASS]", m)

# fake tokenizer: single letters + 2-letter codes are 1 token, except "QQ" (2 tokens) and "Z" merges with prefix ending ":"
VOCAB = {}
def enc(s):
    out, i = [], 0
    while i < len(s):
        if s[i:i+2] == "QQ": out += [VOCAB.setdefault("Q",len(VOCAB)), VOCAB.setdefault("Q",len(VOCAB))]; i += 2; continue
        if s[i:i+2].isupper() and len(s[i:i+2]) == 2 and s[i:i+2].isalpha(): t = s[i:i+2]; i += 2
        elif s[i] == ">" and s[i+1:i+2] == "Z": t = ">Z"; i += 2
        else: t = s[i]; i += 1
        out.append(VOCAB.setdefault(t, len(VOCAB)))
    return out

codes, ids = select_answer_codes(enc, "<turn>model\n>", 255)
assert "QQ" not in codes and "Z" not in codes and len(codes) == 255 and len(set(ids)) == 255
ok(f"single-token check drops multi-token 'QQ' and prefix-merging 'Z'; 255 distinct codes")
try: select_answer_codes(enc, ">", 700); raise SystemExit("should fail")
except ValueError: ok("too few codes raises instead of silently shrinking")

torch.manual_seed(0); V, d = len(VOCAB) + 10, 32
lm = torch.randn(V, d, dtype=torch.bfloat16)
head = CodeReadoutHead(lm, ids)
h = torch.randn(4, d, dtype=torch.bfloat16)
lg = head(h, torch.tensor([3, 26, 255, 2]))
ref = (h.float() @ lm.float()[ids].T)
assert torch.equal(lg[2], ref[2]) and head.weight.dtype == torch.float32
ok("step-0 readout == LM logits on code tokens (exact), head fp32")
assert torch.isinf(lg[0, 3:]).all() and torch.isfinite(lg[0, :3]).all()
p = lg.log_softmax(-1); assert torch.isfinite(p[0, :3]).all()
lg.log_softmax(-1)[torch.arange(4), torch.tensor([0, 1, 2, 0])].sum().backward()
assert head.weight.grad[3:26].abs().sum() > 0 and torch.isfinite(head.weight.grad).all()
ok("masking: invalid options -inf, finite log_softmax, finite grads")

row = {"question": {"type": "choice", "criteria": {k: None for k in "abcdef"}}, "target": [0, .1, .2, .3, .4, 0], "label": "e"}
seen = set()
for e in range(20):
    r = shuffle_options(row, random.Random(e))
    assert dict(zip(r["question"]["criteria"], r["target"])) == dict(zip(row["question"]["criteria"], row["target"]))
    seen.add(tuple(r["question"]["criteria"]))
assert len(seen) > 10 and list(row["question"]["criteria"]) == list("abcdef")
ok(f"per-epoch shuffle permutes soft targets in lockstep ({len(seen)} distinct orders), input not mutated")

rows = [{"question": {"type": "noul"}, "target": i < 90, "source_name": "voice"} for i in range(100)] + \
       [{"question": {"type": "noul"}, "target": i < 30, "source_name": "churn"} for i in range(40)] + \
       [{"question": {"type": "choice", "criteria": {}}, "source_name": "x"}] * 5
idx = NoulBalancedSampler(rows, 1).indices(0)
for src in ("voice", "churn"):
    labs = [rows[i]["target"] for i in idx if rows[i].get("source_name") == src]
    assert sum(labs) == len(labs) - sum(labs), src
assert sum(1 for i in idx if rows[i]["question"]["type"] == "choice") == 5
ok("Noul sampler: 50/50 per source (voice 90:10 -> 90:90, churn 30:10 -> 30:30); choice untouched")

base = " ".join(f"word{i}" for i in range(60))
nd = NearDuplicates(); nd.add(base)
assert nd.matches(base.replace("word59", "other")) and not nd.matches(" ".join(f"tok{i}" for i in range(60)))
ok("near-duplicate detector: 1-word edit caught, unrelated text passes")
tr, n = decontaminate([{"s": base}, {"s": "short text"}, {"s": "fresh " * 30}], [{"s": base.upper()}], lambda r: r["s"])
assert n == 1 and len(tr) == 2; ok("decontaminate removes eval overlap (case-normalized)")
rs = [{"s": "A", "label": 1}, {"s": "a ", "label": 2}, {"s": "B", "label": 1}, {"s": "b", "label": 1}]
kept, c = drop_conflicts(rs, lambda r: r["s"]); assert c == 1 and len(kept) == 1
ok("conflicting labels on same normalized state dropped")
fr = [{"family": f"f{i//3}", "i": i} for i in range(300)]
sp = family_split(fr, {"train": .8, "dev": .1, "temp": .1}, 7)
fams = [{r["family"] for r in v} for v in sp.values()]
assert not (fams[0] & fams[1] or fams[0] & fams[2] or fams[1] & fams[2]) and sum(map(len, sp.values())) == 300
ok(f"family split: no family crosses folds, sizes {[len(v) for v in sp.values()]}")
print("ALL RESTART TESTS PASSED")
