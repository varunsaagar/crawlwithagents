# 05 — Metrics and drift

Cross-links: [Architecture](01-architecture.md) · [Implementation](03-implementation-guide.md) · [Versioning](04-versioning-and-ops.md) · [References](06-references.md)

Honesty rule: **sparse ground truth means most live numbers are estimates.** Label the estimate. Never dress judge-pass rates up as precision.

---

## Precision / recall / FP / FN with sparse GT

You have dense judge scores (thousands/day) and sparse human labels (hundreds/week). That asymmetry drives the reporting design.

### What you can compute on gold / HITL only

| Metric | Needs | Use |
|--------|-------|-----|
| Precision, recall, F1 | Human y + judge ŷ | Judge quality, not product quality |
| Sensitivity Se, specificity Sp | same | Inputs to prevalence adjustment |
| Cohen’s κ | same | Primary calibration headline |
| Confusion slices | same | Error analysis |

### What you can compute on traffic

| Metric | Meaning | Safe publication? |
|--------|---------|-------------------|
| Raw judge pass/fail rate | Instrument reading | Yes, labelled as judge rate for `judge_version` |
| Bias-adjusted prevalence | Rogan–Gladen using current Se/Sp | Yes, with Se/Sp vintage + N |
| Human failure rate on HITL sample | Sparse but trustworthy trend | Yes, with CI / error bars |
| “Precision of the voice agent” from judges alone | — | **No** |

### Worked reporting pattern

```text
Safety (week 36):
  Judge fail rate (high-risk): 3.2%  (n=4200, judge=safety@1.2.0)
  Se=0.81, Sp=0.97 on gold@0.3.0 (n=320, κ=0.66)
  Adjusted fail prevalence ≈ Rogan–Gladen(...) 
  HITL fail rate: 2.1% (n=120)  [plot both]
```

Do not invent Se/Sp — measure them after each major judge/rubric change.

### FP / FN costs (product framing)

| Error | Typical cost | Monitoring bias |
|-------|--------------|-----------------|
| FP safety (judge says fail, human OK) | Alert fatigue, bad rollbacks | Track FP rate on HITL |
| FN safety (judge OK, human fail) | Real harm / compliance | Prioritise Se; 100% high-risk sampling |
| FP faithfulness | Over-triggering groundings | Cost in eng time |
| FN faithfulness | User trust | Product quality |

Thresholds are **business** choices; this pack does not prescribe a false number.

---

## Three drift signals

Keep these distinct on dashboards (see [Who Drifted: the System or the Judge?](06-references.md)).

### 1) Input / traffic drift (system)

- Embedding drift on user utterances / full transcripts (Phoenix).
- Tabular: ASR confidence, call duration, locale mix, risk_tag mix, empty retrieval rate (Evidently).
- **Action:** investigate data path, ASR, routing — not the judge prompt.

### 2) Behavioural / output drift (system)

- Distribution of `model_answer` embeddings.
- Retrieval score distributions; doc_id concentration (sudden single-doc dominance).
- Human HITL failure rates; escalation rate; CSAT if available.
- **Action:** prompt/model/search rollback candidates.

### 3) Judge drift (instrument)

- Score-rate change **replicated on frozen replay set**.
- κ / Se / Sp drop vs previous week on same gold.
- Pairwise disagreement between `judge_version` A vs B on same sessions.
- **Action:** rollback judge; never “fix” production copy to match a broken judge.

**Detection drill (Month 1 exit):** deliberately deploy a broken judge in shadow; confirm only `judge.*` fires.

---

## Dashboards to build

### Board A — System health

- Volume: sessions/day, high-risk fraction.
- ASR confidence histogram + % sessions below floor.
- Retrieval: empty rate, mean top-1 score.
- Outcomes: escalate rate, hangup reasons (if trusted).
- HITL failure rates by rubric (sparse).
- Canary vs control: bias-adjusted faithfulness / policy metrics.
- Cost: $ or £ per 1k sessions (runtime + judges).

### Board B — Judge health

- Per-metric score rates by `judge_version`.
- κ, Se, Sp trend vs `gold_set_version`.
- Shadow vs live judge agreement.
- Provider error / timeout rate for judge calls.
- Token usage per judge.

### Board C — Promotion

- List of artifacts in shadow / canary / full.
- Time in stage; owners; last human rubric approval.
- CI gate status for open prompt PRs.

### Shared debug (not for exec screens)

- Session deep links into Langfuse.
- Disagreement queues (judge↔human, judge↔judge).

---

## What NOT to publish

| Anti-pattern | Why it is wrong |
|--------------|-----------------|
| “% judge pass = precision” | Precision requires GT; this is a rate from a noisy instrument |
| “Accuracy 99%” on imbalanced safety | Prevalence games; use κ + Se/Sp |
| Single blended “quality score” hiding polarity mixes | Task-unresolved polarity confusion |
| Exec tile with no `judge_version` / `gold_set_version` | Unreproducible |
| Alert on n&lt;30 without caveat | Noise |
| Comparing judge rates across MAJOR rubric versions without note | Different meanings |

---

## Statistical hygiene (minimum)

- Always show **N**.
- Prefer Wilson intervals or bootstrap on HITL rates when N is small — pick one method and stick to it.
- Recompute Se/Sp on a schedule (weekly) and on every `judge_version` bump.
- Hold out gold items that prompt authors cannot overfit in CI (private split).

---

## Mapping metrics → actions

| Observation | First fork | Likely action |
|-------------|------------|---------------|
| Judge rate ↑, frozen gold replay ↑ | Judge | Rollback judge |
| Judge rate ↑, frozen gold stable, HITL ↑ | System | Rollback prompt/search |
| Judge rate ↑, frozen gold stable, HITL flat | Sampling / mix shift | Check traffic strata |
| κ ↓ | Judge or label guideline drift | Recalibrate / retrain annotators |
| Cost ↑, quality flat | Ops | Sampling cap |

---

## Next

Bibliography and red herrings: [06-references.md](06-references.md). Copy-paste schemas: [07-templates.md](07-templates.md).
