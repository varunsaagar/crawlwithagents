"""Chunk-and-aggregate Jev scoring for long docs and big option sets. score_fn(text, question, kind, options) -> {opt: p}.
Noul: split doc into 8-16K chunks (overlap 512 tok), P(true) = noisy-OR over chunks (or max). Choice with >K options:
tournament in groups of K (default 26 for letter-logit), winners re-scored; also per-chunk then average/max of evidence.
Score: confidence-weighted mean of per-chunk expectations. Re-calibrate the AGGREGATE with LTT (noisy-OR is overconfident)."""
from __future__ import annotations
import math

def chunks(text, size_tok=12000, overlap_tok=512, cpt=4):
    s, o = size_tok * cpt, overlap_tok * cpt
    return [text[i:i + s] for i in range(0, max(1, len(text)), s - o)] or [text]

def noul(score_fn, text, q, agg="noisy_or", **kw):
    ps = [score_fn(c, q, "noul", ["true", "false"])["true"] for c in chunks(text, **kw)]
    p = 1 - math.prod(1 - x for x in ps) if agg == "noisy_or" else max(ps)
    return {"true": p, "false": 1 - p, "per_chunk": ps}

def choice(score_fn, text, q, options, k=26, **kw):
    cs = chunks(text, **kw)
    def best(opts):  # evidence may sit in any chunk: take max prob per option across chunks
        agg = {o: 0.0 for o in opts}
        for c in cs:
            for o, p in score_fn(c, q, "choice", opts).items(): agg[o] = max(agg[o], p)
        z = sum(agg.values()) or 1.0
        return {o: p / z for o, p in agg.items()}
    pool = list(options)
    while len(pool) > k:  # tournament: top-2 of each group of k advance
        nxt = []
        for i in range(0, len(pool), k):
            d = best(pool[i:i + k]); nxt += sorted(d, key=d.get, reverse=True)[:2]
        pool = nxt
    return best(pool)

if __name__ == "__main__":  # self-test with a fake scorer: evidence "XYZ" in one chunk, answer opt-137 of 300
    import random
    doc = "".join(random.choice("abc ") for _ in range(240000)); doc = doc[:150000] + " XYZ opt-137 " + doc[150000:]
    def fake(c, q, kind, opts):
        if kind == "noul": return {"true": 0.9 if "XYZ" in c else 0.05, "false": 0}
        return {o: (10.0 if (f" {o} " in c and "XYZ" in c) else 1.0) for o in opts}
    print("noul", round(noul(fake, doc, "has XYZ?")["true"], 3))
    r = choice(fake, doc, "which?", [f"opt-{i}" for i in range(300)])
    print("choice", max(r, key=r.get))
