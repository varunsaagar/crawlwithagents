"""Single-process scorer: loads last/weights.pt into an UNSHARDED model, re-scores dev."""
import json, os, sys, torch
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import train_zero3_reference as T
ckpt = sys.argv[1]
net = T.build(sharded=False)   # same seed -> same frozen base (real pod: load /base)
sd = torch.load(os.path.join(ckpt, "weights.pt"))
missing, unexpected = net.load_state_dict(sd, strict=False)
assert not unexpected, unexpected
assert all(("lora_" not in k and not k.startswith("head.")) for k in missing), "trainable keys missing"
score = T.evaluate(net, T.dataset(2, 30)); meta = json.load(open(os.path.join(ckpt, "meta.json")))
print(json.dumps(dict(ckpt=ckpt, rescored=score, logged=meta["score"], match=abs(score - meta["score"]) < 1e-9, n_tensors=len(sd))))
assert abs(score - meta["score"]) < 1e-9
