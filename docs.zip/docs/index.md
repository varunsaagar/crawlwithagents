# jevjudge

`jevjudge` is a typed Python SDK for running **Jev decision models as an LLM judge** for voice and chat agents.

An LLM-as-judge makes one generative call per metric and returns free text. jevjudge does it differently:

* Each metric is a **rubric of typed questions** (yes/no, multiple choice, ordered scale).
* Fast Kairos decision models (`kairos-jev`, `kev-gemma`, `laya`, `djev`, or the stacked `jev-stack`) answer every question about a conversation, usually in **one request per state view**. They return probabilities and no text.
* A **confidence gate** accepts an answer when its confidence `q = max p` reaches the threshold θ.
* Anything below θ goes to a **Gemma / Gemini fallback**. The fallback is independent: it never sees Jev's verdict. It writes a rationale only when you ask for one.
* Thresholds can be **certified** per metric, and per traffic segment if you want. The guarantee is that the cascade's accuracy is at least the fallback's accuracy minus ε, with probability ≥ 1 − δ. Certificates are **approved, rolled back and phased in** under explicit governance, and anything in doubt fails closed to the fallback.
* An **accuracy monitor** freezes a metric to the fallback when its live accuracy drops. **Drift statistics** watch confidence, escalation rate and valid rate, and a **human review queue** turns hard and high-stakes items into gold labels.
* Broad metrics can be **decomposed** into narrow read-off questions combined by a learned verdict model. This took action completion from 44% to 96% answered by Jev.
* Scores use the same math as DeepEval's JevEval. Results come out as OpenTelemetry `gen_ai.evaluation.result` events, the CMCS `metrics` blob, Langfuse scores or Phoenix span annotations.

!!! tip "Why"
    On the v2 held-out set in [Results](results.md), the certified `jev-stack` cascade beat gemini-3.8-flash alone on all five voice metrics. Jev answered 96–100% of the verdicts itself, at 1.7–5.6% of the cost of a Gemini call per metric.

## 30-second example

The example below runs offline: `mock/demo` is the built-in deterministic mock backend. To use real models, drop both arguments: the defaults are `tiers=["djev"]` and `fallback="gemini-3.8-flash"` (see [Installation](installation.md) for credentials).

```python
from jevjudge import Judge

judge = Judge.from_preset("voice", tiers=["mock/demo"], fallback=None)   # live: Judge.from_preset("voice")

trace = {"session_id": "s1", "turns": [
    {"speaker": "user", "text": "Can you remove the international add-on?"},
    {"speaker": "agent", "text": "Done. The add-on is removed and you will see it on your next bill."},
]}
report = judge.grade(trace)

print(report.verdicts())        # {rubric_id: 'fired' | 'clean' | None}
print(report.rubric("output_pii").reason)
blob = report.to_blob()         # CMCS metrics blob
events = report.to_events()     # OTel gen_ai.evaluation.result events
judge.close()
```

## Architecture

```mermaid
flowchart LR
    IN["OTLP spans / BigQuery rows /<br/>turn lists / DeepEval cases / text"] --> S[Session]
    S --> P["pack<br/>(views, token budget, chunks)"]
    P --> R{route}
    R -->|read_off / style_sensitive| D["decide<br/>System One tier k"]
    D --> G{"gate<br/>q ≥ θ?"}
    G -->|"no, more tiers"| D
    G -->|accept| A[audit]
    G -->|"low conf / abstain / invalid"| E["escalate<br/>Gemma / Gemini"]
    R -->|"derive / reference_free / frozen"| E
    R -->|"rule / classifier"| C[code check]
    E --> A
    A --> AG["aggregate<br/>DeepEval math"]
    C --> AG
    AG --> OUT["GradeReport → OTel events,<br/>CMCS blob, JSONL"]
    REG[("certificate<br/>registry")] -.θ.-> G
    MON[("accuracy monitor<br/>e-process")] -.freeze.-> R
    A -.disagreements.-> MON
    OUT -.-> RQ[("human review<br/>queue")]
    OUT -.-> DS[("drift<br/>statistics")]
```

The judge is a compiled LangGraph state machine (`jevjudge.judge.graph`). The **calibration engine** (`jevjudge.calibration`) turns retained probabilities and labels into certificates. The **Calibration Studio** (`jevjudge serve`) wraps the whole workflow (upload traces, pick or convert rubrics, run, calibrate, export code) in a UI and an HTTP API.

## Where to go next

| I want to… | Read |
|---|---|
| Install and authenticate | [Installation](installation.md) |
| Grade my first session | [Quickstart](quickstart.md) |
| Write a judge for my own metric | [Build a judge for any metric](guides/custom-metric.md) |
| Reuse an existing LLM-judge prompt | [Convert an LLM judge](guides/convert-llm-judge.md) |
| Certify thresholds and go to production | [Escalation and calibration](concepts/escalation-and-calibration.md), [Production](guides/production.md) |
| Phase in, approve and roll back certificates | [Threshold governance](guides/governance.md) |
| Get human labels for hard and high-stakes items | [Human review queue](guides/review-queue.md) |
| Watch drift, freezes and latency; send results to Langfuse / Phoenix | [Monitoring and sinks](guides/monitoring.md) |
| Judge a broad metric with narrow questions | [Decomposed metrics](guides/decomposed-metrics.md) |
| See every config key | [Configuration](configuration.md) |
