# Research and alternative options — Kairos 26B ZeRO-3 / 64K

## A. Verified references (every link was opened via search results on 2026-10-12)

**Reference architecture: avbiswas/bev-train** (github.com/avbiswas/bev-train, commit a58c551, cloned and read)
- `network.py:107`: "Head runs in fp32 even under bf16 autocast: bf16 logits are too coarse for a stable loss". The backbone output is cast with `.float()` and `torch.autocast(enabled=False)`.
- Head: a task-type embedding token, then the option reps, then the answer token. It applies position-free attention blocks, then `einsum("bd,bcd->bc", answer_proj, choice_proj)/sqrt(new_dim)` and `masked_fill(~choice_mask, -inf)`.
- `tokenization.py`: every choice span starts at the same position id, choices can't see each other, and the answer comes after the longest choice and sees all of them.
- `dataset.py`: noul is two choices `["No","Yes"]`; score is levels written as `"i: level"` ("Choices share position ids, so the level index is written into the text"). Loss is plain `F.cross_entropy` over options.
- One difference: bev-train makes one row per question. Kairos packs all questions per state (the state is encoded once). `test_head.py` checks that packed equals separate within 1.6e-7.
- The bev-decider PyPI card says it truncates states over 2,048 tokens by default, and the HF model is cc-by-nc-4.0 (so don't reuse its weights commercially; the architecture idea is fine).

**Post-destroy "Default process group has not been initialized"**
- pytorch/pytorch#126379: `get_rank()` in the excepthook after `destroy_process_group()` raises this ValueError. Fixed by PR #126739.
- NVIDIA/Megatron-LM#3775 and PR #3781: the same error from `get_rank()` after destroy. The fix guards it with `torch.distributed.is_initialized()`.
- salesforce/LAVIS#537: `dist.barrier()` without a live group. Fix: `if is_dist_avail_and_initialized(): dist.barrier()`.

**ZeRO-3 rank-0-only eval or save deadlocks**
- deepspeedai/DeepSpeed#4910: ZeRO-3 hangs if any rank skips `generate()`. Maintainer (tjruwase): "all ranks in the data parallel group are expected to perform similar computation/communication, otherwise you will see the deadlocks".
- microsoft/DeepSpeedExamples#561: a ZeRO-3 save hang, "caused by that only rank0 calls the saving method. While under zero-3, all processes should do the stuff."
- deepspeedai/DeepSpeed#797: "all ranks need to call save_checkpoint" (there is a barrier in engine.save_checkpoint).
- kohya-ss/sd-scripts#1247: save_state inside `is_main_process` leads to an NCCL timeout. The fix moves it out of the rank-0 block.
- TensorAuto/OpenTau#435 / PR #462: in-training eval under ZeRO-3/FSDP desyncs all-gathers. Fixed by lockstep eval on all ranks (the HF `synced_gpus` pattern).
- huggingface/transformers#12587: `stage3_gather_16bit_weights_on_model_save` OOM at save. Options: disable it and run `zero_to_fp32.py` offline.
- deepspeedai/DeepSpeed#3582: host-memory growth after each ZeRO-3 16-bit consolidated save. Worth watching pod RAM during saves.

**Mixed fp32 head + bf16 LoRA under ZeRO-3 (defect 7)**
- deepspeedai/DeepSpeed#8072, PR #8073 (per-param dtype in `_allgather_params_coalesced`) and PR #8113 (merged 2026-07-11: "allows ZeRO-3 coalesced all-gather buckets to contain parameters with different original dtypes", aimed at fp32 LoRA on a bf16 base).
- huggingface/trl#6091: workaround `get_peft_model(..., autocast_adapter_dtype=False)`.
- Implication: on a DeepSpeed release that includes #8113, you may not need to promote the bf16 LoRA/norms to fp32. Promoting to fp32, as Kairos did, is still the safe choice and keeps the head fp32. I didn't verify which pip release first ships #8113. Check `pip show deepspeed` against the release notes.

**Gemma-4-26B-A4B long context**
- HF model card (google/gemma-4-26B-A4B) and the Gemma 4 model card: 256K context, about 25.2B total and about 3.8B active parameters.
- NVIDIA NeMo-RL Gemma 4 guide: FSDP2 recipes using expert parallel and context parallel (EP16/CP2 etc.) on 32 GPUs at 4K sequences. There's no public 64K fine-tune recipe for this model.

**Pod-RAM tokenisation per rank**
- HF forums (datasets multiprocessing memory) and datasets #3847 / #6369: tokenise once on rank 0, `save_to_disk`, then `load_from_disk` (Arrow mmap) on every rank. `main_process_first` alone doesn't stop every rank holding a copy.

**Not found:** I found no relevant Reddit (r/LocalLLaMA, r/MachineLearning), X or Stack Overflow thread more specific than the issues above, so none are cited.

## B. Options, ranked

| # | option | pros | cons | effort | risk |
|---|---|---|---|---|---|
| a | **Minimal fix, keep ZeRO-3** (PATCH.md) | Smallest change. The other 7 defects are already solved. Tested pattern | Manual gathers stay hand-rolled | 1 h + 45 min smoke | Low |
| b | `engine.save_checkpoint()` on all ranks + offline `zero_to_fp32.py` (or `get_fp32_state_dict_from_zero_checkpoint`), then filter to lora/head | Official path; gives resumable optimizer state (needed for h) | Checkpoint is big (optimizer shards); needs an extra conversion step; the trainable-only filter is still needed | ½ day | Low |
| c | FSDP2 `fully_shard` per decoder layer + DCP (`torch.distributed.checkpoint`) save/`get_model_state_dict(full_state_dict=True, cpu_offload=True)` | Native PyTorch; supports mixed dtypes per param; composes with context parallel; NeMo-RL uses it for Gemma 4 | Trainer rewrite; MoE expert wrapping and flex_attention compile need validation | 3–5 days | Medium |
| d | ZeRO-2 + CPU optimizer offload + activation checkpoint/offload | Rank-0 eval works again (params replicated) | It doesn't fit. The log shows 32K and 64K both OOM at about 78–84 GB with full params on every GPU (50.7 GB model + about 28 GB fixed MoE overhead). Optimizer state is tiny (64M trainable), so offloading it saves about 1 GB. Not viable on 80 GB | — | High |
| e | Single GPU (H200 141 GB / B200 180 GB), no distributed | No collectives at all; model 50.7 + 28 fixed + 64K activations should fit in about 141 GB (estimate) | Needs that hardware; one GPU is about 3× slower per epoch than 3 ranks | ½ day if hardware exists | Low to medium (memory estimate unmeasured) |
| f | Ulysses (DeepSpeed sequence parallel) / FSDP2 context parallel | Splits the 64K activations across GPUs; opens 128K | Needs flex_attention with Kairos' custom two-mask (choice-isolating) path to work under sequence sharding. Mask-aware CP isn't off-the-shelf | 1–2 weeks | High |
| g | Pre-tokenised shared cache (Arrow/`np.memmap` on the RWX PVC, written once by one job) | Removes Lesson 13's limit (5 ranks used 103/104 GiB). Allows 4–5 ranks. Faster start | One-off build job; must match the tokenizer and packer versions (hash them) | ½–1 day | Low |
| h | `torchrun --max-restarts=2` + resume from `last/` (plus step/RNG/optimizer state via b) | Survives transient NCCL or node faults; a 125 h run shouldn't depend on zero faults | Restarts only help if save/resume is correct, so do it after a and b. Today `last/` holds weights only, so a restart loses the optimizer state and step count | ½ day | Low |

**Recommended order:** (a) now, then the smoke run, then the full run. In parallel, (g) to go from 3 ranks to 4–5, then (b) + (h) for resumability. Consider (c)/(f) only if you need 128K or 8+ GPUs. Use (e) if an H200 or B200 becomes free.
