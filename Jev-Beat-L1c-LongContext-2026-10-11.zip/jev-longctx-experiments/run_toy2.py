"""Phase 2 (time-boxed): one seed per training variant, single-pass length sweep; + base seed 1."""
import json, time, torch
from toy_pointer import *
torch.set_num_threads(8)
STEPS = 3000; L0 = 64; LENS = [64, 128, 256, 512]; QT = ["noul", "choice", "score"]
MODELS = [("base", dict(L0=L0, steps=STEPS, k_train=(2, 6)), 1),
  ("hard_distract", dict(L0=L0, steps=STEPS, k_train=(6, 30)), 0),
  ("length_mix", dict(L0=L0, steps=STEPS, k_train=(2, 6), L_mix=[64, 64, 128, 256]), 0),
  ("ssmax_trained", dict(L0=L0, steps=STEPS, k_train=(2, 6), ssmax_train=True), 0),
  ("sandwich", dict(L0=L0, steps=STEPS, k_train=(2, 6), sandwich=True), 0)]
out = []; t0 = time.time()
def log(**r):
    out.append(r); print(json.dumps(r), f"t={time.time()-t0:.0f}s", flush=True); json.dump(out, open("results_toy2.json", "w"), indent=1)
for name, cfg, seed in MODELS:
    m = train(cfg, seed).eval(); torch.save(m.state_dict(), f"ckpt_{name}_s{seed}.pt")
    for L in LENS:
        for qt in QT: log(exp="length", model=name, seed=seed, L=L, k=L // 16, qtype=qt, mode="single", **evaluate(m, cfg, L, L // 16, qt, n=300))
    if name == "hard_distract":
        for k in [2, 6, 14, 30]:
            for qt in QT: log(exp="distract_fixL", model=name, seed=seed, L=64, k=k, qtype=qt, mode="single", **evaluate(m, cfg, 64, k, qt, n=300))
        for L in LENS:
            for qt in QT: log(exp="length_fixk", model=name, seed=seed, L=L, k=4, qtype=qt, mode="single", **evaluate(m, cfg, L, 4, qt, n=300))
