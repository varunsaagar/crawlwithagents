# PLAN — LLM-as-Judge continuous evaluation (one-pager)

**Goal:** Production continuous evaluation for voice-agent sessions (≈50–70k/day) + Llama/custom search. Build elsewhere; this pack is the blueprint.

**Audience:** Senior eng / ML platform. en-GB.

---

## Winning architecture (decision)

| Layer | Choice |
|-------|--------|
| Trace store | **Self-hosted Langfuse** |
| Online judges | **Binary rubric LLM judges** (safety, search relevance, faithfulness, task healthy, policy) |
| Calibration | **Weekly HITL anchors** + versioned gold sets; κ, Se, Sp; Rogan–Gladen-adjusted prevalence |
| CI | **Promptfoo / DeepEval** on pinned gold — gate prompt promotions |
| Drift | **Phoenix + Evidently**; separate **system** vs **judge** signals |
| Sampling | **5–10% random + 100% high-risk** (+ higher on canaries) |

Detail: [README](README.md) · [01-architecture.md](01-architecture.md)

---

## Phased delivery

| Phase | Outcome | Doc |
|-------|---------|-----|
| **Day 0 (2–4h)** | Ingest → Langfuse → one faithfulness judge → versions tagged | [02-build-plan.md](02-build-plan.md#day-0--24-hour-mvp) |
| **Week 1** | Five judges, sampling, gold@0.1, CI stub, alert stub | [02](02-build-plan.md#week-1--online-sampling--five-judges--ci-stub) |
| **Month 1** | Dual drift boards, promotion/rollback, runbooks, cost caps | [02](02-build-plan.md#month-1--production-discipline) |

Implementation sketches: [03-implementation-guide.md](03-implementation-guide.md)

---

## Version everything

`prompt_version` · `judge_version` · `rubric_version` · `gold_set_version` · `model_id`

- Immutable artifacts + changelog  
- Promote **shadow → canary → full**  
- **Humans approve rubric changes before live**  
- Rollback = pointer flip ≤15 min  

→ [04-versioning-and-ops.md](04-versioning-and-ops.md)

---

## Metrics honesty

- Sparse GT ⇒ publish judge rates **and** adjusted prevalence, never “% pass = precision”  
- Three drift signals: input/traffic · behaviour/output · judge/instrument  
- Dashboards: system / judge / promotion  

→ [05-metrics-and-drift.md](05-metrics-and-drift.md)

---

## Non-negotiables

1. Call path fail-open; eval async.  
2. Idempotent scores on `(session_id, judge_version)`.  
3. Alert namespaces: `system.*` vs `judge.*` vs `ops.*`.  
4. Measure κ — do not invent it.  
5. ASR quality can fake “judge” failures (see Artefact ref).

---

## Templates & references

- Copy-paste: [07-templates.md](07-templates.md)  
- Bibliography (Netflix lifecycle, arXiv 2608.18300, Who Drifted 2606.15474, G-Eval, RAGAS, reporting 2511.21140, Artefact, tooling): [06-references.md](06-references.md)  
- Full file list: [INDEX.md](INDEX.md)

---

## Success bar (Month 1)

On-call can answer **“Did the system drift or the judge?”** with evidence, and roll back either side within fifteen minutes — without publishing vanity precision tiles.

---

## First week owners (fill in)

| Stream | Name |
|--------|------|
| Langfuse + ingest | |
| Judges + rubrics | |
| Gold / HITL | |
| CI gates | |
| On-call / alerts | |

Kick-off: read this page, then skim [01-architecture.md](01-architecture.md) before writing code.
