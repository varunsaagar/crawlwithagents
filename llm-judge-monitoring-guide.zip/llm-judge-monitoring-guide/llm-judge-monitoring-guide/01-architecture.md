# 01 — Architecture

Cross-links: [PLAN](PLAN.md) · [Build plan](02-build-plan.md) · [Implementation](03-implementation-guide.md) · [Versioning](04-versioning-and-ops.md) · [Metrics](05-metrics-and-drift.md) · [Templates](07-templates.md)

---

## System diagram

```mermaid
flowchart TB
  subgraph Voice["Voice agent runtime"]
    ASR[ASR / STT]
    ORCH[Session orchestrator]
    SEARCH[Llama / custom search]
    LLM[Response LLM]
    TTS[TTS / actions]
  end

  subgraph Ingest["Ingest path"]
    IW[Ingest worker]
    REDACT[PII redact / hash]
  end

  subgraph Store["Observability store"]
    LF[(Langfuse self-hosted)]
    OBJ[(Object store: transcripts / docs)]
  end

  subgraph Online["Online evaluation"]
    SAMPLE[Sampler: 5–10% + 100% high-risk]
    JUDGES[Rubric LLM judges]
    QUEUE[Eval queue]
  end

  subgraph Offline["Offline / CI"]
    GOLD[(Versioned gold sets)]
    PF[Promptfoo / DeepEval]
    HITL[Weekly HITL anchors]
  end

  subgraph Drift["Drift & ops"]
    PHX[Phoenix]
    EV[Evidently]
    ALERT[Alert manager]
  end

  ASR --> ORCH
  ORCH --> SEARCH
  SEARCH --> LLM
  LLM --> TTS
  ORCH --> IW
  SEARCH --> IW
  LLM --> IW
  IW --> REDACT --> LF
  IW --> OBJ
  LF --> SAMPLE --> QUEUE --> JUDGES
  JUDGES --> LF
  GOLD --> PF
  GOLD --> HITL
  HITL --> LF
  LF --> PHX
  LF --> EV
  JUDGES --> ALERT
  PHX --> ALERT
  EV --> ALERT
  PF -.->|gate promotions| ORCH
```

---

## Components

| Component | Role | Notes |
|-----------|------|-------|
| Voice runtime | Produces sessions | Emits correlation IDs on every hop |
| Ingest worker | Normalises → Langfuse + object store | Async; never block the call path |
| Langfuse (self-hosted) | Traces, scores, datasets, UI | Own retention & network policy |
| Online eval worker | Samples + runs rubric judges | Idempotent on `session_id` + `judge_version` |
| Gold / HITL | Human labels, weekly refresh | Only source of calibration GT |
| Promptfoo / DeepEval | CI regressions for search + prompts | Blocks merge / promotion |
| Phoenix / Evidently | Embedding & tabular drift | Separate system vs judge panels |
| Alerting | Pages on calibrated signals | See [alert rules](03-implementation-guide.md#alert-rules) |

**Decision:** Langfuse is the system of record for traces and judge scores. Object store holds bulky payloads (full transcripts, retrieved doc blobs) referenced by hash. Do not duplicate the transcript in three databases.

---

## Session trace data model

Minimal fields every session must carry. Extend, do not rename, without a schema version bump.

```json
{
  "schema_version": "session_trace.v1",
  "session_id": "sess_01HZX...",
  "call_id": "call_...",
  "started_at": "2026-09-10T18:00:00Z",
  "ended_at": "2026-09-10T18:04:12Z",
  "channel": "voice",
  "locale": "en-GB",
  "transcript": [
    {"role": "user", "text": "...", "t0_ms": 0, "t1_ms": 1200, "asr_confidence": 0.91},
    {"role": "agent", "text": "...", "t0_ms": 1500, "t1_ms": 4200}
  ],
  "search_query": "reset broadband router lights amber",
  "retrieved_docs": [
    {"doc_id": "kb_4421", "title": "...", "score": 0.78, "snippet_hash": "sha256:..."}
  ],
  "model_answer": "Try power-cycling the router for 60 seconds...",
  "prompt_version": "voice_reply@3.2.1",
  "model_id": "llama-3.1-70b-instruct@2026-08-01",
  "search_backend_id": "custom-search@1.4.0",
  "asr_confidence": 0.88,
  "asr_confidence_min_turn": 0.62,
  "outcomes": {
    "task_resolved": null,
    "escalated": false,
    "hangup_reason": "user",
    "csat": null,
    "policy_flags": []
  },
  "risk_tags": ["billing", "high_value"],
  "high_risk": true,
  "ingest_at": "2026-09-10T18:04:15Z"
}
```

### Field contracts

| Field | Required | Contract |
|-------|----------|----------|
| `session_id` | yes | Globally unique, immutable |
| `transcript` | yes | Ordered turns; store ASR conf per user turn |
| `search_query` | when search ran | Exact string sent to retriever |
| `retrieved_docs` | when search ran | IDs + scores; full text via object store |
| `model_answer` | yes | Final agent utterance(s) under evaluation |
| `prompt_version` | yes | Semver or `name@version` — see [04](04-versioning-and-ops.md) |
| `model_id` | yes | Includes weights/date tag |
| `asr_confidence` | yes | Session aggregate (mean of user turns) |
| `outcomes.*` | partial OK | Fill when known; null ≠ false |
| `high_risk` | yes | Boolean from policy (billing, medical, legal, VIP, complaint) |

Judge scores are **not** part of the ingest payload; they attach later as Langfuse scores keyed by `(session_id, judge_version, rubric_version)`.

---

## Judge vs system drift (must separate)

| Drift type | What moved | Typical signals | Wrong response |
|------------|------------|-----------------|----------------|
| **System drift** | Traffic, ASR, retrieval, prompts, models | Input embedding shift; retrieval hit-rate; human-labelled failure rate up | Blame the judge |
| **Judge drift** | Judge model, prompt, rubric, temperature | κ vs HITL drops; score rate jumps with **stable** gold; judge↔judge disagreement | Ship “fixes” to production prompts |

Architecture rule: **two dashboards, two alert namespaces** (`system.*` vs `judge.*`). Shared charts are fine for debugging; shared *alerts* are not. See [05-metrics-and-drift.md](05-metrics-and-drift.md) and arXiv [2606.15474](06-references.md).

---

## Sampling policy

Online judges are expensive. Sample deliberately.

### Default online policy

| Stratum | Rate | Rationale |
|---------|------|-----------|
| High-risk (`high_risk=true`) | **100%** | Safety / policy / VIP |
| Random remainder | **5–10%** | Prevalence + trend |
| New `prompt_version` / `model_id` (canary) | **25–50%** for canary cohort | Fast signal before full |
| Explicit opt-in debug IDs | 100% | Short TTL |

Tune the random band with cost: at 60k sessions/day, 10% ≈ 6k judged/day; five binary judges ≈ 30k judge calls/day. Budget that explicitly.

### Offline / HITL policy

- **Gold set:** fixed N (start 200–500) stratified by intent / risk / locale; versioned (`gold_set_version`).
- **Weekly anchor:** +100–200 fresh stratified labels; never reuse the same week’s labels for both training judge prompts *and* reporting κ without a hold-out.
- **Disagreement review:** all judge↔human mismatches on anchors; sample of judge↔judge disagreements.

### Sampling filter (conceptual)

See SQL-ish template in [07-templates.md](07-templates.md#sampling-sql-ish-filter). Implement in the eval worker, not in the voice path.

---

## Latency & isolation

- Call path: fire-and-forget ingest (queue). Fail-open: lost eval ≠ dropped call.
- Eval worker: own GPU/API quota; circuit-break on judge provider errors.
- CI: gold-set eval only; never hit production traffic from CI.

---

## Security & PII

- Redact before Langfuse if your threat model requires it; keep reversible tokens only in a locked vault if needed for HITL.
- Access: least privilege on Langfuse UI; audit exports.
- Retention: align with call-recording policy (often 30–90 days for full text; longer for aggregates).

---

## Next

Implement the phased plan in [02-build-plan.md](02-build-plan.md). Schemas and workers in [03-implementation-guide.md](03-implementation-guide.md).
