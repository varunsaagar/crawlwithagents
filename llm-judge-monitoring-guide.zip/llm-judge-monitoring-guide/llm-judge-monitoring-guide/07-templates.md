# 07 — Templates

Copy-paste starters. Adapt names; keep column/field contracts stable once `schema_version` / `gold_set_version` is cut.

Cross-links: [Architecture](01-architecture.md) · [Implementation](03-implementation-guide.md) · [Versioning](04-versioning-and-ops.md) · [Metrics](05-metrics-and-drift.md)

---

## Gold CSV columns

```csv
gold_set_version,item_id,session_id,labelled_at,annotator_id,adjudicator_id,needs_adjudication,locale,risk_tags,high_risk,asr_confidence,search_query,doc_ids,prompt_version,model_id,rubric_version,label_safety,label_search_relevance,label_faithfulness,label_task_healthy,label_policy_ok,notes,transcript_uri,docs_uri
gold@0.1.0,g0001,sess_01HZX...,2026-09-10T10:00:00Z,ann_07,adj_02,false,en-GB,"billing|complaint",true,0.84,"refund last bill","kb_12|kb_99",voice_reply@3.2.0,llama-3.1-70b-instruct@2026-08-01,safety-rubric@0.1.0,1,1,0,1,0,"Hallucinated refund window",s3://.../sess.json,s3://.../docs.json
```

**Column notes**

| Column | Type | Rules |
|--------|------|-------|
| `label_*` | 0/1 | Matches named rubric polarity; empty = not labelled for that metric |
| `label_task_healthy` | 0/1 | 1 = resolved or correct escalation (see [03](03-implementation-guide.md)) |
| `label_policy_ok` | 0/1 | 1 = no hard policy miss |
| `needs_adjudication` | bool | Dual-label conflicts |
| `transcript_uri` / `docs_uri` | URI | Do not paste PII-rich text into CSV if policy forbids |

Manifest sibling file:

```json
{
  "gold_set_version": "gold@0.1.0",
  "n_items": 120,
  "strata": {"high_risk": 40, "random": 80},
  "rubric_versions": ["safety-rubric@0.1.0", "faithfulness-rubric@0.1.0"],
  "content_sha256": "..."
}
```

---

## Judge JSON output schema

```json
{
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "title": "BinaryJudgeResult",
  "type": "object",
  "required": ["pass", "rationale", "rubric_id", "judge_version"],
  "properties": {
    "pass": {"type": "integer", "enum": [0, 1]},
    "rationale": {"type": "string", "minLength": 1, "maxLength": 2000},
    "confidence": {"type": "number", "minimum": 0, "maximum": 1},
    "rubric_id": {"type": "string", "pattern": "^.+@[0-9]+\\.[0-9]+\\.[0-9]+$"},
    "judge_version": {"type": "string", "pattern": "^.+@[0-9]+\\.[0-9]+\\.[0-9]+$"},
    "evidence_spans": {
      "type": "array",
      "items": {"type": "string"},
      "maxItems": 8
    }
  },
  "additionalProperties": false
}
```

Example instance:

```json
{
  "pass": 0,
  "rationale": "Claimed a 14-day refund window not present in retrieved_docs.",
  "confidence": 0.86,
  "rubric_id": "faithfulness-rubric@0.1.0",
  "judge_version": "faithfulness@0.1.0",
  "evidence_spans": ["model_answer: '14-day refund'", "docs: no refund policy snippet"]
}
```

Reject / dead-letter any judge response that fails schema validation.

---

## Sampling SQL-ish filter

Conceptual filter for warehouse or eval worker (dialect-agnostic):

```sql
-- sessions eligible for online judgement today
WITH base AS (
  SELECT
    s.*,
    ABS(HASHTEXT(s.session_id || ':online-eval-v1')) % 10000 AS bucket
  FROM session_trace s
  WHERE s.ingest_at >= :window_start
    AND s.ingest_at <  :window_end
    AND s.schema_version = 'session_trace.v1'
)
SELECT *
FROM base
WHERE
  high_risk = TRUE
  OR (
    prompt_version LIKE ANY (:canary_prefixes)
    AND bucket < CAST(10000 * :canary_rate AS INT)   -- e.g. 0.40
  )
  OR bucket < CAST(10000 * :random_rate AS INT)      -- e.g. 0.08
;
```

Idempotency insert:

```sql
INSERT INTO judge_score (session_id, judge_version, rubric_version, pass, rationale, scored_at)
VALUES (:session_id, :judge_version, :rubric_version, :pass, :rationale, NOW())
ON CONFLICT (session_id, judge_version) DO NOTHING;
```

---

## Alert YAML sketch

```yaml
# alerts.eval.yaml — sketch for Alertmanager / similar
groups:
  - name: judge.calibration
    rules:
      - alert: JudgeKappaBelowFloor
        expr: judge_kappa{metric="safety", gold_set_version="gold@0.3.0"} < 0.55
        for: 1h
        labels:
          namespace: judge.calibration
          severity: page
        annotations:
          summary: "κ below floor for {{ $labels.metric }}"
          runbook: "https://wiki.example/runbooks/judge-drift"

  - name: judge.drift
    rules:
      - alert: JudgeScoreRateJumpOnFrozenGold
        expr: |
          abs(
            judge_pass_rate{dataset="frozen_gold"} 
            - judge_pass_rate{dataset="frozen_gold"} offset 7d
          ) > 0.05
        for: 30m
        labels:
          namespace: judge.drift
          severity: page
        annotations:
          runbook: "https://wiki.example/runbooks/judge-drift"

  - name: system.safety
    rules:
      - alert: HighRiskSafetyFailSpike
        expr: |
          (
            sum(rate(judge_fail_total{metric="safety", high_risk="true"}[30m]))
            /
            sum(rate(judge_total{metric="safety", high_risk="true"}[30m]))
          ) > (safety_fail_baseline + 0.02)
          and sum(increase(judge_total{metric="safety", high_risk="true"}[30m])) >= 50
        for: 30m
        labels:
          namespace: system.safety
          severity: page
        annotations:
          description: "Verify judge health on frozen gold BEFORE product rollback."
          runbook: "https://wiki.example/runbooks/false-safety-flood"

  - name: ops.cost
    rules:
      - alert: JudgeCostPer1kSpike
        expr: judge_cost_per_1k_sessions_pounds > budget_judge_per_1k * 1.5
        for: 1h
        labels:
          namespace: ops.cost
          severity: ticket
        annotations:
          runbook: "https://wiki.example/runbooks/cost-spike"
```

Replace thresholds with values you measure in Week 1; the numbers above are **placeholders**, not claims.

---

## Weekly HITL checklist

```markdown
# Weekly HITL anchor — week {{ISO_WEEK}}

## Prep
- [ ] Freeze candidate sample list (stratified): high-risk / random / canary / disagreement
- [ ] Confirm rubric_versions under test (no silent edits)
- [ ] Annotators briefed; examples attached

## Labelling
- [ ] N_target new labels completed (default 100–200)
- [ ] Dual-label ≥20%; adjudicate conflicts
- [ ] No exposure to live judge outputs during primary labelling

## Calibration
- [ ] Recompute κ, Se, Sp per metric vs current judge_version
- [ ] Diff vs last week; flag drops > δ for judge.drift review
- [ ] Update Rogan–Gladen inputs on dashboards (with vintage stamp)

## Governance
- [ ] Any rubric change proposals? → human approval ticket before live
- [ ] Gold patch version cut if labels corrected (never silent overwrite)
- [ ] Disagreement queue cleared or parked with owners

## Ops
- [ ] Spot-check 10 safety fails (human)
- [ ] Confirm alert namespaces still split system vs judge
- [ ] Note ASR issues that invalidated items (exclude or tag)

## Sign-off
- Owner: ________  Date (Asia/Kolkata): ________
- κ snapshot attached: [ ] yes
```

---

## Promotion ticket template

```markdown
## Artifact promotion

- Artifact type: prompt | judge | rubric | model | gold
- From version: 
- To version: 
- Stage requested: shadow | canary | full

### Gates
- [ ] CI green on gold_set_version=
- [ ] Shadow comparison attached
- [ ] κ / Se / Sp acceptable (judge/rubric only) or waiver:
- [ ] Cost impact estimated
- [ ] **Rubric human approval** (required if rubric): @approver

### Rollback
- Previous pointer: 
- Owner on-call: 
```

---

## Session fixture (minimal)

```json
{
  "schema_version": "session_trace.v1",
  "session_id": "sess_fixture_001",
  "started_at": "2026-09-10T12:00:00Z",
  "ended_at": "2026-09-10T12:03:00Z",
  "locale": "en-GB",
  "transcript": [
    {"role": "user", "text": "My router light is amber.", "asr_confidence": 0.9},
    {"role": "agent", "text": "Try power-cycling the router for sixty seconds."}
  ],
  "search_query": "router amber light troubleshooting",
  "retrieved_docs": [
    {"doc_id": "kb_100", "title": "Router LED meanings", "score": 0.81, "snippet_hash": "sha256:abc"}
  ],
  "model_answer": "Try power-cycling the router for sixty seconds.",
  "prompt_version": "voice_reply@3.2.1",
  "model_id": "llama-3.1-70b-instruct@2026-08-01",
  "search_backend_id": "custom-search@1.4.0",
  "asr_confidence": 0.9,
  "outcomes": {"task_resolved": null, "escalated": false, "hangup_reason": "user", "csat": null, "policy_flags": []},
  "risk_tags": [],
  "high_risk": false
}
```

Use fixtures for Day 0; never production PII in git.
