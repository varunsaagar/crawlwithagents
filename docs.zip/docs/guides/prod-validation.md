# Production validation: JEV vs the production judge

This page records how jevjudge is checked against the judge that scores production today (CMCS, a GPT/Gemini
LLM-as-judge), on real traffic. The question it answers: **on one full day of production conversations, does the JEV
stack reach the same verdicts as the production judge, and where they differ, who is right?**

Status: **run 1 (2026-09-29) complete**. 16,511 sessions graded (82,555 verdicts), 0 errors.

## What is compared

| | Production (incumbent) | JEV |
|---|---|---|
| Judge | CMCS metric jobs (LLM-as-judge, one call per metric group) | `configs/judge_v2.yaml`: the full JEV stack |
| Models | GPT / Gemini via CMCS lanes | 3-member jev-stack (kairos-jev, kev-gemma, djev) + fitted combiner; decomposed action completion and toxicity with learned `verdict_model`s; certified thresholds; escalation to gemini-3.8-flash, then gemma-26b, only when the stack is not confident |
| Output | `m_*` columns of `prod_eval_hub_sessions` | for every session × metric: stack verdict + probability **before** escalation, escalated?, final verdict, latency |
| Endpoints | CMCS lanes | **prod** Kairos gateway (`kairos-gateway.verizon.com`, LiteLLM, Bearer JWT) |

The two JEV readings are reported separately:

- **Jev-only:** the stack's own verdict, with no LLM involved.
- **Cascade:** what jevjudge returns in production, after any escalation.

## Data: run 1

- **Source:** `vz-it-pr-ienv-vegsdo-0.vz_aid_vegs_tbls.prod_eval_hub_sessions`, `date_bucket = 2026-09-29`. This is
  the most recent day with Sierra, Decagon and CES voice all present; Decagon voice traffic stops after 09-29.
- **Input:** the stored session rebuild (`spans` / `transcript`), which is the same rebuild CMCS's own optimizer
  harness uses.
- **Sample:** 15,173 voice sessions, stratified; plus all 1,338 sessions of the two chat projects (second job).
  - Every session the production judge flagged (PII, hallucination ≥ 0.5, action-completion failure) is included.
  - About 3,000 random other sessions per project are added, plus all of CES_VOICE_AGENT.
  - Sampling weights are kept, so agreement is also reported for the whole day (population-weighted).

| Project | Sessions that day | Production positives (all taken) | Random others | Weight on others |
|---|---|---|---|---|
| SIERRA_PILOT | 19,567 | 3,929 | 2,395 | 6.53 |
| DECAGON_PILOT | 16,794 | 2,220 | 2,593 | 5.62 |
| CES_VOICE_AGENT_NONBILLING | 5,738 | 2,004 | 1,934 | 1.93 |
| CES_VOICE_AGENT | 98 | 26 | 72 | 1.0 |

### Metric mapping

| JEV metric | Production column | Comparable? |
|---|---|---|
| action_completion | `m_action_completion` (0/1) | yes |
| output_pii | `m_output_pii` (0/1) | yes |
| hallucination | `m_hallucination` (0–1, positive at ≥ 0.5) | yes |
| output_toxicity | `m_output_toxicity` | agreement only: production is 0 on every session that day, so precision, recall and kappa are undefined |
| sexism | `m_output_sexism` (`m_input_sexism` is null everywhere) | agreement only: production is 0 on every session that day |

## How accuracy is measured

For each project × metric, for both Jev-only and Cascade:

1. **Agreement with production.** Reported as n, positive rate (production vs JEV), raw agreement, Cohen's kappa, and
   precision / recall / F1 with production as reference. Each is given both on the sample and population-weighted.
2. **Who is right when they disagree (blind adjudication).**
   - Up to 150 disagreements per metric are drawn, stratified by project.
   - Each one is judged by gemini-3.8-flash on the prod gateway, with the same rubric question and a rationale.
   - The adjudicator is not told which judge said what.
   - Reported: the share of disagreements where it sides with JEV vs with production.
3. **Cost and speed.** Escalation rate (how often JEV needed an LLM) and latency (p50 / p95 per session).

Production is not ground truth. Its own action-completion labels were only about 90% self-consistent in earlier
experiments (see [results](../results.md)). That is why disagreements are adjudicated rather than counted as JEV errors.
Human labels exist only for 83 hallucination sessions between 09-07 and 09-14, none of which fall on 09-29.

## Results: run 1 (2026-09-29)

### Totals

| | |
|---|---|
| Sessions graded | 16,511: 15,173 voice (stratified) + 1,338 chat (all) |
| Errors / timeouts | 0 of 82,555 session × metric gradings |
| Ungradable, no stored content | 1,418 in the sample. In the whole day: SIERRA_PILOT 3,540, DECAGON_PILOT 66 |
| Wall clock on Dataproc | voice 2 h 04 min; chat about 10 min |
| Latency per session (all 5 metrics) | p50 8.9 s, p95 30.8 s |

### Agreement with production (all projects, final cascade verdicts)

Positive means the issue is present (for action completion: the task was not completed). Precision, recall and F1 use
production as the reference.

| Metric | n | Production + | JEV + | Agreement | Kappa | P / R / F1 | Escalation |
|---|---|---|---|---|---|---|---|
| action completion | 15,093 | 47.4% | 52.6% | **0.731** (population-weighted 0.762) | 0.46 | 0.70 / 0.77 / 0.73 | 9.9% |
| PII | 15,093 | 1.6% | 0.7% | **0.980** | 0.14 | 0.23 / 0.11 / 0.15 | 0.6% |
| hallucination | 15,088 | 0.6% | 3.9% | **0.958** | 0.05 | 0.03 / 0.22 / 0.06 | 0.6% |
| toxicity | 15,093 | 0 | 6 sessions | 1.000 | – | – | 0.6% |
| sexism | 15,093 | 0 | 5 sessions | 1.000 | – | – | 0.6% |

The two JEV readings barely differ. For action completion, agreement is 0.724 with JEV alone and 0.731 after
escalation: the stack decides almost everything on its own.

Action completion by project (agreement / kappa):

| Project | Agreement / kappa | Note |
|---|---|---|
| SIERRA_PILOT | 0.74 / 0.48 | |
| DECAGON_PILOT | 0.78 / 0.55 | |
| DECAGON_PILOT_CHAT | 0.79 / 0.43 | |
| SIERRA_PILOT_CHAT | 0.68 / 0.28 | |
| CES_VOICE_AGENT_NONBILLING | 0.66 / 0.33 | JEV flags far more failures (77% vs 49%) |
| CES_VOICE_AGENT | 0.51 / 0.17 | JEV flags far more failures (69% vs 27%), on n = 98 |

Full per-project tables for every metric are in `reports/prod_validation/2026-09-29/summary.md`.

### Who is right when they disagree (blind adjudication by gemini-3.8-flash, prod gateway)

| Metric | Disagreements judged | Sides with JEV | Production-only flags upheld for JEV | JEV-only flags upheld |
|---|---|---|---|---|
| action completion | 150 | **69%** | 39 / 62 | 65 / 88 |
| PII | 149 | **78%** | 103 / 107 (production's extra PII flags rejected) | 13 / 42 |
| hallucination | 149 | 40% | 11 / 12 | 49 / 137 (JEV's extra flags mostly rejected) |
| toxicity | 6 | 0% | – | 0 / 6 |
| sexism | 5 | 20% | – | 1 / 5 |

On action completion the adjudicator sides with JEV most strongly on CES_VOICE_AGENT_NONBILLING (41 / 49) and Sierra
(36 / 47). On Decagon it slightly favours production (22 of 39 cases).

### Estimated accuracy, taking the adjudicator as truth

The estimate assumes both judges are right where they agree, and splits the disagreements by the adjudication rate.
It is computed on the stratified sample (not population-weighted) and relies on one LLM adjudicator.

| Metric | JEV | Production |
|---|---|---|
| action completion | **≈ 0.92** | ≈ 0.81 |
| PII | **≈ 0.996** | ≈ 0.984 |
| hallucination | ≈ 0.975 | **≈ 0.983** |
| toxicity / sexism | ≈ 0.9996 (11 rejected flags in 15k sessions) | 1.0 (no positives that day) |

### What this shows

1. **Action completion, the critical metric.** JEV and production disagree on about 27% of sessions. Where they do, an
   independent judge sides with JEV about 2 to 1. JEV answers 90% of verdicts without any LLM.
2. **PII.** JEV is more conservative than production. Production's extra flags were almost all rejected (103 / 107).
3. **Hallucination is the weak spot.** JEV flags about 6× more than production, and most of the extra flags are
   rejected. The likely cause is input fidelity: hallucination is judged against what the agent was told and what
   tools returned, and the hub's stored copy has no system prompt or tool inputs and cuts tool outputs at 2,000
   characters. So claims that were grounded can look unsupported. Next steps:
   - re-grade the disagreement set from the full traces (`vz_aid_otel_traces_tbl`);
   - recalibrate the hallucination threshold on the adjudicated labels.
4. **Toxicity and sexism.** Production found nothing that day; JEV raised 11 flags in 15,093 sessions, all but one rejected.

## Pilot (100 sessions, before the full run)

| | |
|---|---|
| Errors / timeouts | 0 of 500 session × metric gradings |
| Latency per session (all 5 metrics) | p50 25.7 s, p95 35.5 s |
| Escalation | action completion 4%; PII, sexism, toxicity and hallucination 0% |
| Throughput | about 0.9 sessions/s steady state (4 tasks, kev-gemma capped at 16 concurrent) |

## Known limits of run 1

- **Input fidelity.** The hub row omits tool inputs and system prompts, and caps tool outputs at 2,000 characters.
  The production judge saw the full trace, so part of any disagreement can come from JEV seeing less.
- **Audit sampling.** The 5% audit escalation (about 4.5% of verdicts flagged) did not execute on executors, because
  the monitor is disabled there. This does not change any verdict, and escalation rates exclude audits.
- **Use-case coverage.** Run 1 covers the four voice projects. For other use cases, coverage depends on whether CMCS
  wrote production verdicts for them (see below).

## Use-case coverage (2026-09-29)

**Reading the traces works for every team.** `otel-check` and the [trace contract](trace-contract.md) cover all 27
projects in `vz_aid_otel_traces_tbl`.

**Comparing accuracy needs production verdicts.** On 09-29, CMCS wrote production verdicts for exactly 6 projects, and
all 6 are in run 1:

| Project | Sessions | Production positives | In run 1 |
|---|---|---|---|
| SIERRA_PILOT | 19,567 | AC fail 3,885, PII 50, hallucination 14 | stratified sample |
| DECAGON_PILOT | 16,794 | AC fail 2,142, PII 88, hallucination 9 | stratified sample |
| CES_VOICE_AGENT_NONBILLING | 5,738 | AC fail 1,911, PII 96, hallucination 65 | stratified sample |
| DECAGON_PILOT_CHAT | 692 | AC fail 119, PII 11, hallucination 1 | all |
| SIERRA_PILOT_CHAT | 646 | AC fail 117, PII 4 | all |
| CES_VOICE_AGENT | 98 | AC fail 26 | all |

- **Toxicity and sexism:** production scored 0 positives for both, in every project.
- **Sessions without stored content:** about 3.5k SIERRA_PILOT hub rows have neither spans nor transcript. They are
  reported as ungradable, not dropped.

**Use cases with traces but no production verdicts** have nothing to agree with, so they can only get JEV rates plus a
Gemini reference sample. This needs a separate extract from the 184 GB/day traces partition, which is pending a cost
decision:

- ces_hotline (about 20.7k sessions);
- vz-gpt;
- VCG_ORION_AGENT_PROD and VCG_ORION_AGENT_PREPROD;
- the Sierra and Decagon "Verizon Pilot Agent" services;
- the mita-*, server-* and IRIS agents (internal tools: the voice metrics apply only partly).

## Reproduce

```bash
# on a machine with prod gcloud access; runs on Dataproc (vz-it-pr-ienv-vegsdo-dp-eph-cpu4), never locally
bash spark/submit_prod_validation.sh   # sample → grade → compare → adjudicate; config passed as
                                       # spark.yarn.appMasterEnv.* + spark.executorEnv.*, proxies cleared,
                                       # gateway JWT read from Secret Manager at runtime
```

Outputs:

- **Per-row results:** `gs://ienv-prod-vegsdo-0-usre-cmcscode/jevjudge/prod_validation/2026-09-29/`. Rationales are
  only stored there.
- **Aggregates:** `reports/prod_validation/2026-09-29/`. Counts and metrics only.
