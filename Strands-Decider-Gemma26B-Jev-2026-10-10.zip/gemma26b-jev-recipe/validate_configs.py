"""Check stage YAMLs only use keys strands-decider's TrainConfig accepts (parsed from source, no torch needed)."""
import ast, os, sys, yaml
REPO = os.environ.get("REPO", "/workspace/refs/strands-decider")
tree = ast.parse(open(f"{REPO}/src/strands_decider/train.py").read())
keys = next({s.target.id for s in n.body if isinstance(s, ast.AnnAssign)}
            for n in tree.body if isinstance(n, ast.ClassDef) and n.name == "TrainConfig")
bad = 0
for p in sys.argv[1:]:
    cfg = yaml.safe_load(open(p))
    unk = set(cfg) - keys
    ok = not unk and cfg["base_model"].startswith("google/gemma-4") and cfg["force_bos"] and \
         not any(t.startswith("in_proj") or t == "out_proj" for t in cfg["lora_targets"]) and \
         (not cfg.get("precompute_frozen_kl") or cfg.get("group_by_length"))
    print(f"{p}: {'OK' if ok else 'FAIL'} max_length={cfg['max_length']} unknown={sorted(unk)}")
    bad += not ok
sys.exit(bad)
