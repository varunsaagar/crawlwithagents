import random, sys, os, torch
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from jev_native_head import JevHead, TinyBackbone, JevNet, freeze_for_lora, pack
torch.manual_seed(0); H = 64
def check(name, ok, info=""): print(f"[{'PASS' if ok else 'FAIL'}] {name} {info}"); assert ok

# 1 permutation equivariance at K=255 (head alone)
head = JevHead(H, layers=2).eval(); K = 255
C = torch.randn(2, K, H); A = torch.randn(2, H); M = torch.ones(2, K, dtype=torch.bool); M[1, 200:] = False
T = torch.tensor([0, 0]); perm = torch.randperm(K)
with torch.no_grad():
    l1 = head(C, A, M, T); l2 = head(C[:, perm], A, M[:, perm], T)
fin = M & M  # compare finite entries; -inf positions must coincide
err = (l1[:, perm][M[:, perm]] - l2[M[:, perm]]).abs().max().item()
check("perm-equivariance K=255", err < 1e-5 and torch.equal(torch.isinf(l1[:, perm]), torch.isinf(l2)), f"max|err|={err:.3e}")

# 2 mask never selects invalid
lp = head.log_probs(l1, T); am = l1.argmax(-1)
check("mask: argmax always valid", bool(M[torch.arange(2), am].all()), f"invalid prob mass={lp[~M].exp().sum().item():.1e}")

# 3 fp32 head under bf16 backbone/autocast
bb = TinyBackbone(128, H).to(torch.bfloat16); freeze_for_lora(bb); net = JevNet(bb, H)
check("head params fp32", all(p.dtype == torch.float32 for p in net.head.parameters()))
rng = random.Random(0); state = [rng.randrange(10, 128) for _ in range(50)]
qs = [dict(type="choice", q_ids=[2, 3], options=[[o, o+1] for o in range(20, 27)]),
      dict(type="noul", q_ids=[2, 4, 33], options=[[5], [6]]),
      dict(type="score", q_ids=[2, 7], options=[[8, 0], [8, 1], [8, 2], [8, 3]])]
with torch.autocast("cpu", dtype=torch.bfloat16):
    lg, _ = net(pack(state, qs, {"ANS": 1}))
check("logits fp32 from bf16 backbone", lg.dtype == torch.float32, str(lg.dtype))
check("trainable = lora only in backbone", all(("lora_" in n) == p.requires_grad for n, p in bb.named_parameters()))

# 4 packed multi-question == separate forwards (fp32 backbone)
bb = TinyBackbone(512, H); freeze_for_lora(bb); net = JevNet(bb, H).eval()
with torch.no_grad():
    packed, _ = net(pack(state, qs, {"ANS": 1}))
    sep = [net(pack(state, [q], {"ANS": 1}))[0][0] for q in qs]
errs = [ (packed[i, :len(sep[i])] - sep[i]).abs().max().item() for i in range(3)]
check("packed == separate", max(errs) < 1e-5, f"max|err|={max(errs):.3e}")

# 5 option order invariance end-to-end (backbone shares start positions + isolating mask)
perm = [3, 0, 6, 1, 5, 2, 4]; q2 = dict(qs[0], options=[qs[0]["options"][j] for j in perm])
with torch.no_grad():
    a = net(pack(state, [qs[0]], {"ANS": 1}))[0][0]; b = net(pack(state, [q2], {"ANS": 1}))[0][0]
e2e = (a[perm] - b).abs().max().item()
check("end-to-end option-order invariance", e2e < 1e-5, f"max|err|={e2e:.3e}")

# 6 long-ish packing, truncated=0, and over-length is refused (never silently cut)
long_state = [rng.randrange(10, 128) for _ in range(4000)]
qsL = [dict(type="choice", q_ids=[2, 3], options=[[o] for o in range(10, 10+K)])] + qs[1:]
p = pack(long_state, qsL, {"ANS": 1}, max_len=8192)
check("pack 4k state + K=255 within 8192", p["truncated"] == 0, f"L={len(p['ids'])} truncated={p['truncated']}")
try: pack(long_state, qsL, {"ANS": 1}, max_len=4096); check("over-length refused", False)
except ValueError as ex: check("over-length refused (no silent truncation)", True, str(ex)[:60])
with torch.no_grad(): lgL, _ = net(p)
check("forward at K=255 finite on valid", torch.isfinite(lgL[0, :255]).all().item(), f"shape={tuple(lgL.shape)}")
net.train(); net.backbone.gc = True
loss = torch.nn.functional.cross_entropy(net(pack(state, qs, {"ANS": 1}))[0], torch.tensor([1, 0, 2])); loss.backward()
check("grad checkpointing backward: lora+head grads", all(p.grad is not None for p in net.parameters() if p.requires_grad))
