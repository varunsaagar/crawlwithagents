"""Decisive eval: native-26B Jev vs prompted 26B (0.900) vs L1c E4B (0.215) vs prompted E2B (0.500)
on IDENTICAL item_ids. Inputs: one JSONL per system with {item_id, type, n_tokens, pred, gold, conf?}.
Reports per system/type/bucket accuracy, paired McNemar vs reference, and the decision rule."""
import json, math, sys
from collections import defaultdict
from calibrate import bucket

def load(p): return {r["item_id"]: r for r in map(json.loads, open(p))}

def mcnemar(a, b):
    """exact two-sided p for discordant pairs (a right/b wrong = n10, a wrong/b right = n01)."""
    n10 = sum(x and not y for x, y in zip(a, b)); n01 = sum(y and not x for x, y in zip(a, b)); n = n10 + n01
    if n == 0: return n10, n01, 1.0
    k = min(n10, n01); p = 2 * sum(math.comb(n, i) for i in range(k + 1)) / 2 ** n
    return n10, n01, min(1.0, p)

def compare(systems, ref="prompted_26b", cand="native_26b"):
    common = set.intersection(*(set(s) for s in systems.values()))
    assert common, "no shared item_ids"; ids = sorted(common)
    res = {"n_items": len(ids), "acc": {}, "slices": defaultdict(dict)}
    for name, s in systems.items():
        ok = [s[i]["pred"] == s[i]["gold"] for i in ids]; res["acc"][name] = sum(ok) / len(ok)
        for i, o in zip(ids, ok):
            k = f'{s[i]["type"]}|{bucket(s[i]["n_tokens"])}'; d = res["slices"][k].setdefault(name, [0, 0]); d[0] += o; d[1] += 1
    a = [systems[cand][i]["pred"] == systems[cand][i]["gold"] for i in ids]
    b = [systems[ref][i]["pred"] == systems[ref][i]["gold"] for i in ids]
    n10, n01, p = mcnemar(a, b); gap = res["acc"][cand] - res["acc"][ref]
    res["paired"] = dict(cand_only=n10, ref_only=n01, p=p, gap=gap)
    if gap >= -0.02: verdict = "SHIP-TRACK: native one-pass within 2 pts of prompted 26B -> proceed to calibration/LTT + 64k slices"
    elif gap >= -0.10: verdict = "RECIPE GAP (moderate): run head-vs-finetune diagnostic before more 64k compute"
    else: verdict = "RECIPE GAP (large, like L1c vs E2B): stop scaling; diagnose head/packing/finetune (prompted base, LoRA without head, head-only)"
    res["verdict"] = verdict; res["slices"] = {k: {n: v[0] / v[1] for n, v in d.items()} for k, d in res["slices"].items()}
    return res

if __name__ == "__main__":
    systems = {a.split("=")[0]: load(a.split("=")[1]) for a in sys.argv[1:]}
    print(json.dumps(compare(systems), indent=1))
