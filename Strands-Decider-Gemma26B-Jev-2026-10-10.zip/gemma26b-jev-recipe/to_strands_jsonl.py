"""Convert Jev rows -> strands-decider Example JSONL.
Jev row: {"type":"noul|choice|score","context":str,"question":str,"options":[str|[name,desc]],"label":int|bool,"group":str}
Example fields (src/strands_decider/data/format.py): kind, state, instructions, options [[name,desc]], label, task, weight.
noul: label 0=false 1=true, options [["no",""],["yes",""]] (check format.py for the exact noul convention before use).
Also writes ctx_tokens so length buckets can be assigned later."""
import argparse, json
def conv(r, tok=None):
    kind = r["type"]; opts = r.get("options") or (["no", "yes"] if kind == "noul" else [])
    opts = [o if isinstance(o, list) else [o, ""] for o in opts]
    lab = int(r["label"]) if not isinstance(r["label"], str) else [o[0] for o in opts].index(r["label"])
    ex = {"kind": kind, "state": r["context"], "instructions": r["question"], "options": opts,
          "label": lab, "task": r.get("group", "unknown"), "weight": r.get("weight", 1.0)}
    if tok: ex["ctx_tokens"] = len(tok(r["context"])["input_ids"])
    return ex
if __name__ == "__main__":
    ap = argparse.ArgumentParser(); ap.add_argument("--src"); ap.add_argument("--out")
    ap.add_argument("--tokenizer", default=None); a = ap.parse_args()
    tok = None
    if a.tokenizer:
        from transformers import AutoTokenizer; tok = AutoTokenizer.from_pretrained(a.tokenizer)
    with open(a.src) as f, open(a.out, "w") as g:
        for line in f: g.write(json.dumps(conv(json.loads(line), tok)) + "\n")
