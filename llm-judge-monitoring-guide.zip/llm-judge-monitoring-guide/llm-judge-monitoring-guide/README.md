# LLM-as-Judge Continuous Evaluation Pack

**Audience:** Staff/senior engineers and ML platform leads building production evaluation for voice-agent call sessions (≈50–70k/day) plus Llama/custom search retrieval.

**Scope:** You build and run this **elsewhere**. This pack is design, schemas, prompts, ops, and references — not a deployable stack on this machine.

**Language note:** en-GB throughout.

---

## What you get

| Doc | Purpose |
|-----|---------|
| [PLAN.md](PLAN.md) | One-pager printable plan + deep links |
| [01-architecture.md](01-architecture.md) | Diagram, components, session data model, sampling |
| [02-build-plan.md](02-build-plan.md) | Day 0 → Week 1 → Month 1 with gates |
| [03-implementation-guide.md](03-implementation-guide.md) | Langfuse outline, workers, judges, κ, CI |
| [04-versioning-and-ops.md](04-versioning-and-ops.md) | Version scheme, promotion, runbooks |
| [05-metrics-and-drift.md](05-metrics-and-drift.md) | Metrics with sparse GT; drift signals; anti-patterns |
| [06-references.md](06-references.md) | Curated bibliography + red herrings |
| [07-templates.md](07-templates.md) | Copy-paste CSV/JSON/SQL/YAML/checklists |
| [INDEX.md](INDEX.md) | File index |

---

## How to use this pack

1. Read [PLAN.md](PLAN.md) (10 minutes). Align stakeholders on the winning architecture.
2. Lock the [session data model](01-architecture.md#session-trace-data-model) and [versioning scheme](04-versioning-and-ops.md) before writing ingest code.
3. Execute [Day 0 MVP](02-build-plan.md#day-0--24-hour-mvp) using sketches in [03-implementation-guide.md](03-implementation-guide.md).
4. Copy templates from [07-templates.md](07-templates.md); do not invent parallel schemas.
5. Wire CI (Promptfoo/DeepEval) before any prompt promotion — see [promotion gates](04-versioning-and-ops.md#promotion-shadow--canary--full).
6. Treat human labels as the only ground truth for calibration; judges are instruments, not oracles.

---

## Five-minute executive summary (winning architecture)

**Stack decision (decisive):**

1. **Self-hosted Langfuse** as the trace store and eval UI for session spans (ASR → search → LLM → TTS/actions). You own retention, PII controls, and cost at 50–70k sessions/day.
2. **Rubric LLM judges** (binary, G-Eval-style) for online sampling: safety, search relevance, faithfulness, task unresolved, policy miss. Each judge emits structured JSON with score + rationale + rubric version.
3. **Weekly HITL anchors** — stratified human labels on a fixed gold-set refresh + random sample. Compute Cohen’s κ, sensitivity, specificity; apply Rogan–Gladen-style bias adjustment before publishing prevalence.
4. **DeepEval / Promptfoo in CI** for Llama/custom search prompt regressions against versioned gold sets. No prompt merges to `main` without green eval gates.
5. **Phoenix / Evidently** for distributional and embedding drift on inputs, retrievals, and judge score rates — separate dashboards for **system drift** vs **judge drift** ([Who Drifted](06-references.md)).

**Throughput reality:** 50–70k sessions/day ≈ 0.6–0.8 Hz average. Online-judge 5–10% + 100% high-risk is tractable if you batch, cache embeddings, and keep judges binary/short-context. Cost and latency budgets belong in Month 1 ops, not Day 0 theatre.

**Non-negotiables:**

- Version everything: `prompt_version`, `judge_version`, `rubric_version`, `gold_set_version`, `model_id`.
- Never publish “% judge pass” as precision.
- Human-approve rubric changes before they affect live alerts (Netflix-style lifecycle discipline).
- Separate alerts: system quality vs judge calibration vs cost.

---

## What this pack is not

- Not a Helm chart, Terraform module, or production Dockerfile dump.
- Not a claim that your judges will hit a specific κ — measure it.
- Not Netflix’s classic A/B experimentation platform; that is a red herring for this problem (see [06-references.md](06-references.md#red-herrings)).

---

## Suggested reading order

[PLAN.md](PLAN.md) → [01-architecture.md](01-architecture.md) → [02-build-plan.md](02-build-plan.md) → [03-implementation-guide.md](03-implementation-guide.md) → [04-versioning-and-ops.md](04-versioning-and-ops.md) → [05-metrics-and-drift.md](05-metrics-and-drift.md) → [07-templates.md](07-templates.md) → [06-references.md](06-references.md).

---

## Operating assumptions

- Peak and average load differ; size the eval queue for peaks, not daily averages alone.
- High-risk taxonomy will be wrong at first — version it (`risk_policy@x.y.z`) and treat sudden high-risk fraction jumps as an ops incident.
- Judge models and generator models must be pinned; “default vendor latest” is forbidden in production scoring.
- This pack deliberately omits cloud account IDs, internal hostnames, and any metrics not measured on *your* traffic.

## Related one-pager

Print [PLAN.md](PLAN.md) for kick-off meetings; keep this README as the pack entrypoint for engineers implementing elsewhere.
