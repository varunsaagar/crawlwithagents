#!/usr/bin/env python3
"""Page shell and components for the Kairos engineering walkthroughs.

The CSS in `shell.css` was lifted verbatim out of `laya/granite/docs/training-explained.html`
so these documents are the same object as the two that came before, not a lookalike. The
Verizon faces are inlined as base64 woff2 for the same reason the earlier walkthroughs do it:
the docs get read on machines that have never had the fonts installed.

Figures are inline SVG rather than canvas. The earlier walkthroughs paint to canvas and need a
`document.fonts.ready` repaint or the first paint lands in a fallback face; SVG has no such
race, and it stays sharp when someone zooms or prints.
"""
from __future__ import annotations

import base64
import html
from pathlib import Path

HERE = Path(__file__).parent

RED = "#F50A23"
INK = "#1A1A1A"
MUT = "#5E5E5E"
DIM = "#8A8A8A"
LINE = "#E4DED1"
LINE2 = "#EDEDED"
STONE = "#F3EDE0"
STONE2 = "#FAF8F4"
GREEN = "#0E7A45"
GREEN_T = "#E8F4EE"
AMBER = "#8A5300"
AMBER_T = "#FCF2E0"
BLUE = "#1F4B63"
BLUE_T = "#EAF1F5"
RED_T = "#FDECEE"

FONTS = [("Verizon NHG TX", 400, "VerizonNHGTX-Regular.woff2"),
         ("Verizon NHG TX", 700, "VerizonNHGTX-Bold.woff2"),
         ("Verizon NHG DS", 700, "VerizonNHGDS-Bold.woff2")]


def esc(s) -> str:
    return html.escape(str(s), quote=False)


def _fontcss() -> str:
    out = []
    for fam, weight, fn in FONTS:
        b64 = base64.b64encode((HERE / "assets" / fn).read_bytes()).decode()
        out.append(f"@font-face{{font-family:'{fam}';src:url('data:font/woff2;base64,{b64}') "
                   f"format('woff2');font-weight:{weight}}}")
    return "\n".join(out)


# ── inline components ───────────────────────────────────────────────────────
def lens(kind: str, tag: str, *paras: str) -> str:
    """One of the three explanation boxes the earlier walkthroughs use, plus `warn`."""
    body = "".join(f"<p>{p}</p>" for p in paras)
    return f'<div class="lens {kind}"><span class="tag">{esc(tag)}</span>{body}</div>'


def eli5(*p): return lens("eli5", "in plain English", *p)
def math(*p): return lens("math", "the number", *p)
def tech(*p): return lens("tech", "in the code", *p)
def warn(*p): return lens("warn", "the trap", *p)


def eq(*lines: str) -> str:
    return '<div class="eq">' + "<br>".join(lines) + "</div>"


def code(body: str, src: str | None = None) -> str:
    out = f"<pre>{body}</pre>"
    if src:
        out += f'<div class="src">{esc(src)}</div>'
    return out


def table(headers: list[str], rows: list[list], *, numeric: set[int] | None = None,
          bold_rows: set[int] | None = None) -> str:
    numeric = numeric or set()
    bold_rows = bold_rows or set()
    th = "".join(f"<th>{esc(h)}</th>" for h in headers)
    trs = []
    for i, r in enumerate(rows):
        tds = []
        for j, c in enumerate(r):
            cls = ' class="n"' if j in numeric else ""
            val = esc(c)
            if i in bold_rows:
                val = f"<b>{val}</b>"
            tds.append(f"<td{cls}>{val}</td>")
        trs.append("<tr>" + "".join(tds) + "</tr>")
    return f"<table><thead><tr>{th}</tr></thead><tbody>{''.join(trs)}</tbody></table>"


def figure(svg: str, title: str, caption: str) -> str:
    return (f'<figure><div class="bar"><span class="t">{esc(title)}</span></div>'
            f'{svg}<figcaption>{caption}</figcaption></figure>')


def section(n: int, sid: str, h2: str, sub: str, body: str) -> str:
    return (f'<section id="{sid}"><div class="stg"><span class="n">{n}</span>'
            f'<h2>{esc(h2)}</h2></div><p class="sub">{sub}</p>{body}</section>')


def page(*, title: str, kicker: str, h1: str, lede: str, facts: list[tuple[str, str]],
         nav: list[tuple[str, str]], sections: list[str], banner: str = "") -> str:
    navhtml = "".join(f'<a href="#{sid}">{esc(lbl)}</a>' for sid, lbl in nav)
    factshtml = "".join(f"<div><b>{esc(v)}</b>{esc(k)}</div>" for v, k in facts)
    return f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>{esc(title)}</title>
<style>
{_fontcss()}

{(HERE / "shell.css").read_text()}
.banner{{background:{STONE};border-left:4px solid {RED};padding:14px 18px;border-radius:3px;
  margin:0 0 26px;font-size:14px}}
.banner b{{font-weight:700}}
.pill{{display:inline-block;font-family:var(--mono);font-size:10.5px;letter-spacing:.09em;
  text-transform:uppercase;padding:3px 9px;border-radius:11px;font-weight:700;vertical-align:2px}}
.ok{{background:{GREEN_T};color:{GREEN}}} .mid{{background:{AMBER_T};color:{AMBER}}}
.no{{background:{RED_T};color:#A8071A}} .info{{background:{BLUE_T};color:{BLUE}}}
</style>
</head>
<body>
<div class="wrap">
<header>
  <div class="kick">{esc(kicker)}</div>
  <h1>{esc(h1)}</h1>
  <div class="rule"></div>
  <p class="lede" style="margin-top:22px">{lede}</p>
  <div class="facts">{factshtml}</div>
</header>
<nav>{navhtml}</nav>
{banner}
{''.join(sections)}
</div>
</body>
</html>
"""


# ── SVG figure primitives ───────────────────────────────────────────────────
class Fig:
    """Minimal SVG drawing, sized in user units and scaled to the column width."""

    def __init__(self, w: int = 1160, h: int = 360):
        self.w, self.h = w, h
        self.o: list[str] = []

    def rect(self, x, y, w, h, *, fill="none", stroke=None, sw=1, rx=0, dash=None):
        a = f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="{rx}" fill="{fill}"'
        if stroke:
            a += f' stroke="{stroke}" stroke-width="{sw}"'
        if dash:
            a += f' stroke-dasharray="{dash}"'
        self.o.append(a + "/>")
        return self

    def text(self, x, y, s, *, size=14, weight="400", fill=INK, anchor="start",
             fam="tx", ls=None):
        f = {"tx": "'Verizon NHG TX'", "ds": "'Verizon NHG DS'",
             "mono": "ui-monospace,Menlo,monospace"}[fam]
        a = (f'<text x="{x}" y="{y}" font-size="{size}" font-weight="{weight}" fill="{fill}" '
             f'font-family="{f},Helvetica,Arial,sans-serif"')
        if anchor != "start":
            a += f' text-anchor="{anchor}"'
        if ls:
            a += f' letter-spacing="{ls}"'
        self.o.append(a + ">" + esc(s) + "</text>")
        return self

    def line(self, x1, y1, x2, y2, *, stroke=DIM, sw=1.4, dash=None):
        a = f'<line x1="{x1}" y1="{y1}" x2="{x2}" y2="{y2}" stroke="{stroke}" stroke-width="{sw}"'
        if dash:
            a += f' stroke-dasharray="{dash}"'
        self.o.append(a + "/>")
        return self

    def arrow(self, x1, y1, x2, y2, *, stroke=RED, sw=2):
        self.o.append(f'<line x1="{x1}" y1="{y1}" x2="{x2}" y2="{y2}" stroke="{stroke}" '
                      f'stroke-width="{sw}" marker-end="url(#ah)"/>')
        return self

    def circle(self, cx, cy, r, *, fill=RED):
        self.o.append(f'<circle cx="{cx}" cy="{cy}" r="{r}" fill="{fill}"/>')
        return self

    def box(self, x, y, w, h, title, sub=None, *, fill=STONE2, stroke=LINE,
            color=INK, size=15):
        self.rect(x, y, w, h, fill=fill, stroke=stroke, rx=9)
        if sub:
            self.text(x + 14, y + h / 2 - 3, title, size=size, weight="700", fill=color)
            self.text(x + 14, y + h / 2 + 17, sub, size=12.5, fill=MUT)
        else:
            self.text(x + 14, y + h / 2 + 5, title, size=size, weight="700", fill=color)
        return self

    def bar(self, x, y, w, h, frac, *, fill=RED, track="#EDEDED"):
        self.rect(x, y, w, h, fill=track, rx=h / 2)
        self.rect(x, y, max(h, w * min(1.0, max(0.0, frac))), h, fill=fill, rx=h / 2)
        return self

    def render(self) -> str:
        return (f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {self.w} {self.h}" '
                f'role="img"><defs><marker id="ah" markerWidth="9" markerHeight="9" refX="7" '
                f'refY="3.2" orient="auto"><path d="M0,0 L7,3.2 L0,6.4 z" fill="{RED}"/></marker>'
                f'</defs><rect width="{self.w}" height="{self.h}" fill="#fff"/>'
                + "".join(self.o) + "</svg>")
