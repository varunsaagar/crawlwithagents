#!/usr/bin/env bash
# Runs all tests on CPU with gloo, 3 ranks. Usage: bash run_tests.sh  (needs torch)
set -u; cd "$(dirname "$0")"; export OMP_NUM_THREADS=1 PYTHONUNBUFFERED=1
OUT=${OUT:-/tmp/kz3}; rm -rf $OUT; mkdir -p $OUT
TR="torchrun --standalone --nproc_per_node 3"
echo "=== (c) head tests ==="; python test_head.py || exit 1

echo; echo "=== (a1) BUG REPRO: barrier after destroy_process_group (train.py:406) ==="
$TR train_zero3_reference.py --out $OUT/bug406 --steps 20 --eval_every 10 --bug post_destroy_barrier > $OUT/bug406.txt 2>&1; rc=$?
echo "exit=$rc"; grep -m2 -o "ValueError: Default process group has not been initialized[^\n]*" $OUT/bug406.txt | cut -c1-80
grep -q "Default process group has not been initialized" $OUT/bug406.txt && [ $rc -ne 0 ] && echo "[PASS] reproduced" || { echo "[FAIL]"; exit 1; }

echo; echo "=== (a2) BUG REPRO: rank-0-only eval under ZeRO-3 (Failure #8), timeout 15s ==="
s=$(date +%s); timeout 120 $TR train_zero3_reference.py --out $OUT/bug8 --steps 20 --eval_every 10 --bug rank0_eval --timeout_s 15 > $OUT/bug8.txt 2>&1; rc=$?
echo "exit=$rc after $(( $(date +%s)-s ))s; dev events: $(cat $OUT/bug8/log.rank*.jsonl 2>/dev/null | grep -c dev)"
grep -m1 -oiE "(timed out|timeout|Connection closed)[^\n]{0,80}" $OUT/bug8.txt
[ $rc -ne 0 ] && echo "[PASS] deadlock reproduced (killed by collective timeout)" || { echo "[FAIL]"; exit 1; }

echo; echo "=== (b) FIXED trainer, 3 ranks end-to-end ==="
$TR train_zero3_reference.py --out $OUT/fixed --steps 60 --eval_every 20 > $OUT/fixed.txt 2>&1; rc=$?
echo "exit=$rc"; grep -E "exitcode|Error" $OUT/fixed.txt | head -3
for r in 0 1 2; do echo "rank$r: $(grep -c '"dev"' $OUT/fixed/log.rank$r.jsonl) dev events, $(tail -1 $OUT/fixed/log.rank$r.jsonl)"; done
echo "best writes: $(wc -l < $OUT/fixed/best/writes.log) (by: $(cut -d' ' -f1 $OUT/fixed/best/writes.log | sort -u | tr '\n' ' '))"
echo "last writes: $(wc -l < $OUT/fixed/last/writes.log) (by: $(cut -d' ' -f1 $OUT/fixed/last/writes.log | sort -u))"
ls -l $OUT/fixed/best/weights.pt $OUT/fixed/last/weights.pt
python score_single.py $OUT/fixed/last && python score_single.py $OUT/fixed/best || exit 1
[ $rc -eq 0 ] && echo "[PASS] fixed trainer: all ranks exit 0" || { echo "[FAIL]"; exit 1; }
