# Workload routing

The `route` node sends each criterion to a lane according to its `workload_class` (Judge Plane v2 §4.3):

| `workload_class` | Lane | Behaviour |
|---|---|---|
| `read_off` (default) | System One | tiers → gate → escalate when unsure |
| `style_sensitive` | System One | same, but θ is at least `escalation.style_sensitive_floor` (default 0.95) |
| `derive` | System Two | goes straight to the fallback when `escalation.derive_direct: true` (default); otherwise read_off |
| `reference_free` | System Two | always goes to the fallback; never auto-gated |
| `rule` | code | answered by `code_checks[criterion_name](session)` when a check is registered; otherwise read_off |
| `classifier` | code | same as `rule` (hook for a trained classifier) |

The router applies two more rules to verdict criteria in `serve` mode:

* if the accuracy monitor has **frozen** the unit, the verdict goes to System Two with reason `drift_freeze`;
* in `calibrate` mode, detail criteria are skipped, because calibration only needs the gated verdicts.

## Code checks

A code check is any `Callable[[Session | None], str]` that returns a label of the criterion's question. Its answer gets probability 1 and `final_source: code`.

```python
import asyncio, re
from jevjudge import CriterionGrader, EscalationConfig, Rubric, Session
from jevjudge.backends.mock import MockBackend

rubric = Rubric.from_dict({"id": "format", "criteria": [
    {"name": "ssn_pattern", "type": "noul", "verdict": True, "workload_class": "rule",
     "instructions": "An AGENT line contains a full nine-digit SSN pattern."}]})

def ssn_check(session: Session | None) -> str:
    text = " ".join(t.text for t in (session.agent_turns if session else []))
    return "true" if re.search(r"\b\d{3}-\d{2}-\d{4}\b", text) else "false"

grader = CriterionGrader([MockBackend("jev")], EscalationConfig(judges=[], threshold=0.9),
                         code_checks={"ssn_pattern": ssn_check})
s = Session.from_turns("s1", [{"speaker": "agent", "text": "Your SSN is 123-45-6789."}])
v = asyncio.run(grader.grade(s, [rubric])).rubric("format").criteria[0]
print(v.final.label, v.final_source.value)      # true code
```

## Modes

`grader.grade(item, rubrics, mode=...)` selects how the graph runs:

| Mode | Tiers | Gate | System Two | Use |
|---|---|---|---|---|
| `serve` (default) | cheapest first, stop when accepted | yes | escalations + audit slice | production |
| `calibrate` | **every** tier answers every verdict | no early stop | the reference answers every verdict | build calibration records |
| `collect` | every tier answers **every** criterion | no early stop | none | feature collection (e.g. fitting combiners on detail questions) |

In `calibrate` and `collect` modes, monitor freezes, derive routing and θ = ∞ skips don't apply, so you get complete probability data.

## Graph shape

```mermaid
stateDiagram-v2
    [*] --> pack
    pack --> route
    route --> decide: open criteria and tiers exist
    route --> escalate: nothing for System One
    decide --> gate
    gate --> decide: still open and tiers left
    gate --> escalate
    escalate --> audit
    audit --> aggregate
    aggregate --> [*]
```

Each node is a pure async function of `JudgeState`. That makes the graph easy to checkpoint, to interrupt for human review, to trace in LangSmith, or to embed as a subgraph (see [LangGraph](../guides/langgraph.md)).
