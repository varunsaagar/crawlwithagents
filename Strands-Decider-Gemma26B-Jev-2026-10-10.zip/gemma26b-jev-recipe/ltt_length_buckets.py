"""Learn-then-Test threshold per (group, context-length bucket). Fixed-sequence testing from strict to loose
thresholds; binomial p-value on risk = P(Jev answers & wrong | answered) vs eps. Uncertified buckets -> escalate.
preds JSONL: {"group":str,"ctx_tokens":int,"conf":float,"correct":0|1}  (correct = vs gold, or agreement with LLM in label-free mode)."""
import argparse, json, collections
from math import comb
BUCKETS = [(0, 8192, "le8k"), (8192, 32768, "8-32k"), (32768, 65536, "32-64k"), (65536, 1 << 30, "64-128k")]
def bucket(n): return next(b for lo, hi, b in BUCKETS if lo <= n < hi)
def binom_p(errs, n, eps):  # P(X <= errs | Bin(n, eps))
    return sum(comb(n, k) * eps**k * (1 - eps)**(n - k) for k in range(errs + 1))
def certify(rows, eps, delta, min_n=50):
    for lam in [x / 100 for x in range(99, 49, -1)]:
        ans = [r for r in rows if r["conf"] >= lam]
        if len(ans) < min_n: continue
        if binom_p(sum(1 - r["correct"] for r in ans), len(ans), eps) > delta: break  # fixed sequence stops
        best = (lam, len(ans) / len(rows))
    return locals().get("best")
if __name__ == "__main__":
    ap = argparse.ArgumentParser(); ap.add_argument("--preds"); ap.add_argument("--eps", type=float, default=0.02)
    ap.add_argument("--delta", type=float, default=0.05); a = ap.parse_args()
    g = collections.defaultdict(list)
    for l in open(a.preds):
        r = json.loads(l); g[(r["group"], bucket(r["ctx_tokens"]))].append(r)
    out = {f"{k[0]}|{k[1]}": (dict(threshold=c[0], coverage=round(c[1], 3)) if (c := certify(v, a.eps, a.delta)) else "UNCERTIFIED->LLM")
           for k, v in sorted(g.items())}
    print(json.dumps(out, indent=2))
