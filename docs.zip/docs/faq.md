# FAQ

### Does Jev write a rationale?

No. Decision models return probabilities only. Every rubric's `reason` is assembled from the outcomes and probabilities (see [Scoring](concepts/scoring.md#deterministic-reason)). A generated rationale comes only from System Two, on escalation (`rationale: on_escalation`) or always (`rationale: always`), and it is written after the verdict.

### Why does every item escalate?

Check `escalation_reason` on the verdict criterion:

* `uncertified`: `threshold: certified`, and there is no matching ACTIVE certificate. This happens when the rubric was edited, the tiers or the reference (`judges[0]`) changed, or the certificate expired after the 30-day TTL. Re-certify, or use a fixed threshold while you experiment.
* `drift_freeze`: the monitor alarmed. See `grader.monitor.summary()`, and call `reset(unit)` after promoting a new certificate (the Studio approve endpoint does this, and `POST /v1/projects/{id}/monitor/reset` clears a freeze).
* `invalid`: the backend failed. Read `criteria[i].system_one[-1].error`.
* `low_conf`: θ is higher than the model's confidence. Look at `system_one[-1].q`.

### I get HTTP 404 from a model that is up

From a laptop, an unresolvable host, such as an in-cluster `*.svc` URL, is answered by the corporate proxy with a **404 with an HTML body**. Check that `base_url` resolves from where you run, and that `*.verizon.com` is in `NO_PROXY`. TLS errors usually mean the corporate root is missing. jevjudge uses the OS trust store via `truststore`, or `JEVJUDGE_CA_BUNDLE` if set.

### djev returns 401 / 503

Every Kairos pod call sends `Authorization: Bearer $JEV_API_KEY`. A 401 means the key is missing from the environment. Under load, djev answers `503 capacity full`. jevjudge retries 429 and 5xx three times with backoff. After that the answer is invalid and escalates, which affected about 2% of items in the batch runs.

### Can I use an LLM as a tier, not just as a fallback?

Yes: `tiers: [{model: gemma-26b}]`. Its probabilities come from the answer letter's logprobs. A model without logprobs (Gemini 3.x on Vertex) gets probability 1 on its parsed letter, so the gate can't rank its errors. Use such models as fallbacks.

### Why are `success` and `verdict` different?

For rubrics with a verdict criterion, `success` means the rubric **passed**: `verdict == "clean"` (for `output_pii`, no violation; for `action_completion`, completed). `score` stays the DeepEval-style weighted mean (P(true) for a Noul), so for safety metrics a high score means a likely violation. Rubrics without a verdict use `success = score ≥ threshold`.

### How many requests does one session cost?

Per System One tier, there is one request per distinct (view × chunk plan) × number of chunks. The five voice metrics make 3 requests. Each escalated or audited question costs one request per System Two judge tried, because LLMs answer one question per request. `report.calls` has the exact counts per backend.

### How do I judge chat, not voice?

The pipeline is channel-agnostic. Pass `{"session_id", "turns": [{"role": "user" | "assistant", "content": ...}]}` (`assistant`/`bot` → agent, `customer`/`caller` → user). Optionally override the role labels with `packing: {roles: {user: USER, agent: ASSISTANT, system: SYSTEM, tool: TOOL}}`. Remember that rubric text mentioning CUSTOMER and AGENT should match those labels.

### Does editing a rubric's description break certificates?

No. `description`, `owner` and `output_alias` are excluded from the revision hash. Everything else is included: question text, labels, credits, weights, views, guidelines, aggregate, threshold, `verdict_model`, and chunking unless it is the default.

### Can the fallback see what Jev answered?

No. System Two gets the same packed state, the question and the optional `fallback_instructions`, but never Jev's label or probabilities. This keeps escalation independent.

### Is there a synchronous API?

Yes. `Judge` wraps `CriterionGrader` with a private event loop thread, so `judge.grade(item)` also works inside Jupyter.

### Where do temperatures from certificates get applied?

The engine fits a temperature per tier and stores it in the certificate when it improves held-out NLL. The 0.2.0 grader does **not** apply certificate temperatures at serving time. The shipped certificates were fitted without temperature scaling (`fit_temperature=False` in the Studio, and the solver only needs a monotone signal), so this has no effect on them.
