"""Frozen evaluation harness. Owns inputs, reference, checks and timing. Candidates never
see this file's internals. Run directly: python harness.py candidates/current.py --json out.json
Guardrails are numbered G1..G9 and map to known reward hacks (see ../design.md, section 8)."""
import argparse, ast, hashlib, importlib.util, json, math, os, sys, time
import torch

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, ROOT)
from kernels.formats import random_nvfp4, random_mxfp8   # noqa: E402
from kernels.reference import moe_ref, route              # noqa: E402

GPU = torch.cuda.is_available() and os.environ.get("TRITON_INTERPRET") != "1"
DEV = "cuda" if GPU else "cpu"
SHAPES = dict(E=128, H=2304, I=1152, K=8) if os.environ.get("INKLING_SHAPES") == "1" or GPU \
    else dict(E=8, H=128, I=64, K=2)

BANNED_CALLS = {"matmul", "bmm", "mm", "linear", "einsum", "addmm", "baddbmm", "tensordot",
                "scaled_mm", "_scaled_mm", "moe_ref", "grouped_gemm_ref", "dequant",
                "dequant_nvfp4", "dequant_mxfp8"}
BANNED_IMPORTS = ("vllm", "humming", "harness", "kernels.reference", "cutlass_library")


def static_check(path):                                               # G1
    src = open(path).read()
    tree = ast.parse(src)
    problems = []
    for node in ast.walk(tree):
        if isinstance(node, (ast.Import, ast.ImportFrom)):
            names = [a.name for a in node.names] + ([node.module] if getattr(node, "module", None) else [])
            for n in names:
                if n and any(n == b or n.startswith(b + ".") for b in BANNED_IMPORTS):
                    problems.append(f"banned import {n}")
        if isinstance(node, ast.Call):
            f = node.func
            name = f.attr if isinstance(f, ast.Attribute) else getattr(f, "id", "")
            if name in BANNED_CALLS:
                problems.append(f"banned call {name}() line {node.lineno}")
        if isinstance(node, ast.BinOp) and isinstance(node.op, ast.MatMult):
            problems.append(f"'@' matmul on line {node.lineno}")
    if "triton.jit" not in src and "load_inline" not in src:
        problems.append("no @triton.jit or load_inline kernel found")
    if "fused_moe_wq" not in src:
        problems.append("missing fused_moe_wq entry point")
    return problems


def load(path):
    spec = importlib.util.spec_from_file_location("candidate", path)
    m = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(m)
    return m.fused_moe_wq


def make_layer(fmt, seed):
    g = torch.Generator().manual_seed(seed)
    mk = {"nvfp4": random_nvfp4, "mxfp8": random_mxfp8}[fmt]
    E, H, I = SHAPES["E"], SHAPES["H"], SHAPES["I"]
    w13, w2 = mk(E, 2 * I, H, g), mk(E, H, I, g)
    return tuple(t.to(DEV) for t in w13), tuple(t.to(DEV) for t in w2)


def make_tokens(T, seed, mode="normal"):
    g = torch.Generator().manual_seed(seed)
    E, H, K = SHAPES["E"], SHAPES["H"], SHAPES["K"]
    x = torch.randn((T, H), generator=g)
    if mode == "large":
        x = x * 64
    if mode == "zeros":
        x = torch.zeros_like(x)
    logits = torch.randn((T, E), generator=g)
    if mode == "one_expert":                       # every token routed to the same experts
        logits = torch.arange(E, dtype=torch.float32).repeat(T, 1)
    w, ids = route(logits, K, scale=8.0)
    return x.bfloat16().to(DEV), ids.to(DEV), w.to(DEV)


def check_numerics(fn, tokens_list, formats, seed0):                  # G2, G3
    worst = 0.0
    for fmt in formats:
        w13, w2 = make_layer(fmt, seed0)
        cpu = lambda t: tuple(a.cpu() for a in t)
        for i, T in enumerate(tokens_list):
            for mode in ("normal", "large", "zeros", "one_expert"):
                x, ids, w = make_tokens(T, seed0 + 31 * i, mode)
                out = fn(x, ids, w, w13, w2, fmt, fmt)
                if out.data_ptr() in (x.data_ptr(),):
                    return False, f"output aliases input ({fmt}, T={T})"
                if out.shape != (T, SHAPES["H"]) or out.dtype != torch.bfloat16:
                    return False, f"bad shape/dtype {tuple(out.shape)} {out.dtype}"
                if not torch.isfinite(out.float()).all():
                    return False, f"non-finite output ({fmt}, T={T}, {mode})"
                ref = moe_ref(x.cpu(), ids.cpu(), w.cpu(), cpu(w13), cpu(w2), fmt, fmt).float()
                o = out.float().cpu()
                if mode == "zeros":
                    if o.abs().max() != 0:
                        return False, "zero input gave non-zero output"
                    continue
                rel = ((o - ref).norm() / ref.norm().clamp_min(1e-30)).item()
                worst = max(worst, rel)
                if rel > 2e-2:
                    return False, f"rel err {rel:.3e} ({fmt}, T={T}, {mode})"
    return True, f"worst rel err {worst:.3e}"


def check_determinism_and_invariance(fn, seed0):                      # G4, G5, G6
    # bf16 output rounding hides most fp32 reduction-order changes (a torch simulation at
    # 1024x2304 flipped roughly 1 bf16 value in 4,400 between BK=32 and BK=64), so a
    # batch-dependent kernel is only reliably caught when many output values are compared.
    # GPU mode therefore uses Inkling shapes and a 512-token batch; CPU mode is a smoke test.
    T = 512 if GPU else 33
    solo = list(range(0, T, T // 16))[:16] if GPU else list(range(T))
    subs = (7, 64, 257) if GPU else (2, 5, 9, 17)
    w13, w2 = make_layer("nvfp4", seed0)
    x, ids, w = make_tokens(T, seed0 + 7)
    a = fn(x, ids, w, w13, w2, "nvfp4", "nvfp4")
    b = fn(x, ids, w, w13, w2, "nvfp4", "nvfp4")
    if not torch.equal(a.view(torch.int16), b.view(torch.int16)):
        return False, "not bitwise deterministic run to run"
    for t in solo:
        s = fn(x[t:t + 1], ids[t:t + 1], w[t:t + 1], w13, w2, "nvfp4", "nvfp4")
        if not torch.equal(s[0].view(torch.int16), a[t].view(torch.int16)):
            return False, f"batch invariance broken for token {t} (batch 1 vs {T})"
    for n in subs:
        s = fn(x[:n], ids[:n], w[:n], w13, w2, "nvfp4", "nvfp4")
        if not torch.equal(s.view(torch.int16), a[:n].view(torch.int16)):
            return False, f"batch invariance broken (batch {n} vs {T})"
    x2, ids2, w2r = make_tokens(T, seed0 + 999)
    c = fn(x2, ids2, w2r, w13, w2, "nvfp4", "nvfp4")
    if torch.equal(c, a):
        return False, "output did not change with input (caching?)"
    return True, "deterministic, batch-invariant, input-sensitive"


def calibrate_peak_bw():
    n = 1 << 28
    src = torch.empty(n, dtype=torch.uint8, device="cuda"); dst = torch.empty_like(src)
    for _ in range(3):
        dst.copy_(src)
    torch.cuda.synchronize()
    s, e = torch.cuda.Event(True), torch.cuda.Event(True)
    s.record()
    for _ in range(10):
        dst.copy_(src)
    e.record(); torch.cuda.synchronize()
    return 2 * n * 10 / (s.elapsed_time(e) * 1e-3)                  # bytes/s (read+write)


def bench(fn, tokens_list, iters=30):                                 # G7, G8
    if not GPU:
        return None, "no GPU: performance not measured"
    peak = calibrate_peak_bw()
    E, H, I = SHAPES["E"], SHAPES["H"], SHAPES["I"]
    w13, w2 = make_layer("nvfp4", 1234)
    flush = torch.empty(256 << 20, dtype=torch.uint8, device="cuda")
    res = {}
    for T in tokens_list:
        x, ids, w = make_tokens(T, 4321 + T)
        for _ in range(3):
            fn(x, ids, w, w13, w2, "nvfp4", "nvfp4")
        ts = []
        for _ in range(iters):
            flush.zero_()
            torch.cuda.synchronize()
            s, e = torch.cuda.Event(True), torch.cuda.Event(True)
            s.record(); fn(x, ids, w, w13, w2, "nvfp4", "nvfp4"); e.record()
            torch.cuda.synchronize()
            ts.append(s.elapsed_time(e) * 1e-3)
        t = sorted(ts)[len(ts) // 2]
        weight_bytes = ids.unique().numel() * (3 * H * I) * (0.5 + 1 / 16)
        frac = weight_bytes / t / peak
        res[T] = dict(seconds=t, implied_bw_fraction=frac)
    return res, f"calibrated copy bandwidth {peak / 1e9:.0f} GB/s"


def evaluate(path, cfg, holdout=False):
    out = dict(path=path, ok=False)
    probs = static_check(path)
    if probs:
        out["reason"] = "; ".join(probs); return out
    try:
        fn = load(path)
    except Exception as ex:  # noqa: BLE001
        out["reason"] = f"import/compile error: {ex!r}"[:500]; return out
    shapes = cfg["holdout_shapes"] if holdout else cfg["visible_shapes"]
    seed0 = 777 if holdout else 1
    try:
        ok, msg = check_numerics(fn, shapes["tokens"], shapes["formats"], seed0)
        out["numerics"] = msg
        if not ok:
            out["reason"] = msg; return out
        ok, msg = check_determinism_and_invariance(fn, seed0)
        out["invariance"] = msg
        if not ok:
            out["reason"] = msg; return out
        perf, note = bench(fn, cfg["bench_tokens"])
    except Exception as ex:  # noqa: BLE001
        out["reason"] = f"runtime error: {ex!r}"[:500]; return out
    out["perf"], out["perf_note"] = perf, note
    if perf:
        bad = [T for T, r in perf.items() if r["implied_bw_fraction"] > cfg["roofline_max_fraction_of_peak_bw"]]
        if bad:                                                        # G8
            out["reason"] = f"implied bandwidth above roofline at T={bad}: treat as a bug"; return out
    out["ok"] = True
    return out


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("candidate"); ap.add_argument("--holdout", action="store_true")
    ap.add_argument("--config", default=os.path.join(HERE, "config.json"))
    ap.add_argument("--json", default="")
    a = ap.parse_args()
    r = evaluate(a.candidate, json.load(open(a.config)), a.holdout)
    s = json.dumps(r, indent=1, default=str)
    print(s)
    if a.json:
        open(a.json, "w").write(s)
