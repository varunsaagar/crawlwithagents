# Relaunch checklist — Kairos 26B native-Jev 64K (ZeRO-3, 3 ranks)

## 0. Pre-flight (5 min, no GPU)
- [ ] Run the PATCH.md greps. There must be exactly one `destroy_process_group`, inside `safe_teardown()`, and no collective under `if rank == 0`.
- [ ] `assert zero_stage == 3` exists in train() and save().
- [ ] `skip_post_eval: true` in config.
- [ ] Optional: copy `train_zero3_reference.py` + `run_tests.sh` to the pod and run them on CPU (about 40 s) to check the torch build.

## 1. Smoke run (same config as the real run except:)
```
seqs_per_epoch: 100        # ~33 steps on 3 ranks
eval_every: 10             # >=2 dev events, exercises best/ twice
dev_max_items: 20          # keep eval short; full dev later
pack.max_len: 65536        # keep it: the point is to test the 64K path
NCCL timeout: default 600 s (do NOT raise for the smoke)
torchrun --nproc_per_node 3 ... 2>&1 | tee smoke.log
```
Expect about 33 × 81 s ≈ 45 min, plus the evals.

## 2. Pass criteria (all four)
1. **Dev event logged:** `grep '"dev"' log.jsonl` shows a dev event at step 10, and training continues to step 11 and beyond.
2. **best/ written once per improvement, by rank 0:** one `weights.pt`, no `.tmp` left behind, mtime matches the dev event, and no "file exists"/partial-write errors from ranks 1–2.
3. **last/ on disk and loads in the single-GPU scorer:** `weights.pt` is about 240 MB (not KB-sized empty shards), and the scorer's rescored dev score equals the logged final dev score.
4. **All ranks exit 0:** torchrun reports no `ChildFailedError`, and `grep -c "process group has not been initialized" smoke.log` is 0.

Only then launch the full run (`seqs_per_epoch 7000`).

## 3. Separate single-GPU calibrate + test job (replaces the in-run post-eval)
1. Load the bf16 base from `/base` (text stack via AutoModelForCausalLM, defect 1). Run `wrap()`, load `last/weights.pt` with `strict=False`, and assert no lora/head keys are missing. Run in eval mode with **no ZeRO**.
2. Score the dev split and store per-item logits.
3. Fit temperature per type (choice/noul/score) and per length bucket (8k/16k/32k/64k) on dev, minimising NLL. Write `head.log_temp` and save to `final/`.
4. Score test: accuracy and ECE per type × length bucket × source × option-count bucket, plus the 64K retention ratio.
5. Compare against L1c and the served baseline on the same items. Promote only if it beats L1c.
It fits on one H100: inference at 64K without grads is well under the 74.6 GB training peak (estimate; measure it).
