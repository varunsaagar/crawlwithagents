# Threshold governance

The certified threshold θ decides how often Jev answers and how often the Gemma / Gemini fallback is called. Governance covers three things:

* how you **migrate** from hand-set thresholds to certified ones without a big-bang switch;
* who **approves** a certificate, and how you roll it back;
* how certificates are scoped per traffic segment (**Mondrian strata**) and what happens when anything is in doubt (**fail closed**).

All of it is configured on `EscalationConfig` and enforced by `CriterionGrader.threshold_for`. The certificates themselves live in `CertificateRegistry` (`jevjudge.calibration.registry`).

## Migration phases

`EscalationConfig.phase` only matters when `threshold: certified`. It decides how the certified θ and your existing hand-set θ (`static_thresholds`) are combined.

| `phase` | θ served | Certificate missing or expired | Fingerprint mismatch | `policy_source` |
|---|---|---|---|---|
| `legacy_shadow` | static θ; the certified θ is only recorded as `shadow_threshold` | static θ | static θ | `static(shadow)` |
| `tighter_of` | `max(static, certified)`: never looser than today | static θ | ∞ (escalate) | `tighter_of`, `static(no certificate)` |
| `certified_preferred` | certified θ | static θ | ∞ (escalate) | `certified`, `static(no certificate)` |
| `enforce` (default) | certified θ | ∞ (escalate) | ∞ (escalate) | `certified`, `uncertified`, `expired`, `fingerprint_mismatch` |

`static_thresholds` is either one float for every unit or a dict. The dict is searched in this order: `rubric/criterion@type`, `rubric/criterion`, `rubric`, `criterion`, `default`. The same static θ applies to every System One tier.

!!! warning "A phase only affects units that have a static θ"
    If `static_thresholds` has no entry for a unit (and no `default`), that unit behaves as `enforce` in every phase: no certificate means every item escalates. Add a `default` key during migration if you want every unit covered.

A drift freeze from the [accuracy monitor](monitoring.md#accuracy-monitor) is never overridden. The router sends a frozen unit to System Two before any threshold is looked up, in every phase, including `legacy_shadow`.

Every criterion result and OTel event records which branch was taken:

| `CriterionResult` field | OTel attribute | Content |
|---|---|---|
| `policy_source` | `jev.policy.source` | the `policy_source` values above, or `fixed` for a non-certified threshold |
| `shadow_threshold` | `jev.shadow_threshold` | `legacy_shadow` only: the certified θ that would have been served (absent when it would be ∞) |
| `threshold` | `jev.threshold` | the θ actually served (absent when ∞) |
| `calibration_version` | `jev.calibration.version` | the certificate id; `fixed:<θ>` for fixed thresholds; `static:<θ>` when a migration phase serves the static θ |
| `stratum` | `jev.stratum` | the Mondrian stratum the policy was looked up for |

### Rollout recipe

Start from a deployment that uses hand-set thresholds, for example `threshold: {output_pii: 0.97, default: 0.9}`.

1. **Certify, but serve nothing new (`legacy_shadow`).** Move the hand-set values into `static_thresholds`, switch to `threshold: certified`, and point `registry:` at the certificate file. Behaviour is unchanged. Every event now carries `jev.shadow_threshold`.

    ```yaml
    escalation:
      judges: [{model: gemini-3.8-flash}, {model: gemma-26b}]
      threshold: certified
      phase: legacy_shadow
      static_thresholds: {output_pii: 0.97, default: 0.9}
      audit_rate: 0.05
    registry: registry/certificates.json
    ```

    Exit when, for every unit, you have compared `jev.confidence.q` against `jev.threshold` and `jev.shadow_threshold` on a week of traffic and reviewed the items where the two decisions differ.

2. **Only tighten (`tighter_of`).** A certificate can now raise θ (more escalation), never lower it. Use this phase to absorb certificates that are stricter than your hand-set values.

    Exit when the escalation rate per unit is stable (see [drift statistics](monitoring.md#drift-statistics)) and no unit is frozen.

3. **Certificates win (`certified_preferred`).** The certified θ is served even when it is lower than the static one, which is where the cost saving comes from. Units without a certificate still use the static θ.

    Exit when every unit you serve has an ACTIVE, approved certificate (`registry.history(unit)` or `GET /v1/projects/{id}/certificates`).

4. **Target state (`enforce`).** Remove `phase` (the default is `enforce`) and `static_thresholds`. From here on, a missing, expired or mismatched certificate sends that unit to the fallback.

Rolling back a phase is a config change: set the previous `phase` and reload the grader.

!!! note "Monitor θ adjustments"
    When the monitor is enabled, its tighten-only ACI controller can raise the certified θ between re-certifications. In `legacy_shadow`, that raised value is what `shadow_threshold` reports.

## Certificate lifecycle

```mermaid
stateDiagram-v2
    [*] --> PROPOSED: propose(cert)
    PROPOSED --> ACTIVE: approve(id, approver)
    ACTIVE --> SUPERSEDED: another certificate of the same unit and stratum is approved
    SUPERSEDED --> ACTIVE: approve(id, approver), or rollback of its successor
    ACTIVE --> ROLLED_BACK: rollback(unit_id, stratum)
    ROLLED_BACK --> ACTIVE: approve(id, approver)
    PROPOSED --> REVOKED: revoke(id)
    ACTIVE --> REVOKED: revoke(id)
```

`revoke` works from any state; the diagram shows the two common ones.

| Method | Effect |
|---|---|
| `propose(cert) -> Certificate` | registers the certificate in state `PROPOSED`. It is stored but never served |
| `approve(cert_id, approver, note="") -> Certificate` | `PROPOSED`, `SUPERSEDED` or `ROLLED_BACK` → `ACTIVE`. Records `approver` and `approved_at`. The previous ACTIVE certificate of the same unit and stratum becomes `SUPERSEDED`, and the new one records it in `supersedes`. Raises `ValueError` for any other state, or if the certificate has expired |
| `rollback(unit_id, stratum="all", by=None, note="") -> Certificate \| None` | the ACTIVE certificate → `ROLLED_BACK`. The certificate it superseded becomes ACTIVE again, if it has not expired. Returns the new ACTIVE certificate, or `None` when the unit is now uncertified (everything escalates) |
| `revoke(cert_id, by=None, note="")` | → `REVOKED`. Revoking the ACTIVE certificate leaves the unit uncertified |
| `history(unit_id) -> list[dict]` | every certificate of the unit: `certificate_id`, `state`, `stratum`, `thetas`, `approver`, `approved_at`, `issued_at`, `expires_at`, `expired`, `tier_models`, `reference_model`, `supersedes`, `eps`, `delta`, `n_cal`, `mode`, and the `history` event log (`event`, `by`, `at`, `note`) |
| `active(unit_id, stratum="all")` | the ACTIVE certificate, or `None` |
| `promote(cert)` | the pre-governance shortcut: adds the certificate as ACTIVE without an approver or an event log. Used by `jevjudge calibrate --promote` and `experiments/build_registry_v2.py` |
| `save()` / `load()` | persist to / reload from the registry JSON |

Every transition appends an event to the certificate's `history`, so the registry file is its own audit log. Keep it under review like code.

### In Python

The example runs offline. In real use, the certificate comes from `CalibrationEngine(...).certify_unit(records, tiers)` (see [Escalation and calibration](../concepts/escalation-and-calibration.md#calibration-engine)). Here a helper builds one by hand.

```python
import asyncio
import datetime as dt

from jevjudge import CriterionGrader, EscalationConfig, Session, preset
from jevjudge.backends.mock import MockBackend, keyword_rule
from jevjudge.calibration.engine import Certificate, fingerprint, unit_id
from jevjudge.calibration.registry import CertificateRegistry

rubrics = [r for r in preset("voice") if r.id == "output_toxicity"]
rub, vc = rubrics[0], rubrics[0].verdict_criterion
UNIT = unit_id(rub.id, vc.name, vc.type.value)          # "output_toxicity/agent_toxic@noul"


def make_cert(cid: str, theta: float, stratum: str = "all") -> Certificate:
    """Stand-in for CalibrationEngine(...).certify_unit(records, ["jev"])[0]."""
    now = dt.datetime.now(dt.timezone.utc)
    return Certificate(
        certificate_id=cid, unit_id=UNIT, rubric_revision=rub.revision, criterion=vc.name,
        tier_models=["jev"], reference_model="llm", fingerprint=fingerprint(rub.revision, ["jev"], "llm"),
        mode="parity_gold", method="ltt_sfst", eps=0.03, delta=0.05, n_cal=500, n_valid=500,
        thetas=[theta], temperatures=[1.0], state="ACTIVE", issued_at=now.isoformat(),
        expires_at=(now + dt.timedelta(days=30)).isoformat(), stratum=stratum)


reg = CertificateRegistry()                               # CertificateRegistry("registry/certificates.json") to persist
reg.propose(make_cert("tox-v1", 0.80))
reg.approve("tox-v1", approver="alice@example.com", note="Q4 recertification")
reg.propose(make_cert("tox-v2", 0.90))
reg.approve("tox-v2", approver="bob@example.com")         # tox-v1 becomes SUPERSEDED
reg.save()                                                # no-op without a path
print([(h["certificate_id"], h["state"]) for h in reg.history(UNIT)])
# [('tox-v1', 'SUPERSEDED'), ('tox-v2', 'ACTIVE')]

jev = MockBackend("jev", rules=[keyword_rule("output_toxicity__agent_toxic", ["idiot"], 0.99, 0.15)])
llm = MockBackend("llm", kind="llm")                      # the reference: judges[0].name is fingerprinted
grader = CriterionGrader(
    [jev],
    EscalationConfig(judges=[], threshold="certified", phase="tighter_of",
                     static_thresholds={"output_toxicity": 0.95, "default": 0.9}),
    judges=[llm], registry=reg,
)
session = Session.from_turns("s1", [{"speaker": "user", "text": "fix my bill"},
                                    {"speaker": "agent", "text": "Sure, one moment."}])
v = asyncio.run(grader.grade(session, rubrics)).rubric("output_toxicity").criteria[0]
print(v.policy_source, v.threshold, v.calibration_version)          # tighter_of 0.95 tox-v2

reg.rollback(UNIT, by="alice@example.com", note="v2 escalates too much")
print(reg.active(UNIT).certificate_id)                               # tox-v1
```

!!! warning "A running grader does not see registry edits"
    `CriterionGrader` loads the registry file once, at construction. After approving or rolling back from another process, call `grader.registry.load()` or rebuild the grader. The HTTP server does this for you: the approve and rollback endpoints drop the project's cached grader.

!!! note "Approving and frozen units"
    In Python, approving a certificate does not touch the accuracy monitor: call `AccuracyMonitor.reset(unit)` as well. The Studio approve endpoint resets the unit's monitor for you, and `POST /v1/projects/{id}/monitor/reset` clears a freeze explicitly. See [Monitoring](monitoring.md#accuracy-monitor).

### Over HTTP (Calibration Studio)

The Studio server exposes the lifecycle per project. See the [HTTP API](../reference/http-api.md#governance).

```bash
# every unit with its certificate history (state, approver, events)
curl -s localhost:8000/v1/projects/$PID/certificates | jq '.[] | {unit_id, states: [.certificates[] | .state]}'

# approve a PROPOSED (or SUPERSEDED / ROLLED_BACK) certificate; 400 if it is unknown, expired or in the wrong state
curl -s -X POST localhost:8000/v1/projects/$PID/certificates/$CERT/approve \
     -H 'Content-Type: application/json' -d '{"approver": "alice@example.com", "note": "reviewed holdout"}'
# -> {"certificate_id": "...", "state": "ACTIVE", "approver": "alice@example.com"}

# roll back the ACTIVE certificate of one unit and stratum
curl -s -X POST localhost:8000/v1/projects/$PID/certificates/rollback -H 'Content-Type: application/json' \
     -d '{"unit_id": "output_pii/pii_exposed@noul", "stratum": "all", "by": "alice@example.com", "note": "too permissive"}'
# -> {"unit_id": "output_pii/pii_exposed@noul", "active": "<previous id>" | null}
```

!!! note "Studio calibration approves automatically"
    `POST /v1/projects/{id}/calibrate` and `Project.calibrate()` propose each certificate and then approve it as `studio:auto`. To require a human approval, calibrate from Python with `Project.calibrate(..., approve_as=None)`. The certificates then stay `PROPOSED` until someone calls the approve endpoint.

## Mondrian strata

A pooled certificate guarantees accuracy on the traffic mix it was calibrated on. A small project inside that mix can do much worse than the average and still pass. **Mondrian** calibration certifies each stratum separately, so the guarantee holds per stratum.

```yaml
escalation:
  threshold: certified
  strata: [project]               # or [project, journey]
  pooled_fallback: false          # default: a stratum without its own certificate escalates
```

* **Stratum key.** `CriterionGrader.stratum_of(session)` builds the key from the listed fields, for example `project=acme` or `project=acme|journey=billing`. Each field is read from the `Session` attribute of that name (`project`, `journey`, `channel`, `source`, …) and then from `session.meta`. A missing value becomes `unknown`. Without `strata`, or for inputs that are not sessions (plain text, DeepEval cases), the key is `all`.
* **Lookup.** The registry looks for an ACTIVE certificate of the unit *and* the stratum. A stratum without one escalates everything (`uncertified`). It never borrows the pooled θ, unless you set `pooled_fallback: true`. Then it uses the stratum `all` certificate and reports `policy_source: certified(pooled)`.
* **Certify per stratum.** Retain records with their stratum, and call `certify_unit` once per stratum. The certificate takes its `stratum` from the records:

    ```python
    from collections import defaultdict
    from jevjudge.calibration.engine import CalibrationEngine

    async def certify_by_stratum(grader, rubrics, sessions, gold, reg):
        by_stratum = defaultdict(list)
        for s in sessions:
            rep = await grader.grade(s, rubrics, mode="calibrate")
            st = grader.stratum_of(s)                                  # e.g. "project=acme"
            by_stratum[st] += grader.records(rep, rubrics, gold=gold.get(s.session_id), stratum=st)
        tiers = [t.name for t in grader.tiers]
        for st, recs in by_stratum.items():
            for rid in {r.rubric_id for r in recs}:
                unit = [r for r in recs if r.rubric_id == rid and r.reference is not None]
                cert, _ = CalibrationEngine(unit, eps=0.03, delta=0.05, min_n=100).certify_unit(unit, tiers)
                reg.propose(cert)                                      # approve after review
        reg.save()
    ```

* **Lifecycle per stratum.** `approve` supersedes only the ACTIVE certificate of the same unit *and* stratum, and `rollback(unit_id, stratum=...)` acts on one stratum.
* **Sample size.** Every stratum needs `min_n` labelled items of its own, otherwise its θ is ∞. Start with few, large strata.

## Fail-closed rules

When anything is in doubt, the unit gets θ = ∞ for every tier. Jev is not called for that criterion and every item goes to System Two. The registry's `policy()` never raises.

| Situation | Behaviour under `enforce` | `escalation_reason` | `policy_source` |
|---|---|---|---|
| no ACTIVE certificate for the unit (and stratum) | escalate | `uncertified` | `uncertified` |
| certificate only `PROPOSED`, or `REVOKED` / `ROLLED_BACK` with no predecessor | escalate | `uncertified` | `uncertified` |
| certificate past `expires_at` (TTL 30 days by default) | escalate | `uncertified` | `expired` |
| rubric revision, tier names or reference name changed | escalate | `uncertified` | `fingerprint_mismatch` |
| stratum without its own certificate (`pooled_fallback: false`) | escalate | `uncertified` | `uncertified` |
| the certificate disables the tier (θ = ∞) | escalate | `policy` | `certified` |
| monitor alarm | escalate (all phases) | `drift_freeze` | not looked up |
| invalid answer, missing ensemble member or `verdict_model` feature | escalate that item | `invalid` | any |
| `threshold: certified` without a registry | `ConfigError` at construction | | |

The migration phases relax only two rows, *missing* and *expired*, and only for units that have a static θ. A fingerprint mismatch and a drift freeze are never overridden by `tighter_of` or `certified_preferred`. `legacy_shadow` serves the static θ in every case except a drift freeze.

Alert on the rates of `jev.escalation.reason = uncertified | drift_freeze` and on `jev.policy.source`. A jump usually means a rubric was edited, a tier was renamed or a certificate expired.
