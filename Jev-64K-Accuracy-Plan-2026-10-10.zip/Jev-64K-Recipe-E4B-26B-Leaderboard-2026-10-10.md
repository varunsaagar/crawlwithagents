# Jev 64K recipe: Gemma-4 E4B and 26B-A4B, leaderboard-inspired (2026-10-10)

Builds on (not repeated here): `Strands-Decider-to-Gemma26B-Jev-Approach-2026-10-10.md` + `gemma26b-jev-recipe/`,
`Jev-64K-LongContext-Base-Model-Selection-2026-10-10.md`, `Jev-E4B-Inference-Throughput-Plan-2026-10-08.md`,
`GEV-LongContext-Choice-FineTune-Strategy-2026-10-07.md`, `E4B-Jev-Fast-Long-Context-Implementation-Guide-2026-10-07.md`,
`Perplexity-Decider-Learnings-For-E4B-2026-10-07.md`, `Gemma-31B-Jev-FineTune-Calibration-Engine-2026-10-08.md`.

**Assumptions.** "1,800" = one **H800 80 GB** (same FP8/BF16 compute and HBM size as H100 SXM; only NVLink is cut, which
does not matter on one GPU). H100 and H200 numbers are given too. "3,250 concurrency" = 3,250 Jev decisions in flight.
The alternative readings (3,250 RPS, or 3,250 across a fleet) are sized in §6. (Side note: Hard-Decisions runs
1,800 problems per task. If "1,800" meant that benchmark, the leaderboard section §2 covers it.) Every speed and memory number is an
**estimate** from formulas in `jev-64k-recipe/concurrency_calc.py`. None is measured.

## 0. Direct answers

| Question | Answer |
|---|---|
| Which model? | **Both, in tiers.** **Gemma-4-26B-A4B** is the 64K accuracy tier: published strands-decider Gemma soup 207/231 JevBench, RULER 97.3@32K. **E4B** is the fast tier and the one that gets near 3,250 in flight (smaller KV per seq at ≤32K, 187/231 published). Gemma-4-31B stays teacher + escalation. |
| 3,250 concurrent at **64K, one request = one 64K sequence**, 1×80 GB? | **No.** Max ≈ 46 (26B, BF16 KV) / 93 (FP8 KV) / 186 (INT4 KV); E4B 53 / 107 / 215. 3,250 would need ~1.4 TB of FP8 KV, i.e. **31–35 GPUs** on memory alone. Compute is worse: 0.6–0.7 req/s per GPU at 64K, so 3,250 in flight means a queue of **~75–90 minutes** (Little's law). |
| Under which design is it achievable on one GPU? | **Doc-once + shortlisting.** (1) INDEX shortlists to ≤6–8K, (2) many questions share one document prefill (strands doc-once, Q≈32), (3) FP8 KV, (4) prefix cache for repeated documents. E4B @6K FP8: 971 sequences, **~6,400 decisions in flight**, ~314 decisions/s, so 3,250 in flight drains in **~10 s**. 26B @6K FP8: ~1,280 decisions in flight (needs **3 GPUs** for 3,250), ~318 decisions/s. |
| Key insight | Jev decodes ~0 tokens. KV is only held while a sequence is being prefilled or kept as a cached prefix. So "3,250 in flight" is mostly **queue depth**, and what limits it is prefill throughput, not memory. Size by decisions/s × target latency. |
| Leaderboard target (TARGET, not a result) | 26B-A4B 64K Jev: JevBench **207–215/231**, Brier ≤0.16, ECE ≤0.03 per length bucket. E4B 64K: **187–195/231**. On Hard-Decisions (ProofWriter, 1,800 items/task) aim above Kev-9B (58.6/63.8) and GPT-6 Luna (64.1/65.0). Hosted Jev 1.13 (83.8/89.3) is the ceiling to chase, not an expected outcome. |

## 1. Why these models (short)
- Gemma-4 layers are 5 sliding (window 1024; 512 on E-models) to 1 global. KV grows only on global layers. On 26B the global layers also store K=V once. E4B: 18 of 42 layers reuse KV.
- Native context 128K (E4B) / 256K (26B): **no RoPE extension needed for 64K**. Training only teaches the pointer head + LoRA to use long context.
- Licence: Gemma terms allow commercial fine-tuning. No Qwen bases or Qwen-teacher rows (the published strands Gemma soup used Qwen3.5-4B targets, so we retrain).

## 2. Leaderboard: what the top entries do

| Entry | Base | Score (source) | Techniques worth copying |
|---|---|---|---|
| Jev 1.13 (TypeSafe, hosted) | undisclosed | Hard-Decisions open 83.8% / closed 89.3% ([hard-decisions.anth.us/models](https://hard-decisions.anth.us/models)) | One parallel pass for all decisions in a request; calibrated typed outputs |
| GLiDE (Fastino, hosted) | undisclosed | 82.9 / 71.8 (Oct 2), 76.4 / 68.8 (rerun) (same page) | Extra compute only on uncertain decisions. This is our escalate-on-low-confidence tier. |
| strands-decider-26B-A4B-gemma4-v1 | Gemma-4-26B-A4B | JevBench 207/231, Brier 0.162, ECE 0.051, ~245 ms/q H100 (repo `evaluation/results.md`) | Pointer head, LoRA r16, KL to 31B teacher where teacher = gold, KL 0.3 anchor to previous release, **3-seed soup**, per-kind temperature, balanced 247K mix, code-computed gold for rule rows |
| strands-decider 12B / E4B gemma4 v1 | Gemma-4 | 200 / 187 of 231 (repo) | Same recipe; shows the size ladder |
| strands-decider-2B v1 (Qwen) | Qwen3.5 (banned) | 180/231 soup; seeds 177–184 (repo) | Soup ≥ mean of seeds; reference only |
| pplx-decider-v1-27b / AutoJev | Qwen3.8-27B (banned) | Perplexity panel (display-only on BenchLM) | Full SFT; reference only ([HF](https://huggingface.co/perplexity-ai/pplx-decider-v1-27b)) |
| Kev-9B / 4B | Qwen3.5 (banned) | 58.6 / 53.6 open-world (Hard-Decisions) | Pointer head + r16 LoRA on a frozen base. Frozen base alone underperforms. |
| GLiNER2.5-Decide, Laya | DeBERTa / ModernBERT encoders | 32.8–55.6 (Hard-Decisions) | Encoders without instruction following fail. Keep a decoder base. |

**What we take from them:** decoder base + pointer head; teacher distillation filtered by gold; anchor KL; seed soup;
per-kind temperature; balanced decision-type mix; one pass for many questions; escalate when uncertain.
**Long-context additions (ours):** progressive 8K→32K→64K curriculum, 25% short rows replayed, evidence placed at
start/middle/end, same-domain distractors, length-bucketed calibration.

## 3. Context-building recipe (data)
1. **Sources:** current Jev short mix (strands-style balanced mix, without Qwen-labelled files and without non-commercial datasets), long-native sets (multi-doc QA in the style of 2Wiki/MuSiQue, ContractNLI full contracts, code repos, policy + case files written by Gemma-4-31B with **gold computed by code**).
2. **Long synthesis 8K→64K** (`build_long_context.py`): pad each short row with **same-source distractor documents** up to a target drawn uniformly inside each bucket (≤8K, 8–32K, 32–64K); insert the evidence doc at **start/middle/end** (even thirds); 10% multi-evidence rows (2–3 needles spread apart).
3. **Options / catalogs:** Choice rows expanded to **2–300 options** with hard negatives from the same source (near-duplicate names, sibling categories); options shuffled every epoch; Score rows keep the ordinal scale with reversal augmentation.
4. **Negatives:** "unknown" / not-in-doc rows (15%): evidence removed but distractors kept, so the model learns abstention at length.
5. **Teacher labels:** Gemma-4-31B (FP8, vLLM, prefix cache) scores every row's options. Keep its distribution as the KL target **only where its argmax = gold**; otherwise use gold one-hot. Keep track of where each label came from (`provenance`).
6. **Bucket balancing:** stage-3 mix ≈ 25% ≤8K, 35% 8–32K, 40% 32–64K; each kind (Noul/Choice/Score) ≥20% per bucket.
7. **Dedup + contamination:** sha1 on (text, question, position, length band); 13-gram shingle overlap vs JevBench and Hard-Decisions items → drop; held-out long eval built from never-trained sources.

## 4. Fine-tuning recipe (both models; configs in `jev-64k-recipe/configs/`)

| Stage | Max len | Data | LR (LoRA / head) | Epochs | Grad accum (26B / E4B) | Notes |
|---|---|---|---|---|---|---|
| 1 | 8K | full short mix + ≤8K long | 1e-4 / 1e-3 | 2 | 32 / 16 | fresh pointer head, KL anchor to base (or last Jev release) 0.3 |
| 2 | 32K | 25% short + ≤32K long | 5e-5 / 1e-3 | 1 | 32 / 16 | init from stage 1 |
| 3 | 64K | 25% short + ≤64K long | 3e-5 / 1e-3 | 1 | 32 / 16 | activation offload on; init from stage 2 |
| Soup | – | – | – | – | – | seeds 0,1,2 → mean LoRA delta (rank 48) + stacked heads |
| Calibrate | – | held-out per bucket | – | – | – | temperature per kind × length bucket; keep only if NLL improves; then LTT thresholds per group × bucket |

Common: LoRA r16 α32 on q,k,v,o,gate,up,down. **26B: experts and router frozen** (strands limitation). Pointer head dim 256,
dropout 0.05; ordinal smoothing 0.1; forward KL; teacher weight 1.0; FA3 + Liger + gradient checkpointing.
**Distillation chain:** 31B (teacher) → 26B-A4B (stage targets) → E4B: the E4B run uses the **26B soup's** calibrated letter
distributions as an extra KL target (T_kd=2, α=0.6, as in the earlier E4B plan) on top of 31B-where-gold.

**Patches needed vs upstream strands-decider** (not in its schema today, must be added or dropped): `num_slots: 300` (upstream default 24),
`activation_offload`, `liger_kernels`, `attn_impl`, `position_jitter`, `seeds` list, `short_mix_fraction`. All configs parse as valid YAML.

### Training memory on 1×80 GB (estimates; smoke-test each with `--max_steps 20`)
| Model (BF16 weights) | 8K | 32K | 64K | 64K with activation offload |
|---|---|---|---|---|
| 26B-A4B (51.6 GB) | ~55 GB (repo measured 53 GB @4K) | ~62–68 GB | ~68–78 GB (tight) | ~62–70 GB |
| E4B (~16 GB) | ~20 GB | ~28–32 GB | ~38–46 GB | ~30–36 GB |
The pointer head reads only option positions, so there is no full-vocabulary logits tensor at 64K. That is the main memory saving over LM-loss SFT.
If 26B@64K OOMs: offload activations, cut LoRA targets to attention only, or use H200.

## 5. Serving design to maximise concurrency
1. **Doc-once:** one prefill of the document; all questions (Q≈16–64) appended with per-question masks (strands multi-question serving). Decisions = docs × Q.
2. **INDEX shortlisting to 4–8K** before Jev (largest lever: about 8–13× less prefill than 64K).
3. **Prefix cache** (vLLM APC / strands server cache): system prompt + catalog first, document next, questions last.
4. **FP8 KV** (re-fit temperature after switching; INT4 KV only if calibration error stays ≤0.03 in every bucket).
5. **KV offload** (LMCache CPU/NVMe) for hot 64K documents re-asked later. It helps the hit rate, not the peak in-flight count.
6. **Batching:** chunked prefill 8–16K tokens; one model copy per GPU (no tensor parallelism); per-bucket queues so 64K jobs don't block ≤8K ones.

## 6. Concurrency / throughput math (calculator output, H800 = H100; MFU 25%, Q/doc 32)
Formulas: `KV/seq = Σ_sliding min(n,win)·kvh·hd·2·b + Σ_global n·kvh·hd·(1 if K=V else 2)·b`;
`maxSeq = (80·0.92 − weights_FP8 − 6 GB act) / KV`; `prefill = (2·N_active·n + n_global·2·n²·h·d)/(989 TF FP8-dense×2 · MFU)`;
`in-flight latency ≈ in_flight / throughput` (Little's law).

| Model | Ctx | KV (FP8) | Max seqs FP8 | Prefill s | Req/s/GPU | Decisions/s (Q=32) | Doc-once in-flight | GPUs for 3,250 seqs | GPUs for 3,250 RPS, no sharing |
|---|---|---|---|---|---|---|---|---|---|
| 26B-A4B | 64K | 0.44 GB | 93 | 1.72 | 0.58 | 18.6 | 992 | 35 | ~5,600 |
| 26B-A4B | 32K | 0.27 | 150 | 0.68 | 1.47 | 47 | 1,120 | 22 | ~2,200 |
| 26B-A4B | 6K | 0.14 | 301 | 0.10 | 9.9 | 318 | 1,280 | 11 | ~330 |
| E4B | 64K | 0.55 | 107 | 1.34 | 0.74 | 23.8 | 2,400 | 31 | ~4,400 |
| E4B | 32K | 0.28 | 211 | 0.60 | 1.66 | 53 | 3,680 | 16 | ~1,950 |
| E4B | 6K | 0.06 | 971 | 0.10 | 9.8 | 314 | 6,368 | 4 | ~330 |
H200 141 GB roughly doubles max sequences (26B 64K FP8: 220; E4B 6K FP8: 1,894); prefill speed is about the same.
**Readings:** (a) 3,250 in flight per GPU: only E4B with ≤32K + doc-once, or E4B/26B with ≤8K + doc-once. (b) 3,250 **decisions/s**: ~10 GPUs at 6K with Q=32 (E4B or 26B), ~140–175 GPUs at 64K with Q=32, thousands without sharing. (c) 3,250 across a fleet: 4 E4B GPUs (6K, FP8 KV) or 11 26B GPUs. Prefix-cache hits on repeated documents cut these further (70% hit rate ≈ 3× fewer GPUs, per the throughput plan).

## 7. Eval gates (ship only if all pass)
- JevBench ≥ 207 (26B) / ≥ 187 (E4B) at window 4096, and on a 64K-padded JevBench variant drop ≤ 3 points.
- ECE ≤ 0.03 and Brier ≤ 0.17 **in every length bucket**; accuracy drop by evidence position (start/middle/end) ≤ 3 points.
- Short-context accuracy ≥ stage-1 − 1 point; RULER-style needle-in-catalog at 64K ≥ 90%.
- Hard-Decisions run (open/closed world, 1,800 items each) reported, beating Kev-9B and GPT-6 Luna.
- Serving: measured p50/p95 at 6K/32K/64K with `inference-bench`; LTT certificates per group × bucket; uncertified buckets go to the LLM.

## 8. Timeline / GPU-hours (estimates, H100/H800)
| Step | 26B-A4B | E4B |
|---|---|---|
| Data build + 31B teacher labelling (~3B tokens) | ~110 GPU-h (shared) | shared |
| Stage 1–3 per seed (~3.2B training tokens) | ~90 GPU-h | ~70 GPU-h |
| 3 seeds + soup + calibration | ~280 GPU-h | ~220 GPU-h |
| Evals + bench | ~20 GPU-h | ~15 GPU-h |
Total ≈ **650 GPU-h**. Wall clock about 2–3 weeks on 8 GPUs, including a 1-week data build.

## 9. Uncertain / to verify
- All throughput figures assume 25% MFU for prefill; MoE prefill MFU on 26B could be lower. Benchmark with `inference-bench` before sizing.
- E4B KV-owning layer split (20 sliding / 4 global) is inferred from `num_kv_shared_layers=18`; check `config.json` layer types.
- strands-decider support for 300 slots, activation offload and FA3 at 64K is unverified; 26B@64K training memory is the riskiest number.
- INT4 KV effect on calibration is unknown. A longer JevBench variant is not public; we build the 64K-padded one ourselves.
- Hard-Decisions is ProofWriter-only (synthetic). It shows reasoning depth, not domain accuracy.
