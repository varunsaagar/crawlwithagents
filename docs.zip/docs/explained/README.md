# jevjudge visual docs

Open `index.html`.

| file | what it is |
|---|---|
| `jevjudge-explained.html` | the animated walkthrough, 14 stages, 21 figures (built by `build_walkthrough.py`) |
| `arch/*.html` | explorable Archify diagrams: architecture, dataflow, certificate lifecycle (JSON sources beside them) |
| `figures/*.svg` + `.png` | static figures for decks: pipeline, one-pager, one-vs-stack, lifecycle (`node figures/export_png.js`) |
| `FACTS.md` | the only source of numbers for all of the above |

## Build

```bash
python3 build_walkthrough.py   # -> jevjudge-explained.html
python3 build_index.py         # -> index.html
cd figures && node export_png.js   # SVG -> 2x PNG
# diagrams: node ~/.claude/skills/archify/bin/archify.mjs deliver <type> arch/<name>.<type>.json arch/<name>.html --quality showcase
```

`docshell.py`, `shell.css` and `assets/` are copied unchanged from `kairos/docs`, so these pages are the same object as
the Kairos walkthroughs. Shapes marked "illustrative" on a figure are not measurements. Calibration v3 is shown as in
progress until its holdout report lands; update `FACTS.md` and rebuild when it does.
